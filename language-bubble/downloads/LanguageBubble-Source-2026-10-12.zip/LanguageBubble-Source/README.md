# Language Bubble · macOS 源码交接

这是 2026-10-12 的当前工作区源码快照，包含尚未提交的产品修改。用于在另一台 Mac 上用 Codex 阅读、修改、编译和运行；不是已公证的安装包。

## 用 Codex 接着开发

1. 解压整个 ZIP，保留目录结构。
2. 在 Codex 桌面端添加本地项目，选择解压后的 `LanguageBubble-Source` 文件夹；工作环境选择本机。也可以在该目录运行 Codex CLI。
3. 把下面这段话发给 Codex：

> 这是 Language Bubble 的原生 macOS 源码。先阅读 README.md 和 docs/CODEX_HANDOFF.md，检查本机 Xcode、Python 和 uv。请按说明生成独立的 Mock 测试配置、安装依赖、构建并打开 build/Language Bubble.app，然后协助我继续修改。保留 SwiftUI/AppKit 架构，不改写成网页。使用我自己的配置，不连接原作者的服务或账号；先不要启用真实模型。

Codex 负责修改代码、调用构建工具；应用运行在 macOS 中。原生界面不能直接在浏览器或普通 Linux 云环境中运行。Codex 的本地文件/项目用法见 [OpenAI 官方说明](https://learn.chatgpt.com/docs/quickstart)。

## 环境

- 一台 Mac。App 的部署目标为 macOS 14+；开发机器还需满足所用 Xcode 的系统要求。
- 完整 Xcode：本次验证使用 Xcode 26.4.1；仅安装 Command Line Tools 不够。先打开 Xcode 完成首次组件安装，再用 `xcodebuild -version` 检查。
- Python 3.11+ 和 uv（运行本地服务时需要）。
- 首次安装依赖需要联网：ShadKit 由 Xcode 从 GitHub 获取，固定版本在 `Package.resolved`；Python 依赖锁定在 `server/uv.lock`。
- 不需要原作者的 Apple 账号。macOS 本地开发可以 ad hoc 签名；正式向用户分发另需发布签名和公证。

## 第一次启动

以下命令均从解压后的项目根目录执行。脚本只在没有本地配置时生成新的随机测试令牌，不输出令牌，不覆盖已有配置；默认 `AI_MODE=mock`，无需模型 API Key。

```sh
python3 scripts/setup-local-demo.py
uv sync --project server --frozen
python3 scripts/generate_project.py
bash scripts/build-mac.sh
```

在一个终端中启动服务，保留终端运行：

```sh
bash scripts/run-beta.sh
```

然后在 Finder 打开 `build/Language Bubble.app`。在应用的账号/设置中进入“连接 → 第一台设备”，使用预填的本机测试令牌点“创建测试账号”。服务地址为 `http://127.0.0.1:8788`，指向使用者自己的 Mac。

如果只修改学习页面布局，可直接构建并打开，查看“学习”中的 Photography 和 The space 内置文章；查询、收集和同步流程需要启动本地服务并连接测试账号。

如果已有 `.env` 或 `BetaConnection.json`，初始化脚本会保留它们。请检查已有配置是否成对匹配，勿删除或覆盖已有账号配置。Debug 构建会带上本地测试引导令牌，只用于自己的机器；不要把生成后的 Debug `.app` 再发给他人。

系统选区取词和截图功能需要使用者自行在 macOS 中授权辅助功能/屏幕录制。普通文章阅读不依赖这些权限。

## 本包能体验什么

- SwiftUI/AppKit 原生窗口、收集/学习页、拼贴、选区快捷菜单、引用交互、文章与问答界面。
- `ArticleGenerationPreview` 是内存中的确定性演示：文章生成、步骤动画、引用修改和练习并不等于真实模型推理，重启后相关演示状态不保留。
- `AI_MODE=mock` 的查询由本机 Python 服务提供示例回复。真实 AI 需使用者在自己的 `server/.env` 配置服务提供方、模型和 API Key，并主动切到 `live`；Codex 登录不会自动给这个产品提供模型额度。
- 收集列表从新账号开始，不包含原作者的个人记录、截图、收藏或同步数据库。产品内置资源/设计素材已保留。
- 可选 ECDICT 词典数据库未随包分发。需要时参见 `docs/WORD_DICTIONARY.md` 与 `scripts/import_dictionary.py`。
- 内嵌 3D 相机和外部参考链接需要网络；外部服务可用性影响相应内容。

## 代码位置

| 内容 | 文件/目录 |
| --- | --- |
| macOS 应用入口、设置 | `MacApp/LanguageBubbleApp.swift` |
| 学习卡片、文章、composer、步骤条、问答 | `MacApp/BubbleArticleViews.swift` |
| 选区快捷菜单、翻译浮层、取词 | `MacApp/MacCaptureController.swift` |
| 收集页和词条详情 | `MacApp/BubbleRecordWorkspace.swift` |
| 文章演示状态机 | `Shared/ArticleGenerationPreview.swift` |
| 本地状态、同步、模型客户端 | `Client/`、`Shared/` |
| 本机 Python 服务 | `server/` |
| 内置图片、字体、3D 页面 | `Resources/` |
| 设计源素材和交互说明 | `design/`、`docs/` |
| Xcode 项目生成与 macOS 构建 | `scripts/generate_project.py`、`scripts/build-mac.sh` |

保留了共用的 iOS/扩展代码以保证 Xcode 工程完整，本次交接以 `LanguageBubbleMac` scheme 为准。历史文档中的个人机器路径、验收日志和已连接账号描述只反映原环境，不代表新机器已配置；以本文件为首次运行入口。

## 验证与打包范围

本次交接验证（2026-10-12）：从 ZIP 独立解压，生成新的 Mock 配置并按锁文件安装依赖；macOS arm64/x86_64 构建与签名完整性检查通过，Swift 核心 150 项测试、Python 后端 73 项测试通过。没有在另一台实体 Mac 上验收，未进行正式发布公证。

```sh
swift test --scratch-path /private/tmp/language-bubble-core-build
cd server
uv run python -m unittest discover -s tests
```

`Tests/UITests` 是历史 iOS 集成测试，需要独立设备/模拟器和配对配置，不是首次 macOS 构建的前置步骤。真实模型 smoke 脚本会调用模型，不要在 Mock 验证中运行。

包内包括应用源码、Xcode 工程、资源、依赖锁、测试、后端源码和设计说明；不包括 `.git`、Codex 聊天/配置、密钥、`.env`、`BetaConnection.json`、本地数据库、虚拟环境、编译产物和历史 QA 应用。无需原 Codex 聊天也可以继续开发。`SOURCE_MANIFEST.sha256` 记录每个分发文件的校验值。

第三方字体、库和设计参考保留了现有来源/许可说明（如 `Resources/ThirdPartyLicenses.txt`、`Resources/Fonts/`）；此交接不改变它们原有的使用范围。
