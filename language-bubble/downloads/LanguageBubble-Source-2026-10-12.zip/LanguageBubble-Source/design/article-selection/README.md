# Article selection actions

Source: [Figma 1608:979](https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1608-979), including selection action 1597:2144 and composer 1603:916.

The selection toolbar contains only 引用. Its capsule is 84 × 38 design points: a 20-point Fluent Text Quote icon slot, 4-point gap, 16-point text, 12/16-point leading/trailing padding, a 0.5-point border at 15% black, and a zero-offset shadow (Figma blur 12, native radius 6, 12% black). Reader scaling applies to its geometry.

引用 attaches the original selection to the main conversation composer and focuses the existing draft without modifying it. The composer has a 28-point corner radius, 12-point padding, a 36-point quote pill at 5% black, and 16-point spacing before the input row. Its quote label uses 15-point system text and truncates to one line. Original Figma vectors are preserved in ArticleQuoteAction, ArticleQuoteOpening and ArticleQuoteDismiss; glyph geometry is 12 × 11, 10 × 9 and 8 × 8 inside the design's icon slots. ArticleSendArrow is reused.

Removing a quote leaves the instruction draft intact. A new quote replaces the attachment. Sending from the main composer passes the quoted target and UTF-16 range to the existing local generation workflow, clears the attachment and draft only after acceptance, and records the quote and instruction in the conversation. Text and image edits share this path. The floating regeneration action and its inline composer have been removed. Stale or invalid references cannot change other content.

Conversation messages use a regular vertical stack so native selectable text keeps stable measurements as the quote attachment changes the composer height.

While revising text, both native selection and attributed selection backgrounds are cleared. The existing ArticleProgressShimmer luminance mask runs over TextKit selection rectangles, so only selected glyphs fade, including selections that wrap across lines. It shares the step labels' two-second period and 168-point sweep. Reduce Motion keeps the text static. Completion and cancellation remove the mask without changing surrounding text.
