/**
 * createVariableCollection
 *
 * Creates a new Figma variable collection with the specified name and modes.
 * If `modeNames` has more than one entry, the first mode is renamed from
 * Figma's default "Mode 1" to the first name, and additional modes are added.
 *
 * @param {string} name - The display name of the collection (e.g. "Color", "Spacing").
 * @param {string[]} modeNames - Ordered list of mode names (e.g. ["Light", "Dark"] or ["Value"]).
 * @returns {Promise<{
 *   collection: VariableCollection,
 *   modeIds: Record<string, string>
 * }>}
 *   `modeIds` maps each mode name to its modeId string.
 */
async function createVariableCollection(name, modeNames) {
  if (!modeNames || modeNames.length === 0) {
    throw new Error('createVariableCollection: modeNames must have at least one entry.')
  }

  // Create the collection — Figma always creates it with one mode named "Mode 1".
  const collection = figma.variables.createVariableCollection(name)

  // modeIds accumulator
  const modeIds = {}

  // Rename the default first mode
  const defaultMode = collection.modes[0]
  collection.renameMode(defaultMode.modeId, modeNames[0])
  modeIds[modeNames[0]] = defaultMode.modeId

  // Add additional modes
  for (let i = 1; i < modeNames.length; i++) {
    const newModeId = collection.addMode(modeNames[i])
    modeIds[modeNames[i]] = newModeId
  }

  return { collection, modeIds }
}

/**
 * createComponentWithVariants
 *
 * Creates a component set by generating all combinations of `variantAxes`,
 * building one Figma component per combination, then calling
 * `figma.combineAsVariants` to produce the component set. After combining,
 * the variants are repositioned into a grid so they don't all stack at (0, 0).
 *
 * @param {{
 *   name: string,
 *   description?: string,
 *   variantAxes: Record<string, string[]>,
 *   baseProps: {
 *     width: number,
 *     height: number,
 *     fills?: Paint[],
 *     padding?: {top?: number, bottom?: number, left?: number, right?: number},
 *     radius?: number,
 *     layoutMode?: 'HORIZONTAL' | 'VERTICAL' | 'NONE',
 *     itemSpacing?: number
 *   },
 *   page: PageNode
 * }} config
 *   - `name`: Component set name (e.g. "Button").
 *   - `description`: Optional human-readable purpose and usage guidance.
 *   - `variantAxes`: Each key is a variant property name; each value is an array of
 *     allowed values. All combinations are generated (Cartesian product).
 *     Example: { Size: ['Small', 'Medium', 'Large'], Style: ['Primary', 'Ghost'] }
 *     produces 6 variants.
 *   - `baseProps`: Visual properties applied to every variant.
 *   - `page`: The PageNode to create components on (must be set as current page by caller).
 * @returns {Promise<{
 *   componentSet: ComponentSetNode,
 *   variants: ComponentNode[]
 * }>}
 */
async function createComponentWithVariants(config) {
  const { name, variantAxes, baseProps, page } = config

  // Ensure we are on the correct page
  // Caller sets page once for the entire construction operation.

  // Compute Cartesian product of variant axes
  const axisNames = Object.keys(variantAxes)
  const axisValues = axisNames.map((k) => variantAxes[k])
  const combinations = cartesianProduct(axisValues)

  // Build one component per combination
  const components = []
  const propertyKeys = []
  for (const combo of combinations) {
    const comp = figma.createComponent()

    // Name: "Property=Value, Property=Value, ..."
    comp.name = axisNames.map((ax, i) => `${ax}=${combo[i]}`).join(', ')

    // Base geometry
    comp.resize(baseProps.width, baseProps.height)

    // Fills
    if (baseProps.fills !== undefined) {
      comp.fills = baseProps.fills
    } else {
      comp.fills = [{ type: 'SOLID', color: { r: 0.9, g: 0.9, b: 0.9 } }]
    }

    // Corner radius
    if (baseProps.radius !== undefined) {
      comp.cornerRadius = baseProps.radius
    }

    // Auto-layout
    if (baseProps.layoutMode && baseProps.layoutMode !== 'NONE') {
      comp.layoutMode = baseProps.layoutMode
      comp.primaryAxisAlignItems = 'CENTER'
      comp.counterAxisAlignItems = 'CENTER'
      if (baseProps.itemSpacing !== undefined) {
        comp.itemSpacing = baseProps.itemSpacing
      }
    }

    // Padding
    if (baseProps.padding) {
      comp.paddingTop = baseProps.padding.top ?? 0
      comp.paddingBottom = baseProps.padding.bottom ?? 0
      comp.paddingLeft = baseProps.padding.left ?? 0
      comp.paddingRight = baseProps.padding.right ?? 0
    }

    const keys = {}
    for (const [action, id] of Object.entries(config.iconComponents ?? {})) {
      keys[action] = comp.addComponentProperty(action + ' icon', 'INSTANCE_SWAP', id)
    }
    propertyKeys.push(keys)
    page.appendChild(comp)
    components.push(comp)
  }

  // Combine into a component set
  const componentSet = figma.combineAsVariants(components, page)
  componentSet.name = name
  if (config.description) {
    componentSet.description = config.description
  }

  // Grid layout — variants stack at (0, 0) after combineAsVariants; reposition them.
  const GRID_GAP = 16
  const cols = Math.max(1, axisValues[axisValues.length - 1]?.length ?? 1)
  const variantWidth = baseProps.width
  const variantHeight = baseProps.height

  componentSet.children.forEach((variant, idx) => {
    const col = idx % cols
    const row = Math.floor(idx / cols)
    variant.x = col * (variantWidth + GRID_GAP)
    variant.y = row * (variantHeight + GRID_GAP)
  })

  // Resize component set to wrap its children with padding
  const totalCols = Math.min(cols, combinations.length)
  const totalRows = Math.ceil(combinations.length / cols)
  const PADDING = 40
  componentSet.resize(
    totalCols * variantWidth + (totalCols - 1) * GRID_GAP + PADDING * 2,
    totalRows * variantHeight + (totalRows - 1) * GRID_GAP + PADDING * 2,
  )

  // Position component set at a safe canvas location
  componentSet.x = 480
  componentSet.y = 80

  return { componentSet, variants: componentSet.children, propertyKeys }
}

/**
 * Computes the Cartesian product of multiple arrays.
 * cartesianProduct([[A, B], [1, 2]]) → [[A,1], [A,2], [B,1], [B,2]]
 *
 * @param {Array<string[]>} arrays
 * @returns {string[][]}
 */
function cartesianProduct(arrays) {
  return arrays.reduce(
    (acc, curr) => acc.flatMap((combo) => curr.map((val) => [...combo, val])),
    [[]],
  )
}

const page = await figma.getNodeByIdAsync('1437:161');
await figma.setCurrentPageAsync(page);
const name = 'Warm shortcut · 可编辑主组件';
const existing = page.findAllWithCriteria({types:['COMPONENT_SET']}).find(n => n.name === name);
if (existing) return {existingComponentSetId:existing.id, status:'Already exists; inspect before editing'};
const right = Math.max(0, ...page.children.map(n => n.x + n.width)) + 160;
const top = 22545;
await Promise.all([
  figma.loadFontAsync({family:'SF Pro Display',style:'Bold'}),
  figma.loadFontAsync({family:'SF Pro Display',style:'Regular'}),
  figma.loadFontAsync({family:'SF Pro Display',style:'Medium'})
]);
const rgb = hex => ({r:parseInt(hex.slice(0,2),16)/255,g:parseInt(hex.slice(2,4),16)/255,b:parseInt(hex.slice(4,6),16)/255});
const palette = {body:'EC840E',well:'F58B16',highlight:'FFBA42',rim:'F8B659',activeIcon:'FFF9E8',inactiveIcon:'FFBE78'};
const colors = Object.fromEntries(Object.entries(palette).map(([key,hex])=>[key,rgb(hex)]));
const collections = await figma.variables.getLocalVariableCollectionsAsync();
const collectionName = 'Warm shortcut / 编辑颜色';
const priorCollection = collections.find(c=>c.name===collectionName);
const collection = priorCollection ?? (await createVariableCollection(collectionName,['Value'])).collection;
const mode = collection.modes[0].modeId;
const localVariables = await figma.variables.getLocalVariablesAsync();
const variables = {};
const labels = {body:'底色',well:'选中区域',highlight:'内侧高光',rim:'边缘',activeIcon:'选中图标',inactiveIcon:'未选中图标'};
for (const key of Object.keys(palette)) {
  const tokenName = key + ' · ' + labels[key];
  const v = localVariables.find(v=>v.variableCollectionId===collection.id && v.name===tokenName) ?? figma.variables.createVariable(tokenName,collection,'COLOR');
  v.scopes = key==='rim' ? ['STROKE_COLOR'] : key.includes('Icon') ? ['SHAPE_FILL','TEXT_FILL','STROKE_COLOR'] : ['SHAPE_FILL','FRAME_FILL','EFFECT_COLOR'];
  v.setValueForMode(mode,{...colors[key],a:1});
  v.setVariableCodeSyntax('iOS','SelectionShortcutPalette.'+key);
  v.description = '直接对应产品配色；修改此值会同步两种选中状态。';
  variables[key] = v;
}
const bound = key => figma.variables.setBoundVariableForPaint({type:'SOLID',color:colors[key]},'color',variables[key]);
const stop = (position,key) => ({position,color:{...colors[key],a:1},boundVariables:{color:{type:'VARIABLE_ALIAS',id:variables[key].id}}});
const effectStyles = await figma.getLocalEffectStylesAsync();
function effectStyle(name,effects) {
  const style=effectStyles.find(s=>s.name===name) ?? figma.createEffectStyle();
  style.name=name; style.effects=effects; return style;
}
const shadow = (type,color,alpha,x,y,radius) => ({type,color:{...rgb(color),a:alpha},offset:{x,y},radius,visible:true,blendMode:'NORMAL'});
const floating = effectStyle('Warm shortcut / 外部柔影',[shadow('DROP_SHADOW','532E05',.14,0,6,13)]);
const inset = effectStyle('Warm shortcut / 内阴影',[
  shadow('INNER_SHADOW','7B460B',.32*.66,1,4,8),
  shadow('INNER_SHADOW','FFD285',.8*.66,-1,-4,8)
]);
const textStyles=await figma.getLocalTextStylesAsync();
const glyphStyle=textStyles.find(s=>s.name==='Warm shortcut / T') ?? figma.createTextStyle();
glyphStyle.name='Warm shortcut / T'; glyphStyle.fontName={family:'SF Pro Display',style:'Bold'}; glyphStyle.fontSize=30; glyphStyle.lineHeight={unit:'PIXELS',value:36};

const R=99.6/(Math.PI/5), A=-151*Math.PI/180, B=-115*Math.PI/180;
const halfRun=((99.6+54)/2-10-43)/(2*R);
const point=a=>({x:10-R*Math.cos(a),y:215+R*Math.sin(a)});
const anchors={Translate:point(B-halfRun),Polish:point(A+halfRun)};
function curve(cx,cy,r,a,b) {
  const h=4/3*Math.tan((b-a)/4);
  const p0={x:220-cx-r*Math.cos(a),y:cy+r*Math.sin(a)};
  const p3={x:220-cx-r*Math.cos(b),y:cy+r*Math.sin(b)};
  return {p0,p1:{x:p0.x+r*h*Math.sin(a),y:p0.y+r*h*Math.cos(a)},p2:{x:p3.x-r*h*Math.sin(b),y:p3.y-r*h*Math.cos(b)},p3};
}
function capsule(a,b,width) {
  const r=width/2;
  const at=t=>({x:210+R*Math.cos(t),y:215+R*Math.sin(t)});
  const s=at(a),e=at(b);
  return [curve(210,215,R+r,a,b),curve(e.x,e.y,r,b,b+Math.PI/2),curve(e.x,e.y,r,b+Math.PI/2,b+Math.PI),
    curve(210,215,R-r,b,a),curve(s.x,s.y,r,a+Math.PI,a+Math.PI*1.5),curve(s.x,s.y,r,a+Math.PI*1.5,a+Math.PI*2)];
}
function boundsOf(curves) {
  const points=[];
  for(const c of curves) for(let i=0;i<=100;i++) {
    const t=i/100,u=1-t;
    points.push({x:u*u*u*c.p0.x+3*u*u*t*c.p1.x+3*u*t*t*c.p2.x+t*t*t*c.p3.x,y:u*u*u*c.p0.y+3*u*u*t*c.p1.y+3*u*t*t*c.p2.y+t*t*t*c.p3.y});
  }
  return {x:Math.min(...points.map(p=>p.x)),y:Math.min(...points.map(p=>p.y))};
}
async function vector(parent,name,curves) {
  const origin=boundsOf(curves),n=figma.createVector(); n.name=name;
  const vertices=curves.map(c=>({x:c.p0.x-origin.x,y:c.p0.y-origin.y,handleMirroring:'ANGLE'}));
  const segments=curves.map((c,i)=>({start:i,end:(i+1)%curves.length,tangentStart:{x:c.p1.x-c.p0.x,y:c.p1.y-c.p0.y},tangentEnd:{x:c.p2.x-c.p3.x,y:c.p2.y-c.p3.y}}));
  await n.setVectorNetworkAsync({vertices,segments,regions:[{windingRule:'NONZERO',loops:[segments.map((_,i)=>i)]}]});
  parent.appendChild(n); n.x=origin.x; n.y=origin.y; n.strokes=[]; return n;
}
function component(name,w,h) {const c=figma.createComponent();c.name=name;c.resize(w,h);c.fills=[];c.clipsContent=false;return c;}
const parts=figma.createAutoLayout('VERTICAL'); parts.name='Warm shortcut / 共享图形与图标';parts.fills=[];parts.itemSpacing=24;parts.x=right+1220;parts.y=top;
const shellMaster=component('Warm shortcut / Body · 6 个锚点',220,220);parts.appendChild(shellMaster);
const shell=await vector(shellMaster,'Body · 双击编辑 6 个锚点',capsule(A,B,54));
shell.fills=[{type:'GRADIENT_LINEAR',gradientTransform:[[.56,.58,-.07],[-.58,.56,.51]],gradientStops:[{position:0,color:{r:0,g:0,b:0,a:0}},{position:1,color:{r:0,g:0,b:0,a:.04}}]},bound('body')];
shell.strokes=[bound('rim')];shell.strokeWeight=1.25;shell.strokeAlign='INSIDE';
await shell.setEffectStyleIdAsync(floating.id);
shellMaster.description='共享主体：6 个平滑锚点，宽 54，弧长 153.6。双击 Body 编辑轮廓；修改会同步两个状态。边缘由单条内描边控制。';
const translateIcon=component('Warm shortcut / Icon / Translate',36,36);parts.appendChild(translateIcon);
const glyph=figma.createText();translateIcon.appendChild(glyph);await glyph.setTextStyleIdAsync(glyphStyle.id);glyph.characters='T';glyph.textAutoResize='NONE';glyph.resize(36,36);glyph.textAlignHorizontal='CENTER';glyph.textAlignVertical='CENTER';glyph.fills=[bound('activeIcon')];glyph.name='T · 可编辑文字';
const polishIcon=component('Warm shortcut / Icon / Polish',26,26);parts.appendChild(polishIcon);
const svg=figma.createNodeFromSvg('<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24"><path d="M3 18L17 4Q18 3 19 4L21 6Q22 7 21 8L7 22Q6 23 5 22L3 20Q2 19 3 18ZM14 7L18 11M3 8H7M5 6V10M10 3H12M11 2V4M18 17H22M20 15V19" fill="none" stroke="#FFF9E8" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round"/></svg>');
const wand=svg.findAllWithCriteria({types:['VECTOR']})[0];const wandPosition={x:wand.x,y:wand.y};polishIcon.appendChild(wand);wand.name='Wand · 单层路径';wand.x=wandPosition.x;wand.y=wandPosition.y;wand.strokes=[bound('activeIcon')];svg.remove();
translateIcon.description='T 保留为可编辑文字。';polishIcon.description='与产品一致的魔棒图标，单个可编辑矢量图层。';
const {componentSet,variants,propertyKeys}=await createComponentWithVariants({name,iconComponents:{Translate:translateIcon.id,Polish:polishIcon.id},description:'暖色划词快捷方式。Selected 切换 Translate / Polish。每个状态仅四层：Body、Inset、Translate、Polish。Body 主组件的轮廓修改同步两态；主体和选中区各 6 个平滑锚点。颜色请在 Warm shortcut / 编辑颜色 中修改 6 个值。内阴影与柔影是原生效果样式，可直接编辑。出场参考产品：顺时针扫出 0.42 s。',variantAxes:{Selected:['Translate','Polish']},baseProps:{width:220,height:220,fills:[]},page});
componentSet.x=right+650;componentSet.y=top;componentSet.fills=[];componentSet.clipsContent=false;
for(let index=0;index<variants.length;index++) {
  const c=variants[index],selected=index===0?'Translate':'Polish';c.x=24+index*244;c.y=24;c.clipsContent=false;
  const body=shellMaster.createInstance();c.appendChild(body);body.name='Body';body.x=0;body.y=0;
  const angle=selected==='Translate'?B-halfRun:A+halfRun;
  const well=await vector(c,'Inset · 6 个锚点',capsule(angle-halfRun,angle+halfRun,43));
  const center=point(angle),cx=center.x+2-well.x,cy=center.y+5-well.y;
  well.fills=[{type:'GRADIENT_RADIAL',gradientTransform:[[well.width/78,0,.5-cx/78],[0,well.height/78,.5-cy/78]],gradientStops:[stop(0,'well'),stop(.54,'well'),stop(1,'highlight')]}];await well.setEffectStyleIdAsync(inset.id);
  for(const [action,master] of [['Translate',translateIcon],['Polish',polishIcon]]) {
    const icon=master.createInstance();c.appendChild(icon);icon.name=action;icon.x=anchors[action].x-master.width/2;icon.y=anchors[action].y-master.height/2;
    icon.componentPropertyReferences={mainComponent:Object.keys(componentSet.componentPropertyDefinitions).find(key=>key.startsWith(action+' icon#'))};
    const child=icon.children[0];if(child.type==='TEXT') child.fills=[bound(selected===action?'activeIcon':'inactiveIcon')];else child.strokes=[bound(selected===action?'activeIcon':'inactiveIcon')];
  }
}
componentSet.resizeWithoutConstraints(512,268);
function text(parent,characters,size=14,style='Regular') {const t=figma.createText();t.fontName={family:'SF Pro Display',style};t.fontSize=size;t.characters=characters;t.fills=[{type:'SOLID',color:rgb('30302E')}];parent.appendChild(t);return t;}
const preview=figma.createAutoLayout('VERTICAL');preview.name='Warm shortcut · 两种状态预览';preview.x=right;preview.y=top;preview.paddingTop=28;preview.paddingBottom=28;preview.paddingLeft=32;preview.paddingRight=32;preview.itemSpacing=12;preview.fills=[{type:'SOLID',color:rgb('FFFFFF')}];preview.cornerRadius=20;preview.clipsContent=false;
text(preview,'Warm shortcut',24,'Medium');
text(preview,'Editable curves · Shared colors · Native inner shadows',14);
const row=figma.createAutoLayout('HORIZONTAL');row.name='States';row.fills=[];row.itemSpacing=32;preview.appendChild(row);
for(let i=0;i<2;i++){const column=figma.createAutoLayout('VERTICAL');column.name=i===0?'Translate selected':'Polish selected';column.fills=[];column.itemSpacing=0;column.counterAxisAlignItems='CENTER';row.appendChild(column);const instance=variants[i].createInstance();column.appendChild(instance);instance.name=column.name;text(column,column.name,14,'Medium');}
text(preview,'6 anchors per curve / 54 pt width / 20% shorter',13);
figma.currentPage.selection=[componentSet];figma.viewport.scrollAndZoomIntoView([preview,componentSet]);
const roots=[parts,componentSet,preview];
return {createdNodeIds:roots.flatMap(n=>[n.id,...n.findAll().map(c=>c.id)]),mutatedNodeIds:[],pageId:page.id,previewId:preview.id,componentSetId:componentSet.id,partsId:parts.id,collectionId:collection.id,modeId:mode,variables:Object.fromEntries(Object.entries(variables).map(([k,v])=>[k,{id:v.id,name:v.name,values:v.valuesByMode,scopes:v.scopes,codeSyntax:v.codeSyntax}])),styles:{floating:floating.id,inset:inset.id,glyph:glyphStyle.id},variants:variants.map(c=>({id:c.id,name:c.name,children:c.children.map(n=>({id:n.id,name:n.name,type:n.type})),width:c.width,height:c.height})),bodyAnchors:shell.vectorNetwork.vertices.length,insetAnchors:variants.map(c=>c.children.find(n=>n.type==='VECTOR').vectorNetwork.vertices.length),properties:componentSet.componentPropertyDefinitions,previewBounds:{x:preview.x,y:preview.y,w:preview.width,h:preview.height}};
