# Article generation steps

Source: [Vibe Coding — generation panel](https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1561-43124).

`ArticlePreviewProgress` in `MacApp/BubbleArticleViews.swift` is shared by the initial generation plan and the revised plan inserted into the conversation. Both now follow [Figma 1561:43128](https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1561-43128): a “思考了N秒” disclosure header above the five existing steps. No other production step-list implementation was found in macOS, iOS or shared views; the ordinary single-line chat/loading spinners and documentation prototypes are separate surfaces.

The header uses 16-point regular text, foreground650 (#4C4642), a 32-point minimum row, 6-point label/icon gap, 80% opacity and 12-point gap before the steps, scaled with the reader. The exact Fluent chevron exported from `I1617:828;12007:20859;76276:71382` has a 24×24 canvas (the Code Connect reference says 12, but the live instance and rendered design use 24). SwiftUI cannot use the React Fluent component, so its unchanged vector export is bundled as `ArticleThinkingChevron`; it points down when expanded and rotates right when collapsed. The whole header is clickable and keyboard-accessible.

The header remains visible while generating, stopped, awaiting outline approval, reviewing a revised plan, completed and regenerating. Collapsing hides the steps and closes any step editor; the independent Continue control remains available. Expansion preference belongs to the preview so it survives stage changes, navigation and relocation into a revised-plan message. The 200 ms disclosure animation is disabled with Reduce Motion.

`thinkingSeconds` counts successful active preview ticks, including plan adjustment, with one update per whole second. Approval waits, explicit Stop, navigation, the outgoing discard animation and later selection edits do not advance it. Completion freezes the value; regeneration starts a fresh counter once the old attempt is discarded. These are the existing local preview's processing durations, not AI service telemetry.

| Original asset | App asset | Placement at scale 1 |
| --- | --- | --- |
| `assets/thinking-chevron.svg` | `ArticleThinkingChevron` | 24 × 24, beside duration label |
| `assets/done-icon.svg` | `ArticleProgressDone` | 20 × 20, completed marker, 4 pt top inset |
| `assets/number-fill.svg` | `ArticleProgressNumberFill` | 16 × 16, centered in 20 pt marker |
| `assets/number-border.svg` | `ArticleProgressNumberBorder` | 16 × 16, over number fill |
| `assets/line.svg` | `ArticleProgressLine` | 24.5 × 0.5, rotated 90°, below marker |
| `assets/shimmer.svg` | `ArticleProgressShimmer` | 168 × 22 luminance mask, animated across active title |

`done-icon.svg` comes from the exact nested icon `I1561:43132;15032:108619;15017:95587`. `done.svg` is the original composite export retained for reference; using the isolated icon avoids distorting its circle when adapting the connector length. All SVGs are preserved unchanged and bundled as vector assets. Accent and active foreground colors retain the Figma token values in named color assets. Existing Inter typography and panel sizing are reused. Reduce Motion renders a steady active title.

Validation (2026-10-11): universal macOS build passed; all 40 `ArticleGenerationPreviewTests` passed, including active-time pause/resume, approval gating, revised-plan continuity and regeneration reset. Native checks covered the initial and revised-plan callsites, running/paused/waiting headers, completed expansion/collapse with the quiz retained, and the regeneration counter restarting at zero. The final post-regeneration UI capture was unavailable after the QA window closed; the 10-second replay total is covered by the model test. Screenshots are in `build/thinking-progress-waiting.png`, `build/thinking-progress-revised.png` and `build/thinking-progress-complete-collapsed.png`.
