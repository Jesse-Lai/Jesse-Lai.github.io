# 划词结果面板

2026-10-11，按用户提供的词典详情截图调整。

- `BubbleMacRecordDefinition` 从原有词典详情提取，记录详情与划词结果共用单词标题、发音、收藏和词性释义的内容与排版。
- 结果窗口使用平整背景；移除外层卡片、字典来源 / 许可证、复制释义、来源 App / URL、自动保存提示和截图失败提示。来源元数据仍保存，记录功能不变。
- 下方复用 `BubbleMacSourceGallery`，显示同词记录的截图、轻微旋转、投影和 `RecordSceneDot` 点阵。图片可横向浏览并打开原图；没有截图时仅显示点阵，不补造图片。
- 润色继续支持完整修正结果、解释和复制。

## 验证

- Mac arm64 / x86_64 编译与签名通过：`build/selection-result-build.log`。
- 预览直接加载编译后的应用组件，并使用隔离目录中的示例数据；不读取或修改用户记录。
- 检查了有图、无图、400pt 窄窗口与润色四个场景：`dictionary-collage.png`、`dictionary-empty.png`、`dictionary-narrow.png`、`polish.png`。
- 预览入口和日志位于 `build/selection-result-qa/Preview.swift`、`build/selection-result-render.log`。
- 本次不改变截图采集权限。此前因权限不足未保存的截图无法从文字记录恢复。
