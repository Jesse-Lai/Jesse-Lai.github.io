# Photography learning case

The default Mac learning page now presents **Turn an ordinary street into a photograph worth keeping.** The body now contains 910 English words, excluding the title, summary, headings, quotation, captions and references.

- `lesson.json`: editorial copy and verified source metadata.
- `article.md`: readable article with the photographs and reference links.
- `assets/`: unchanged source images, including their original watermarks, and a YouTube thumbnail.
- `asset-sources.json`: original asset URLs, attribution, source articles and SHA-256 checksums.
- `MacApp/BubbleArticleViews.swift`: bundled article data and Mac reading layout. Keep its editorial copy in sync with `lesson.json` when revising the case.

## Editorial treatment

Anne McKinnell's Digital Photography School guide is the main reference. Marc Newton's tutorial adds two photographs of the same portrait setting and a video; Jim Hamel's tutorial adds ways to look for lines in everyday locations. The main reference contains no video. The video card therefore explicitly identifies Newton's video as a supplementary tutorial and opens the original on YouTube.

Source-based explanations have nearby links. The nine-word quotation is attributed. The café scenario, three-photo exercise and reflection prompts are newly written editorial material, not events reported by the sources. The footer identifies the text as an edited lesson and links to all three originals. Images remain at their original aspect ratios in the reader; the library thumbnail alone uses a cover crop.

Images remain the work of their credited creators; attribution is not a licence grant. For the building photograph, the article caption does not identify an individual photographer, so the UI credits the source publication instead of guessing.

## Camera study — 2026-10-09

A new “Get to know your camera” section follows the portrait comparison. The built-in lesson and the generated lesson preview both embed the original Canon AT-1 study from `Resources/CameraStudy`. It retains rotation, compact disassembly, the slider, part definitions and attached dashed labels. The app bundles the HTML, CSS, JavaScript and Viewer SDK; the hosted model and textures still require an internet connection. The embedded viewport excludes the viewer logo, with model attribution and the CC BY 4.0 link below it. A scoped WebKit style suppresses the redundant “click & hold to rotate” hint; the article retains its own drag, zoom and rotation controls.

Mac universal build and code-signature validation passed (`build/article-camera-build.log`). Verified both article layouts in the Mac app, including model loading, automatic rotation, compact expansion, English definitions and attached part labels. Final preview: `build/article-camera-preview.jpg`.

## Scope and verification — 2026-10-07

- Replaces the former built-in space article. It does not modify generated articles, account data or the article-generation service.
- The sidebar is an authored, local photography practice guide, with selectable answers and feedback. It is not a live AI conversation or image critique.
- The 800-word body, source indices and bundled image files were checked against the editorial JSON.
- Mac arm64 / x86_64 build passed: `build/photography-lesson-build.log`.
- Verified in the running Mac app: default article, scroll layout, full original photographs and comparison, video/reference footer, sidebar layout and practice feedback.


## Journey hover

The opening paragraph adds “on your journey” after “You take a photograph”. Only `journey` is dotted-underlined. Hovering its actual TextKit glyph bounds turns both the word and dots to macOS system orange and reveals three cutouts above it. Leaving or pressing Escape restores the normal text. Text selection is preserved.

The travel, quote and ticket cutouts reuse pixels from the existing `LearningSpaceCollage` asset (Figma `1513:14716`); unrelated cards and overlapping baked shadows are excluded. Native shadows and placement follow the article hover design (`1567:43763`). The backdrop samples the enclosing scroll document with AppKit, before the reader’s SwiftUI edge mask, and applies a 6-point Core Image Gaussian blur, with a feathered alpha mask and a light `NSVisualEffectView` popover material above it. The previous material-only implementation tinted the SwiftUI backdrop without visibly blurring the glyphs. Sampling the window root also omitted the masked article, returning only the canvas; sampling its scroll document preserves the text. The feathered blur extends beneath the cutout shadows and excludes only the active word, keeping the orange glyphs crisp. The sample is kept in memory for the current hover and refreshed when its bounds change; scrolling or live resizing dismisses it.

The original entrance is restored: a 0.36-second fade and 14-point rise, with only 55 ms between cutouts. The later 210 ms sequential task has been removed. Reduce Motion removes travel and delay; Reduce Transparency omits the sampled blur and material. The overlay follows line wrapping, clamps to the paragraph width and ignores input. The decorative article illustration ignores hit testing so its enlarged, clipped image cannot intercept the paragraph above it.

### Hover correction validation — 2026-10-10

The full universal Xcode build now succeeds, and `build/Language Bubble.app` is signed with the existing Apple Development identity. The earlier certificate lookup failure occurred inside the sandbox; it did not mean the identity was missing. Build and strict signature verification run with the approved build script outside the sandbox. The original product has been updated directly; the separate preview app is no longer the installation target.

Verified in the signed product’s generated Photography article: text beneath the lower cutout shadows visibly defocuses, while `journey` stays orange and legible. Pointer exit, Escape, re-entry and scrolling dismiss/recreate the backdrop correctly. Temporary bitmap/tree diagnostics have been removed. The final build log and actual hover screenshot are retained locally under `build/journey-blur-fix/`.
