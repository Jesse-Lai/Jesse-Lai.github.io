# Generated article — 2026-10-10

Source: https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1572-43964

This shorter article supersedes the earlier generated preview only. It does not replace the original library lesson in `ArticleDesignContent`.

| Design nodes | Native implementation |
| --- | --- |
| 1572:43975–43976 | Title and metadata in `ArticlePreviewContent` |
| 1572:43977–43981 | First section and two paragraphs, with “journey” interaction preserved |
| 1572:43980 | `ArticleGeneratedBuilding`, original 1500×1500 PNG; 803:389 slot; image height 206.43%, y offset −23.65% |
| 1572:44006, 1572:43982 | Camera section heading and exact introductory paragraph |
| 1572:43984 | Existing interactive `ArticleCameraStudy`, explicitly retained instead of the design screenshot |
| 1572:44009, 1572:44004 | “More before you press the shutter” and paragraph, copied verbatim |
| 1572:44014, 1572:44016 | Reference heading and introduction |
| 1572:44045–44051 | Native link card, 198-point design height, 165-point square thumbnail; `ArticleDreamyReference`, original 1041×1290 PNG |
| 1572:43988–43997 | Existing completion introduction, resilient quiz, closing invitation |
| 1572:43998–44002 | Existing composer and `ArticleSendArrow` vector asset (Swift equivalent of the mapped Fluent arrow) |

Reference title, description and displayed/destination URL are exactly as supplied in Figma. The displayed “800 words · 6 min read” is design copy; `wordCount` records the shorter body separately. No temporary Figma asset URL is used at runtime.

The shared Literata/Inter typography, native toolbar, generation/outline-confirmation flow, scrolling edge effects and camera web view are reused.

2026-10-10 follow-up: removed the camera utility-button row, gesture hint and footer from the reading surface. The expansion slider, part selection and direct 3D gestures remain; the embedded height follows the shorter content. Model attribution, source, license and adaptation note now appear in the existing Settings → Open-source licenses page via `Resources/ThirdPartyLicenses.txt`.

Validation (2026-10-10): `bash scripts/build-mac.sh` completed successfully. In the rebuilt app, generated the Photography / All / 800-word preview through the explicit outline confirmation; checked the completed title, building crop, sidebar quiz inset, final section and complete reference card. The live camera rendered, expanded to 100%, and returned to 0% with Reassemble; Reset view remained functional. Screenshots are in `build/figma-article-1572/` (`article-top.png`, `camera-expanded.png`, `article-bottom.png`).
