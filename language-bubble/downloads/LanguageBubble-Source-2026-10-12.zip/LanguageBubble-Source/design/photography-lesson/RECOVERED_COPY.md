# Recovered article copy — 2026-10-09

The complete case was found in **选择语言学习案例爱好**, created on 2026-10-07.

- Chat: `01a115d5-1343-78d0-937d-ec50626f044b`
- Article-generation turn: `01a115de-9bfb-7cb0-b3ce-aabe4468e0a7`
- Original deliverable: [article.md](article.md)
- Structured source: [lesson.json](lesson.json)
- Current design: [Figma 1521:17008](https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1521-17008)

The user asked for an approximately 800-word case edited from original photography articles, retaining pictures and video, and ending with links to the original sources. The saved article contains all seven sections; its body is reused without rewriting:

1. Start with something you want to show
2. Give the eye a route
3. Notice what changes when a person moves
4. Move before you press the shutter
5. Look in places you already know
6. Your next walk: one subject, three photographs
7. Choose with a reason

The mock uses the Figma title **Leading Lines in Photography: Essential Guide** and metadata **800 words · 6 min read**. Its opening paragraphs are identical to the saved case. The unrelated Astronomy paragraph in the Figma frame is treated as a placeholder; the continuation comes from the recovered photography article. The original markdown and JSON are preserved as historical sources.

The sidebar copies these Figma strings verbatim:

> Now that you’ve read the article, let’s learn these words with a quick quiz!

> How is resilient used in this article?
>
> A. Recovers from difficulties
>
> B. Avoids difficulties
>
> C. Solves problems quickly
>
> D. Works independently

> If you’d like to learn in a different way or change what you’re learning, just let me know!

> Learn your way

The quiz is kept as designed even though “resilient” does not appear in the recovered body. No additional prose is inserted to manufacture a match.
