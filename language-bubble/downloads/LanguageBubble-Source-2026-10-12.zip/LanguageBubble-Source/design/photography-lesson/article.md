# Turn an ordinary street into a photograph worth keeping.

Photography · 800 body words · 6 min read

Learn to use leading lines to give your photographs a clear point of interest. Take your phone, choose a familiar place, and discover how a small change of position can change the picture.

Edited from 3 original tutorials.

![Avenue of Oaks, South Carolina](assets/avenue-of-oaks.jpg)

Photograph: Anne McKinnell. [Original article](https://digital-photography-school.com/how-to-use-leading-lines-for-better-compositions/).

## Start with something you want to show

Imagine stopping outside a café you pass every morning. You like its green door, the warm light inside, and the bicycle beside the entrance. You take a photograph on your journey, but the result feels busy. The door is there, yet nothing tells you where to look first.

Before taking another picture, finish this sentence: I want someone to notice the green door. That small decision gives you a purpose. You can now judge every part of the frame by a useful question: does it help someone find the door? For this walk, your goal is simple: make one familiar subject easier to notice.

## Give the eye a route

A leading line is a visible route through a photograph. It can connect something near the camera with something farther away, giving a flat image a feeling of depth. It might also direct attention toward your subject.

Anne McKinnell’s guide explains that these lines do not need to be straight or painted on the ground. A river, a fallen branch, or the edge of a building can work. What matters is the direction. Follow the line with your eyes: where do you arrive? A strong line needs a destination worth noticing.

[Source 1 · Digital Photography School](https://digital-photography-school.com/how-to-use-leading-lines-for-better-compositions/)

> Leading lines guide the viewer through a composition.

— Anne McKinnell, Digital Photography School.

![Ground markings lead toward the building](assets/lines-toward-building.jpg)

Image source: [Digital Photography School](https://digital-photography-school.com/how-to-use-leading-lines-for-better-compositions/).

## Notice what changes when a person moves

Marc Newton’s tutorial includes two portraits made in the same setting. In one, a wall carries your attention toward the person; in the other, the person has moved away from it. The pair makes the relationship between a line and a subject easy to study.

Look at both photographs before reading further. Where does your eye enter each picture? What does it reach next? Which arrangement makes the wall feel connected to the person? This is a way to understand composition through a visible relationship, rather than treating it as an abstract rule.

[Source 2 · The School of Photography](https://www.theschoolofphotography.com/tutorials/leading-lines-photography)

![Portrait with the wall leading toward the person](assets/portrait-with-wall.jpg)

![Portrait with the person away from the wall](assets/portrait-away-from-wall.jpg)

Photographs: Marc Newton / [The School of Photography](https://www.theschoolofphotography.com/tutorials/leading-lines-photography).

## Get to know your camera

Before you press the shutter, get to know the camera in your hands. This Canon AT-1 is a film camera: its body holds the film, while the lens focuses light onto it. Press the shutter release to take a photograph. The shutter-speed dial controls how long light reaches the film. Move the film advance lever to prepare the next frame, then use the rewind knob when the roll is finished.

Explore the camera below. Drag to turn it, move the slider to separate its controls, and select a part to learn its name. Try saying: “I turn the dial, advance the film, and press the shutter release.”

*Interactive camera study: rotate the Canon AT-1, expand its controls, and select a part to learn its name in the Mac article reader. Model by [AleixoAlonso](https://sketchfab.com/3d-models/canon-at-1-retro-camera-9de66868d0f240e985da00c9480bfc82), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).*

## Move before you press the shutter

Finding a line is only the beginning. McKinnell recommends adjusting your position until it points where you want the viewer to look. Try moving sideways, forward, or backward. Raising or lowering the camera can also change the relationship.

Check the whole frame after each move. If the strongest line takes attention away from your subject, try another position or another line. The useful question is not simply whether a line exists, but what it does.

[Source 1 · Digital Photography School](https://digital-photography-school.com/how-to-use-leading-lines-for-better-compositions/)

## Look in places you already know

In his practical guide, Jim Hamel suggests planning where to look before a shoot. Paths are an accessible starting point, but urban scenes offer fences, buildings, and rows of streetlights too. Shadows can become lines, and looking upward can reveal possibilities you missed at eye level.

He also points out that some patterns become clearer through the camera than they appear to the naked eye. Take a test photograph and examine it. The screen can help you discover a relationship that was difficult to notice while looking at the whole scene. Finding useful lines is an active part of making the picture.

[Source 3 · Digital Photography School](https://digital-photography-school.com/6-tips-for-creating-leading-lines-to-make-your-photos-stand-out-more/)

## Your next walk: one subject, three photographs

Try this small exercise at a place you know well. It could be a courtyard, a quiet walkway, or that café with the green door. Choose a position where you can stop comfortably. Keep the same subject throughout the exercise, so you can compare your decisions.

First, take the picture you would normally take. Do not improve it yet. This is your starting point. Pause and name the thing you want a friend to notice. If your answer contains three different things, choose just one for this experiment.

Second, explore the scene through your phone. Find an edge or a repeated pattern that seems connected to your subject. Make another photograph. Before you move again, describe your decision aloud: I’m using the edge of the pavement to point toward the door. You can use your own words; the sentence only needs to explain your intention.

Third, make one deliberate change. Try a different position and take another photograph. Keep the three images together. Write a short note beside each one about what you changed, so you can connect the result with an action you could repeat tomorrow.

## Choose with a reason

Put your three photographs next to one another. Without zooming in, decide which one communicates your intention most clearly. Ask a friend what they noticed first before telling them what you were trying to show. Their answer gives you another way to examine your choice.

If the original picture works best, keep it. An experiment is still useful when a change does not help. Describe what happened: the new angle made the bicycle more noticeable, but I wanted the door to stand out. That observation gives your next attempt a direction.

Save your favourite and one sentence explaining why you chose it. On your next walk, try the same exercise with a different subject. You are building a habit of making photographs intentionally, one decision at a time.

Return a week later and repeat the experiment. A familiar place can become a useful record of how your photographic choices are changing.

## Watch the technique in action

[![Video: leading lines](assets/leading-lines-video.jpg)](https://www.youtube.com/watch?v=-Y3vL7GAyIc)

Supplementary tutorial: Marc Newton / The School of Photography. Opens on YouTube.

## Read the originals

Edited from three photography tutorials, with a short original quotation and a new practice exercise. Follow the links below for the complete articles and further examples.

- [Leading Lines in Photography: The Essential Guide](https://digital-photography-school.com/how-to-use-leading-lines-for-better-compositions/) — Anne McKinnell · contributions by Jaymes Dempsey. The main guide: recognising lines and choosing a camera position.
- [Leading Lines Photography – Increase your Creative Skills](https://www.theschoolofphotography.com/tutorials/leading-lines-photography) — Marc Newton. Portrait comparisons and a video demonstration in an ordinary location.
- [Six practical tips for leading lines](https://digital-photography-school.com/6-tips-for-creating-leading-lines-to-make-your-photos-stand-out-more/) — Jim Hamel. More places to look, plus advice for planning and reviewing a photograph.
