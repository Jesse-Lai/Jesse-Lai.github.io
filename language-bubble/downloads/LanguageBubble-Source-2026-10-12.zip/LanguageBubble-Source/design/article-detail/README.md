# Article detail assets

Source: [Vibe Coding — expanded article](https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1477-3190), also used by default state `1470:2993`.

These are original image assets returned by Figma's design context, not screenshots of the page:

| File | Figma node | App asset |
| --- | --- | --- |
| `assets/space-exploration.png` | `1477:3203` | `ArticleSpaceExploration` |
| `assets/space-history.png` | `1477:3214` | `ArticleSpaceHistory` |
| `assets/reference-video.svg` | `1477:3205` | `ArticleReferenceVideo` |
| `assets/reference-link.svg` | `1477:3229` | `ArticleReferenceLink` |

These assets document the original space-themed design. As of 2026-10-07, the bundled lesson in `ArticleDesignContent` is the edited photography case documented in `design/photography-lesson/`. Generated and synced articles remain separate. The sidebar practice is authored content, not a generated AI reply.
