# Record collage artwork

Journey detail follows [Figma 1521:15660](https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1521-15660), collage `1521:15884`.

The 724 × 244.1632 canvas keeps the travel cutout at (16.15407, 0), rotated +2°, and the quote at (352.73074, 12.49402), rotated −2°. The ticket sits at (460.5, 110.1328125), rotated −2° about its top-left corner. Its 244 × 147.20187 orange panel uses #F2B86B, a 16-point radius, a 0.5-point black 15% border, and black 10% shadow with 40-point Figma blur (20-point SwiftUI radius).

`JourneyTicketMask` retains the alpha outline from node `1521:15894`; `JourneyTicketContent` is the original image from `1521:15895`. The mask measures 216.27791 × 119.59437 with offset (13.74642, 13.74593) in the unrotated panel. The source image measures 241.47981 × 119.59437 with offset (3.207552, 13.745315).

Use `scripts/update_figma_collages.py --word journey` to preview the local migration. To reuse an existing Journey ticket capture instead of importing another source, pass `--ticket-asset <existing asset ID>`. This changes only its local collage presentation; the original screenshot, source metadata, dictionary, capture order, and sync queue stay intact. The source card still opens the original screenshot. A subsequent run recognizes the bound ticket. Apply with `--apply` only while the app is stopped; the script backs up local state and checks for concurrent edits.

Article hover and learning card collages use separate assets and layouts.
