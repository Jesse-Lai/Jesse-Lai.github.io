# Learning library and creation transition

Design source: Figma `SXTRfnywlGRth5HOe9CHwf`, updated library `1521:16563`, creation overlay `1486:3260`.

- Canvas: 1728 × 1117, #FBFBFB, 48 horizontal inset.
- Navigation: the original shared native `BubbleMacTabs` toolbar (96-point segments, 13-point type, large capsule control size), identical on Records and Learning; cards retain their y=152 design position.
- Cards: 512 wide, 48 spacing, 32 corner radius, 36.5 internal inset; yellow #FFF1CC and blue #E0F5FF.
- Typography: bundled Literata Medium Italic titles, Inter metadata, PingFang SC controls.
- Overlay: 855 × 722, 36.5 inset, 36 section gaps, 32 field gaps; 32-point progressive background blur.
- Animation: SwiftUI matchedGeometryEffect for the shared card surface and native spring(duration: 0.55, bounce: 0.06). Reduce Motion cross-fades; Reduce Transparency uses an opaque backdrop.

The first row reproduces the Figma editorial cards: “The space” / “88 saved words · 22 Sep 2026” and “Photography” / “226 saved words · 06 Oct 2026”. Each collage uses five separate transparent PNG cutouts, including the original masks, rotations and shadows. Titles, metadata, dot grids, card surfaces and controls remain native SwiftUI. These presentation cards do not overwrite synced user data. Existing articles and the photography lesson remain accessible under the card menu’s “My articles”; topic cards open the creation form with the topic prefilled. Photography selects the existing Photography topic option.

The second card's refreshed cutouts come from `1613:767` (bath), `1613:789` (feedback), `1521:16974` (yellow post), `1521:16981` (travel) and `1521:16984` (green post), bundled as `LearningPhotography*`. Their positions and layer order follow `1521:16970`. The two upper cutouts have smaller silhouettes without the old outer shadows; travel is larger and the green post is narrower. PNGs are exported with `contentsOnly: true` to preserve alpha: the asset-download preview includes the blue ancestor background. Original exports are under `photography/`; exact layout/render bounds are in `collage-layers.json`.

Validation (2026-10-11): universal macOS build and strict signing check; all five new assets checked for transparent alpha, callsites and Figma render bounds; native screenshots verified the resting card, subtle hover translation and selected Photography topic in the creation form (`build/learning-photography-rest.png`, `build/learning-photography-hover.png`, `build/learning-photography-topic.png`). The existing shared native toolbar and sunlight overlay remain as implemented.

## Collage hover

Motion reference: Figma `1597:2591`, with resting collages `1521:16760` and `1521:16970`, and the blue card's expanded arrangement `1597:2556`. The refreshed Photography cutouts retain the previously tuned translation offsets, duration and hover shadow.

Hovering anywhere inside a topic card moves its five cutouts outward at their original size, using a shared 200 ms ease-in-out transition in both directions (60% faster than the original 320 ms). Blue-card directions follow the reference's cutout centers; the yellow card uses corresponding outward directions. Travel is limited to 15% of those offsets (at most 9.72 design points) following feedback to keep the movement subtle. All distances scale with the existing responsive card layout. Decoration can extend beyond the card edge without enlarging the hover or click region.

The hovered card also gains a black 6% shadow with X 0, Y 4, blur 32 and spread 0, following the supplied Figma settings. The native shadow uses a 16-point blur radius for the 32-point blur diameter, scaled with the card. It is applied only to the rounded card background and fades in and out over the same 200 ms transition.

Each card owns its hover state. Opening the creation form, leaving the page or deactivating the scene clears that state. Reduce Motion keeps the artwork at rest and updates the shadow without animation. No timers or delayed state mutations are used, so reversing a transition interpolates from its current presentation.

Validation: universal macOS Debug build and strict code-sign verification. Initial native window checks covered both cards, intermediate entrance, exit and creation-form dismissal. Initial evidence is in `build/learning-hover-*.png` and `build/learning-hover-verification.json`; these captures precede the reduction to 15% travel and removal of hover scaling.

Figma assets bundled in the asset catalog:

| Asset | Node | Intrinsic geometry | Use |
| --- | --- | --- | --- |
| LearningSpaceCollage | 1513:14716 | 439 × 346.58185 layout; 498 × 430 shadow export | Original yellow-card collage |
| LearningMarineCollage | 1513:14926 | 439 × 358 layout; 500 × 437 shadow export | Original blue-card collage |
| LearningMore | 1513:14714 | 5 × 23 inside 32 × 71 | Topic menu |
| LearningAdd | 1520:15620 | 12.5 × 12.5 inside 16 × 20 | New article CTA |
| LearningDot | 1513:14572 | 6 × 6 | Card dot pattern |
| LearningHeaderDot | 1520:15309 | 5 × 5 | Form heading pattern |

Creation preferences are sent as topic, saved_word_scope, word_count and instructions. Recent means the last seven days; Half uses the newest half after deduplication. The existing 40-record evidence budget still applies. Custom article lengths are bounded to 200–2000 words. The request ID remains stable when retrying an unchanged draft. Drafts survive dismissal; generation errors keep the form open.

Validation: macOS Debug build; six ArticleStoreTests; fifteen server article tests (including 1600/custom length, scope filtering and supplemental preferences); native UI checks for form selection, custom inputs, invalid length, Escape, and draft restoration. Server API changes must ship with the updated client. No live model generation was performed during UI validation.

## Sunlight overlay

The learning library now shares one viewport-sized transparent Metal shadow layer over the cards, collage images, text and canvas. It preserves all original card colors and controls, using a neutral shadow ceiling that increases radially from 2% at the top-left to 8% at one viewport-height of distance. The circular gradient stays fixed to the viewport; the animated light mask reveals the original surface through it. Soft diagonal light patches drift slowly and follow the pointer with easing and 30% travel: the full pointer range maps to light-center 0.35…0.65 around the page center. The layer ignores hit testing and accessibility.

The field fades out and pauses while the creation form is open. Reduce Motion keeps a static frame; Reduce Transparency and dark appearance omit the effect. Leaving Learning removes the renderer; inactive, occluded and minimized windows pause it. Low Power Mode requests 30 fps. The article reader and Records remain outside the effect.

Implementation and shared standalone preview: `docs/prototypes/sunlight/README.md`. Validation (2026-10-09): universal macOS build, strict code-sign verification, GPU transparent-alpha checks, and native creation-form open/dismiss checks. Current radial-gradient product evidence: `build/sunlight/learning-radial-2-8.png`. The GPU snapshot verifies 2% at top-left and 8% at the far corners (8-bit alpha 5 and 20). Earlier form evidence: `build/sunlight/learning-overlay-form.png`. Apple Silicon was rendered locally; Intel GPU and battery behavior remain unmeasured.
