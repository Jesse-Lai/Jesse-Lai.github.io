import SwiftUI
import AppKit

enum BubbleRecordPalette {
    static let page = Color(nsColor: NSColor(name: nil) { appearance in
        appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua
            ? NSColor.windowBackgroundColor : NSColor(srgbRed: 251 / 255, green: 251 / 255, blue: 251 / 255, alpha: 1)
    })
    static let panel = Color(nsColor: .textBackgroundColor)
    static let border = Color.primary.opacity(0.15)
    static let scroller = NSColor(name: nil) { appearance in
        appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua
            ? NSColor.white.withAlphaComponent(0.25) : NSColor.black.withAlphaComponent(0.20)
    }
}

// Customize the native scroller's drawing. AppKit retains ownership
// of dragging, accessibility, hover expansion, and automatic fading.
struct BubbleScrollIndicatorStyle: NSViewRepresentable {
    var color: NSColor = BubbleRecordPalette.scroller
    var hidesIndicator = false

    func makeNSView(context: Context) -> ScrollerProbe {
        let view = ScrollerProbe()
        view.color = color
        view.hidesIndicator = hidesIndicator
        return view
    }

    func updateNSView(_ view: ScrollerProbe, context: Context) {
        view.color = color
        view.hidesIndicator = hidesIndicator
        view.configureScroller()
    }

    final class ScrollerProbe: NSView {
        var color: NSColor = BubbleRecordPalette.scroller
        var hidesIndicator = false

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            configureScroller()
        }

        override func viewDidMoveToSuperview() {
            super.viewDidMoveToSuperview()
            configureScroller()
        }

        func configureScroller() {
            guard let scrollView = enclosingScrollView,
                  let original = scrollView.verticalScroller else { return }
            if let scroller = original as? TintedScroller {
                scroller.color = color
                scroller.hidesIndicator = hidesIndicator
                scroller.needsDisplay = true
                return
            }
            let scroller = TintedScroller(frame: original.frame)
            scroller.color = color
            scroller.hidesIndicator = hidesIndicator
            scroller.controlSize = original.controlSize
            scroller.doubleValue = original.doubleValue
            scroller.knobProportion = original.knobProportion
            scroller.isEnabled = original.isEnabled
            scrollView.verticalScroller = scroller
        }

        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }

    private final class TintedScroller: NSScroller {
        var color: NSColor = BubbleRecordPalette.scroller
        var hidesIndicator = false {
            didSet { setAccessibilityElement(!hidesIndicator) }
        }
        override class var isCompatibleWithOverlayScrollers: Bool { true }

        // Keep the NSScrollView's native edge effects without drawing a track
        // or leaving an invisible scrollbar that captures pointer input.
        override func draw(_ dirtyRect: NSRect) {
            if !hidesIndicator { super.draw(dirtyRect) }
        }

        override func hitTest(_ point: NSPoint) -> NSView? {
            hidesIndicator ? nil : super.hitTest(point)
        }

        override func drawKnob() {
            guard !hidesIndicator else { return }
            let knob = rect(for: .knob)
            guard !knob.isEmpty else { return }
            let width = min(6, knob.width)
            let rect = NSRect(x: knob.midX - width / 2, y: knob.minY, width: width, height: knob.height)
            color.setFill()
            NSBezierPath(roundedRect: rect, xRadius: width / 2, yRadius: width / 2).fill()
        }

        override func drawKnobSlot(in slotRect: NSRect, highlight flag: Bool) {}
    }
}

// Native material tuning lives here; AppKit owns blur radius and saturation.
enum BubbleRecordVibrancy {
    static let material: NSVisualEffectView.Material = .popover
    static let blendingMode: NSVisualEffectView.BlendingMode = .behindWindow
    static let state: NSVisualEffectView.State = .followsWindowActiveState
    static let isEmphasized = false
    // Lift the system's gray base toward the original near-white page while
    // keeping part of the blurred backdrop visible beneath this color wash.
    static let tintOpacity: Double = 0.8
    static let searchTintOpacity: Double = 0.04
}

struct BubbleRecordBackground: View {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    var body: some View {
        Group {
            if reduceTransparency {
                BubbleRecordPalette.page
            } else {
                BubbleRecordVisualEffect()
                    .overlay(BubbleRecordPalette.page.opacity(BubbleRecordVibrancy.tintOpacity))
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

private struct BubbleRecordVisualEffect: NSViewRepresentable {
    func makeNSView(context: Context) -> RecordEffectView {
        let view = RecordEffectView()
        configure(view)
        return view
    }

    func updateNSView(_ view: RecordEffectView, context: Context) { configure(view) }

    static func dismantleNSView(_ view: RecordEffectView, coordinator: ()) {
        view.restoreWindow()
    }

    private func configure(_ view: RecordEffectView) {
        view.material = BubbleRecordVibrancy.material
        view.blendingMode = BubbleRecordVibrancy.blendingMode
        view.state = BubbleRecordVibrancy.state
        view.isEmphasized = BubbleRecordVibrancy.isEmphasized
    }

    final class RecordEffectView: NSVisualEffectView {
        private weak var configuredWindow: NSWindow?
        private var originalBackground: NSColor?
        private var originalIsOpaque = true
        private var originalTitlebarTransparent = false

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            guard window !== configuredWindow else { return }
            restoreWindow()
            guard let window else { return }
            configuredWindow = window
            originalBackground = window.backgroundColor
            originalIsOpaque = window.isOpaque
            originalTitlebarTransparent = window.titlebarAppearsTransparent
            window.isOpaque = false
            window.backgroundColor = .clear
            window.titlebarAppearsTransparent = true
        }

        func restoreWindow() {
            guard let window = configuredWindow else { return }
            window.backgroundColor = originalBackground ?? .windowBackgroundColor
            window.isOpaque = originalIsOpaque
            window.titlebarAppearsTransparent = originalTitlebarTransparent
            configuredWindow = nil
        }

        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }
}

struct BubbleMacRecordRow: View {
    @Environment(BubbleStore.self) private var store
    let record: BubbleRecord
    let scale: CGFloat

    private var definition: String {
        if let entry = store.dictionary(for: record), record.latest.kind == "translation" {
            return entry.groups.map { $0.pos + " " + $0.meanings.joined(separator: "；") }.joined(separator: "；")
        }
        return [record.latest.result, record.latest.explanation].filter { !$0.isEmpty }.joined(separator: "；")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8 * scale) {
            Text(record.displayTitle)
                .bubbleFont(.headline, size: 24 * scale, weight: .medium, role: .word)
                .foregroundStyle(BubbleContentStyle.text)
                .lineLimit(1)
            Text(definition.split(whereSeparator: \.isWhitespace).joined(separator: " "))
                .font(.custom("PingFangSC-Regular", size: 20 * scale))
                .foregroundStyle(.primary.opacity(0.6))
                .lineLimit(1).truncationMode(.tail)
            if record.latest.isMock {
                Text("AI Mock · 测试数据").bubbleFont(.caption2).foregroundStyle(.orange)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 32 * scale)
        .frame(height: 120 * scale)
        .task(id: record.latest.id) {
            guard record.latest.kind == "translation" else { return }
            _ = try? await store.loadDictionary(for: record)
        }
    }
}

struct BubbleMacRecordDetail: View {
    @Environment(BubbleStore.self) private var store
    @AppStorage("bubbleInterfaceLanguage") private var interfaceLanguage = "zh-Hans"
    let recordID: BubbleRecord.ID
    let scale: CGFloat
    @State private var showSources = false
    @State private var confirmDelete = false

    var body: some View {
        Group {
            if let record = store.record(recordID) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 72 * scale) {
                        if record.sources.contains(where: { !$0.assetIds.isEmpty }) {
                            BubbleMacSourceGallery(record: record, scale: scale)
                        }
                        BubbleMacRecordDefinition(record: record, scale: scale)
                        .padding(.horizontal, 4 * scale)
                    }
                    .padding(.horizontal, 36.5 * scale)
                    .padding(.vertical, 48.5 * scale)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .accessibilityIdentifier("recordDetail")
                .contextMenu {
                    Button("查看出处") { showSources = true }
                    Button(store.isFavorite(recordID) ? "取消收藏" : "收藏") { store.toggleFavorite(recordID) }
                    Divider()
                    Button("删除记录", role: .destructive) { confirmDelete = true }
                }
                .task(id: record.latest.id) {
                    guard record.latest.kind == "translation" else { return }
                    _ = try? await store.loadDictionary(for: record)
                }
            } else {
                ContentUnavailableView("记录已删除", systemImage: "trash")
            }
        }
        .sheet(isPresented: $showSources) {
            VStack(spacing: 0) {
                HStack { Text("出处").bubbleFont(.headline); Spacer(); Button("完成") { showSources = false } }
                    .padding(20)
                BubbleCaptureView(recordID: recordID, embedded: true)
            }.frame(width: 700, height: 680)
                .environment(\.locale, Locale(identifier: interfaceLanguage))
        }
        .confirmationDialog("删除这条记录及所有出处？", isPresented: $confirmDelete) {
            Button("删除", role: .destructive) { Task { await store.deleteRecord(recordID) } }
        }
    }
}

/// Shared dictionary content for the library and the selection result window.
struct BubbleMacRecordDefinition: View {
    @Environment(BubbleStore.self) private var store
    let record: BubbleRecord
    let scale: CGFloat
    var showsFavorite = true

    var body: some View {
        VStack(alignment: .leading, spacing: 36 * scale) {
            title(record)
            meanings(record)
        }
    }

    private func title(_ record: BubbleRecord) -> some View {
        let passage = SceneText.ranges(in: record.latest.source).count > 1 || record.latest.source.count > 40
        return HStack(alignment: .center, spacing: 24 * scale) {
            Text(record.displayTitle)
                .bubbleFont(.largeTitle, size: (passage ? 26 : 48) * scale, weight: .medium, role: .word)
                .foregroundStyle(BubbleContentStyle.text)
                .lineLimit(passage ? nil : 1).minimumScaleFactor(0.6)
                .fixedSize(horizontal: false, vertical: true)
                .textSelection(.enabled).accessibilityAddTraits(.isHeader)
            SpeechControls(text: record.latest.source, iconOnly: true,
                phonetic: store.dictionary(for: record)?.phonetic, designScale: scale)
            if showsFavorite {
                Button { store.toggleFavorite(record.id) } label: {
                    Image("RecordFavorite").resizable()
                        .frame(width: 26.0024 * scale, height: 24.9997 * scale)
                        // Match Figma's optical alignment with the title, not the glyph bounds.
                        .padding(.top, 12 * scale)
                        .padding(.bottom, 4 * scale)
                        .frame(width: 32 * scale, height: 71 * scale)
                        .contentShape(Rectangle())
                        .saturation(store.isFavorite(record.id) ? 1 : 0)
                        .opacity(store.isFavorite(record.id) ? 1 : 0.4)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(store.isFavorite(record.id) ? "取消收藏" : "收藏")
                .accessibilityIdentifier("recordFavorite")
            }
            Spacer(minLength: 0)
        }
        .frame(minHeight: 71 * scale)
    }

    @ViewBuilder private func meanings(_ record: BubbleRecord) -> some View {
        if let entry = store.dictionary(for: record), record.latest.kind == "translation" {
            VStack(alignment: .leading, spacing: 36 * scale) {
                ForEach(Array(entry.groups.enumerated()), id: \.offset) { _, group in
                    HStack(alignment: .firstTextBaseline, spacing: 8 * scale) {
                        Text(group.pos)
                            .bubbleFont(.body, size: 24 * scale)
                            .foregroundStyle(.primary.opacity(0.4))
                            .frame(width: 48 * scale, alignment: .leading)
                        Text(group.meanings.joined(separator: "；"))
                            .font(.custom("PingFangSC-Regular", size: 20 * scale))
                            .foregroundStyle(BubbleContentStyle.text)
                            .lineSpacing(3 * scale)
                            .fixedSize(horizontal: false, vertical: true)
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }.accessibilityIdentifier("wordDictionaryMeanings")
        } else {
            VStack(alignment: .leading, spacing: 16 * scale) {
                Text(record.latest.kind == "translation" ? "译文" : "修改建议").bubbleFont(.headline)
                Text(record.latest.result).foregroundStyle(BubbleContentStyle.text)
                if !record.latest.explanation.isEmpty {
                    Text("简短讲解").bubbleFont(.headline)
                    Text(record.latest.explanation).foregroundStyle(.secondary)
                }
            }
            .font(.custom("PingFangSC-Regular", size: 20 * scale))
            .textSelection(.enabled)
        }
    }
}

struct BubbleMacSourceGallery: View {
    @Environment(BubbleStore.self) private var store
    let record: BubbleRecord
    let scale: CGFloat

    private var scenes: [(id: String, capture: BubbleCapture)] {
        var seen = Set<String>()
        return record.sources.flatMap { capture in
            capture.assetIds.compactMap { id in
                seen.insert(id).inserted && store.scenePresentation(id)?.artwork != .superseded ? (id, capture) : nil
            }
        }
    }

    private var collageScenes: [(id: String, capture: BubbleCapture)] {
        scenes.filter { store.scenePresentation($0.id)?.collagePlacement != nil }
            .sorted { (store.scenePresentation($0.id)?.collagePlacement?.x ?? 0)
                < (store.scenePresentation($1.id)?.collagePlacement?.x ?? 0) }
    }
    private var otherScenes: [(id: String, capture: BubbleCapture)] {
        scenes.filter { store.scenePresentation($0.id)?.collagePlacement == nil }
    }
    private var galleryHeight: CGFloat {
        if collageScenes.contains(where: { store.scenePresentation($0.id)?.artwork == .bubbleBook
            || store.scenePresentation($0.id)?.artwork == .bubblePost }) { return 259.1708 * scale }
        return (collageScenes.isEmpty ? 237.05 : 244.1632) * scale
    }

    var body: some View {
        GeometryReader { geometry in
            ScrollView(.horizontal) {
                HStack(alignment: .center, spacing: -16 * scale) {
                    if !collageScenes.isEmpty {
                        ZStack(alignment: .topLeading) {
                            ForEach(collageScenes, id: \.id) { scene in
                                if let placement = store.scenePresentation(scene.id)?.collagePlacement {
                                    BubbleMacSourceCard(assetID: scene.id, capture: scene.capture, scale: scale)
                                        .rotationEffect(.degrees(placement.rotation), anchor: .topLeading)
                                        .offset(x: placement.x * scale, y: placement.y * scale)
                                }
                            }
                        }
                        .frame(width: 724 * scale, height: galleryHeight, alignment: .topLeading)
                    }
                    ForEach(Array(otherScenes.enumerated()), id: \.element.id) { index, scene in
                        BubbleMacSourceCard(assetID: scene.id, capture: scene.capture, scale: scale,
                                            maximumWidth: max(1, geometry.size.width - 32 * scale))
                            .rotationEffect(.degrees(index % 3 == 2 ? -2 : 2))
                    }
                }
                .padding(.horizontal, collageScenes.isEmpty ? 12 * scale : 0)
                .frame(height: galleryHeight)
            }
            .scrollIndicators(.hidden)
            .scrollClipDisabled()
        }
        .frame(height: galleryHeight)
        .background(alignment: .topLeading) {
            BubbleMacSceneDots(scale: scale)
                .offset(x: -3.5 * scale, y: -15.5 * scale)
        }
        .accessibilityIdentifier("recordSourceGallery")
    }
}

private struct BubbleCollagePlacement {
    let x: CGFloat
    let y: CGFloat
    let width: CGFloat
    let height: CGFloat
    let rotation: Double
}

private extension BubbleScenePresentation {
    var collagePlacement: BubbleCollagePlacement? {
        if let placement {
            return .init(x: CGFloat(placement.x), y: CGFloat(placement.y),
                         width: CGFloat(placement.width), height: CGFloat(placement.height),
                         rotation: placement.rotation)
        }
        return artwork?.placement
    }
}

private extension BubbleSceneArtwork {
    // Figma coordinates use rotation about the top-left corner.
    var placement: BubbleCollagePlacement? {
        switch self {
        case .bubbleBook: .init(x: 20.73185, y: 0, width: 261.4119, height: 250.2001, rotation: 2)
        case .bubblePost: .init(x: 254.85756, y: 44.00416, width: 454.0155, height: 187.1214, rotation: -2)
        case .journeyTravel: .init(x: 16.15407, y: 0, width: 358, height: 231.8104, rotation: 2)
        case .journeyQuote: .init(x: 352.73074, y: 12.49402, width: 358, height: 78.98591, rotation: -2)
        case .journeyTicket: .init(x: 460.5, y: 110.1328125, width: 244, height: 147.20187, rotation: -2)
        case .curatedCutout, .superseded: nil
        }
    }
}

private struct BubbleMacSceneDots: View {
    let scale: CGFloat
    var body: some View {
        Canvas { context, _ in
            let dot = context.resolve(Image("RecordSceneDot"))
            for row in 0..<9 {
                for column in 0..<20 {
                    context.draw(dot, in: CGRect(x: CGFloat(column) * (726 / 19) * scale,
                        y: CGFloat(row) * 37 * scale, width: 5 * scale, height: 5 * scale))
                }
            }
        }
        .frame(width: 731 * scale, height: 301 * scale)
        .allowsHitTesting(false).accessibilityHidden(true)
    }
}

private struct BubbleMacSourceCard: View {
    @Environment(BubbleStore.self) private var store
    @AppStorage("bubbleInterfaceLanguage") private var interfaceLanguage = "zh-Hans"
    let assetID: String
    let capture: BubbleCapture
    let scale: CGFloat
    var maximumWidth: CGFloat = .infinity
    @State private var image: NSImage?
    @State private var isTextCutout = false
    @State private var failed = false
    @State private var attempt = 0
    @State private var preview = false

    private var presentation: BubbleScenePresentation? { store.scenePresentation(assetID) }
    private var artwork: BubbleSceneArtwork? { presentation?.artwork }
    private var width: CGFloat {
        if isTextCutout, presentation == nil, let image {
            return min(560 * scale, maximumWidth, 214 * scale * image.size.width / max(1, image.size.height))
        }
        return (presentation?.collagePlacement?.width ?? 244) * scale
    }
    private var height: CGFloat {
        if let placement = presentation?.collagePlacement { return placement.height * scale }
        let naturalRatio = image.map { $0.size.width / max(1, $0.size.height) } ?? 1.4
        if isTextCutout, presentation == nil { return width / max(0.1, naturalRatio) }
        let ratio = presentation?.aspectRatio ?? max(244 / 214.3887, naturalRatio)
        return width / max(0.1, ratio)
    }

    var body: some View {
        Button {
            if image != nil { preview = true } else if failed { attempt += 1 }
        } label: {
            card
        }
        .buttonStyle(.plain)
        .accessibilityLabel("记录时的场景图片")
        .accessibilityHint("查看原图")
        .accessibilityIdentifier("capturedScene-" + assetID)
        .task(id: "\(assetID)-\(attempt)") {
            failed = false
            do {
                let data = try await store.asset(assetID)
                try Task.checkCancellation()
                image = NSImage(data: data)
                failed = image == nil
                if let bitmap = NSBitmapImageRep(data: data), bitmap.hasAlpha {
                    let corners = [(0, 0), (bitmap.pixelsWide - 1, 0),
                                   (0, bitmap.pixelsHigh - 1), (bitmap.pixelsWide - 1, bitmap.pixelsHigh - 1)]
                    isTextCutout = corners.allSatisfy { (bitmap.colorAt(x: $0.0, y: $0.1)?.alphaComponent ?? 1) < 0.01 }
                } else { isTextCutout = false }
            } catch { if !Task.isCancelled { failed = true } }
        }
        .sheet(isPresented: $preview) { originalPreview }
    }

    @ViewBuilder private var card: some View {
        if artwork == .curatedCutout {
            imageCanvas.shadow(color: .black.opacity(0.12), radius: 16 * scale, x: 0, y: 5 * scale)
        } else if isTextCutout, presentation == nil {
            imageCanvas.shadow(color: .black.opacity(0.12), radius: 14 * scale, x: 0, y: 4 * scale)
        } else if artwork == .journeyTravel || artwork == .journeyQuote {
            imageCanvas
                .mask {
                    Image(artwork == .journeyTravel ? "JourneyTravelMask" : "JourneyQuoteMask")
                        .resizable().frame(width: width, height: height)
                }
                .shadow(color: .black.opacity(0.1), radius: 20 * scale)
        } else {
            ZStack(alignment: .topLeading) {
                if artwork == .bubblePost {
                    Color(red: 0.936469, green: 0.940392, blue: 0.704994)
                    imageCanvas.mask(alignment: .topLeading) {
                        Image("BubblePostMask").resizable()
                            .frame(width: 406.7423 * scale, height: 139.8486 * scale)
                            .offset(x: 23.63663 * scale, y: 23.63325 * scale)
                    }
                } else if artwork == .journeyTicket {
                    Color(red: 242 / 255, green: 184 / 255, blue: 107 / 255)
                    imageCanvas.mask(alignment: .topLeading) {
                        Image("JourneyTicketMask").resizable()
                            .frame(width: 216.27791 * scale, height: 119.59437 * scale)
                            .offset(x: 13.74642 * scale, y: 13.74593 * scale)
                    }
                } else {
                    BubbleRecordPalette.panel
                    imageCanvas
                }
            }
            .frame(width: width, height: height, alignment: .topLeading)
            .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
            .overlay { RoundedRectangle(cornerRadius: 16 * scale).strokeBorder(BubbleRecordPalette.border, lineWidth: 0.5) }
            .shadow(color: .black.opacity(artwork == .bubblePost || artwork == .journeyTicket ? 0.1 : 0.12),
                    radius: 20 * scale, x: 0, y: artwork == .bubblePost || artwork == .journeyTicket ? 0 : 4 * scale)
        }
    }

    private var imageCanvas: some View {
        ZStack(alignment: .topLeading) {
            if let image {
                if let presentation {
                    (presentation.displayImageName.map { Image($0) } ?? Image(nsImage: image)).resizable()
                        .frame(width: width * presentation.imageWidth, height: height * presentation.imageHeight)
                        .offset(x: width * presentation.imageX, y: height * presentation.imageY)
                } else {
                    Image(nsImage: image).resizable().scaledToFit().frame(width: width, height: height)
                }
            } else {
                Group {
                    if failed { Label("重试", systemImage: "arrow.clockwise") }
                    else { ProgressView().controlSize(.small) }
                }.frame(width: width, height: height)
            }
            if artwork == .bubblePost, image != nil {
                EllipticalGradient(colors: [Color(red: 1, green: 0.819608, blue: 0).opacity(0),
                                            Color(red: 1, green: 0.819048, blue: 0)], endRadiusFraction: 0.5)
                    .opacity(0.4)
                    .frame(width: 48.6489 * scale, height: 22.3117 * scale)
                    .clipShape(RoundedRectangle(cornerRadius: 3.24 * scale))
                    .offset(x: 267.6814 * scale, y: 77.42622 * scale)
            }
        }
        .frame(width: width, height: height, alignment: .topLeading)
    }

    private var originalPreview: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("记录时的场景图片").bubbleFont(.headline)
                Spacer()
                Button("完成") { preview = false }.keyboardShortcut(.cancelAction)
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if let image { Image(nsImage: image).resizable().scaledToFit() }
                    if let app = capture.sourceApp { Text(app).foregroundStyle(.secondary) }
                    if let context = capture.surroundingText, !context.isEmpty { Text(context).textSelection(.enabled) }
                    if let url = capture.sourceLink { Link(url.absoluteString, destination: url) }
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
        }.padding(20).frame(width: 800, height: 660)
            .environment(\.locale, Locale(identifier: interfaceLanguage))
    }
}
