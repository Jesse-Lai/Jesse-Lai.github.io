import SwiftUI
import AppKit
import ApplicationServices
import CoreGraphics
import ServiceManagement
import Observation
import OSLog

@MainActor
final class MacApplicationDelegate: NSObject, NSApplicationDelegate, ObservableObject {
    @Published private(set) var store: BubbleStore?
    @Published private(set) var capture: MacCaptureController?
    @Published private(set) var error: String?
    private let loginItem = MacLoginItem()

    func applicationDidFinishLaunching(_ notification: Notification) {
        start()
        loginItem.configureFirstLaunch()
        Logger(subsystem: "com.jesselai.languagebubble.mac", category: "startup").notice(
            "Capture ready: \(self.capture != nil, privacy: .public); accessibility: \(AXIsProcessTrusted(), privacy: .public); login item status: \(self.loginItem.status.rawValue, privacy: .public)")
    }

    /// A login launch may never construct the main window. Background capture
    /// belongs to the application lifetime, not a window's ProgressView.task.
    func start(makeStore: @MainActor () throws -> BubbleStore = { try BubbleStore() }) {
        guard store == nil else { return }
        do {
            let store = try makeStore()
            capture = MacCaptureController(store: store)
            self.store = store
            error = nil
        } catch { self.error = error.localizedDescription }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }
}

@MainActor @Observable
final class MacLoginItem {
    private(set) var status = SMAppService.mainApp.status
    private(set) var error: String?
    var enabled: Bool { status == .enabled || status == .requiresApproval }

    func refresh() { status = SMAppService.mainApp.status }

    func configureFirstLaunch() {
        // Register the product once, then respect changes made in System Settings.
        // Preview/test bundles must never create their own login items.
        guard Bundle.main.bundleIdentifier == "com.jesselai.languagebubble.mac" else { return }
        refresh()
        guard !UserDefaults.standard.bool(forKey: "bubbleLoginItemConfigured") else { return }
        if status == .notRegistered || status == .notFound { setEnabled(true) }
        if error == nil { UserDefaults.standard.set(true, forKey: "bubbleLoginItemConfigured") }
    }

    func setEnabled(_ enabled: Bool) {
        error = nil
        do {
            if enabled {
                if SMAppService.mainApp.status == .requiresApproval {
                    SMAppService.openSystemSettingsLoginItems()
                } else if SMAppService.mainApp.status != .enabled {
                    try SMAppService.mainApp.register()
                }
            } else {
                try SMAppService.mainApp.unregister()
            }
            UserDefaults.standard.set(true, forKey: "bubbleLoginItemConfigured")
        } catch { self.error = error.localizedDescription }
        refresh()
    }
}

@main
struct LanguageBubbleApp: App {
    init() { BubbleTypography.register() }
    @NSApplicationDelegateAdaptor(MacApplicationDelegate.self) private var appDelegate
    @Environment(\.openWindow) private var openWindow
    @AppStorage("bubbleInterfaceLanguage") private var interfaceLanguage = "zh-Hans"
    private var store: BubbleStore? { appDelegate.store }
    private var capture: MacCaptureController? { appDelegate.capture }
    var body: some Scene {
        WindowGroup("Language Bubble", id: "main") {
            MacApplicationContent(appDelegate: appDelegate)
                .frame(minWidth: 860, minHeight: 660)
                .bubbleAppearance(paintsBackground: false)
                .environment(\.locale, Locale(identifier: interfaceLanguage))
        }
        .defaultSize(width: 1180, height: 1180 * 1117.0 / 1728)
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unified)
        .commands {
            CommandGroup(replacing: .appSettings) {
                Button(BubbleLocalization.text("设置") + "…") { showSettings() }
                    .keyboardShortcut(",", modifiers: .command)
            }
        }
        MenuBarExtra("Language Bubble", systemImage: "bubble.left.and.bubble.right.fill") {
            Button("选区查译 " + (capture?.shortcuts.selection.label ?? "")) { capture?.selected() }
            Button("截图 OCR " + (capture?.shortcuts.region.label ?? "")) { capture?.region() }
            Divider()
            Button("打开记录") { showTab(0) }
            Button("场景学习") { showTab(2) }
            Button("设置") { showSettings() }
            Button("同步记录") { Task { await store?.sync() } }
            Button("退出") { NSApp.terminate(nil) }
        }
    }
    private func showTab(_ index: Int) {
        store?.selectedTab = index
        showMainWindow()
    }
    private func showSettings() {
        store?.showingSettings = true
        showMainWindow()
    }
    private func showMainWindow() {
        if let window = NSApp.windows.first(where: { $0.canBecomeMain && !($0 is NSPanel) }) {
            window.makeKeyAndOrderFront(nil)
        } else {
            openWindow(id: "main")
        }
        NSApp.activate(ignoringOtherApps: true)
    }
}

// Observe startup state inside the window's view. The scene may be created
// before applicationDidFinishLaunching publishes the store and capture service.
private struct MacApplicationContent: View {
    @ObservedObject var appDelegate: MacApplicationDelegate

    var body: some View {
        Group {
            if let store = appDelegate.store, let capture = appDelegate.capture {
                BubbleRootView().environment(store).environment(capture)
            } else if let error = appDelegate.error {
                Text(error).padding()
            } else {
                ProgressView()
            }
        }
    }
}

struct MacCaptureSettings: View {
    @Environment(MacCaptureController.self) private var capture
    @Environment(BubbleStore.self) private var store
    @State private var loginItem = MacLoginItem()

    var body: some View {
        Section("采集与快捷键") {
            Toggle("登录时自动启动", isOn: Binding(get: { loginItem.enabled }, set: { loginItem.setEnabled($0) }))
            if loginItem.status == .requiresApproval {
                Button("在系统设置中允许登录启动") { SMAppService.openSystemSettingsLoginItems() }
            }
            if let error = loginItem.error { Text(error).foregroundStyle(.orange) }
            Toggle("选中文字后显示翻译与润色", isOn: Binding(get: { capture.selectionBubbleEnabled }, set: { capture.selectionBubbleEnabled = $0 }))
            Toggle("Option 悬浮取词", isOn: Binding(get: { capture.hoverEnabled }, set: { capture.hoverEnabled = $0 }))
            Button(BubbleLocalization.text("选区查译") + " " + capture.shortcuts.selection.label) { capture.selected() }
                .disabled(capture.isCapturing || store.querying)
            Button(BubbleLocalization.text("区域 OCR") + " " + capture.shortcuts.region.label) { capture.region() }
                .disabled(capture.isCapturing || store.querying)
            NavigationLink("采集权限") {
                ScrollView { MacSetupView().frame(maxWidth: .infinity, alignment: .leading) }
                    .navigationTitle(BubbleLocalization.text("采集权限"))
            }
            NavigationLink("快捷键") {
                MacShortcutView(shortcuts: capture.shortcuts)
                    .navigationTitle(BubbleLocalization.text("快捷键"))
            }
        }
        .onAppear { loginItem.refresh() }
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.didBecomeActiveNotification)) { _ in
            loginItem.refresh()
        }
    }
}

struct MacSetupView: View {
    @State private var accessibility = AXIsProcessTrusted()
    @State private var screenCapture = CGPreflightScreenCaptureAccess()
    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            Label("Language Bubble", systemImage: "bubble.left.and.bubble.right.fill").bubbleFont(.largeTitle, weight: .bold)
            Text("在其他 App 中选中文字，或把光标放在词上查译。截图 OCR 可识别图片、PDF 和可见字幕。")
            Text("开启对应系统权限后使用。AI 模式以 App 中的连接状态为准。")
            Button(LocalizedStringKey(accessibility ? "辅助功能已开启" : "开启辅助功能 · 读取主动查询的选区")) {
                let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
                accessibility = AXIsProcessTrustedWithOptions(options)
            }
            Button(LocalizedStringKey(screenCapture ? "屏幕录制已开启" : "开启屏幕录制 · 保存查询场景")) {
                screenCapture = CGRequestScreenCaptureAccess()
            }
            Button("刷新权限状态") {
                accessibility = AXIsProcessTrusted(); screenCapture = CGPreflightScreenCaptureAccess()
            }
            Text("仅在用户主动查询或启用取词时采集；不会持续记录键盘输入。")
                .bubbleFont(.caption).foregroundStyle(.secondary)
        }.padding(40)
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.didBecomeActiveNotification)) { _ in
            accessibility = AXIsProcessTrusted(); screenCapture = CGPreflightScreenCaptureAccess()
        }
        .onAppear {
            NSApp.setActivationPolicy(.regular)
            NSApp.activate(ignoringOtherApps: true)
            if ProcessInfo.processInfo.arguments.contains("--request-permissions") {
                let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
                accessibility = AXIsProcessTrustedWithOptions(options)
                screenCapture = CGRequestScreenCaptureAccess()
            }
        }
    }
}

struct MacShortcutView: View {
    @Bindable var shortcuts: MacShortcuts
    var body: some View {
        Form {
            ShortcutEditor(title: "选区查译", shortcut: $shortcuts.selection)
            ShortcutEditor(title: "区域 OCR", shortcut: $shortcuts.region)
            if let error = shortcuts.error { Text(error).foregroundStyle(.red) }
            Button("应用快捷键") { shortcuts.apply() }
            Button("恢复默认") { shortcuts.reset() }
            Text("快捷键被其他 App 占用时会提示冲突。Option 悬浮取词可在设置中开启。").bubbleFont(.caption).foregroundStyle(.secondary)
        }.formStyle(.grouped)
    }
}

struct ShortcutEditor: View {
    var title: String
    @Binding var shortcut: CaptureShortcut
    var body: some View {
        Section(title) {
            Picker("按键", selection: $shortcut.key) { ForEach(CaptureShortcut.keys.keys.sorted(), id: \.self) { Text($0) } }
            HStack {
                Toggle("Control", isOn: $shortcut.control)
                Toggle("Option", isOn: $shortcut.option)
                Toggle("Command", isOn: $shortcut.command)
                Toggle("Shift", isOn: $shortcut.shift)
            }
        }
    }
}
