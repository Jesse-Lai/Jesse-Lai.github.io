import SwiftUI
import AppKit
import CoreImage
import WebKit

// An edited photography lesson with verifiable sources, separate from the user's library.
enum ArticleDesignContent {
    struct Source {
        let title: String
        let author: String
        let publisher: String
        let url: URL
        let note: String
    }
    static let cameraHeading = "Get to know your camera"
    static let id = "curated-photography-leading-lines"
    static let article = LearningArticle(
        id: id, title: "Turn an ordinary street into a photograph worth keeping.",
        summary: "Learn to use leading lines to give your photographs a clear point of interest. Take your phone, choose a familiar place, and discover how a small change of position can change the picture.",
        theme: "Photography · Leading lines", language: "en", generatedAt: 0, generationId: id,
        captureIds: [], sections: [
            .init(heading: "Start with something you want to show", text: "Imagine stopping outside a café you pass every morning. You like its green door, the warm light inside, and the bicycle beside the entrance. You take a photograph on your journey, but the result feels busy. The door is there, yet nothing tells you where to look first.\n\nBefore taking another picture, finish this sentence: I want someone to notice the green door. That small decision gives you a purpose. You can now judge every part of the frame by a useful question: does it help someone find the door? For this walk, your goal is simple: make one familiar subject easier to notice.", translation: "", captureIds: [], question: "", answer: ""),
            .init(heading: "Give the eye a route", text: "A leading line is a visible route through a photograph. It can connect something near the camera with something farther away, giving a flat image a feeling of depth. It might also direct attention toward your subject.\n\nAnne McKinnell’s guide explains that these lines do not need to be straight or painted on the ground. A river, a fallen branch, or the edge of a building can work. What matters is the direction. Follow the line with your eyes: where do you arrive? A strong line needs a destination worth noticing.", translation: "", captureIds: [], question: "", answer: ""),
            .init(heading: cameraHeading, text: "Before you press the shutter, get to know the camera in your hands. This Canon AT-1 is a film camera: its body holds the film, while the lens focuses light onto it. Press the shutter release to take a photograph. The shutter-speed dial controls how long light reaches the film. Move the film advance lever to prepare the next frame, then use the rewind knob when the roll is finished.\n\nExplore the camera below. Drag to turn it, move the slider to separate its controls, and select a part to learn its name. Try saying: “I turn the dial, advance the film, and press the shutter release.”", translation: "", captureIds: [], question: "", answer: ""),
            .init(heading: "Move before you press the shutter", text: "Finding a line is only the beginning. McKinnell recommends adjusting your position until it points where you want the viewer to look. Try moving sideways, forward, or backward. Raising or lowering the camera can also change the relationship.\n\nCheck the whole frame after each move. If the strongest line takes attention away from your subject, try another position or another line. The useful question is not simply whether a line exists, but what it does.", translation: "", captureIds: [], question: "", answer: ""),
            .init(heading: "Look in places you already know", text: "In his practical guide, Jim Hamel suggests planning where to look before a shoot. Paths are an accessible starting point, but urban scenes offer fences, buildings, and rows of streetlights too. Shadows can become lines, and looking upward can reveal possibilities you missed at eye level.\n\nHe also points out that some patterns become clearer through the camera than they appear to the naked eye. Take a test photograph and examine it. The screen can help you discover a relationship that was difficult to notice while looking at the whole scene. Finding useful lines is an active part of making the picture.", translation: "", captureIds: [], question: "", answer: ""),
            .init(heading: "Your next walk: one subject, three photographs", text: "Try this small exercise at a place you know well. It could be a courtyard, a quiet walkway, or that café with the green door. Choose a position where you can stop comfortably. Keep the same subject throughout the exercise, so you can compare your decisions.\n\nFirst, take the picture you would normally take. Do not improve it yet. This is your starting point. Pause and name the thing you want a friend to notice. If your answer contains three different things, choose just one for this experiment.\n\nSecond, explore the scene through your phone. Find an edge or a repeated pattern that seems connected to your subject. Make another photograph. Before you move again, describe your decision aloud: I’m using the edge of the pavement to point toward the door. You can use your own words; the sentence only needs to explain your intention.\n\nThird, make one deliberate change. Try a different position and take another photograph. Keep the three images together. Write a short note beside each one about what you changed, so you can connect the result with an action you could repeat tomorrow.", translation: "", captureIds: [], question: "", answer: ""),
            .init(heading: "Choose with a reason", text: "Put your three photographs next to one another. Without zooming in, decide which one communicates your intention most clearly. Ask a friend what they noticed first before telling them what you were trying to show. Their answer gives you another way to examine your choice.\n\nIf the original picture works best, keep it. An experiment is still useful when a change does not help. Describe what happened: the new angle made the bicycle more noticeable, but I wanted the door to stand out. That observation gives your next attempt a direction.\n\nSave your favourite and one sentence explaining why you chose it. On your next walk, try the same exercise with a different subject. You are building a habit of making photographs intentionally, one decision at a time.\n\nReturn a week later and repeat the experiment. A familiar place can become a useful record of how your photographic choices are changing.", translation: "", captureIds: [], question: "", answer: "")
        ], expressions: [], messages: [], revision: 0, wordCount: 817, requestedWordCount: 800)
    static let sources: [Source] = [
        .init(title: "Leading Lines in Photography: The Essential Guide", author: "Anne McKinnell · contributions by Jaymes Dempsey", publisher: "Digital Photography School", url: URL(string: "https://digital-photography-school.com/how-to-use-leading-lines-for-better-compositions/")!, note: "The main guide: recognising lines and choosing a camera position."),
        .init(title: "Leading Lines Photography – Increase your Creative Skills", author: "Marc Newton", publisher: "The School of Photography", url: URL(string: "https://www.theschoolofphotography.com/tutorials/leading-lines-photography")!, note: "A video demonstration of leading lines in an ordinary location."),
        .init(title: "Six practical tips for leading lines", author: "Jim Hamel", publisher: "Digital Photography School", url: URL(string: "https://digital-photography-school.com/6-tips-for-creating-leading-lines-to-make-your-photos-stand-out-more/")!, note: "More places to look, plus advice for planning and reviewing a photograph.")
    ]
    static let sectionSources: [Int?] = [nil, 0, nil, 0, 2, nil, nil]
    static let quote = "Leading lines guide the viewer through a composition."
    static let editorialNote = "Edited from three photography tutorials, with a short original quotation and a new practice exercise. Follow the links below for the complete articles and further examples."
    static let videoURL = URL(string: "https://www.youtube.com/watch?v=-Y3vL7GAyIc")!
    static let lesson = "把刚学到的方法用在一张真实照片上吧。先选一个你希望观众注意到的主体。\n\n如果栏杆的线条指向主体之外，你会先尝试什么？\nA. Move until the railing leads toward the subject\nB. Increase the saturation\nC. Memorise the camera settings\n\n下次散步时，给同一个场景拍三个版本，比较哪一处最先吸引你的视线。\n\n也可以用英语描述你的决定：I moved to the left so the line points toward the door."
}

// Figma 1513:14519 and 1486:3260. Native controls keep the article data live;
// the shared surface morphs from the create card into the preference form.
struct BubbleArticleLibrary: View {
    @Environment(BubbleStore.self) private var store
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Binding var selection: String?
    @Namespace private var creationTransition
    @State private var showGenerator = false
    @State private var generatorContentVisible = false
    @State private var generatorPresentationID: UUID?
    @State private var sunlightPointer: CGPoint?
    @State private var draft = ArticleGenerationDraft()
    @Binding var previews: [ArticleGenerationPreview]
    private var articles: [LearningArticle] { previews.map(\.article) + [ArticleDesignContent.article] + store.articles }
    private var transitionDuration: TimeInterval { reduceMotion ? 0.18 : 0.55 }
    private var contentEntranceDelay: TimeInterval { reduceMotion ? 0 : 0.3 }
    private var transition: Animation {
        reduceMotion ? .easeInOut(duration: transitionDuration) : .spring(duration: transitionDuration, bounce: 0.06)
    }

    var body: some View {
        Group {
            if let id = selection, let article = articles.first(where: { $0.id == id }) {
                BubbleArticleReader(articleID: article.id, preview: previews.first { $0.id == id },
                    onBack: { selection = nil }).id(id)
            } else {
                GeometryReader { geometry in
                    let scale = min(1, geometry.size.width / 1728)
                    ZStack {
                        library(scale: scale)
                            .overlay {
                                if colorScheme == .light && !reduceTransparency {
                                    LearningSunlight(pointer: sunlightPointer, active: !showGenerator)
                                        .opacity(showGenerator ? 0 : 1)
                                }
                            }
                            .onContinuousHover { phase in
                                switch phase {
                                case .active(let location):
                                    sunlightPointer = CGPoint(
                                        x: location.x / max(geometry.size.width, 1),
                                        y: location.y / max(geometry.size.height, 1))
                                case .ended: sunlightPointer = nil
                                }
                            }
                            .blur(radius: showGenerator && !reduceTransparency ? 32 * scale : 0)
                            .allowsHitTesting(!showGenerator)
                            .accessibilityHidden(showGenerator)
                        if showGenerator {
                            (reduceTransparency ? ArticleReaderStyle.canvas : Color(white: 221.0 / 255).opacity(0.1))
                                .ignoresSafeArea()
                                .contentShape(Rectangle())
                                .onTapGesture { dismissGenerator() }
                                .transition(.opacity)
                        }
                        generator(size: geometry.size)
                            .zIndex(1)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .animation(transition, value: showGenerator)
                    .onExitCommand { if showGenerator { dismissGenerator() } }
                }
                .ignoresSafeArea(.container, edges: .top)
            }
        }
        .task { await store.refreshArticles() }
    }

    private func library(scale: CGFloat) -> some View {
        ScrollView {
            VStack(spacing: 0) {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 48 * scale), count: 3), spacing: 48 * scale) {
                    ForEach(LearningLibraryTopic.allCases) { topic in
                        ArticleLibraryCard(topic: topic, articles: articles, scale: scale, hoverEnabled: !showGenerator,
                            openTopic: { open(topic) },
                            openArticle: { selection = $0 },
                            learnTopic: {
                                draft.topic = topic == .photography ? .photography : .other
                                draft.customTopic = topic == .photography ? "" : topic.title
                                presentGenerator()
                            })
                    }
                    ZStack {
                        if !showGenerator {
                            creationSurface(scale: scale)
                                .matchedGeometryEffect(id: "creationSurface", in: creationTransition,
                                    properties: reduceMotion ? [] : .frame)
                            newArticleContent(scale: scale)
                        }
                    }
                    .frame(height: 572 * scale)
                }
            }
            .padding(.horizontal, 48 * scale)
            // Reserve the original card position under the shared native toolbar.
            .padding(.top, 152 * scale)
            .padding(.bottom, 48 * scale)
            .frame(maxWidth: 1728)
            .frame(maxWidth: .infinity, alignment: .top)
        }
        .scrollIndicators(.hidden)
    }

    private func creationSurface(scale: CGFloat) -> some View {
        RoundedRectangle(cornerRadius: 32 * scale, style: .continuous)
            .fill(ArticleReaderStyle.surface)
            .overlay(RoundedRectangle(cornerRadius: 32 * scale, style: .continuous)
                .strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5 * scale))
    }

    private func newArticleContent(scale: CGFloat) -> some View {
        VStack(spacing: 32 * scale) {
            Text(verbatim: "Learn what you love\nin English.")
                .bubbleFont(.title, size: 40 * scale, weight: .medium, role: .word)
                .foregroundStyle(Color.primary.opacity(0.2))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .lineSpacing(0)
                .frame(height: 118 * scale)
            Button(action: presentGenerator) {
                HStack(spacing: 6 * scale) {
                    Image("LearningAdd").resizable().frame(width: 12.5 * scale, height: 12.5 * scale)
                        .frame(width: 16 * scale, height: 20 * scale)
                    Text(verbatim: "Learn something new")
                        .font(.custom("PingFangSC-Regular", size: 16 * scale))
                        .tracking(-0.23 * scale)
                }
                .foregroundStyle(.white.opacity(0.86))
                .padding(.horizontal, 16 * scale)
                .frame(height: 44 * scale)
                .background(Color(white: 43.0 / 255), in: Capsule())
                .contentShape(Capsule())
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("newThemeArticle")
        }
        .padding(.horizontal, 36.5 * scale)
        .padding(.bottom, 44 * scale)
    }

    private func generator(size: CGSize) -> some View {
        let scale = min(1, size.width / 1728)
        return ZStack {
            if showGenerator {
                creationSurface(scale: scale)
                    .matchedGeometryEffect(id: "creationSurface", in: creationTransition,
                        properties: reduceMotion ? [] : .frame)
                    .shadow(color: .black.opacity(0.04), radius: 40 * scale)
                    .transition(.opacity)
                // Begin revealing the form 0.3 seconds after expansion starts.
                // Remove it immediately on dismissal; only the surface morphs back.
                BubbleArticleGenerator(draft: $draft, scale: scale, contentVisible: generatorContentVisible,
                    dismiss: dismissGenerator, onGenerate: generate)
                    .transition(.identity)
            }
        }
            .frame(width: min(855 * scale, size.width - 40), height: min(722 * scale, size.height - 48))
            .allowsHitTesting(showGenerator)
            .accessibilityHidden(!showGenerator)
            .accessibilityAddTraits(.isModal)
            .task(id: generatorPresentationID) {
                guard let presentationID = generatorPresentationID, showGenerator else { return }
                do { try await Task.sleep(for: .seconds(contentEntranceDelay)) }
                catch { return }
                guard !Task.isCancelled, showGenerator, generatorPresentationID == presentationID else { return }
                generatorContentVisible = true
            }
    }

    private func presentGenerator() {
        guard !showGenerator else { return }
        store.articleError = nil
        generatorContentVisible = false
        generatorPresentationID = UUID()
        withAnimation(transition) { showGenerator = true }
    }

    private func dismissGenerator() {
        guard !store.generatingArticles else { return }
        generatorPresentationID = nil
        withAnimation(transition) { showGenerator = false }
    }

    private func generate() {
        guard draft.validation == nil else { return }
        let preview = ArticlePreviewContent.make(draft)
        previews.insert(preview, at: 0)
        generatorPresentationID = nil
        generatorContentVisible = false
        showGenerator = false
        selection = preview.id
        draft = ArticleGenerationDraft()
    }

    private func open(_ topic: LearningLibraryTopic) {
        // Stable IDs keep each card attached to its own finished lesson and
        // preserve local edits when returning from the reader in this session.
        if !previews.contains(where: { $0.id == topic.articleID }) {
            let article = topic == .space ? ArticleSpaceContent.make() : ArticlePreviewContent.make(
                ArticleGenerationDraft(topic: .photography, scope: .all, wordCount: 800),
                id: topic.articleID, initiallyComplete: true)
            previews.append(article)
        }
        selection = topic.articleID
    }

}

// Figma's editorial cards are presentation content, separate from synced articles.
private enum LearningLibraryTopic: String, CaseIterable, Identifiable {
    case space, photography
    var id: String { rawValue }
    var articleID: String { "library-" + rawValue }
    var title: String { self == .space ? "The space" : "Photography" }
    var caption: String {
        self == .space ? "88 saved words · 22 Sep 2026" : "226 saved words · 06 Oct 2026"
    }
    var height: CGFloat { self == .space ? 560.58185 : 572 }
    var collageHeight: CGFloat { self == .space ? 346.58185 : 358 }
    var collageLayers: [LearningCollageLayer] { self == .space ? Self.spaceLayers : Self.photographyLayers }

    // Transparent Figma exports include the original cutouts, rotations and shadows.
    // Their render bounds preserve shadow padding and original positions.
    private static let spaceLayers: [LearningCollageLayer] = [
        .init(asset: "LearningSpaceTravel",
            frame: CGRect(x: -29.7429, y: -39.373, width: 296.7583, height: 225.707),
            hoverOffset: CGSize(width: -24, height: -20)),
        .init(asset: "LearningSpaceQuote",
            frame: CGRect(x: 171.5837, y: -39.3789, width: 295.5591, height: 133.9863),
            hoverOffset: CGSize(width: 28, height: -20)),
        .init(asset: "LearningSpaceTicket",
            frame: CGRect(x: 202.6685, y: 53.668, width: 261.8542, height: 187.166),
            hoverOffset: CGSize(width: 40, height: -8)),
        .init(asset: "LearningSpaceBubbles",
            frame: CGRect(x: -27.1646, y: 123.8105, width: 273.7634, height: 259.2713),
            hoverOffset: CGSize(width: -20, height: 8)),
        .init(asset: "LearningSpacePost",
            frame: CGRect(x: 142.5923, y: 198.5938, width: 325.25, height: 184.4881),
            hoverOffset: CGSize(width: 24, height: 8))
    ]
    private static let photographyLayers: [LearningCollageLayer] = [
        .init(asset: "LearningPhotographyBath",
            frame: CGRect(x: 10.0718, y: 0, width: 219.3565, height: 121.7164),
            hoverOffset: CGSize(width: -31.5388, height: -21.7779)),
        .init(asset: "LearningPhotographyYellowPost",
            frame: CGRect(x: 115.5339, y: 99.3398, width: 353.9434, height: 175.2715),
            hoverOffset: CGSize(width: 64.802, height: -9.0039)),
        .init(asset: "LearningPhotographyFeedback",
            frame: CGRect(x: 210.3423, y: 0.0006, width: 217.8153, height: 77.5811),
            hoverOffset: CGSize(width: 35.6736, height: -25.5)),
        .init(asset: "LearningPhotographyTravel",
            frame: CGRect(x: 12, y: 226.4922, width: 204.4216, height: 131.5078),
            hoverOffset: CGSize(width: -23.5, height: -30.3906)),
        .init(asset: "LearningPhotographyGreenPost",
            frame: CGRect(x: 152.0156, y: 239.4531, width: 315.3906, height: 155.0469),
            hoverOffset: CGSize(width: 26.8809, height: 0.9707))
    ]
    var color: Color {
        self == .space ? Color(red: 1, green: 241.0 / 255, blue: 204.0 / 255)
            : Color(red: 224.0 / 255, green: 245.0 / 255, blue: 1)
    }
}

private struct ArticleLibraryCard: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var isHovered = false
    let topic: LearningLibraryTopic
    let articles: [LearningArticle]
    let scale: CGFloat
    let hoverEnabled: Bool
    var openTopic: () -> Void
    var openArticle: (String) -> Void
    var learnTopic: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Button(action: openTopic) {
                VStack(alignment: .leading, spacing: 32 * scale) {
                    VStack(alignment: .leading, spacing: 12 * scale) {
                        Text(verbatim: topic.title)
                            .bubbleFont(.title, size: 48 * scale, weight: .medium, role: .word)
                            .lineLimit(1)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.trailing, 56 * scale)
                            .frame(height: 71 * scale)
                            .foregroundStyle(.black)
                        Text(verbatim: topic.caption).bubbleFont(.caption, size: 20 * scale)
                            .foregroundStyle(.black.opacity(0.5)).lineLimit(1)
                            .frame(height: 26 * scale, alignment: .leading)
                    }
                    Color.clear
                        .frame(height: topic.collageHeight * scale)
                        .overlay(alignment: .topLeading) {
                            LearningCardCollage(layers: topic.collageLayers, scale: scale,
                                expanded: isHovered && hoverEnabled && !reduceMotion)
                        }
                }
                .padding(36.5 * scale)
                .frame(maxWidth: .infinity)
                .frame(height: topic.height * scale, alignment: .topLeading)
                .background(alignment: .topLeading) {
                    LearningDotPattern(columns: 13, rows: 10, asset: "LearningDot")
                        .frame(width: 440 * scale, height: 348 * scale)
                        .offset(x: 36 * scale, y: 176 * scale)
                }
                .background {
                    RoundedRectangle(cornerRadius: 32 * scale, style: .continuous)
                        .fill(topic.color)
                        .shadow(color: .black.opacity(isHovered && hoverEnabled ? 0.06 : 0),
                            radius: 16 * scale, x: 0, y: 4 * scale)
                        .animation(reduceMotion ? nil : .easeInOut(duration: 0.20),
                            value: isHovered && hoverEnabled)
                }
                .overlay(RoundedRectangle(cornerRadius: 32 * scale, style: .continuous)
                    .strokeBorder(.black.opacity(0.15), lineWidth: 0.5 * scale))
                .contentShape(RoundedRectangle(cornerRadius: 32 * scale, style: .continuous))
            }
            .buttonStyle(.plain)
            .accessibilityLabel(topic.title)
            .accessibilityHint("打开文章")
            .accessibilityIdentifier("learning-topic-" + topic.id)

            Menu {
                Button("Learn more about this topic", action: learnTopic)
                Divider()
                Menu("My articles") {
                    ForEach(articles) { article in
                        Button(article.theme) { openArticle(article.id) }
                    }
                }
            } label: {
                Image("LearningMore").resizable().frame(width: 3 * scale, height: 13.8 * scale)
                    .frame(width: 32 * scale, height: 71 * scale)
            }
            .menuStyle(.borderlessButton).menuIndicator(.hidden).fixedSize()
            .accessibilityLabel("Article options")
            .accessibilityIdentifier("learning-topic-options-" + topic.id)
            .padding(36.5 * scale)
        }
        .onHover { isHovered = $0 && hoverEnabled }
        .onChange(of: hoverEnabled) { _, enabled in
            if !enabled { isHovered = false }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { isHovered = false }
        }
        .onDisappear { isHovered = false }
    }
}

private struct LearningCollageLayer: Identifiable {
    let asset: String
    let frame: CGRect
    let hoverOffset: CGSize
    var id: String { asset }
}

private struct LearningCardCollage: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let layers: [LearningCollageLayer]
    let scale: CGFloat
    let expanded: Bool
    private let hoverTravel: CGFloat = 0.15

    var body: some View {
        ZStack(alignment: .topLeading) {
            ForEach(layers) { layer in
                Image(layer.asset)
                    .resizable()
                    .frame(width: layer.frame.width * scale, height: layer.frame.height * scale)
                    .offset(
                        x: (layer.frame.minX + (expanded ? layer.hoverOffset.width * hoverTravel : 0)) * scale,
                        y: (layer.frame.minY + (expanded ? layer.hoverOffset.height * hoverTravel : 0)) * scale)
            }
        }
        .frame(width: 0, height: 0, alignment: .topLeading)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.20), value: expanded)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

private struct LearningDotPattern: View {
    let columns: Int
    let rows: Int
    let asset: String
    var body: some View {
        Canvas { context, size in
            let image = context.resolve(Image(asset))
            let diameter = size.width / CGFloat(columns == 30 ? 156.4 : 73.3333)
            for row in 0..<rows {
                for column in 0..<columns {
                    let x = CGFloat(column) * (size.width - diameter) / CGFloat(columns - 1)
                    let y = CGFloat(row) * (size.height - diameter) / CGFloat(rows - 1)
                    context.draw(image, in: CGRect(x: x, y: y, width: diameter, height: diameter))
                }
            }
        }
        .allowsHitTesting(false).accessibilityHidden(true)
    }
}

private struct ArticleGenerationDraft: Equatable {
    enum Topic: String, CaseIterable {
        case photography = "Photography", cooking = "Cooking", music = "Music", other = "Other"
        var icon: String {
            switch self {
            case .photography: return "📷"
            case .cooking: return "🍳"
            case .music: return "🎵"
            case .other: return "💡"
            }
        }
    }
    var topic: Topic?
    var customTopic = ""
    var scope: ArticleSavedWordScope?
    var wordCount: Int?
    var customLength = false
    var customWordCount = ""
    var notes = ""
    var resolvedTopic: String {
        topic == .other ? customTopic.trimmingCharacters(in: .whitespacesAndNewlines) : topic?.rawValue ?? ""
    }
    var resolvedWordCount: Int? { customLength ? Int(customWordCount) : wordCount }
    var hasRequiredSelections: Bool {
        topic != nil && scope != nil && (customLength || wordCount != nil)
    }
    var validation: String? {
        guard topic != nil else { return "Choose a topic you would like to explore." }
        if topic == .other && resolvedTopic.isEmpty { return "Enter a topic you would like to explore." }
        if resolvedTopic.count > 200 { return "Keep your topic under 200 characters." }
        guard scope != nil else { return "Choose which saved words to revisit." }
        if let count = resolvedWordCount, (200...2000).contains(count) { }
        else { return "Choose a length between 200 and 2000 words." }
        if notes.count > 1000 { return "Keep your notes under 1000 characters." }
        return nil
    }
}

private struct BubbleArticleGenerator: View {
    @Environment(BubbleStore.self) private var store
    @Binding var draft: ArticleGenerationDraft
    let scale: CGFloat
    let contentVisible: Bool
    var dismiss: () -> Void
    var onGenerate: () -> Void
    @FocusState private var focusedField: Field?
    private enum Field { case form, topic, length, notes }
    private var validation: String? {
        draft.validation
    }
    private var canGenerate: Bool { validation == nil && !store.generatingArticles }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 36 * scale) {
                Text(verbatim: "Learn something new in English")
                    .bubbleFont(.title, size: 36 * scale, weight: .medium, role: .word)
                    .foregroundStyle(BubbleContentStyle.text)
                    .frame(height: 65 * scale, alignment: .bottomLeading)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(alignment: .topLeading) {
                        LearningDotPattern(columns: 30, rows: 4, asset: "LearningHeaderDot")
                            .frame(height: 80 * scale)
                    }
                    .modifier(entrance(0))
                VStack(alignment: .leading, spacing: 32 * scale) {
                    field("What would you like to learn?") {
                        HStack(spacing: 16 * scale) {
                            ForEach(ArticleGenerationDraft.Topic.allCases, id: \.self) { topic in
                                chip(topic.rawValue, icon: topic.icon, selected: draft.topic == topic) {
                                    draft.topic = topic
                                    if topic == .other { focusedField = .topic }
                                }.accessibilityIdentifier("articleTheme-" + topic.rawValue)
                            }
                        }
                        if draft.topic == .other {
                            TextField("A topic you’re curious about…", text: $draft.customTopic)
                                .textFieldStyle(.plain).padding(12 * scale)
                                .background(ArticleReaderStyle.canvas, in: RoundedRectangle(cornerRadius: 10 * scale, style: .continuous))
                                .focused($focusedField, equals: .topic)
                                .accessibilityIdentifier("articleTopic")
                        }
                    }
                    .modifier(entrance(1))
                    field("How many saved words do you want to revisit?") {
                        HStack(spacing: 16 * scale) {
                            ForEach(ArticleSavedWordScope.allCases, id: \.self) { scope in
                                chip(scope.title, selected: draft.scope == scope) { draft.scope = scope }
                                    .help(scope == .recent ? "Words saved in the last seven days" : scope == .half ? "The most recently saved half of your words" : "Choose from all your saved words")
                                    .accessibilityIdentifier("articleScope-" + scope.rawValue)
                            }
                        }
                    }
                    .modifier(entrance(2))
                    field("How long would you like it to be?") {
                        HStack(spacing: 16 * scale) {
                            ForEach([1600, 800, 400], id: \.self) { count in
                                chip("\(count) words", selected: !draft.customLength && draft.wordCount == count) {
                                    draft.wordCount = count; draft.customLength = false
                                }.accessibilityIdentifier("articleLength-\(count)")
                            }
                            chip("Custom", selected: draft.customLength) {
                                draft.customLength = true; focusedField = .length
                            }.accessibilityIdentifier("articleLength-custom")
                        }
                        if draft.customLength {
                            TextField("200–2000 words", text: $draft.customWordCount)
                                .textFieldStyle(.plain).padding(12 * scale)
                                .background(ArticleReaderStyle.canvas, in: RoundedRectangle(cornerRadius: 10 * scale, style: .continuous))
                                .focused($focusedField, equals: .length)
                                .accessibilityIdentifier("articleCustomLength")
                        }
                    }
                    .modifier(entrance(3))
                    VStack(alignment: .leading, spacing: 16 * scale) {
                        fieldLabel("Anything else to add?")
                        ZStack(alignment: .topLeading) {
                            if draft.notes.isEmpty {
                                Text(verbatim: "Make it your own...")
                                    .foregroundStyle(Color.primary.opacity(0.43))
                                    .padding(.horizontal, 20 * scale).padding(.vertical, 16 * scale)
                                    .allowsHitTesting(false)
                            }
                            TextEditor(text: $draft.notes)
                                .scrollContentBackground(.hidden)
                                .padding(.horizontal, 15 * scale).padding(.vertical, 12 * scale)
                                .focused($focusedField, equals: .notes)
                                .accessibilityLabel("Anything else to add?")
                                .accessibilityIdentifier("articleNotes")
                        }
                        .font(.custom("PingFangSC-Regular", size: 20 * scale))
                        .frame(height: 100 * scale)
                        .background(ArticleReaderStyle.canvas, in: RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5 * scale))
                    }
                    .modifier(entrance(4))
                }
                HStack(spacing: 16 * scale) {
                    if let error = store.articleError {
                        Text(LocalizedStringKey(error)).foregroundStyle(.red).font(.system(size: 14 * scale))
                    } else if draft.hasRequiredSelections, let validation {
                        Text(verbatim: validation).foregroundStyle(.secondary).font(.system(size: 14 * scale))
                    }
                    Spacer(minLength: 0)
                    Button {
                        guard canGenerate else { return }
                        focusedField = nil
                        onGenerate()
                    } label: {
                        HStack(spacing: 8 * scale) {
                            if store.generatingArticles { ProgressView().controlSize(.small).tint(.white) }
                            Text(verbatim: store.generatingArticles ? "Creating your article…" : "Create my article")
                        }
                        .font(.custom("PingFangSC-Regular", size: 16 * scale))
                        .tracking(-0.23 * scale).foregroundStyle(.white.opacity(0.86))
                        .padding(.horizontal, 16 * scale).frame(height: 44 * scale)
                        .background(Color(white: 43.0 / 255), in: Capsule())
                        .contentShape(Capsule())
                    }
                    .buttonStyle(.plain)
                    .disabled(!canGenerate)
                    .opacity(canGenerate || store.generatingArticles ? 1 : 0.35)
                    .keyboardShortcut(.return, modifiers: .command)
                    .accessibilityIdentifier("generateThemeArticle")
                }
                .modifier(entrance(5))
            }
            .padding(36.5 * scale)
        }
        .scrollIndicators(.hidden)
        .clipShape(RoundedRectangle(cornerRadius: 32 * scale, style: .continuous))
        .disabled(store.generatingArticles)
        .focusable()
        .focusEffectDisabled()
        .focused($focusedField, equals: .form)
        .onAppear { focusedField = .form }
        .accessibilityLabel("Create a learning article")
        .accessibilityAction(.escape, dismiss)
    }

    private func entrance(_ order: Int) -> ArticleGeneratorEntrance {
        ArticleGeneratorEntrance(isPresented: contentVisible, order: order, scale: scale)
    }

    private func fieldLabel(_ title: String) -> some View {
        Text(verbatim: title).font(.custom("PingFangSC-Regular", size: 20 * scale))
            .foregroundStyle(BubbleContentStyle.text)
            .frame(height: 28 * scale, alignment: .leading).padding(.horizontal, 4 * scale)
    }

    private func field<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12 * scale) {
            fieldLabel(title)
            content()
        }
    }

    private func chip(_ title: String, icon: String? = nil, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6 * scale) {
                if let icon { Text(verbatim: icon) }
                Text(verbatim: title)
            }
            .font(.custom("PingFangSC-Regular", size: 15 * scale))
            .tracking(-0.23 * scale)
            .foregroundStyle(selected ? Color.white.opacity(0.95) : Color.primary.opacity(0.86))
            .padding(.horizontal, 10 * scale).frame(height: 36 * scale)
            .background(selected ? Color(white: 43.0 / 255) : Color.primary.opacity(0.05), in: Capsule())
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

private struct ArticleGeneratorEntrance: ViewModifier {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let isPresented: Bool
    let order: Int
    let scale: CGFloat
    @State private var isVisible = false

    func body(content: Content) -> some View {
        content
            .opacity(isVisible ? 1 : 0)
            .offset(y: isVisible || reduceMotion ? 0 : 14 * scale)
            .allowsHitTesting(isVisible)
            .disabled(!isVisible)
            .accessibilityHidden(!isVisible)
            .task(id: isPresented) {
                guard isPresented else { return }
                if !reduceMotion, order > 0 {
                    do { try await Task.sleep(for: .milliseconds(70 * order)) }
                    catch { return }
                }
                guard !Task.isCancelled else { return }
                withAnimation(reduceMotion ? .easeOut(duration: 0.16)
                    : .timingCurve(0.22, 1, 0.36, 1, duration: 0.42)) {
                    isVisible = true
                }
            }
    }
}

// Figma 1470:2993 / 1477:3190. Scale with the workspace, while keeping
// text and controls usable at the minimum supported Mac window width.
enum ArticleReaderStyle {
    static let bodyTextNative = NSColor(srgbRed: 85.0 / 255, green: 85.0 / 255, blue: 85.0 / 255, alpha: 1)
    static let bodyText = Color(nsColor: bodyTextNative)
    static let canvas = Color(nsColor: NSColor(name: nil) { appearance in
        appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
            ? NSColor(calibratedWhite: 0.10, alpha: 1) : NSColor(calibratedWhite: 251.0 / 255, alpha: 1)
    })
    static let surface = Color(nsColor: .textBackgroundColor)
    static let composerSurface = Color(nsColor: NSColor(name: nil) { appearance in
        appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
            ? NSColor(calibratedWhite: 0.14, alpha: 1) : NSColor(calibratedWhite: 248.0 / 255, alpha: 1)
    })
    static let border = Color.primary.opacity(0.15)
    static let scroller = NSColor(name: nil) { appearance in
        appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
            ? NSColor.white.withAlphaComponent(0.24) : NSColor.black.withAlphaComponent(0.18)
    }
    static let transition = Animation.spring(response: 0.48, dampingFraction: 0.88)
    static let stepTransition = Animation.easeInOut(duration: 0.42)
    static let confirmationTransition = Animation.easeInOut(duration: 0.32)
}

private struct ArticleReaderMetrics {
    let width: CGFloat
    var scale: CGFloat { min(1, max(0.65, width / 1728)) }
    var margin: CGFloat { 48 * scale }
    var gap: CGFloat { 48 * scale }
    var scrollerGutter: CGFloat { min(24, 32 * scale) }
    var panelWidth: CGFloat { 500 * scale }
    var panelInset: CGFloat { 32.5 * scale }
    var availableWidth: CGFloat { max(0, width - 2 * margin) }
    var floatingComposerWidth: CGFloat { min(435 * scale, availableWidth) }
    var bodySize: CGFloat { 20 * scale }
    func readingWidth(chatOpen: Bool) -> CGFloat {
        min(1084 * scale, max(0, availableWidth - (chatOpen ? panelWidth + gap : 0)))
    }
}

private struct ArticleReadingScrollEdges: ViewModifier {
    let scale: CGFloat
    let topInset: CGFloat
    private var barHeight: CGFloat { 40 * scale }
    private var fadeHeight: CGFloat { 8 * scale }

    func body(content: Content) -> some View {
        Group {
            if #available(macOS 26, *) {
                content
                    .safeAreaBar(edge: .top, spacing: 0) {
                        edgeBar.padding(.bottom, max(0, topInset - 6))
                    }
                    .safeAreaBar(edge: .bottom, spacing: 0) {
                        edgeBar.padding(.top, barHeight - 6)
                    }
                    .scrollEdgeEffectStyle(.soft, for: [.top, .bottom])
                    .scrollEdgeEffectHidden(false, for: [.top, .bottom])
                    .mask { edgeMask }
                    // Extend the scroll viewport behind the entire titlebar.
                    // The top safe-area bar keeps the resting title in place,
                    // while scrolled content stays visible through native blur
                    // all the way to the window's top edge.
                    .padding(.top, -topInset)
                    .padding(.bottom, -barHeight)
            } else {
                content
                    .padding(.vertical, fadeHeight)
                    .mask { edgeMask }
                    .padding(.vertical, -fadeHeight)
            }
        }
    }

    private var edgeBar: some View {
        // As on the record page, a text layout gives safeAreaBar the content
        // geometry needed for native blur; Color.clear only produces a fade.
        Text(verbatim: " ")
            .frame(maxWidth: .infinity)
            .frame(height: 6)
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }

    private var edgeMask: some View {
        VStack(spacing: 0) {
            LinearGradient(colors: [.clear, .black], startPoint: .top, endPoint: .bottom)
                .frame(height: fadeHeight)
            Rectangle().fill(.black)
            LinearGradient(colors: [.black, .clear], startPoint: .top, endPoint: .bottom)
                .frame(height: fadeHeight)
        }
    }
}

private struct BubbleArticleReader: View {
    @Environment(BubbleStore.self) private var store
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let articleID: String
    var preview: ArticleGenerationPreview? = nil
    var onBack: () -> Void
    @State private var chatOpen = false
    @State private var draft = ""
    @State private var quoteError: String?
    @State private var pendingQuestion: String?
    @State private var pendingID = UUID().uuidString.lowercased()
    @State private var asking = false
    @State private var replyError: String?
    @State private var requestTask: Task<Void, Never>?
    @State private var composerHeight: CGFloat = 44
    @State private var editingOutline = false
    @State private var selectedExpression: LearningArticle.Expression?
    @State private var source: BubbleCapture?
    @State private var practiceFeedback: String?
    @FocusState private var composerFocused: Bool
    private var isDesignArticle: Bool { articleID == ArticleDesignContent.id }
    private var showsConversation: Bool {
        chatOpen || (preview.map { !$0.opensAsFinishedArticle || !$0.isComplete } ?? false)
    }
    private var article: LearningArticle? {
        preview?.article ?? (isDesignArticle ? ArticleDesignContent.article : store.articles.first { $0.id == articleID })
    }
    private var canSend: Bool {
        preview?.isRewinding != true && preview?.planAdjustmentPhase != .submitted && !asking
            && (preview?.quotedSelection == nil || preview?.canEditLocally == true)
            && !draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && draft.count <= 2000
    }
    private var showsStop: Bool {
        preview?.isGenerating == true && draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    private var generationAnchor: String? {
        guard let preview else { return nil }
        if preview.isComplete { return "preview-outline" }
        if preview.isShowingRevisedOutline { return "preview-outline" }
        switch preview.step {
        case .outline, .research: return "preview-outline"
        case .writing: return "preview-section-\(preview.writingSectionIndex ?? 0)"
        case .images: return "preview-image"
        case .artifact: return "preview-camera"
        }
    }
    private var completionMessageID: String? {
        preview?.completionMessageID
    }

    var body: some View {
        GeometryReader { geometry in
            let metrics = ArticleReaderMetrics(width: geometry.size.width)
            let contentTop = max(152 * metrics.scale, geometry.frame(in: .global).minY)
            ZStack(alignment: .bottomTrailing) {
                HStack(alignment: .top, spacing: showsConversation ? metrics.gap : 0) {
                    readingPane(metrics, topInset: contentTop)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                    if showsConversation {
                        conversation(metrics)
                            .frame(width: metrics.panelWidth)
                            .transition(reduceMotion ? .identity : .move(edge: .trailing).combined(with: .opacity))
                    }
                }
                ZStack(alignment: .bottom) {
                    if let preview, preview.isAwaitingOutlineConfirmation {
                        outlineConfirmation(preview, metrics: metrics)
                            // Both states share the composer's bottom anchor. Positive
                            // offset rises on insertion and sinks on removal, without a wipe.
                            .transition(reduceMotion ? .opacity : .offset(y: 24 * metrics.scale).combined(with: .opacity))
                            .zIndex(1)
                    } else {
                        composer(metrics)
                            .transition(reduceMotion ? .opacity : .opacity.combined(with: .offset(y: 12 * metrics.scale)))
                    }
                }
                    .animation(reduceMotion ? .easeOut(duration: 0.12) : ArticleReaderStyle.confirmationTransition,
                               value: preview?.isAwaitingOutlineConfirmation)
                    .frame(width: showsConversation ? metrics.panelWidth - 2 * metrics.panelInset : metrics.floatingComposerWidth)
                    .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { composerHeight = $0 }
                    .padding(.trailing, showsConversation ? metrics.panelInset : (metrics.availableWidth - metrics.floatingComposerWidth) / 2)
                    .padding(.bottom, showsConversation ? metrics.panelInset : 0)
                    .zIndex(1)
            }
            .padding(.horizontal, metrics.margin)
            // Figma's content starts at y=152, including the header. Account
            // for the native toolbar instead of adding its height a second time.
            .padding(.top, contentTop - geometry.frame(in: .global).minY)
            .padding(.bottom, metrics.margin)
            .animation(reduceMotion ? nil : ArticleReaderStyle.transition, value: chatOpen)
        }
        .background(ArticleReaderStyle.canvas)
        .toolbar {
            ToolbarItem(placement: .navigation) {
                Button(action: onBack) { Label("所有文章", systemImage: "chevron.left") }
                    .labelStyle(.iconOnly).help("所有文章")
                    .accessibilityIdentifier("backToArticles")
            }
            ToolbarItem(placement: .primaryAction) {
                if !isDesignArticle, !showsConversation, !(preview?.messages.isEmpty ?? article?.messages.isEmpty ?? true) || pendingQuestion != nil {
                    Button("继续对话", systemImage: "bubble.left.and.bubble.right") { chatOpen = true }
                        .labelStyle(.iconOnly).help("继续对话")
                        .accessibilityIdentifier("reopenArticleConversation")
                }
            }
        }
        .onExitCommand { chatOpen = false }
        .popover(item: $selectedExpression) { expression in
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text(expression.text).bubbleFont(.title3, weight: .semibold)
                    Spacer()
                    SpeechControls(text: expression.text, iconOnly: true)
                }
                Text(expression.meaning).textSelection(.enabled)
                HStack {
                    Button("查看原始记录") {
                        source = store.state.captures[expression.captureId]; selectedExpression = nil
                    }
                    Button("问问 AI") {
                        selectedExpression = nil
                        submit(BubbleLocalization.text("请结合这篇文章，解释 “%@” 的意思和用法。", expression.text))
                    }
                }
            }.padding(22).frame(width: 340)
        }
        .sheet(item: $source) { capture in
            NavigationStack {
                BubbleCaptureView(recordID: BubbleRecord.key(for: capture))
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { source = nil } } }
            }.frame(width: 660, height: 600)
                .environment(\.locale, Locale(identifier: UserDefaults.standard.string(forKey: "bubbleInterfaceLanguage") ?? "zh-Hans"))
        }
        .task(id: preview?.runID) { await preview?.run(reduceMotion: reduceMotion) }
        .onChange(of: preview?.isAwaitingOutlineConfirmation) { _, _ in editingOutline = false }
        .onDisappear { requestTask?.cancel() }
    }

    private func readingPane(_ metrics: ArticleReaderMetrics, topInset: CGFloat) -> some View {
        ScrollViewReader { proxy in
        ScrollView {
            Group {
                if let preview {
                    ArticlePreviewReading(preview: preview, scale: metrics.scale, onQuote: { selection in
                        guard preview.quoteSelection(selection) else { return }
                        quoteError = nil
                        chatOpen = true
                        composerFocused = true
                    })
                        .padding(.trailing, metrics.scrollerGutter)
                        .padding(.bottom, showsConversation ? 40 * metrics.scale
                            : max(104 * metrics.scale, composerHeight + 24 * metrics.scale))
                        .background(BubbleScrollIndicatorStyle(hidesIndicator: true))
                } else if let article {
                    VStack(alignment: .leading, spacing: 12 * metrics.scale) {
                        Text(article.title)
                            .bubbleFont(.largeTitle, size: 48 * metrics.scale, weight: .medium, role: .word)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.bottom, 16 * metrics.scale)
                            .accessibilityIdentifier("articleTitle")
                        if isDesignArticle {
                            ArticlePhotographyContent(scale: metrics.scale)
                        } else {
                            Text(article.summary)
                                .bubbleFont(.body, size: metrics.bodySize)
                                .foregroundStyle(ArticleReaderStyle.bodyText)
                                .lineSpacing(2 * metrics.scale).textSelection(.enabled)
                            if let imageID = articleImages(article).first {
                                articleImage(imageID, metrics: metrics)
                            }
                            ForEach(Array(article.sections.enumerated()), id: \.offset) { index, section in
                                ArticleReadingSection(section: section, expressions: article.expressions, scale: metrics.scale,
                                    onExpression: { selectedExpression = $0 })
                                    .accessibilityIdentifier("articleSection-\(index)")
                                ForEach(sectionImages(article, index: index), id: \.self) { imageID in
                                    articleImage(imageID, metrics: metrics)
                                }
                            }
                        }
                    }
                    .foregroundStyle(.primary)
                    .padding(.bottom, max(104 * metrics.scale, composerHeight + 24 * metrics.scale))
                    .padding(.trailing, metrics.scrollerGutter)
                    .background(BubbleScrollIndicatorStyle(hidesIndicator: true))
                }
            }
            // Constrain the text column, while keeping its side margins scrollable.
            .frame(width: metrics.readingWidth(chatOpen: showsConversation) + metrics.scrollerGutter)
            .frame(maxWidth: .infinity)
        }
        .task(id: generationAnchor) {
            guard let generationAnchor else { return }
            // Leave the generated illustration visible before moving to the 3D
            // region, and pause there before returning to the completed article.
            // Other sections only need time to participate in layout. A newer
            // anchor or leaving the reader cancels this pending scroll.
            let delay: Duration = generationAnchor == "preview-camera" || preview?.isComplete == true
                ? .milliseconds(500) : .milliseconds(80)
            do { try await Task.sleep(for: delay) } catch { return }
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.55)) {
                proxy.scrollTo(generationAnchor, anchor: UnitPoint(x: 0, y: 0.12))
            }
        }
        // Keep the native scroller infrastructure for macOS 26 soft-edge blur;
        // the probe suppresses its drawing and hit testing in both article modes.
        .scrollIndicators(.automatic)
        .accessibilityIdentifier("articleReadingPane")
        .modifier(ArticleReadingScrollEdges(scale: metrics.scale, topInset: topInset))
        // Put the system scroller in the existing column gap. Compensating
        // outside the viewport preserves the article's width and alignment.
        .padding(.trailing, -metrics.scrollerGutter)
        }
    }

    private func articleImages(_ article: LearningArticle) -> [String] {
        var seen = Set<String>()
        return article.captureIds.compactMap { store.state.captures[$0] }.flatMap(\.assetIds).filter { seen.insert($0).inserted }
    }

    private func sectionImages(_ article: LearningArticle, index: Int) -> [String] {
        var seen = Set(articleImages(article).prefix(1))
        for section in article.sections.prefix(index) {
            for asset in section.captureIds.compactMap({ store.state.captures[$0] }).flatMap(\.assetIds) { seen.insert(asset) }
        }
        return article.sections[index].captureIds.compactMap { store.state.captures[$0] }
            .flatMap(\.assetIds).filter { seen.insert($0).inserted }
    }

    private func articleImage(_ assetID: String, metrics: ArticleReaderMetrics) -> some View {
        Color.primary.opacity(0.035)
            .aspectRatio(803.0 / 389, contentMode: .fit)
            .overlay { ArticleOriginalImage(assetID: assetID) }
            .clipShape(RoundedRectangle(cornerRadius: 12 * metrics.scale, style: .continuous))
            .overlay { RoundedRectangle(cornerRadius: 12 * metrics.scale, style: .continuous).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5) }
            .padding(.vertical, 16 * metrics.scale)
            .onTapGesture {
                source = article?.captureIds.compactMap { store.state.captures[$0] }.first { $0.assetIds.contains(assetID) }
            }
            .accessibilityAddTraits(.isButton)
            .help("查看原始记录")
    }

    private func conversation(_ metrics: ArticleReaderMetrics) -> some View {
        GeometryReader { panelGeometry in
        ScrollViewReader { proxy in
            ScrollView {
                // Native selectable messages need stable heights when the quote
                // attachment changes the viewport above the composer.
                VStack(alignment: .leading, spacing: 24 * metrics.scale) {
                    if let preview {
                        VStack(alignment: .leading, spacing: 32 * metrics.scale) {
                            if !preview.opensAsFinishedArticle || !preview.isComplete || preview.thinkingSeconds > 0 {
                                Text("我将根据你的内容创建学习材料。以下是生成计划，你可以随时暂停或补充要求。")
                                    .modifier(ArticleBodyTypography(scale: metrics.scale))
                                    .fixedSize(horizontal: false, vertical: true)
                                if preview.latestPlanMessageID == nil {
                                    ArticlePreviewProgress(preview: preview, scale: metrics.scale)
                                }
                            }
                        }
                        .id("generation-plan")
                        ForEach(preview.messages.filter {
                            !preview.isAwaitingOutlineConfirmation && $0.text != ArticleGenerationPreview.outlineConfirmationPrompt
                                && !preview.outlineApprovalMessageIDs.contains($0.id)
                        }) { message in
                            VStack(alignment: .leading, spacing: 16 * metrics.scale) {
                                if let comment = preview.localEditComments[message.id] {
                                    ArticleLocalCommentMessage(edit: comment, scale: metrics.scale)
                                } else if message.text != ArticleGenerationPreview.outlineConfirmationPrompt {
                                    messageView(message.text, fromUser: message.role == "user", metrics: metrics)
                                }
                                if message.id == preview.latestPlanMessageID {
                                    ArticlePreviewProgress(preview: preview, scale: metrics.scale)
                                        .transition(reduceMotion ? .opacity : .opacity.combined(with: .offset(y: 12 * metrics.scale)))
                                }
                                if message.id == preview.completionMessageID,
                                   !preview.suggestions.isEmpty, preview.quotedSelection == nil {
                                    completionSuggestions(preview, metrics: metrics)
                                        .padding(.top, 8 * metrics.scale)
                                }
                            }
                            .modifier(ArticleDiscardTransition(discarding: preview.isDiscardingMessage(message.id)))
                            .id(message.id)
                            .transition(reduceMotion ? .opacity : .opacity.combined(with: .offset(y: 16 * metrics.scale)))
                        }
                        if let edit = preview.localEdit {
                            HStack(spacing: 10 * metrics.scale) {
                                ProgressView().controlSize(.small)
                                Text(edit.selection.target == .image ? "正在更新配图…" : "正在修改选中的文本…")
                                Spacer(minLength: 0)
                                Button("取消") { preview.cancelLocalEdit() }.buttonStyle(.plain)
                            }.bubbleFont(.body, size: 16 * metrics.scale)
                                .foregroundStyle(.secondary)
                                .accessibilityIdentifier("articleLocalEditProgress")
                        }
                    } else if isDesignArticle {
                        Text("摄影练习")
                            .bubbleFont(.caption, size: 16 * metrics.scale, weight: .medium)
                            .foregroundStyle(.secondary)
                        ArticleAssistantMessage(text: ArticleDesignContent.lesson, scale: metrics.scale, enabled: true) { answer in
                            practiceFeedback = answer.components(separatedBy: "\n").last?.hasPrefix("A.") == true
                                ? "答对了！调整位置可以让栏杆的线条指向主体。再拍一张，比较哪一处最先吸引你的视线。"
                                : "先试着调整位置。改变颜色或相机设置不会改变栏杆的指向，找一个能让线条引导视线看向主体的角度吧。"
                        }
                        if let practiceFeedback {
                            Text(practiceFeedback).modifier(ArticleBodyTypography(scale: metrics.scale))
                                .textSelection(.enabled).accessibilityIdentifier("photographyPracticeFeedback")
                        }
                    } else {
                        ForEach(article?.messages ?? []) { message in
                            messageView(message.text, fromUser: message.role == "user", metrics: metrics).id(message.id)
                        }
                        if let pendingQuestion, !(article?.messages.contains(where: { $0.id == pendingID }) ?? false) {
                            messageView(pendingQuestion, fromUser: true, metrics: metrics)
                        }
                        if asking {
                            HStack(spacing: 9) {
                                ProgressView().controlSize(.small)
                                Text("正在思考…").foregroundStyle(.secondary)
                            }.bubbleFont(.body, size: metrics.bodySize)
                        }
                        if let replyError {
                            VStack(alignment: .leading, spacing: 12) {
                                Text(LocalizedStringKey(replyError)).foregroundStyle(.secondary)
                                Button("重试这条问题") { sendPending() }.disabled(asking)
                                    .accessibilityIdentifier("retryArticleQuestion")
                            }.bubbleFont(.body, size: metrics.bodySize)
                        }
                    }
                    Color.clear.frame(height: 1).id("latest")
                }
                .padding(metrics.panelInset)
                .animation(reduceMotion ? nil : ArticleReaderStyle.stepTransition, value: preview?.isComplete)
                .animation(reduceMotion ? nil : ArticleReaderStyle.stepTransition, value: preview?.latestPlanMessageID)
            }
            .scrollIndicators(.hidden)
            .onChange(of: preview?.messages.count) { _, _ in
                if preview?.isRewinding != true && preview?.isAwaitingOutlineConfirmation != true {
                    if preview?.planAdjustmentPhase != nil,
                       let userMessage = preview?.messages.last(where: { $0.role == "user" }) {
                        withAnimation(reduceMotion ? nil : ArticleReaderStyle.stepTransition) {
                            proxy.scrollTo(userMessage.id, anchor: .top)
                        }
                    } else if let completionMessageID, preview?.messages.last?.id == completionMessageID {
                        proxy.scrollTo(preview?.latestPlanMessageID ?? "generation-plan", anchor: .top)
                    } else if let preview, let last = preview.messages.last, preview.outlineApprovalMessageIDs.contains(last.id) {
                        // The approval is hidden; keep the current plan's scroll position.
                    } else { proxy.scrollTo("latest", anchor: .bottom) }
                }
            }
            .onChange(of: preview?.isComplete) { _, complete in
                if complete == true { proxy.scrollTo(preview?.latestPlanMessageID ?? "generation-plan", anchor: .top) }
            }
            .onChange(of: article?.messages.count) { _, _ in proxy.scrollTo("latest", anchor: .bottom) }
            .onChange(of: asking) { _, _ in proxy.scrollTo("latest", anchor: .bottom) }
            .onAppear {
                if preview?.isComplete == true {
                    proxy.scrollTo(preview?.latestPlanMessageID ?? "generation-plan", anchor: .top)
                } else if preview == nil && !isDesignArticle { proxy.scrollTo("latest", anchor: .bottom) }
            }
        }
        }
        .padding(.bottom, composerHeight + metrics.panelInset)
        .frame(maxHeight: .infinity)
        .background(ArticleReaderStyle.surface, in: RoundedRectangle(cornerRadius: 32 * metrics.scale, style: .continuous))
        .clipShape(RoundedRectangle(cornerRadius: 32 * metrics.scale, style: .continuous))
        .overlay { RoundedRectangle(cornerRadius: 32 * metrics.scale, style: .continuous).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5) }
        .accessibilityIdentifier("articleConversation")
    }

    // Figma 1630:1438: intrinsic-width prompts, 24 pt below the completion copy.
    private func completionSuggestions(_ preview: ArticleGenerationPreview, metrics: ArticleReaderMetrics) -> some View {
        VStack(alignment: .leading, spacing: 24 * metrics.scale) {
            ForEach(preview.suggestions, id: \.self) { suggestion in
                Button {
                    // Suggested prompts are independent of an unsent composer draft.
                    preview.reply(to: suggestion)
                } label: {
                    Text(suggestion)
                        .modifier(ArticleBodyTypography(scale: metrics.scale))
                        .foregroundStyle(.primary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, 24.5 * metrics.scale)
                        .padding(.vertical, 16.5 * metrics.scale)
                        .background(Color(white: 242.0 / 255).opacity(0.3), in: RoundedRectangle(cornerRadius: 16 * metrics.scale))
                        .overlay {
                            RoundedRectangle(cornerRadius: 16 * metrics.scale)
                                .strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5 * metrics.scale)
                        }
                        .contentShape(RoundedRectangle(cornerRadius: 16 * metrics.scale))
                }
                .buttonStyle(ArticleSendButtonStyle())
                .accessibilityIdentifier(suggestion == ArticleGenerationPreview.quizSuggestion
                    ? "articleSuggestQuiz" : "articleSuggestSimplify")
            }
        }
    }

    // Figma 1561:43392: a compact confirmation card anchored over the composer.
    private func outlineConfirmation(_ preview: ArticleGenerationPreview, metrics: ArticleReaderMetrics) -> some View {
        let scale = metrics.scale
        let updating = editingOutline || !draft.isEmpty
        let shape = RoundedRectangle(cornerRadius: 28.8 * scale)
        let foreground = Color(red: 43.0 / 255, green: 43.0 / 255, blue: 43.0 / 255)
        return VStack(alignment: .leading, spacing: 3.6 * scale) {
            VStack(alignment: .leading, spacing: 0) {
                Text(updating ? "你希望如何调整这个大纲？" : ArticleGenerationPreview.outlineConfirmationPrompt)
                    .bubbleFont(.body, size: 20 * scale)
                    .foregroundStyle(foreground)
                    .lineSpacing(6 * scale)
                    .frame(maxWidth: .infinity, minHeight: 30 * scale, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.leading, 12 * scale).padding(.trailing, 8 * scale)
                    .padding(.vertical, 2 * scale)
                Color.clear.frame(height: 18 * scale).accessibilityHidden(true)
            }
            if let feedback = preview.outlineFeedback {
                Text(feedback).bubbleFont(.caption, size: 13 * scale)
                    .foregroundStyle(.secondary).padding(.horizontal, 12 * scale)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("articleOutlineFeedback")
            }
            if updating {
                HStack(spacing: 8 * scale) {
                    TextField("说说你想怎么学…", text: $draft, axis: .vertical)
                        .textFieldStyle(.plain).lineLimit(1...3)
                        .bubbleFont(.body, size: 14.4 * scale)
                        .focused($composerFocused)
                        .onSubmit { updateOutline(preview) }
                        .accessibilityLabel("补充大纲要求")
                        .accessibilityIdentifier("articleOutlineComposer")
                    if !draft.isEmpty {
                        Button { updateOutline(preview) } label: {
                            Image(systemName: "arrow.up").font(.system(size: 14 * scale, weight: .semibold))
                                .foregroundStyle(ArticleReaderStyle.surface)
                                .frame(width: 28 * scale, height: 28 * scale)
                                .background(Color.primary, in: Circle())
                        }.buttonStyle(.plain).disabled(!canSend)
                            .help("更新大纲").accessibilityLabel("更新大纲")
                            .accessibilityIdentifier("sendOutlineRevision")
                    }
                }
                .padding(.horizontal, 16 * scale).padding(.vertical, 10 * scale)
                .frame(minHeight: 50.4 * scale)
                .background(Color(red: 204.0 / 255, green: 196.0 / 255, blue: 192.0 / 255).opacity(0.2),
                            in: RoundedRectangle(cornerRadius: 23.4 * scale))
                .padding(.horizontal, 8 * scale).padding(.bottom, 8 * scale)
                if draft.count > 2000 {
                    Text("请控制在 2000 字以内。").bubbleFont(.caption, size: 12 * scale).foregroundStyle(.red)
                        .padding(.horizontal, 12 * scale)
                }
            }
            Button {
                if updating { editingOutline = false; draft = "" }
                else { editingOutline = true }
                composerFocused = editingOutline
            } label: {
                Text(updating ? "取消修改" : "拒绝")
                    .bubbleFont(.body, size: 16 * scale)
                    .foregroundStyle(foreground)
                    .frame(maxWidth: .infinity).frame(height: 48 * scale)
                    .overlay(RoundedRectangle(cornerRadius: 16 * scale).strokeBorder(Color.black.opacity(0.2), lineWidth: scale))
                    .contentShape(RoundedRectangle(cornerRadius: 16 * scale))
            }.buttonStyle(.plain).accessibilityIdentifier("denyArticleOutline")
                .padding(.horizontal, 8 * scale).padding(.top, 2 * scale).padding(.bottom, 8 * scale)
            Button {
                if updating {
                    updateOutline(preview)
                } else {
                    withAnimation(reduceMotion ? .easeOut(duration: 0.12) : ArticleReaderStyle.confirmationTransition) {
                        _ = preview.confirmOutline()
                    }
                    composerFocused = false
                }
            } label: {
                Text(updating ? "更新大纲" : "执行")
                    .bubbleFont(.body, size: 16 * scale)
                    .frame(maxWidth: .infinity).frame(height: 48 * scale)
                    .foregroundStyle(Color(red: 226.0 / 255, green: 221.0 / 255, blue: 217.0 / 255))
                    .background(Color(red: 39.0 / 255, green: 35.0 / 255, blue: 32.0 / 255),
                                in: RoundedRectangle(cornerRadius: 16 * scale))
                    .opacity(updating && !canSend ? 0.45 : 1)
            }.buttonStyle(.plain).disabled(updating && !canSend)
                .accessibilityIdentifier(updating ? "updateArticleOutline" : "confirmArticleOutline")
                .padding(.horizontal, 8 * scale).padding(.top, 2 * scale).padding(.bottom, 8 * scale)
        }
        .padding(.horizontal, 9 * scale).padding(.top, 16 * scale).padding(.bottom, 10 * scale)
        .frame(maxWidth: 669.6 * scale)
        .background(Color.white.opacity(0.94), in: shape)
        .background(.ultraThinMaterial, in: shape)
        .overlay { shape.strokeBorder(Color.black.opacity(0.15), lineWidth: 0.5 * scale) }
        .shadow(color: .black.opacity(0.10), radius: 12 * scale, y: 4 * scale)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("articleOutlineConfirmation")
    }

    private func updateOutline(_ preview: ArticleGenerationPreview) {
        if preview.reviseOutline(draft) {
            draft = ""
            editingOutline = false
            composerFocused = false
        }
    }

    private func composer(_ metrics: ArticleReaderMetrics) -> some View {
        let hasQuote = preview?.quotedSelection != nil
        return VStack(alignment: .leading, spacing: 6) {
            if draft.count > 2000 {
                Text("问题请控制在 2000 字以内。")
                    .bubbleFont(.caption, size: 12).foregroundStyle(.red)
                    .padding(.horizontal, 16)
            }
            if let quoteError {
                Text(quoteError).bubbleFont(.caption, size: 12 * metrics.scale)
                    .foregroundStyle(.secondary).padding(.horizontal, 16 * metrics.scale)
            }
            VStack(alignment: .leading, spacing: 16 * metrics.scale) {
                if let preview, let selection = preview.quotedSelection {
                    ArticleComposerQuote(selection: selection, imageCaption: preview.imageCaption, scale: metrics.scale) {
                        preview.removeQuote()
                        quoteError = nil
                        composerFocused = true
                    }
                }
                HStack(alignment: .center, spacing: 8 * metrics.scale) {
                    TextField("说说你想怎么学…", text: $draft, axis: .vertical)
                        .disabled(preview?.isRewinding == true || preview?.planAdjustmentPhase == .submitted)
                        .textFieldStyle(.plain).lineLimit(1...4)
                        .bubbleFont(.body, size: metrics.bodySize)
                        .focused($composerFocused).onSubmit { submit(draft) }
                        .accessibilityLabel(preview?.isComplete == false ? "输入要求，调整计划和大纲" : "围绕这篇文章，问点什么…")
                        .accessibilityIdentifier("articleComposer")
                    Button {
                        if showsStop { preview?.stop() }
                        else { submit(draft) }
                    } label: {
                        Group {
                            if showsStop {
                                RoundedRectangle(cornerRadius: 2 * metrics.scale, style: .continuous)
                                    .frame(width: 13 * metrics.scale, height: 13 * metrics.scale)
                                    .frame(width: 24 * metrics.scale, height: 24 * metrics.scale)
                            } else {
                                Image("ArticleSendArrow").renderingMode(.template)
                                    .resizable().frame(width: 15.9955 * metrics.scale, height: 18 * metrics.scale)
                                    .frame(width: 24 * metrics.scale, height: 24 * metrics.scale)
                            }
                        }
                        .foregroundStyle(ArticleReaderStyle.surface)
                        .frame(width: 36 * metrics.scale, height: 36 * metrics.scale)
                        .background(showsStop || canSend ? Color.primary : Color(white: 178.0 / 255), in: Circle())
                        .frame(width: 44 * metrics.scale, height: 44 * metrics.scale)
                        .contentShape(Circle())
                    }
                    .buttonStyle(ArticleSendButtonStyle()).disabled(!showsStop && !canSend)
                    .help(showsStop ? "停止生成" : preview?.isAwaitingOutlineConfirmation == true ? "发送补充要求并生成" : preview?.isGenerating == true ? "发送调整" : "发送问题")
                    .accessibilityLabel(showsStop ? "停止生成" : preview?.isAwaitingOutlineConfirmation == true ? "发送补充要求并生成" : preview?.isGenerating == true ? "发送调整" : "发送问题")
                    .accessibilityIdentifier(showsStop ? "stopArticleGeneration" : "sendArticleQuestion")
                }
                .padding(.leading, (hasQuote ? 4 : 24) * metrics.scale)
                .padding(.trailing, (hasQuote ? 0 : 9) * metrics.scale)
            }
            .padding(hasQuote ? 12 * metrics.scale : 0)
            .padding(.vertical, hasQuote ? 0 : 10 * metrics.scale)
            .frame(minHeight: (hasQuote ? 120 : 64) * metrics.scale)
            .background(preview != nil || !showsConversation ? ArticleReaderStyle.surface : ArticleReaderStyle.composerSurface, in: RoundedRectangle(cornerRadius: (hasQuote ? 28 : 32) * metrics.scale, style: .continuous))
            .overlay { RoundedRectangle(cornerRadius: (hasQuote ? 28 : 32) * metrics.scale, style: .continuous).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5) }
            .shadow(color: .black.opacity(showsConversation ? 0 : 0.10), radius: 20 * metrics.scale)
        }
    }

    @ViewBuilder
    private func messageView(_ text: String, fromUser: Bool, metrics: ArticleReaderMetrics) -> some View {
        if fromUser {
            HStack {
                Spacer(minLength: 24)
                Text(text).textSelection(.enabled)
                    .padding(.horizontal, (preview == nil ? 16 : 32) * metrics.scale)
                    .padding(.vertical, (preview == nil ? 12 : 20) * metrics.scale)
                    .background {
                        let shape = RoundedRectangle(cornerRadius: 16 * metrics.scale, style: .continuous)
                        if preview != nil {
                            shape.fill(Color(red: 1, green: 250.0 / 255, blue: 240.0 / 255)
                                .shadow(.inner(color: Color(red: 1, green: 170.0 / 255, blue: 0).opacity(0.12), radius: 20 * metrics.scale)))
                                .overlay(shape.strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
                        } else { shape.fill(Color.primary.opacity(0.045)) }
                    }
            }.bubbleFont(.body, size: metrics.bodySize).lineSpacing(3 * metrics.scale)
        } else {
            ArticleAssistantMessage(text: text, scale: metrics.scale, enabled: !asking, onAnswer: submit)
        }
    }

    private func submit(_ question: String) {
        let question = question.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !question.isEmpty, question.count <= 2000, !asking else { return }
        if let preview {
            chatOpen = true
            if preview.quotedSelection != nil {
                guard preview.canEditLocally else { return }
                guard preview.regenerateQuotedSelection(comment: question) else {
                    quoteError = "引用内容已发生变化，请重新引用。"
                    return
                }
                draft = ""
                quoteError = nil
                return
            }
            draft = ""
            if preview.isComplete { preview.reply(to: question) }
            else { preview.steer(question) }
            return
        }
        if isDesignArticle {
            draft = ""; chatOpen = true
            return
        }
        pendingQuestion = question; pendingID = UUID().uuidString.lowercased()
        draft = ""; chatOpen = true
        sendPending()
    }

    private func sendPending() {
        guard let pendingQuestion, !asking else { return }
        asking = true; replyError = nil
        requestTask = Task {
            defer { asking = false }
            do {
                try await store.askArticle(articleID, question: pendingQuestion, requestID: pendingID)
                self.pendingQuestion = nil
            } catch is CancellationError { }
            catch { replyError = error.localizedDescription }
        }
    }
}

private struct ArticleCameraStudy: View {
    let scale: CGFloat
    @State private var contentHeight: CGFloat = 720

    var body: some View {
        CameraStudyWebView(contentHeight: $contentHeight)
            .frame(height: contentHeight)
            .frame(maxWidth: .infinity)
            .accessibilityIdentifier("articleCameraStudy")
    }
}

private struct CameraStudyWebView: NSViewRepresentable {
    @Binding var contentHeight: CGFloat

    func makeCoordinator() -> Coordinator { Coordinator(height: $contentHeight) }

    func makeNSView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.userContentController.add(context.coordinator, name: "cameraStudy")
        // The article provides its own orbit controls and keyboard instructions.
        let hintStyle = WKUserScript(source: """
            if (location.hostname === 'sketchfab.com') {
                const style = document.createElement('style');
                style.textContent = '.viewer-movehint { display: none !important; }';
                document.head.appendChild(style);
            }
            """, injectionTime: .atDocumentEnd, forMainFrameOnly: false)
        configuration.userContentController.addUserScript(hintStyle)
        configuration.mediaTypesRequiringUserActionForPlayback = []
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = context.coordinator
        view.uiDelegate = context.coordinator
        view.setValue(false, forKey: "drawsBackground")
        context.coordinator.forwardScrollingToArticle(from: view)
        if let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "CameraStudy") {
            view.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        } else {
            view.loadHTMLString("<p>The camera study could not be loaded. Please reopen the article.</p>", baseURL: nil)
        }
        return view
    }

    func updateNSView(_ view: WKWebView, context: Context) {
        // Keep the same web view and model state when the conversation pane opens.
        context.coordinator.height = $contentHeight
    }

    static func dismantleNSView(_ view: WKWebView, coordinator: Coordinator) {
        coordinator.stopForwardingScrolling()
        view.configuration.userContentController.removeScriptMessageHandler(forName: "cameraStudy")
        view.stopLoading()
        view.navigationDelegate = nil
        view.uiDelegate = nil
    }

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
        var height: Binding<CGFloat>
        private var scrollMonitor: Any?
        init(height: Binding<CGFloat>) { self.height = height }

        func forwardScrollingToArticle(from webView: WKWebView) {
            stopForwardingScrolling()
            // WebKit can consume wheel events even when its HTML cannot scroll.
            // Route only events over this embedded view to the native article,
            // preserving the original delta, phase and momentum information.
            scrollMonitor = NSEvent.addLocalMonitorForEvents(matching: .scrollWheel) { [weak webView] event in
                guard let webView, let window = webView.window, event.window === window,
                      let contentView = window.contentView,
                      let hitView = contentView.hitTest(contentView.superview?.convert(event.locationInWindow, from: nil) ?? event.locationInWindow),
                      hitView === webView || hitView.isDescendant(of: webView),
                      let articleScrollView = webView.enclosingScrollView else { return event }
                articleScrollView.scrollWheel(with: event)
                return nil
            }
        }

        func stopForwardingScrolling() {
            if let scrollMonitor { NSEvent.removeMonitor(scrollMonitor) }
            scrollMonitor = nil
        }

        deinit {
            if let scrollMonitor { NSEvent.removeMonitor(scrollMonitor) }
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.frameInfo.isMainFrame, message.name == "cameraStudy",
                  let data = message.body as? [String: Any], let value = data["height"] as? Double,
                  value.isFinite, (280...1600).contains(value) else { return }
            if abs(height.wrappedValue - value) > 1 { height.wrappedValue = value }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.navigationType == .linkActivated,
               let url = navigationAction.request.url, ["https", "http"].contains(url.scheme ?? "") {
                NSWorkspace.shared.open(url)
                decisionHandler(.cancel)
            } else { decisionHandler(.allow) }
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url, ["https", "http"].contains(url.scheme ?? "") {
                NSWorkspace.shared.open(url)
            }
            return nil
        }
    }
}

private struct ArticlePhotographyContent: View {
    let scale: CGFloat
    private var sources: [ArticleDesignContent.Source] { ArticleDesignContent.sources }

    var body: some View {
        VStack(alignment: .leading, spacing: 28 * scale) {
            Text("PHOTOGRAPHY  ·  817 WORDS  ·  6 MIN READ")
                .bubbleFont(.caption, size: 15 * scale, weight: .medium)
                .tracking(1.1 * scale).foregroundStyle(.secondary)
            Text(ArticleDesignContent.article.summary)
                .modifier(ArticleBodyTypography(scale: scale)).textSelection(.enabled)
                .foregroundStyle(ArticleReaderStyle.bodyText)
            Text("Edited from 3 original tutorials")
                .bubbleFont(.caption, size: 16 * scale).foregroundStyle(.secondary)
            photograph("ArticleLeadingLinesOaks",
                caption: "Avenue of Oaks, South Carolina. Photograph by Anne McKinnell.",
                alt: "An oak-lined avenue receding into the distance.", sourceIndex: 0)

            ForEach(Array(ArticleDesignContent.article.sections.enumerated()), id: \.offset) { index, section in
                VStack(alignment: .leading, spacing: 14 * scale) {
                    Text(section.heading)
                        .bubbleFont(.title3, size: 28 * scale, weight: .semibold)
                        .fixedSize(horizontal: false, vertical: true)
                    ArticleJourneyText(content: section.text, scale: scale)
                    if let sourceIndex = ArticleDesignContent.sectionSources[index] {
                        Link(destination: sources[sourceIndex].url) {
                            Label("Source \(sourceIndex + 1) · \(sources[sourceIndex].publisher)", systemImage: "arrow.up.right")
                        }
                        .bubbleFont(.caption, size: 15 * scale).foregroundStyle(.secondary)
                    }
                }
                .padding(.top, 8 * scale)
                .accessibilityIdentifier("photographySection-\(index)")

                if index == 1 {
                    VStack(alignment: .leading, spacing: 12 * scale) {
                        Text("“\(ArticleDesignContent.quote)”")
                            .bubbleFont(.title3, size: 28 * scale, weight: .medium, role: .word)
                            .textSelection(.enabled)
                        Link("Anne McKinnell · Digital Photography School", destination: sources[0].url)
                            .bubbleFont(.caption, size: 15 * scale).foregroundStyle(.secondary)
                    }
                    .padding(24 * scale).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.primary.opacity(0.035), in: RoundedRectangle(cornerRadius: 16 * scale, style: .continuous))
                    photograph("ArticleLeadingLinesBuilding",
                        caption: "Follow the ground markings toward the building.",
                        alt: "Ground markings create lines toward a building at the back of the image.", sourceIndex: 0)
                        .frame(maxWidth: 680 * scale).frame(maxWidth: .infinity)
                }
                if section.heading == ArticleDesignContent.cameraHeading { ArticleCameraStudy(scale: scale) }
            }
            video
            references
        }
        .accessibilityIdentifier("photographyArticle")
    }

    private func photograph(_ name: String, caption: String, alt: String, sourceIndex: Int) -> some View {
        VStack(alignment: .leading, spacing: 10 * scale) {
            // Keep the entire original composition visible: the lines are the lesson.
            Image(name).resizable().scaledToFit()
                .clipShape(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
                .accessibilityLabel(alt)
            Text(caption).textSelection(.enabled)
            Link("Image source · \(sources[sourceIndex].publisher) ↗", destination: sources[sourceIndex].url)
        }
        .bubbleFont(.caption, size: 15 * scale).foregroundStyle(.secondary)
    }

    var video: some View {
        Link(destination: ArticleDesignContent.videoURL) {
            HStack(spacing: 22 * scale) {
                Image("ArticleLeadingLinesVideo").resizable().scaledToFit()
                    .frame(width: 190 * scale)
                    .overlay { Image(systemName: "play.circle.fill").font(.system(size: 42 * scale))
                        .symbolRenderingMode(.palette).foregroundStyle(.white, .black.opacity(0.5)) }
                    .clipShape(RoundedRectangle(cornerRadius: 10 * scale, style: .continuous))
                VStack(alignment: .leading, spacing: 8 * scale) {
                    Text("Watch the technique in action")
                        .bubbleFont(.headline, size: 22 * scale, weight: .semibold)
                    Text("Marc Newton · The School of Photography")
                        .bubbleFont(.caption, size: 16 * scale).foregroundStyle(.secondary)
                    Text("Supplementary tutorial · Watch on YouTube ↗")
                        .bubbleFont(.caption, size: 15 * scale).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .padding(20 * scale).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.primary.opacity(0.035), in: RoundedRectangle(cornerRadius: 16 * scale, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 16 * scale, style: .continuous))
        }
        .buttonStyle(.plain).foregroundStyle(.primary)
        .accessibilityIdentifier("photographyVideoLink")
    }

    var references: some View {
        VStack(alignment: .leading, spacing: 22 * scale) {
            Divider().padding(.bottom, 8 * scale)
            Text("Read the originals")
                .bubbleFont(.title3, size: 28 * scale, weight: .semibold)
            Text(ArticleDesignContent.editorialNote)
                .modifier(ArticleBodyTypography(scale: scale)).foregroundStyle(ArticleReaderStyle.bodyText)
                .textSelection(.enabled)
            ForEach(Array(sources.enumerated()), id: \.offset) { index, source in
                Link(destination: source.url) {
                    HStack(alignment: .top, spacing: 16 * scale) {
                        Text(String(format: "%02d", index + 1))
                            .bubbleFont(.caption, size: 16 * scale, weight: .medium)
                            .foregroundStyle(.secondary).padding(.top, 4 * scale)
                        VStack(alignment: .leading, spacing: 8 * scale) {
                            Text(source.title).bubbleFont(.headline, size: 21 * scale, weight: .semibold)
                            Text(source.author).bubbleFont(.caption, size: 16 * scale).foregroundStyle(.secondary)
                            Text(source.note).bubbleFont(.body, size: 18 * scale).foregroundStyle(.secondary)
                            Text("\(source.publisher) ↗").bubbleFont(.caption, size: 15 * scale).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "arrow.up.right").font(.system(size: 16 * scale)).foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
                }
                .buttonStyle(.plain).foregroundStyle(.primary)
                .accessibilityIdentifier("photographySource-\(index)")
                if index < sources.count - 1 { Divider() }
            }
        }
        .padding(.top, 12 * scale)
        .accessibilityIdentifier("photographyReferences")
    }
}

private struct ArticleReadingSection: View {
    let section: LearningArticle.Section
    let expressions: [LearningArticle.Expression]
    let scale: CGFloat
    var onExpression: (LearningArticle.Expression) -> Void

    private var text: AttributedString {
        var value = AttributedString(section.text)
        value.foregroundColor = ArticleReaderStyle.bodyText
        for (index, expression) in expressions.enumerated() {
            if let range = value.range(of: expression.text, options: .caseInsensitive) {
                value[range].link = URL(string: "bubble-expression://term/\(index)")
                value[range].foregroundColor = ArticleReaderStyle.bodyText
                value[range].underlineStyle = .single
            }
        }
        return value
    }

    var body: some View {
        Text(text).bubbleFont(.body, size: 20 * scale).lineSpacing(2 * scale)
            .textSelection(.enabled)
            .environment(\.openURL, OpenURLAction { url in
                guard url.scheme == "bubble-expression", let index = Int(url.lastPathComponent), expressions.indices.contains(index) else { return .discarded }
                onExpression(expressions[index]); return .handled
            })
    }
}

private struct ArticleReferenceText: View {
    let text: String
    let assetName: String
    let count: Int
    let scale: CGFloat

    var body: some View {
        Text(text)
            .modifier(ArticleBodyTypography(scale: scale))
            .foregroundStyle(ArticleReaderStyle.bodyText)
            .textSelection(.enabled)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .overlay(alignment: .topLeading) {
                // An overlay preserves native text selection and the 26px
                // line box. Inline attachments change the line's descent.
                GeometryReader { geometry in
                    Image(nsImage: referenceImage)
                        .frame(width: 46 * scale, height: 24 * scale)
                        .position(referencePosition(width: geometry.size.width))
                }
                .allowsHitTesting(false)
                .accessibilityHidden(true)
            }
    }

    private func referencePosition(width: CGFloat) -> CGPoint {
        let string = NSAttributedString(string: text, attributes: [
            .font: BubbleTypography.nativeFont(size: 20 * scale)
        ])
        let typesetter = CTTypesetterCreateWithAttributedString(string)
        var offset = 0
        var lineIndex = 0
        var lastWidth: CGFloat = 0
        while offset < string.length {
            let length = max(1, CTTypesetterSuggestLineBreak(typesetter, offset, max(1, width)))
            let line = CTTypesetterCreateLine(typesetter, CFRange(location: offset, length: length))
            lastWidth = CTLineGetTypographicBounds(line, nil, nil, nil)
            offset += length
            if offset < string.length { lineIndex += 1 }
        }
        return CGPoint(x: lastWidth + 31 * scale, y: (CGFloat(lineIndex) * 26 + 13) * scale)
    }

    private var referenceImage: NSImage {
        let image = NSImage(size: NSSize(width: 46 * scale, height: 24 * scale))
        image.lockFocus()
        NSImage(named: assetName)?.draw(in: NSRect(x: 0, y: 0, width: 24 * scale, height: 24 * scale))
        let countRect = NSRect(x: 22 * scale, y: 0, width: 24 * scale, height: 24 * scale)
        NSColor.labelColor.withAlphaComponent(0.05).setFill()
        NSBezierPath(roundedRect: countRect, xRadius: 12 * scale, yRadius: 12 * scale).fill()
        let countText = NSAttributedString(string: "+\(count)", attributes: [
            .font: NSFont.systemFont(ofSize: 12 * scale),
            .foregroundColor: NSColor.labelColor.withAlphaComponent(0.64)
        ])
        let size = countText.size()
        countText.draw(at: NSPoint(x: countRect.midX - size.width / 2, y: countRect.midY - size.height / 2))
        image.unlockFocus()
        image.accessibilityDescription = "+\(count)"
        return image
    }
}

private struct ArticleBodyTypography: ViewModifier {
    let scale: CGFloat
    var weight: Font.Weight = .regular

    func body(content: Content) -> some View {
        let font = BubbleTypography.nativeFont(size: 20 * scale, weight: weight)
        let extraLeading = max(0, 26 * scale - font.ascender + font.descender - font.leading)
        content.font(Font(font))
            .lineSpacing(extraLeading)
            .padding(.vertical, extraLeading / 2)
    }
}

private struct ArticleSendButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.opacity(configuration.isPressed ? 0.8 : 1)
    }
}

private struct ArticleDesignImage: View {
    let name: String
    let topAligned: Bool
    let scale: CGFloat

    var body: some View {
        Color.clear.aspectRatio(803.0 / 389, contentMode: .fit)
            .overlay {
                GeometryReader { geometry in
                    Image(name).resizable().scaledToFill()
                        .frame(width: geometry.size.width,
                               height: geometry.size.height * (topAligned ? 1.1258 : 1),
                               alignment: topAligned ? .top : .center)
                        .offset(y: topAligned ? geometry.size.height * 0.0004 : 0)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
            .overlay { RoundedRectangle(cornerRadius: 12 * scale, style: .continuous).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5) }
            .padding(.vertical, 16 * scale)
    }
}

private struct ArticleAssistantMessage: View {
    @Environment(\.colorScheme) private var colorScheme
    let text: String
    let scale: CGFloat
    let enabled: Bool
    var onAnswer: ((String) -> Void)?
    @State private var selectedChoice: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 24 * scale) {
            ForEach(Array(ArticleReplyBlock.parse(text).enumerated()), id: \.offset) { _, block in
                switch block {
                case .paragraph(let text):
                    markdown(text)
                        .modifier(ArticleBodyTypography(scale: scale))
                        .padding(.leading, 2 * scale)
                        .textSelection(.enabled)
                case .quiz(let question, let choices):
                    VStack(alignment: .leading, spacing: 16 * scale) {
                        markdown(question)
                            .modifier(ArticleBodyTypography(scale: scale, weight: .semibold))
                            .textSelection(.enabled)
                        VStack(alignment: .leading, spacing: 10 * scale) {
                            ForEach(choices, id: \.self) { choice in
                                Button {
                                    selectedChoice = choice
                                    let prompt = (try? AttributedString(markdown: question)).map { String($0.characters) } ?? question
                                    onAnswer?(prompt + "\n" + choice)
                                } label: {
                                    (Text(String(choice.prefix(2))).font(Font(BubbleTypography.font(size: 20 * scale, weight: .semibold))) + Text(String(choice.dropFirst(2))))
                                        .modifier(ArticleBodyTypography(scale: scale))
                                        .frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
                                        .background(selectedChoice == choice ? Color.primary.opacity(0.05) : .clear, in: RoundedRectangle(cornerRadius: 4 * scale, style: .continuous))
                                }.buttonStyle(.plain).disabled(!enabled)
                                    .accessibilityAddTraits(selectedChoice == choice ? [.isSelected] : [])
                            }
                        }
                    }
                    .padding(.horizontal, 32.5 * scale)
                    .padding(.top, 20.5 * scale)
                    .padding(.bottom, 32.5 * scale)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background { quizBackground }
                    .clipShape(RoundedRectangle(cornerRadius: 16 * scale))
                    .overlay { RoundedRectangle(cornerRadius: 16 * scale).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5) }
                    .accessibilityIdentifier("articleQuiz")
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func markdown(_ value: String) -> Text {
        Text((try? AttributedString(markdown: value, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(value))
    }

    // Figma 1588:1991. Keep the exported gradient layer at its design size and
    // anchor its overflow to the card's lower-right corner as text wraps.
    private var quizBackground: some View {
        (colorScheme == .dark ? Color(red: 0.20, green: 0.16, blue: 0.09)
            : Color(red: 1, green: 250.0 / 255, blue: 240.0 / 255))
            .overlay(alignment: .bottomTrailing) {
                Image(decorative: "ArticleQuizGlow").resizable()
                    .frame(width: 590 * scale, height: 393 * scale)
                    .offset(x: 254 * scale, y: 110 * scale)
            }
            .overlay(alignment: .bottomTrailing) {
                HStack(spacing: 7.68 * scale) {
                    RoundedRectangle(cornerRadius: 8.448 * scale)
                        .frame(width: 11.2 * scale, height: 24.064 * scale)
                    RoundedRectangle(cornerRadius: 8.448 * scale)
                        .frame(width: 11.2 * scale, height: 24.064 * scale)
                }
                .foregroundStyle(.white)
                .rotationEffect(.degrees(17.54))
                .frame(width: 35.934 * scale, height: 32.012 * scale)
                .padding(.trailing, 31.066 * scale)
                .padding(.bottom, 19.988 * scale)
            }
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}

private struct ArticleOriginalImage: View {
    @Environment(BubbleStore.self) private var store
    let assetID: String
    var cover = false
    @State private var image: NSImage?

    var body: some View {
        Group {
            if let image {
                if cover { Image(nsImage: image).resizable().scaledToFill() }
                else { Image(nsImage: image).resizable().scaledToFit() }
            } else {
                Image(systemName: "photo").font(.largeTitle).foregroundStyle(.tertiary)
                    .frame(maxWidth: .infinity, minHeight: 100)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: cover ? 0 : 18, style: .continuous))
        .task(id: assetID) { image = (try? await store.asset(assetID)).flatMap(NSImage.init(data:)) }
        .accessibilityLabel("记录中的原始图片")
    }
}

// A complete, bundled English lesson for the space card. It is available offline
// and remains separate from the user's synced articles and saved vocabulary.
@MainActor private enum ArticleSpaceContent {
    static let referenceURL = URL(string: "https://science.nasa.gov/solar-system/")!
    static let sections: [LearningArticle.Section] = [
        section("Start with the world beneath your feet", """
        Imagine seeing Earth from high above the clouds. Roads disappear, familiar cities become difficult to find, and the horizon begins to curve. The planet feels enormous when you stand on it, yet surprisingly small when you look at it from a distance. A journey into space begins with this change of perspective: our home is one world in a much larger system.

        Earth is surrounded by an atmosphere, a mixture of gases held close by gravity. It gives us air to breathe and helps protect life at the surface. The air becomes thinner as altitude increases; there is no solid roof separating the sky from space. In the photograph, you can see a high-altitude view above much of the atmosphere. It is a useful first step toward imagining the view from orbit.
        """),
        section("Get to know a spacesuit", """
        Outside a spacecraft, an astronaut needs much more than warm clothing. A spacesuit is a small life-support system. It supplies oxygen, maintains pressure around the body, and helps control temperature. Different suits are designed for different tasks, such as launching in a spacecraft or working outside it.

        Look at the parts in the illustration below. The helmet surrounds the head, while the visor helps protect the eyes. Gloves allow the astronaut to handle tools, although moving the fingers inside a pressurised glove takes effort. Boots protect the feet, and connectors join parts of the suit to other equipment. Practise a short description: “The astronaut lowers the visor and checks the gloves.” Linking each word to a visible part makes the vocabulary easier to remember.
        """),
        section("Understand what it means to orbit", """
        An orbit is the curved path one object follows around another under gravity. The Moon orbits Earth, and Earth orbits the Sun. A spacecraft in low Earth orbit is still pulled strongly by Earth's gravity. It moves sideways fast enough that, as it falls, the surface curves away beneath it.

        This helps explain why astronauts float inside an orbiting spacecraft. They and the spacecraft are falling together, so they experience apparent weightlessness. It does not mean gravity has disappeared. Try using the word in two ways: “The station is in orbit” describes its situation, while “The station orbits Earth” describes what it does.
        """),
        section("Look beyond the Moon", """
        The Moon is Earth's natural satellite. It shines in our sky because its surface reflects sunlight. As the Moon travels around Earth, we see different portions of its sunlit half. These changing views are its phases; ordinary lunar phases are not caused by Earth's shadow.

        Beyond the Moon, our solar system contains eight planets, their moons, and many smaller objects. The Sun is a star at the centre of this system. Earth and the other planets travel around it, while the Sun produces energy that reaches us as light and heat. Space exploration uses both human crews and robotic spacecraft. A probe can carry cameras and instruments to places that people have not visited.
        """),
        section("Bring the new words back to Earth", """
        You do not need a rocket to start exploring. On a clear evening, find a comfortable place to look at the Moon. Notice its shape and its position relative to a nearby building. Make a small sketch, then repeat the observation on another evening. You are practising an important scientific habit: describe what you observe before deciding how to explain it.

        Finish with three sentences of your own. Describe the atmosphere around Earth, something that orbits our planet, and a piece of equipment an astronaut uses. For example: “A satellite orbits Earth. The atmosphere becomes thinner with altitude. The astronaut checks the helmet before leaving the spacecraft.” Each sentence connects an English word with an idea you can picture.
        """)
    ]

    private static func section(_ heading: String, _ text: String) -> LearningArticle.Section {
        .init(heading: heading, text: text, translation: "", captureIds: [], question: "", answer: "")
    }

    static func make() -> ArticleGenerationPreview {
        let id = LearningLibraryTopic.space.articleID
        let wordCount = sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count
        let article = LearningArticle(id: id, title: "A Journey into Space: From Earth to Orbit",
            summary: "\(wordCount) words · \(max(1, Int(ceil(Double(wordCount) / 150)))) min read",
            theme: "Space · Earth, orbits and exploration", language: "en", generatedAt: 0, generationId: id,
            captureIds: [], sections: sections, expressions: [], messages: [], revision: 0, wordCount: wordCount)
        return ArticleGenerationPreview(article: article, request: "Explore space in English.",
            imageAsset: "ArticleSpaceExploration", imageCaption: "A high-altitude view above Earth's clouds.",
            initiallyComplete: true,
            practice: .init(question: "orbit 在文中是什么意思？",
                choices: ["A curved path around another object", "The air surrounding a planet", "A protective part of a spacesuit", "Light reflected by the Moon"],
                answer: 0, explanation: "orbit 表示轨道，即物体在引力作用下绕另一个物体运行的弯曲路径，例如月球绕地球运行的轨道。"))
    }
}

// Generated-article copy from Figma 1572:43964. Keep this fixture separate from
// the longer library lesson; the camera screenshot's slot remains interactive.
@MainActor private enum ArticlePreviewContent {
    static let referenceHeading = "Read the original article"
    static let referenceIntroduction = "Read the full tutorial for step-by-step tips and examples."
    static let referenceTitle = "How to create dreamy, soft-focus photos"
    static let referenceSummary = "Learn to use natural light and creative blur to capture mood and movement."
    static let referenceURL = URL(string: "https://openai.com/zh-Hans-CN/index/gpt-6-for-everyone/")!
    static let sections: [LearningArticle.Section] = [
        .init(heading: "Start with something you want to show",
            text: "Imagine stopping outside a café you pass every morning. You like its green door, the warm light inside, and the bicycle beside the entrance. You take a photograph on your journey, but the result feels busy. The door is there, yet nothing tells you where to look first.\n\nBefore taking another picture, finish this sentence: I want someone to notice the green door. That small decision gives you a purpose. You can now judge every part of the frame by a useful question: does it help someone find the door? For this walk, your goal is simple: make one familiar subject easier to notice.",
            translation: "", captureIds: [], question: "", answer: ""),
        .init(heading: ArticleDesignContent.cameraHeading,
            text: "Before you press the shutter, get to know the camera in your hands. This Canon AT-1 is a film camera: its body holds the film, while the lens focuses light onto it. Press the shutter release to take a photograph. The shutter-speed dial controls how long light reaches the film. Move the film advance lever to prepare the next frame, then use the rewind knob when the roll is finished.",
            translation: "", captureIds: [], question: "", answer: ""),
        .init(heading: "More before you press the shutter",
            text: "Finding a line is only the beginning. McKinnell recommends adjusting your position until it points where you want the viewer to look. Try moving sideways, forward, or backward. Raising or lowering the camera can also change the relationship.",
            translation: "", captureIds: [], question: "", answer: "")
    ]

    static func make(_ draft: ArticleGenerationDraft, id: String? = nil, initiallyComplete: Bool = false) -> ArticleGenerationPreview {
        let id = id ?? "mock-" + UUID().uuidString.lowercased()
        let article = LearningArticle(id: id,
            title: "Leading Lines in Photography: Essential Guide", summary: "800 words · 6 min read",
            theme: "Photography · Leading lines", language: "en", generatedAt: Date().timeIntervalSince1970,
            generationId: id, captureIds: [], sections: sections, expressions: [], messages: [], revision: 0,
            wordCount: sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count,
            requestedWordCount: draft.resolvedWordCount)
        let topic = draft.resolvedTopic.isEmpty ? "Photography" : draft.resolvedTopic
        var request = "Create an article about \(topic.lowercased()).\n\(draft.resolvedWordCount ?? 400) words · \((draft.scope ?? .all).title) saved words"
        if !draft.notes.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { request += "\n\n" + draft.notes }
        return ArticleGenerationPreview(article: article, request: request,
            imageAsset: "ArticleGeneratedBuilding", imageCaption: "Follow the ground markings toward the building.",
            outline: [
                .init(heading: "Start with an everyday scene:", detail: "Use a neighborhood café as an example to identify what you want viewers to notice first."),
                .init(heading: "Get to know your camera:", detail: "Rotate and take apart a 3D camera to learn its main components and related English vocabulary."),
                .init(heading: "Move before you shoot:", detail: "Learn how changing your position or camera height helps leading lines guide attention toward your subject."),
                .init(heading: "Explore further:", detail: "Follow a link to the original tutorial for more tips and examples.")
            ], initiallyComplete: initiallyComplete)
    }
}

private struct ArticlePreviewProgress: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let preview: ArticleGenerationPreview
    let scale: CGFloat
    @State private var editingStep: ArticleGenerationPreview.Step?
    @State private var revisionDraft = ""
    @State private var hoveredStep: ArticleGenerationPreview.Step?
    @FocusState private var focusedStep: ArticleGenerationPreview.Step?
    @FocusState private var revisionFocused: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 24 * scale) {
            // Figma 1561:43128. Both initial and revised plans share this
            // disclosure, including paused, awaiting approval and complete states.
            VStack(alignment: .leading, spacing: 12 * scale) {
                Button {
                    withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                        preview.isThinkingExpanded.toggle()
                        if !preview.isThinkingExpanded {
                            closeEditor()
                            hoveredStep = nil
                            focusedStep = nil
                        }
                    }
                } label: {
                    HStack(spacing: 6 * scale) {
                        Text("思考了\(preview.thinkingSeconds)秒")
                            .bubbleFont(.body, size: 16 * scale)
                            .foregroundStyle(Color("ArticleProgressForeground650"))
                            .padding(.bottom, 2 * scale)
                        Image("ArticleThinkingChevron").resizable()
                            .frame(width: 24 * scale, height: 24 * scale)
                            .rotationEffect(.degrees(preview.isThinkingExpanded ? 0 : -90))
                            .accessibilityHidden(true)
                    }
                    .frame(maxWidth: .infinity, minHeight: 32 * scale, alignment: .leading)
                    .opacity(0.8)
                    .contentShape(Rectangle())
                }.buttonStyle(.plain)
                    .help(preview.isThinkingExpanded ? "收起思考步骤" : "展开思考步骤")
                    .accessibilityLabel("思考了\(preview.thinkingSeconds)秒")
                    .accessibilityValue(preview.isThinkingExpanded ? "已展开" : "已收起")
                    .accessibilityHint("展开或收起思考步骤")
                    .accessibilityIdentifier("toggleArticleThinking")
                if preview.isThinkingExpanded {
                    VStack(alignment: .leading, spacing: 4 * scale) {
                        ForEach(ArticleGenerationPreview.Step.allCases, id: \.rawValue) { step in
                            VStack(alignment: .leading, spacing: 12 * scale) {
                                stepRow(step)
                                if editingStep == step { revisionEditor(step) }
                            }
                            .background {
                                RoundedRectangle(cornerRadius: 12 * scale)
                                    .fill((hoveredStep == step || editingStep == step || focusedStep == step) && preview.isComplete
                                        ? Color(white: 246.0 / 255) : .clear)
                                    .padding(.leading, -8 * scale)
                                    .allowsHitTesting(false)
                            }
                            .onHover { hoveredStep = $0 ? step : (hoveredStep == step ? nil : hoveredStep) }
                            .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(step)))
                        }
                    }.transition(.opacity)
                }
            }.accessibilityElement(children: .contain)
                .accessibilityIdentifier("articleGenerationProgress")
            if preview.isStopped {
                Button { preview.resume() } label: {
                    Label("继续生成", systemImage: "play.fill")
                        .bubbleFont(.body, size: 16 * scale)
                        .padding(.horizontal, 16 * scale).padding(.vertical, 12 * scale)
                        .background(Color.primary.opacity(0.05), in: Capsule())
                }.buttonStyle(.plain).accessibilityIdentifier("resumeArticleGeneration")
            }
        }
        .onExitCommand { closeEditor() }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: preview.isThinkingExpanded)
        .onChange(of: preview.isThinkingExpanded) { _, expanded in
            if !expanded {
                closeEditor()
                hoveredStep = nil
                focusedStep = nil
            }
        }
    }

    private func stepRow(_ step: ArticleGenerationPreview.Step) -> some View {
        let done = preview.isComplete || step.rawValue < preview.step.rawValue || (step == .outline && preview.isAwaitingOutlineConfirmation)
        let active = preview.isGenerating && step == preview.step
        let awaitingApproval = step == .outline && preview.isAwaitingOutlineConfirmation
        let stopped = preview.isStopped && step == preview.step
        return HStack(alignment: .top, spacing: 12 * scale) {
            VStack(spacing: 8 * scale) {
                ZStack {
                    if done {
                        Image("ArticleProgressDone").resizable()
                            .frame(width: 20 * scale, height: 20 * scale)
                            .transition(reduceMotion ? .opacity : .opacity.combined(with: .scale(scale: 0.7)))
                    } else {
                        Image("ArticleProgressNumberFill").resizable()
                            .frame(width: 16 * scale, height: 16 * scale)
                        Image("ArticleProgressNumberBorder").resizable()
                            .frame(width: 16 * scale, height: 16 * scale)
                        Text("\(step.rawValue + 1)")
                            .bubbleFont(.caption2, size: 10 * scale, weight: .semibold)
                            .foregroundStyle(Color("ArticleProgressAccent600"))
                            .padding(.bottom, scale)
                    }
                }.frame(width: 20 * scale, height: 20 * scale)
                    .animation(reduceMotion ? nil : .easeOut(duration: 0.3), value: done)
                if step != .artifact {
                    Image("ArticleProgressLine").resizable()
                        .frame(width: 24.5 * scale, height: 0.5 * scale)
                        .rotationEffect(.degrees(90))
                        .frame(width: 20 * scale, height: 24 * scale)
                }
            }
            .padding(.top, 4 * scale)
            .accessibilityHidden(true)
            Text(stepTitle(step))
                .bubbleFont(.body, size: 20 * scale)
                .foregroundStyle(done ? Color(white: 43.0 / 255)
                    : active ? Color("ArticleProgressForeground900") : Color(white: 136.0 / 255))
                .modifier(ArticleProgressShimmer(active: active, scale: scale))
                .frame(maxWidth: .infinity, minHeight: 32 * scale, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 2 * scale)
            if preview.canEditLocally {
                Button { edit(step) } label: {
                    HStack(spacing: 4 * scale) {
                        Image("ArticleRethinkChat").renderingMode(.template).resizable()
                            .frame(width: 20 * scale, height: 20 * scale)
                        Text("重新生成").bubbleFont(.body, size: 16 * scale)
                            .fixedSize()
                    }
                    .foregroundStyle(Color("ArticleProgressForeground900").opacity(0.6))
                    .padding(.trailing, 16 * scale).padding(.top, 6 * scale)
                    .contentShape(Rectangle())
                    .opacity(hoveredStep == step || editingStep == step || focusedStep == step ? 1 : 0)
                }.buttonStyle(.plain)
                    .focused($focusedStep, equals: step)
                    .help("从此节点重新推理")
                    .accessibilityLabel("从\(stepTitle(step))重新生成")
                    .accessibilityIdentifier("regenerateArticleStep-\(step.rawValue)")
            }
        }
        .frame(minHeight: 56 * scale, alignment: .topLeading)
        .transaction { $0.animation = nil }
        .contentShape(Rectangle())
        .contextMenu {
            if preview.canEditLocally {
                Button("重新生成", systemImage: "arrow.counterclockwise") { edit(step) }
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel(stepTitle(step))
        .accessibilityValue(awaitingApproval ? "Waiting for approval" : done ? "Completed" : active ? "In progress" : stopped ? "Stopped" : "Pending")
        .accessibilityActions {
            if preview.canEditLocally {
                Button("重新生成") { edit(step) }
            }
        }
    }

    private func stepTitle(_ step: ArticleGenerationPreview.Step) -> String {
        if preview.teachesCameraParts {
            switch step {
            case .outline: return "调整学习大纲"
            case .research: return "查找相机结构资料"
            case .writing: return "撰写相机部件讲解"
            case .images: return "添加示例图片"
            case .artifact: return "制作部件互动练习"
            }
        }
        switch step {
        case .outline: return "梳理学习大纲"
        case .research: return preview.id == LearningLibraryTopic.space.articleID ? "查找太空探索资料" : "查找摄影教程"
        case .writing: return "撰写学习文章"
        case .images: return "添加示例图片"
        case .artifact: return "制作互动练习"
        }
    }

    private func edit(_ step: ArticleGenerationPreview.Step) {
        withAnimation(.easeInOut(duration: 0.2)) {
            editingStep = editingStep == step ? nil : step
            revisionDraft = ""
        }
        revisionFocused = editingStep != nil
    }

    private func closeEditor() {
        editingStep = nil
        revisionDraft = ""
        revisionFocused = false
    }

    private func revisionEditor(_ step: ArticleGenerationPreview.Step) -> some View {
        VStack(alignment: .leading, spacing: 12 * scale) {
            Text(step == .outline ? "从大纲开始，重新生成后续全部内容。" : "保留前面的步骤和产出，重新生成此步骤及后续内容。")
                .bubbleFont(.caption, size: 13 * scale).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            TextField(revisionPlaceholder(step), text: $revisionDraft, axis: .vertical)
                .textFieldStyle(.plain).lineLimit(2...4)
                .bubbleFont(.body, size: 16 * scale)
                .padding(12 * scale)
                .background(ArticleReaderStyle.surface, in: RoundedRectangle(cornerRadius: 10 * scale, style: .continuous))
                .focused($revisionFocused)
                .onKeyPress(keys: [.return], phases: .down) { (key: KeyPress) -> KeyPress.Result in
                    // The IME owns Return until its marked Chinese/Japanese text
                    // is committed. Shift-Return remains a newline.
                    let shiftPressed = key.modifiers.contains(EventModifiers.shift)
                    let hasMarkedText = (NSApp.keyWindow?.firstResponder as? NSTextView)?.hasMarkedText() ?? false
                    guard !shiftPressed && !hasMarkedText else { return KeyPress.Result.ignored }
                    submitRevision(step)
                    return .handled
                }
                .accessibilityLabel("补充修改要求").accessibilityIdentifier("articleRegenerationNotes")
            HStack {
                if revisionDraft.count > 2000 {
                    Text("请控制在 2000 字以内。")
                        .bubbleFont(.caption, size: 12 * scale).foregroundStyle(.red)
                }
                Spacer(minLength: 0)
                Button {
                    submitRevision(step)
                } label: {
                    Text("重新推理").padding(.horizontal, 13 * scale).padding(.vertical, 8 * scale)
                        .foregroundStyle(ArticleReaderStyle.surface)
                        .background(Color.primary, in: Capsule())
                }.buttonStyle(.plain)
                    .disabled(revisionDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || revisionDraft.count > 2000)
                    .opacity(revisionDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || revisionDraft.count > 2000 ? 0.35 : 1)
                    .keyboardShortcut(.return, modifiers: .command)
                    .accessibilityIdentifier("confirmArticleRegeneration")
            }.bubbleFont(.caption, size: 14 * scale)
        }
        .padding(14 * scale)
        .background(ArticleReaderStyle.canvas, in: RoundedRectangle(cornerRadius: 14 * scale, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14 * scale, style: .continuous).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
        .background(ArticleOutsideClickMonitor(enabled: editingStep != nil) { closeEditor() })
        .accessibilityElement(children: .contain)
        .transition(.opacity.combined(with: .move(edge: .top)))
    }

    private func submitRevision(_ step: ArticleGenerationPreview.Step) {
        if preview.regenerate(from: step, instruction: revisionDraft) { closeEditor() }
    }

    private func revisionPlaceholder(_ step: ArticleGenerationPreview.Step) -> String {
        switch step {
        case .outline: return "补充要求，例如：把摄影机换成单反相机"
        case .research: return "补充教程要求"
        case .writing: return "补充要求，例如：写短一点"
        case .images: return "补充要求，例如：换成建筑配图"
        case .artifact: return "补充要求，例如：考查 compare 这个单词"
        }
    }

}

/// Animate the original Figma luminance mask across the active step title.
private struct ArticleProgressShimmer: ViewModifier {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let active: Bool
    let scale: CGFloat
    var rects: [CGRect]? = nil

    func body(content: Content) -> some View {
        content.mask {
            if active && !reduceMotion {
                TimelineView(.animation(minimumInterval: 1.0 / 30)) { timeline in
                    GeometryReader { geometry in
                        let width = 168 * scale
                        let phase = timeline.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 2) / 2
                        let sweep = rects?.reduce(CGRect.null) { $0.union($1) }
                            ?? CGRect(origin: .zero, size: geometry.size)
                        ZStack(alignment: .leading) {
                            Color.white
                            Image("ArticleProgressShimmer").resizable()
                                .frame(width: width, height: geometry.size.height)
                                .offset(x: sweep.isNull ? -width : sweep.minX - width + (sweep.width + width) * phase)
                                .frame(width: geometry.size.width, height: geometry.size.height, alignment: .leading)
                                .mask {
                                    if let rects {
                                        Path { path in
                                            for rect in rects { path.addRect(rect) }
                                        }
                                    } else {
                                        Rectangle()
                                    }
                                }
                        }
                        .compositingGroup().luminanceToAlpha()
                    }
                }
            } else {
                Color.white
            }
        }
    }
}

private struct ArticlePreviewSuggestions: View {
    let prompts: [String]
    let scale: CGFloat
    var onSuggestion: (String) -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 10 * scale) {
            ForEach(Array(prompts.enumerated()), id: \.offset) { index, prompt in
                Button { onSuggestion(prompt) } label: {
                    HStack(spacing: 10 * scale) {
                        Text(prompt).multilineTextAlignment(.leading)
                        Spacer(minLength: 0)
                        Image(systemName: "arrow.up.right").font(.system(size: 12 * scale))
                    }
                    .bubbleFont(.body, size: 16 * scale)
                    .padding(.horizontal, 14 * scale).padding(.vertical, 12 * scale)
                    .background(ArticleReaderStyle.canvas, in: RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
                    .contentShape(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
                }.buttonStyle(.plain).accessibilityIdentifier("articleSuggestion-\(index)")
            }
        }
    }
}

private struct ArticleDiscardTransition: ViewModifier {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let discarding: Bool
    @State private var started: Date?
    @State private var particles: [ArticleDissolveParticle] = []

    func body(content: Content) -> some View {
        TimelineView(.animation(paused: !discarding || started == nil || reduceMotion)) { timeline in
            let elapsed = discarding ? started.map { max(0, timeline.date.timeIntervalSince($0)) } ?? 0 : 0
            let progress = sin(min(1, elapsed / 0.8) * .pi / 2)
            content
                .clipShape(ArticleDissolveWipe(progress: reduceMotion ? 0 : progress))
                .opacity(discarding && reduceMotion ? 0 : 1)
                .animation(reduceMotion ? .easeOut(duration: 0.12) : nil, value: discarding)
                .background(ArticleDissolveCapture(active: discarding && !reduceMotion) { samples in
                    particles = samples
                    started = Date()
                })
                .overlay {
                    if discarding && !reduceMotion && started != nil {
                        Canvas { context, _ in
                            for particle in particles {
                                let life = (elapsed - particle.birth) * 60
                                guard life >= 0, life < particle.death else { continue }
                                let distance = 3 * life
                                let oscillation = sin(life * .pi * 2 / 100)
                                let x = 210 + particle.x + cos(particle.angle) * distance - sin(particle.angle) * oscillation
                                let y = 210 + particle.y + sin(particle.angle) * distance + cos(particle.angle) * oscillation
                                context.opacity = (1 - life / particle.death) * particle.alpha
                                context.fill(Path(ellipseIn: CGRect(x: x - 0.9, y: y - 0.9, width: 1.8, height: 1.8)),
                                             with: .color(particle.color))
                            }
                        }
                        .padding(-210)
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                    }
                }
        }
        .onChange(of: discarding) { _, value in
            if !value { started = nil; particles = [] }
        }
        .allowsHitTesting(!discarding)
        .accessibilityHidden(discarding)
    }
}

private struct ArticleDissolveWipe: Shape {
    let progress: Double
    func path(in rect: CGRect) -> Path {
        // Idle content can include the journey hover card extending outside its
        // text bounds. Only the departing content should acquire a tight clip.
        if progress == 0 { return Path(rect.insetBy(dx: -10000, dy: -10000)) }
        return Path(CGRect(x: rect.minX, y: rect.minY, width: rect.width, height: rect.height * (1 - progress)))
    }
}

/// Native port of docs/prototypes/particle-dissolve/effect.js (Export preset).
/// Copyright (c) 2018 Travis Fischer, MIT; see Resources/ThirdPartyLicenses.txt.
private struct ArticleDissolveParticle {
    let x: Double
    let y: Double
    let color: Color
    let alpha: Double
    let birth: Double
    let angle: Double
    let death: Double
}

/// Capture the actual rendered region, including TextKit glyphs and native media,
/// before clipping starts. No screen recording or external-window capture is used.
private struct ArticleDissolveCapture: NSViewRepresentable {
    let active: Bool
    let captured: ([ArticleDissolveParticle]) -> Void
    func makeNSView(context: Context) -> CaptureView { CaptureView() }
    func updateNSView(_ view: CaptureView, context: Context) {
        guard view.active != active else { return }
        view.active = active
        view.generation += 1
        let generation = view.generation
        guard active else { return }
        DispatchQueue.main.async { [weak view] in
            guard let view, view.active, view.generation == generation else { return }
            captured(view.sample())
        }
    }
    static func dismantleNSView(_ view: CaptureView, coordinator: ()) {
        view.active = false
        view.generation += 1
    }
    final class CaptureView: NSView {
        var active = false
        var generation = 0
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
        override var isFlipped: Bool { true }

        func sample() -> [ArticleDissolveParticle] {
            guard let root = window?.contentView, bounds.width > 0, bounds.height > 0 else { return [] }
            let frame = convert(bounds, to: root)
            let region = frame.intersection(root.visibleRect)
            guard !region.isEmpty, let bitmap = root.bitmapImageRepForCachingDisplay(in: region) else { return [] }
            root.cacheDisplay(in: region, to: bitmap)
            guard let source = bitmap.cgImage else { return [] }
            let width = max(1, Int(region.width)), height = max(1, Int(region.height))
            var pixels = [UInt8](repeating: 0, count: width * height * 4)
            let drawn = pixels.withUnsafeMutableBytes { bytes -> Bool in
                guard let context = CGContext(data: bytes.baseAddress, width: width, height: height,
                    bitsPerComponent: 8, bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
                context.draw(source, in: CGRect(x: 0, y: 0, width: width, height: height))
                return true
            }
            guard drawn else { return [] }
            let local = convert(region, from: root)
            var bands = [[(Double, Double, Color, Double)]](repeating: [], count: 48)
            for y in stride(from: 0, to: height, by: 2) {
                let localY = local.minY + Double(y)
                let fraction = min(1, max(0, 1 - localY / bounds.height))
                let band = min(47, Int(asin(fraction) / (.pi / 2) * 48))
                for x in stride(from: 0, to: width, by: 2) {
                    let offset = (y * width + x) * 4
                    let alpha = Double(pixels[offset + 3]) / 255
                    guard alpha > 0.25 else { continue }
                    let r = Double(pixels[offset]) / alpha, g = Double(pixels[offset + 1]) / alpha, b = Double(pixels[offset + 2]) / alpha
                    // Native capture includes the neutral pane surface. Keep ink
                    // and photo colors, never turn that empty surface into confetti.
                    guard min(r, g, b) < 235 || max(r, g, b) - min(r, g, b) > 12 else { continue }
                    bands[band].append((local.minX + Double(x), localY,
                        Color(.sRGB, red: min(1, r / 255), green: min(1, g / 255), blue: min(1, b / 255), opacity: 1), alpha))
                }
            }
            var result: [ArticleDissolveParticle] = []
            for index in bands.indices where !bands[index].isEmpty {
                let previous = sin(Double(index) / 48 * .pi / 2)
                let progress = sin(Double(index + 1) / 48 * .pi / 2)
                let count = Int(7 * ((progress - previous) * 100 + 1))
                for _ in 0..<count {
                    let pixel = bands[index].randomElement()!
                    result.append(.init(x: pixel.0, y: pixel.1, color: pixel.2, alpha: pixel.3,
                        birth: Double(index) / 60, angle: -.pi / 2 + Double.random(in: -0.5...0.5) * .pi * 0.65,
                        death: Double.random(in: 28...68)))
                }
            }
            return result
        }
    }
}

private struct ArticleOutsideClickMonitor: NSViewRepresentable {
    let enabled: Bool
    let dismiss: () -> Void
    func makeNSView(context: Context) -> MonitorView { MonitorView() }
    func updateNSView(_ view: MonitorView, context: Context) { view.dismiss = enabled ? dismiss : nil }
    static func dismantleNSView(_ view: MonitorView, coordinator: ()) { view.stop() }
    final class MonitorView: NSView {
        var dismiss: (() -> Void)?
        private var monitor: Any?
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
        override func viewDidMoveToWindow() {
            stop()
            guard window != nil else { return }
            monitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown, .keyDown]) { [weak self] event in
                guard let self, let dismiss = self.dismiss else { return event }
                if event.type == .keyDown {
                    guard event.window === self.window, event.keyCode == 53,
                          (self.window?.firstResponder as? NSTextView)?.hasMarkedText() != true else { return event }
                    dismiss()
                    return nil
                }
                if event.window !== self.window || !self.bounds.contains(self.convert(event.locationInWindow, from: nil)) { dismiss() }
                return event
            }
        }
        func stop() { if let monitor { NSEvent.removeMonitor(monitor) }; monitor = nil }
        deinit { stop() }
    }
}

/// TextKit supplies the actual glyph bounds, so the hover target follows line
/// wrapping, window resizing and selection instead of estimating word offsets.
private struct ArticleJourneyText: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    let content: String
    let scale: CGFloat
    var fontSize: CGFloat = 20
    var fontRole: BubbleTypography.Role = .body
    var highlightRange: NSRange? = nil
    var selectionIsPending = false
    var onSelection: ((NSRange) -> Void)? = nil
    var onHighlightRects: (([CGRect]) -> Void)? = nil
    @State private var wordRect: CGRect?

    var body: some View {
        Group {
            if content.contains("on your journey") || onSelection != nil {
                ArticleJourneyTextLayout(content: content, scale: scale, fontSize: fontSize, fontRole: fontRole,
                    highlightRange: highlightRange, selectionIsPending: selectionIsPending,
                    onSelection: onSelection, onHighlightRects: onHighlightRects) { rect in
                    wordRect = rect
                }
                .overlay(alignment: .topLeading) {
                    GeometryReader { geometry in
                        if let wordRect {
                            let collageScale = min(scale, geometry.size.width / 486)
                            let halfWidth = 243 * collageScale
                            let centerX = min(max(wordRect.midX + 27 * collageScale, halfWidth),
                                              geometry.size.width - halfWidth)
                            let origin = CGPoint(x: centerX - halfWidth, y: wordRect.minY - 235 * collageScale)
                            ArticleJourneyPortal(scale: collageScale, reduceMotion: reduceMotion,
                                reduceTransparency: reduceTransparency,
                                wordRect: wordRect.offsetBy(dx: -origin.x, dy: -origin.y))
                                .frame(width: 486 * collageScale, height: 275 * collageScale)
                                .position(x: centerX, y: wordRect.minY - 97.5 * collageScale)
                        }
                    }
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
                }
                .onDisappear { wordRect = nil }
            } else {
                Text(content).modifier(ArticleBodyTypography(scale: scale))
                    .textSelection(.enabled).fixedSize(horizontal: false, vertical: true)
            }
        }
        .foregroundStyle(fontRole == .body ? ArticleReaderStyle.bodyText : Color.primary)
        .zIndex(wordRect == nil ? 0 : 1)
    }
}

private struct ArticleJourneyTextLayout: NSViewRepresentable {
    let content: String
    let scale: CGFloat
    var fontSize: CGFloat = 20
    var fontRole: BubbleTypography.Role = .body
    var highlightRange: NSRange? = nil
    var selectionIsPending = false
    var onSelection: ((NSRange) -> Void)? = nil
    var onHighlightRects: (([CGRect]) -> Void)? = nil
    let onHover: (CGRect?) -> Void

    func makeNSView(context: Context) -> JourneyTextView {
        let view = JourneyTextView()
        view.wantsLayer = true
        view.isEditable = false
        view.isSelectable = true
        view.isRichText = true
        view.delegate = view
        view.drawsBackground = false
        view.textContainerInset = .zero
        view.textContainer?.lineFragmentPadding = 0
        view.textContainer?.widthTracksTextView = false
        view.isVerticallyResizable = false
        view.isHorizontallyResizable = false
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.setAccessibilityIdentifier("articleJourneyParagraph")
        return view
    }

    func updateNSView(_ view: JourneyTextView, context: Context) {
        view.onHover = onHover
        view.baseTextColor = fontRole == .body ? ArticleReaderStyle.bodyTextNative : NSColor.labelColor
        view.onSelection = onSelection
        view.onHighlightRects = onHighlightRects
        view.isUpdatingContent = true
        defer { view.isUpdatingContent = false }
        view.selectionIsPending = selectionIsPending
        if selectionIsPending { view.endHover() }
        if selectionIsPending || (view.highlightRange != nil && highlightRange == nil) {
            view.setSelectedRange(NSRange(location: 0, length: 0))
        }
        view.highlightRange = highlightRange
        let font = BubbleTypography.nativeFont(size: fontSize * scale, role: fontRole,
                                              weight: fontSize == 20 ? .regular : .medium)
        let paragraph = NSMutableParagraphStyle()
        paragraph.minimumLineHeight = (fontSize == 20 ? 26 : fontSize * 1.4) * scale
        paragraph.maximumLineHeight = paragraph.minimumLineHeight
        let text = NSMutableAttributedString(string: content, attributes: [
            .font: font, .foregroundColor: view.baseTextColor, .paragraphStyle: paragraph
        ])
        let phrase = (content as NSString).range(of: "on your journey")
        let range = phrase.location == NSNotFound ? phrase :
            NSRange(location: phrase.location + phrase.length - 7, length: 7)
        if range.location != NSNotFound {
            let color = view.isWordHovered ? NSColor.systemOrange : view.baseTextColor
            text.addAttributes([.underlineStyle: NSUnderlineStyle.single.rawValue | NSUnderlineStyle.patternDot.rawValue,
                                .foregroundColor: color, .underlineColor: NSColor.clear], range: range)
        }
        if !selectionIsPending, let highlightRange, NSMaxRange(highlightRange) <= text.length {
            text.addAttribute(.backgroundColor, value: NSColor.selectedTextBackgroundColor.withAlphaComponent(0.24), range: highlightRange)
        }
        if view.textStorage?.isEqual(to: text) != true {
            let selectedRange = view.selectedRange()
            let sameContent = view.string == content
            view.textStorage?.setAttributedString(text)
            // Applying the selection's background must not clear the native
            // selection or emit a delayed deselection on the first drag.
            if sameContent, NSMaxRange(selectedRange) <= text.length {
                view.setSelectedRange(selectedRange)
            }
            view.wordRange = range
            view.invalidateIntrinsicContentSize()
            view.needsLayout = true
        }
        view.scheduleHighlightRects()
    }

    func sizeThatFits(_ proposal: ProposedViewSize, nsView view: JourneyTextView, context: Context) -> CGSize? {
        guard let width = proposal.width, width > 0, let container = view.textContainer,
              let layout = view.layoutManager else { return nil }
        container.containerSize = CGSize(width: width, height: .greatestFiniteMagnitude)
        layout.ensureLayout(for: container)
        return CGSize(width: width, height: ceil(layout.usedRect(for: container).height))
    }

    static func dismantleNSView(_ view: JourneyTextView, coordinator: ()) {
        view.endHover()
        view.onHover = nil
        view.onSelection = nil
        view.onHighlightRects = nil
    }

    final class JourneyTextView: NSTextView, NSTextViewDelegate {
        var isUpdatingContent = false
        private var isDraggingSelection = false
        var baseTextColor = ArticleReaderStyle.bodyTextNative
        var onHover: ((CGRect?) -> Void)?
        var onSelection: ((NSRange) -> Void)?
        var onHighlightRects: (([CGRect]) -> Void)?
        var highlightRange: NSRange?
        var selectionIsPending = false
        private var highlightUpdateScheduled = false
        private var lastHighlightRects: [CGRect] = []
        var wordRange = NSRange(location: NSNotFound, length: 0)
        private var hoverArea: NSTrackingArea?
        private var lastRect: CGRect?
        private var scrollMonitor: Any?
        private var resizeObserver: NSObjectProtocol?
        private var suppressHoverUntilMouseMoves = false

        func endHover() { publish(nil) }
        deinit {
            if let scrollMonitor { NSEvent.removeMonitor(scrollMonitor) }
            if let resizeObserver { NotificationCenter.default.removeObserver(resizeObserver) }
        }
        var isWordHovered: Bool { lastRect != nil }

        override func layout() {
            super.layout()
            scheduleHighlightRects()
        }

        func scheduleHighlightRects() {
            guard !highlightUpdateScheduled else { return }
            highlightUpdateScheduled = true
            // sizeThatFits probes several widths. Publish only the final mounted
            // width, otherwise alternating probes can create a SwiftUI layout loop.
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.highlightUpdateScheduled = false
                self.publishHighlightRects()
            }
        }

        private func publishHighlightRects() {
            var rects: [CGRect] = []
            if let range = highlightRange, NSMaxRange(range) <= (textStorage?.length ?? 0),
               bounds.width > 0, let layout = layoutManager, let container = textContainer {
                container.containerSize = CGSize(width: bounds.width, height: .greatestFiniteMagnitude)
                layout.ensureLayout(for: container)
                let glyphs = layout.glyphRange(forCharacterRange: range, actualCharacterRange: nil)
                layout.enumerateEnclosingRects(forGlyphRange: glyphs,
                    withinSelectedGlyphRange: NSRange(location: NSNotFound, length: 0), in: container) { rect, _ in
                        rects.append(rect.offsetBy(dx: self.textContainerOrigin.x, dy: self.textContainerOrigin.y))
                    }
            }
            guard rects != lastHighlightRects else { return }
            lastHighlightRects = rects
            onHighlightRects?(rects)
        }

        private func publishSelection() {
            let range = selectedRange()
            onSelection?(range)
        }

        func textViewDidChangeSelection(_ notification: Notification) {
            guard !isUpdatingContent, !isDraggingSelection else { return }
            let range = selectedRange()
            DispatchQueue.main.async { [weak self] in
                guard let self, self.selectedRange() == range, !self.isUpdatingContent else { return }
                self.publishSelection()
            }
        }

        override func draw(_ dirtyRect: NSRect) {
            super.draw(dirtyRect)
            guard wordRange.location != NSNotFound, let layout = layoutManager,
                  let container = textContainer else { return }
            let glyphs = layout.glyphRange(forCharacterRange: wordRange, actualCharacterRange: nil)
            let scale = (font?.pointSize ?? 20) / 20
            let diameter = 1.2 * scale
            (isWordHovered ? NSColor.systemOrange : NSColor.labelColor).setFill()
            // Keep the native underline attribute for accessibility, but draw
            // round dots ourselves so descenders don't turn it into dashes.
            layout.enumerateEnclosingRects(forGlyphRange: glyphs,
                withinSelectedGlyphRange: NSRange(location: NSNotFound, length: 0), in: container) { rect, _ in
                let bounds = rect.offsetBy(dx: self.textContainerOrigin.x, dy: self.textContainerOrigin.y)
                for x in stride(from: bounds.minX + diameter / 2, through: bounds.maxX - diameter / 2, by: 3 * scale) {
                    NSBezierPath(ovalIn: NSRect(x: x - diameter / 2, y: bounds.maxY - diameter,
                                               width: diameter, height: diameter)).fill()
                }
            }
        }

        override func updateTrackingAreas() {
            super.updateTrackingAreas()
            if let hoverArea { removeTrackingArea(hoverArea) }
            let area = NSTrackingArea(rect: .zero,
                options: [.mouseEnteredAndExited, .mouseMoved, .activeAlways, .inVisibleRect],
                owner: self, userInfo: nil)
            addTrackingArea(area)
            hoverArea = area
            updateHover()
        }

        override func mouseEntered(with event: NSEvent) {
            suppressHoverUntilMouseMoves = false
            updateHover(at: event.locationInWindow)
        }
        override func mouseMoved(with event: NSEvent) {
            super.mouseMoved(with: event)
            suppressHoverUntilMouseMoves = false
            updateHover(at: event.locationInWindow)
        }
        override func mouseExited(with event: NSEvent) { publish(nil) }
        override func mouseDown(with event: NSEvent) {
            suppressHoverUntilMouseMoves = false
            publish(nil)
            isDraggingSelection = true
            super.mouseDown(with: event)
            isDraggingSelection = false
            publishSelection()
            if selectedRange().length == 0 { updateHover(at: event.locationInWindow) }
        }
        override func keyDown(with event: NSEvent) {
            if event.keyCode == 53 {
                publish(nil)
                setSelectedRange(NSRange(location: 0, length: 0))
                publishSelection()
            } else {
                super.keyDown(with: event)
                publishSelection()
            }
        }
        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            if let resizeObserver { NotificationCenter.default.removeObserver(resizeObserver) }
            resizeObserver = nil
            publish(nil)
            if let window {
                resizeObserver = NotificationCenter.default.addObserver(forName: NSWindow.willStartLiveResizeNotification,
                    object: window, queue: .main) { [weak self] _ in
                        self?.suppressHoverUntilMouseMoves = true
                        self?.publish(nil)
                    }
            }
        }

        private func updateHover(at eventPoint: CGPoint? = nil) {
            guard !selectionIsPending, !suppressHoverUntilMouseMoves, let window, let layout = layoutManager,
                  let container = textContainer, wordRange.location != NSNotFound else { publish(nil); return }
            let point = convert(eventPoint ?? window.mouseLocationOutsideOfEventStream, from: nil)
            guard visibleRect.contains(point) else { publish(nil); return }
            layout.ensureLayout(for: container)
            let glyphs = layout.glyphRange(forCharacterRange: wordRange, actualCharacterRange: nil)
            var hovered: CGRect?
            layout.enumerateEnclosingRects(forGlyphRange: glyphs,
                withinSelectedGlyphRange: NSRange(location: NSNotFound, length: 0), in: container) { rect, _ in
                let bounds = rect.offsetBy(dx: self.textContainerOrigin.x, dy: self.textContainerOrigin.y)
                if bounds.contains(point) { hovered = bounds }
            }
            publish(hovered)
        }

        private func publish(_ rect: CGRect?) {
            guard rect != lastRect else { return }
            let wasHovered = isWordHovered
            lastRect = rect
            if rect != nil, scrollMonitor == nil {
                // A window-level backdrop must disappear before the article scrolls.
                scrollMonitor = NSEvent.addLocalMonitorForEvents(matching: .scrollWheel) { [weak self] event in
                    if let self, event.window === self.window {
                        self.suppressHoverUntilMouseMoves = true
                        self.publish(nil)
                    }
                    return event
                }
            } else if rect == nil, let monitor = scrollMonitor {
                NSEvent.removeMonitor(monitor)
                scrollMonitor = nil
            }
            if wasHovered != isWordHovered, wordRange.location != NSNotFound,
               NSMaxRange(wordRange) <= (textStorage?.length ?? 0) {
                let color = isWordHovered ? NSColor.systemOrange : baseTextColor
                textStorage?.addAttributes([.foregroundColor: color], range: wordRange)
                needsDisplay = true
            }
            // Tracking areas also update during layout; deliver outside that pass.
            DispatchQueue.main.async { [weak self] in
                guard let self, self.lastRect == rect else { return }
                self.onHover?(rect)
            }
        }
    }
}

/// Reuses the three journey cutouts from the learning library collage;
/// placement follows Figma 1567:43877/43880/43883.
private struct ArticleJourneyCollage: View {
    let reduceMotion: Bool
    let scale: CGFloat
    @State private var visible = false

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.clear.frame(width: 486 * scale, height: 255 * scale)
            Image("ArticleJourneyTravel").resizable()
                .frame(width: 151.8 * scale, height: 102.4 * scale)
                .rotationEffect(.degrees(-4))
                .modifier(entrance(x: 40, y: 127, order: 0))
            Image("ArticleJourneyTicket").resizable()
                .frame(width: 195.2 * scale, height: 122.6 * scale)
                .rotationEffect(.degrees(-4))
                .modifier(entrance(x: 175, y: 32, order: 1))
            Image("ArticleJourneyQuote").resizable()
                .frame(width: 219.4 * scale, height: 56.6 * scale)
                .rotationEffect(.degrees(4))
                .modifier(entrance(x: 226, y: 170, order: 2))
        }
        .frame(width: 486 * scale, height: 275 * scale)
        .allowsHitTesting(false)
        .onAppear { visible = true }
    }

    private func entrance(x: CGFloat, y: CGFloat, order: Double) -> ArticleJourneyEntrance {
        .init(visible: visible, reduceMotion: reduceMotion, scale: scale, x: x, y: y, order: order)
    }
}

private struct ArticleJourneyEntrance: ViewModifier {
    let visible: Bool
    let reduceMotion: Bool
    let scale: CGFloat
    let x: CGFloat
    let y: CGFloat
    let order: Double
    func body(content: Content) -> some View {
        content
            .shadow(color: .black.opacity(0.12), radius: 20 * scale, y: 4 * scale)
            .opacity(visible ? 1 : 0)
            .offset(x: x * scale, y: (y + (visible || reduceMotion ? 0 : 14)) * scale)
            .animation(.easeOut(duration: reduceMotion ? 0.12 : 0.36)
                .delay(reduceMotion ? 0 : order * 0.055), value: visible)
    }
}

/// Sample this app's article before presenting the decoration. AppKit material
/// alone loses its backdrop inside SwiftUI composition groups; Core Image keeps
/// the underlying glyphs visibly blurred, with a light native material on top.
/// The sample lasts only for this hover; scrolling or resizing dismisses it.
private struct ArticleJourneyPortal: NSViewRepresentable {
    let scale: CGFloat
    let reduceMotion: Bool
    let reduceTransparency: Bool
    let wordRect: CGRect

    func makeNSView(context: Context) -> Anchor {
        Anchor(scale: scale, reduceMotion: reduceMotion, reduceTransparency: reduceTransparency, wordRect: wordRect)
    }
    func updateNSView(_ view: Anchor, context: Context) {
        view.configure(scale: scale, reduceMotion: reduceMotion, reduceTransparency: reduceTransparency, wordRect: wordRect)
    }
    static func dismantleNSView(_ view: Anchor, coordinator: ()) { view.overlay.removeFromSuperview() }

    final class PassThroughView: NSView {
        override var isFlipped: Bool { true }
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }

    final class Anchor: NSView {
        let overlay = PassThroughView()
        private let effect = NSVisualEffectView()
        private let backdrop = NSImageView()
        private var sampledRect: CGRect?
        private var isSampling = false
        private static let imageContext = CIContext()
        private let images: NSHostingView<ArticleJourneyCollage>
        private var scale: CGFloat
        private var wordRect: CGRect

        init(scale: CGFloat, reduceMotion: Bool, reduceTransparency: Bool, wordRect: CGRect) {
            self.scale = scale
            self.wordRect = wordRect
            images = NSHostingView(rootView: ArticleJourneyCollage(reduceMotion: reduceMotion, scale: scale))
            super.init(frame: .zero)
            effect.material = .popover
            effect.blendingMode = .withinWindow
            effect.state = .active
            effect.isHidden = reduceTransparency
            backdrop.isHidden = reduceTransparency
            backdrop.setAccessibilityHidden(true)
            backdrop.wantsLayer = true
            backdrop.imageScaling = .scaleAxesIndependently
            let mask = CALayer()
            backdrop.layer?.mask = mask
            effect.alphaValue = 0.10
            images.sizingOptions = []
            images.setAccessibilityElement(false)
            overlay.setAccessibilityElement(false)
            overlay.setAccessibilityHidden(true)
            overlay.addSubview(backdrop)
            overlay.addSubview(effect)
            overlay.addSubview(images)
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
        override var isFlipped: Bool { true }
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
        override func viewDidMoveToWindow() { super.viewDidMoveToWindow(); sync() }
        override func layout() { super.layout(); sync() }

        func configure(scale: CGFloat, reduceMotion: Bool, reduceTransparency: Bool, wordRect: CGRect) {
            self.scale = scale
            self.wordRect = wordRect
            effect.isHidden = reduceTransparency
            backdrop.isHidden = reduceTransparency
            images.rootView = ArticleJourneyCollage(reduceMotion: reduceMotion, scale: scale)
            sync()
        }

        private func sync() {
            guard !isSampling else { return }
            guard let root = window?.contentView else { overlay.removeFromSuperview(); return }
            guard bounds.width > 0, bounds.height > 0 else { return }
            let target = convert(bounds, to: root)
            let materialFrame = CGRect(x: 0, y: 10 * scale, width: 486 * scale, height: 285 * scale)
            // Sample inside the scroll document, before the reader's edge mask
            // creates a separate SwiftUI compositing group.
            let sourceView = enclosingScrollView?.documentView ?? root
            let sampleRect = convert(materialFrame, to: sourceView)
            if !backdrop.isHidden, sampledRect != sampleRect {
                isSampling = true
                overlay.isHidden = true
                sampleBackground(in: sourceView, rect: sampleRect)
                sampledRect = sampleRect
                overlay.isHidden = false
                isSampling = false
            }
            if overlay.superview !== root { root.addSubview(overlay) }
            overlay.frame = target
            backdrop.frame = materialFrame
            let mask = makeMask(in: materialFrame)
            effect.maskImage = mask
            backdrop.layer?.mask?.contents = mask.cgImage(forProposedRect: nil, context: nil, hints: nil)
            backdrop.layer?.mask?.frame = backdrop.bounds
            effect.frame = materialFrame
            images.frame = CGRect(x: 0, y: 0, width: 486 * scale, height: 275 * scale)
        }

        private func makeMask(in frame: CGRect) -> NSImage {
            let protectedWord = wordRect.offsetBy(dx: -frame.minX, dy: -frame.minY)
                .insetBy(dx: -3 * scale, dy: -2 * scale)
            let featherRadius = 3 * scale
            return NSImage(size: frame.size, flipped: false) { bounds in
                guard let context = NSGraphicsContext.current?.cgContext,
                      let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceGray(),
                        colors: [CGColor(gray: 1, alpha: 1), CGColor(gray: 1, alpha: 1),
                                 CGColor(gray: 1, alpha: 0)] as CFArray,
                        locations: [0, 0.86, 1]) else { return false }
                context.saveGState()
                context.translateBy(x: bounds.midX, y: bounds.midY)
                context.scaleBy(x: bounds.width / 2, y: bounds.height / 2)
                context.drawRadialGradient(gradient, startCenter: .zero, startRadius: 0,
                                           endCenter: .zero, endRadius: 1, options: [])
                context.restoreGState()
                // Let the material extend beneath the cutout shadows. Knock out
                // only the active word instead of exposing the whole text line.
                let clearRect = CGRect(x: protectedWord.minX, y: bounds.height - protectedWord.maxY,
                                       width: protectedWord.width, height: protectedWord.height)
                context.setBlendMode(.destinationOut)
                context.setFillColor(CGColor(gray: 0, alpha: 1))
                context.setShadow(offset: .zero, blur: featherRadius, color: CGColor(gray: 0, alpha: 1))
                context.addPath(CGPath(roundedRect: clearRect, cornerWidth: featherRadius,
                                       cornerHeight: featherRadius, transform: nil))
                context.fillPath()
                return true
            }
        }

        private func sampleBackground(in sourceView: NSView, rect: CGRect) {
            guard let bitmap = sourceView.bitmapImageRepForCachingDisplay(in: rect) else { return }
            sourceView.cacheDisplay(in: rect, to: bitmap)
            guard let cgImage = bitmap.cgImage else { return }
            let source = CIImage(cgImage: cgImage)
            // cacheDisplay can omit SwiftUI's GPU-composited canvas. Blurring a
            // transparent text raster would leave the original sharp glyphs
            // showing through, so first composite over the reader's canvas.
            let white: CGFloat = sourceView.effectiveAppearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
                ? 0.10 : 251.0 / 255
            let canvas = CIImage(color: CIColor(red: white, green: white, blue: white, alpha: 1))
                .cropped(to: source.extent)
            let opaqueSource = source.composited(over: canvas)
            let pixelsPerPoint = CGFloat(bitmap.pixelsWide) / rect.width
            let blurred = opaqueSource.clampedToExtent().applyingFilter("CIGaussianBlur",
                parameters: [kCIInputRadiusKey: 6 * scale * pixelsPerPoint]).cropped(to: source.extent)
            guard let rendered = Self.imageContext.createCGImage(blurred, from: source.extent) else { return }
            backdrop.image = NSImage(cgImage: rendered, size: rect.size)
        }
    }
}

/// Only newly received text fades in. A single attributed Text keeps normal
/// paragraph wrapping and selection, without inserting a typing cursor.
private struct ArticleStreamingText: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let content: String
    let streaming: Bool
    let scale: CGFloat
    @State private var receivedContent = ""
    @State private var segments: [Segment] = []
    @State private var isFading = false
    private let fadeDuration = 0.28

    private struct Segment {
        let text: String
        let arrivedAt: Date
    }

    var body: some View {
        Group {
            if !streaming && !isFading {
                ArticleJourneyText(content: content, scale: scale)
            } else {
                TimelineView(.animation(minimumInterval: 1.0 / 60, paused: !isFading || reduceMotion)) { timeline in
                    Text(attributedText(at: timeline.date))
                        .modifier(ArticleBodyTypography(scale: scale))
                        .textSelection(.enabled)
                }
            }
        }
        .onChange(of: content, initial: true) { _, value in
            receive(value)
        }
        .task(id: content) {
            // Settle the last batch even when generation is stopped or finishes.
            do { try await Task.sleep(for: .milliseconds(280)) }
            catch { return }
            segments = content.isEmpty ? [] : [Segment(text: content, arrivedAt: .distantPast)]
            isFading = false
        }
    }

    private func receive(_ value: String) {
        guard value != receivedContent else { return }
        let now = Date()
        if value.hasPrefix(receivedContent), streaming || !receivedContent.isEmpty {
            // Coalesce settled text so only the short trailing fade needs updating.
            let settled = segments.prefix { now.timeIntervalSince($0.arrivedAt) >= fadeDuration }
            let stableText = settled.map(\.text).joined()
            segments = (stableText.isEmpty ? [] : [Segment(text: stableText, arrivedAt: .distantPast)])
                + segments.dropFirst(settled.count)
            segments.append(Segment(text: String(value.dropFirst(receivedContent.count)), arrivedAt: now))
            isFading = true
        } else {
            // Restored results and steering edits do not replay the whole paragraph.
            segments = value.isEmpty ? [] : [Segment(text: value, arrivedAt: .distantPast)]
            isFading = false
        }
        receivedContent = value
    }

    private func attributedText(at date: Date) -> AttributedString {
        var result = AttributedString()
        for segment in segments {
            let progress = reduceMotion ? 1 : min(1, max(0, date.timeIntervalSince(segment.arrivedAt) / fadeDuration))
            let opacity = progress * progress * (3 - 2 * progress)
            var text = AttributedString(segment.text)
            text.foregroundColor = ArticleReaderStyle.bodyText.opacity(opacity)
            result += text
        }
        return result
    }
}

/// A comment always carries a snapshot of the selected text or image into chat.
private struct ArticleLocalCommentMessage: View {
    let edit: ArticleGenerationPreview.LocalEdit
    let scale: CGFloat
    var body: some View {
        VStack(alignment: .leading, spacing: 14 * scale) {
            Label(edit.selection.target.label, systemImage: edit.imageAsset == nil ? "text.quote" : "photo")
                .bubbleFont(.caption, size: 13 * scale).foregroundStyle(.secondary)
            HStack(spacing: 12 * scale) {
                RoundedRectangle(cornerRadius: 1).fill(Color.primary.opacity(0.18)).frame(width: 2)
                if let asset = edit.imageAsset {
                    Image(asset).resizable().scaledToFill().frame(width: 110 * scale, height: 68 * scale)
                        .clipped().clipShape(RoundedRectangle(cornerRadius: 6 * scale))
                        .accessibilityLabel("修改前的配图")
                } else {
                    Text(edit.selection.quote).bubbleFont(.body, size: 15 * scale)
                        .foregroundStyle(.secondary).lineLimit(4).textSelection(.enabled)
                }
            }.fixedSize(horizontal: false, vertical: true)
            Text(edit.comment).modifier(ArticleBodyTypography(scale: scale)).textSelection(.enabled)
        }
        .padding(20 * scale).frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 1, green: 250.0 / 255, blue: 240.0 / 255),
                    in: RoundedRectangle(cornerRadius: 16 * scale))
        .overlay(RoundedRectangle(cornerRadius: 16 * scale).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
        .accessibilityIdentifier("articleLocalEditComment")
    }
}

private struct ArticleImageQuoteButton: View {
    let preview: ArticleGenerationPreview
    let selection: ArticleGenerationPreview.LocalSelection
    let scale: CGFloat
    let onQuote: (ArticleGenerationPreview.LocalSelection) -> Void
    private var controlWidth: CGFloat { 84 * scale }
    private var controlHeight: CGFloat { 38 * scale }

    var body: some View {
        control
        .onExitCommand { preview.localSelection = nil }
    }

    private var control: some View {
        Button { onQuote(selection) } label: {
            HStack(spacing: 4 * scale) {
                Image("ArticleQuoteAction").renderingMode(.template).resizable()
                    .frame(width: 12 * scale, height: 11 * scale)
                    .frame(width: 20 * scale, height: 20 * scale)
                    .accessibilityHidden(true)
                Text("引用").bubbleFont(.body, size: 16 * scale).fixedSize()
            }
            .foregroundStyle(Color(white: 43.0 / 255))
            .padding(.leading, 12 * scale).padding(.trailing, 16 * scale)
            .frame(width: controlWidth, height: controlHeight)
            .background(ArticleReaderStyle.surface, in: Capsule())
            .overlay(Capsule().strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .shadow(color: .black.opacity(0.12), radius: 6 * scale)
        .accessibilityLabel("引用")
        .accessibilityIdentifier("quoteArticleSelection")
        .help("引用到对话")
    }
}

private struct ArticleComposerQuote: View {
    let selection: ArticleGenerationPreview.LocalSelection
    let imageCaption: String
    let scale: CGFloat
    let onRemove: () -> Void
    private var text: String { selection.target == .image ? imageCaption : selection.quote }

    var body: some View {
        HStack(spacing: 6 * scale) {
            Image("ArticleQuoteOpening").renderingMode(.template).resizable()
                .frame(width: 10 * scale, height: 9 * scale)
                .frame(width: 16 * scale, height: 16 * scale)
                .accessibilityHidden(true)
            Text(text.replacingOccurrences(of: "\n", with: " "))
                .font(.system(size: 15 * scale)).tracking(-0.23 * scale)
                .lineLimit(1).truncationMode(.tail)
                .frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityLabel(text)
                .accessibilityIdentifier("articleComposerQuoteText")
            Button(action: onRemove) {
                Image("ArticleQuoteDismiss").renderingMode(.template).resizable()
                    .frame(width: 8 * scale, height: 8 * scale)
                    .frame(width: 16 * scale, height: 16 * scale)
                    .contentShape(Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("移除引用")
            .accessibilityIdentifier("removeArticleComposerQuote")
            .help("移除引用")
        }
        .foregroundStyle(Color.primary.opacity(0.86))
        .padding(.horizontal, 10 * scale)
        .frame(height: 36 * scale)
        .background(Color.primary.opacity(0.05), in: Capsule())
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("articleComposerQuote")
    }
}

private struct ArticleLocalEditableText: View {
    @Environment(MacCaptureController.self) private var capture
    let preview: ArticleGenerationPreview
    let target: ArticleGenerationPreview.LocalTarget
    let content: String
    let scale: CGFloat
    let onQuote: (ArticleGenerationPreview.LocalSelection) -> Void
    var fontSize: CGFloat = 20
    var fontRole: BubbleTypography.Role = .body
    @State private var rects: [CGRect] = []
    private var selection: ArticleGenerationPreview.LocalSelection? {
        preview.localSelection?.target == target ? preview.localSelection : nil
    }
    private var pending: ArticleGenerationPreview.LocalSelection? {
        preview.localEdit?.selection.target == target ? preview.localEdit?.selection : nil
    }
    var body: some View {
        ArticleJourneyText(content: content, scale: scale, fontSize: fontSize, fontRole: fontRole,
            highlightRange: (pending ?? selection)?.range,
            selectionIsPending: pending != nil,
            onSelection: { range in
                guard preview.canEditLocally else { return }
                if range.length > 0, Range(range, in: content) != nil {
                    let next = ArticleGenerationPreview.LocalSelection(target: target, original: content, range: range)
                    if preview.localSelection != next { preview.localSelection = next }
                    capture.showArticleSelection(owner: preview.id, text: next.quote, context: content,
                        isValid: { preview.canEditLocally && preview.localSelection == next
                            && preview.localContent(target) == content },
                        quote: { onQuote(next) })
                } else if selection != nil { preview.localSelection = nil }
            }, onHighlightRects: { if rects != $0 { rects = $0 } })
        // Mask the text itself; pending edits have no native or attributed selection background.
        .modifier(ArticleProgressShimmer(active: pending != nil, scale: scale, rects: rects))
        .zIndex(selection == nil ? 0 : 5)
        .onExitCommand { preview.localSelection = nil }
    }
}

private struct ArticlePreviewReading: View {
    @Environment(MacCaptureController.self) private var capture
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let preview: ArticleGenerationPreview
    let scale: CGFloat
    let onQuote: (ArticleGenerationPreview.LocalSelection) -> Void
    private var isSpace: Bool { preview.id == LearningLibraryTopic.space.articleID }
    var body: some View {
        VStack(alignment: .leading, spacing: 12 * scale) {
            if !preview.outlineVisible {
                EmptyView()
            } else if preview.showsArticleOutline {
                VStack(alignment: .leading, spacing: 36 * scale) {
                    Text("The article will follow this outline")
                        .bubbleFont(.largeTitle, size: 48 * scale, weight: .medium, role: .word)
                        .frame(maxWidth: .infinity, minHeight: 71 * scale, alignment: .leading)
                        .fixedSize(horizontal: false, vertical: true)
                        .accessibilityIdentifier("articleOutlineTitle")
                    VStack(alignment: .leading, spacing: 12 * scale) {
                        ForEach(Array(preview.outline.enumerated()), id: \.offset) { index, item in
                            VStack(alignment: .leading, spacing: 0) {
                                Text(item.heading)
                                    .bubbleFont(.title2, size: 28 * scale, weight: .medium, role: .word)
                                    .frame(minHeight: 42 * scale, alignment: .leading)
                                Text(item.detail).modifier(ArticleBodyTypography(scale: scale))
                                    .foregroundStyle(ArticleReaderStyle.bodyText)
                                    .fixedSize(horizontal: false, vertical: true)
                            }.frame(maxWidth: .infinity, alignment: .leading)
                                .accessibilityIdentifier("articleOutlineItem-\(index)")
                        }
                    }
                    .padding(36.5 * scale)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(ArticleReaderStyle.surface, in: RoundedRectangle(cornerRadius: 32 * scale))
                    .overlay(RoundedRectangle(cornerRadius: 32 * scale).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
                    .textSelection(.enabled)
                }
                .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.outline)))
                .id("preview-outline")
                .transition(reduceMotion ? .opacity : .opacity.combined(with: .offset(y: 12 * scale)))
            } else if preview.showsArticleText {
                VStack(alignment: .leading, spacing: 12 * scale) {
                VStack(alignment: .leading, spacing: 12 * scale) {
                editableText(preview.article.title, target: .title, fontSize: 48, fontRole: .word)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("articleTitle")
                editableText(preview.article.summary, target: .summary)
                    .foregroundStyle(ArticleReaderStyle.bodyText)
                }.padding(.bottom, 24 * scale)
                    .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.outline)))
                    .id("preview-outline")
                if let note = preview.generationNotes[.writing] {
                    Text("Writing focus: " + note).bubbleFont(.caption, size: 14 * scale).foregroundStyle(.secondary)
                        .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.writing)))
                }
                    ForEach(Array(preview.article.sections.enumerated()).filter { preview.showsSection(at: $0.offset) }, id: \.offset) { index, section in
                        VStack(alignment: .leading, spacing: 12 * scale) {
                            editableText(section.heading, target: .heading(index), fontSize: 28, fontRole: .word)
                                .padding(.top, (index == 0 ? 4 : 8) * scale)
                                .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.outline)))
                            let paragraphs = preview.text(at: index).components(separatedBy: "\n\n")
                            ForEach(Array(paragraphs.enumerated()), id: \.offset) { paragraphIndex, paragraph in
                                if !paragraph.isEmpty {
                                    Group {
                                        if preview.isComplete {
                                            ArticleLocalEditableText(preview: preview,
                                                target: .paragraph(section: index, paragraph: paragraphIndex), content: paragraph, scale: scale,
                                                onQuote: onQuote)
                                        } else {
                                            ArticleStreamingText(content: paragraph, streaming: preview.isWritingSection(index), scale: scale)
                                        }
                                    }.modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.writing)))
                                        .zIndex(preview.localSelection?.target == .paragraph(section: index, paragraph: paragraphIndex) ? 5 : 0)
                                        .transition(.opacity)
                                }
                                if index == 0 && paragraphIndex == 0 && preview.showsImages { illustration }
                            }
                            if index == 1 && isSpace && preview.showsImages {
                                Group {
                                    if preview.imagesReady {
                                        Image("ArticleSpaceHistory").resizable().scaledToFit()
                                            .clipShape(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
                                            .accessibilityLabel("Spacesuit parts: helmet, visor, spacesuit, connector, glove and boot")
                                            .accessibilityIdentifier("spaceSuitIllustration")
                                    } else {
                                        ArticlePreviewSkeleton(kind: .image, scale: scale, active: preview.isGenerating, imageProgress: preview.imageProgress)
                                            .transition(.opacity)
                                    }
                                }
                                .padding(.vertical, 16 * scale)
                                .id("preview-camera")
                                .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.images)))
                            }
                            if index == 1 && !isSpace && preview.showsArtifact {
                                Group {
                                    if preview.artifactReady {
                                        ArticleCameraStudy(scale: scale)
                                            .transition(.opacity)
                                    } else {
                                        ArticlePreviewSkeleton(kind: .artifact, scale: scale, active: preview.isGenerating)
                                            .accessibilityIdentifier("articleArtifactSkeleton")
                                            .transition(.opacity)
                                    }
                                }
                                .padding(.vertical, 16 * scale)
                                .accessibilityIdentifier("articlePreviewArtifact")
                                .id("preview-camera")
                                .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.artifact)))
                            }
                        }.frame(maxWidth: .infinity, alignment: .leading)
                            .zIndex(selectedSection == index ? 5 : 0)
                            .accessibilityElement(children: .contain)
                            .accessibilityIdentifier("articlePreviewSection-\(index)")
                            .id("preview-section-\(index)")
                    }
                }
                .transition(reduceMotion ? .opacity : .opacity.combined(with: .offset(y: 12 * scale)))
            }
            if preview.showsImages && preview.researchReady {
                Text(isSpace ? "Explore further" : ArticlePreviewContent.referenceHeading)
                    .bubbleFont(.title2, size: 28 * scale, weight: .medium, role: .word)
                    .padding(.top, 8 * scale)
                    .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.research)))
                Text(isSpace ? "Discover the planets, moons and other objects in our solar system with NASA Science." : ArticlePreviewContent.referenceIntroduction)
                    .modifier(ArticleBodyTypography(scale: scale))
                    .foregroundStyle(ArticleReaderStyle.bodyText)
                    .textSelection(.enabled)
                    .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.research)))
                Group {
                    ArticlePreviewReferenceCard(scale: scale, isSpace: isSpace)
                }
                    .padding(.vertical, 16 * scale)
                    .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.research)))
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
            .onChange(of: preview.localSelection) { _, selection in
                if selection == nil || selection?.target == .image { capture.dismissArticleSelection(owner: preview.id) }
            }
            .onChange(of: preview.canEditLocally) { _, editable in
                if !editable { capture.dismissArticleSelection(owner: preview.id) }
            }
            .onDisappear { capture.dismissArticleSelection(owner: preview.id) }
            .animation(reduceMotion ? nil : ArticleReaderStyle.stepTransition, value: preview.outlineVisible)
            .animation(reduceMotion ? nil : ArticleReaderStyle.stepTransition, value: preview.isShowingRevisedOutline)
            .animation(reduceMotion ? nil : ArticleReaderStyle.stepTransition, value: preview.step)
            .animation(reduceMotion ? nil : ArticleReaderStyle.stepTransition, value: preview.isComplete)
    }
    private var selectedSection: Int? {
        switch preview.localSelection?.target {
        case .paragraph(let section, _): return section
        case .heading(let section): return section
        default: return nil
        }
    }
    @ViewBuilder
    private func editableText(_ content: String, target: ArticleGenerationPreview.LocalTarget,
                              fontSize: CGFloat = 20, fontRole: BubbleTypography.Role = .body) -> some View {
        if preview.isComplete {
            ArticleLocalEditableText(preview: preview, target: target, content: content, scale: scale,
                                     onQuote: onQuote, fontSize: fontSize, fontRole: fontRole)
        } else if fontSize == 20 {
            Text(content).modifier(ArticleBodyTypography(scale: scale))
        } else {
            Text(content).bubbleFont(.title2, size: fontSize * scale, weight: .medium, role: fontRole)
        }
    }
    private var illustration: some View {
        Group {
            if let progress = preview.localImageProgress {
                ArticlePreviewSkeleton(kind: .image, scale: scale, active: true, imageProgress: progress)
                    .accessibilityIdentifier("articleLocalImageGeneration")
            } else if preview.imagesReady {
                Color.clear.aspectRatio(803.0 / 389, contentMode: .fit)
                    .overlay {
                        GeometryReader { geometry in
                            // Figma 1572:43980: the original image is 206.43% of the crop height.
                            let originalCrop = preview.imageAsset == "ArticleGeneratedBuilding"
                            let imageHeight: CGFloat = geometry.size.height * (originalCrop ? 2.0643 : 1.0)
                            let imageOffset: CGFloat = originalCrop ? -geometry.size.height * 0.2365 : 0.0
                            Image(preview.imageAsset).resizable().scaledToFill()
                                .frame(width: geometry.size.width, height: imageHeight)
                                .offset(y: imageOffset)
                        }
                        .allowsHitTesting(false)
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
                    .overlay {
                        if preview.localSelection?.target == .image {
                            RoundedRectangle(cornerRadius: 12 * scale).strokeBorder(Color.accentColor, lineWidth: 2)
                                .allowsHitTesting(false)
                        }
                    }
                    .overlay {
                        Button(action: selectImage) {
                            Color.clear.contentShape(RoundedRectangle(cornerRadius: 12 * scale))
                        }.buttonStyle(.plain)
                            .accessibilityLabel("选择配图：" + preview.imageCaption)
                            .accessibilityIdentifier("selectArticleImage")
                    }
                    .overlay(alignment: .topTrailing) {
                        if let selection = preview.localSelection, selection.target == .image, preview.canEditLocally {
                            ArticleImageQuoteButton(preview: preview, selection: selection, scale: scale, onQuote: onQuote)
                                .padding(12 * scale)
                        }
                    }
                    .accessibilityElement(children: .contain)
                    .transition(.opacity)
            } else {
                    ArticlePreviewSkeleton(kind: .image, scale: scale, active: preview.isGenerating, imageProgress: preview.imageProgress)
                        .accessibilityIdentifier("articleImageSkeleton")
                        .transition(.opacity)
            }
        }.padding(.vertical, 16 * scale)
            // The enlarged crop extends above its visible frame. It is decorative
            // and must not intercept pointer events from the journey paragraph.
            .allowsHitTesting(preview.canEditLocally)
            .accessibilityIdentifier("articlePreviewImage").id("preview-image")
            .modifier(ArticleDiscardTransition(discarding: preview.isDiscarding(.images)))
    }
    private func selectImage() {
        guard preview.canEditLocally else { return }
        preview.localSelection = .init(target: .image, original: preview.imageAsset, range: NSRange(location: 0, length: 0))
    }
    private func sectionLabel(_ number: String, title: String, ready: Bool) -> some View {
        HStack(spacing: 10 * scale) {
            Text(number).foregroundStyle(.tertiary).monospacedDigit()
            Text(title)
            Spacer()
            if !ready { Text(preview.isStopped ? "Stopped" : "Coming up").font(.system(size: 12 * scale)).foregroundStyle(.tertiary) }
        }.bubbleFont(.caption, size: 15 * scale, weight: .medium)
    }
}

private struct ArticlePreviewReferenceCard: View {
    let scale: CGFloat
    var isSpace = false
    private var referenceURL: URL { isSpace ? ArticleSpaceContent.referenceURL : ArticlePreviewContent.referenceURL }

    var body: some View {
        Link(destination: referenceURL) {
            HStack(spacing: 24 * scale) {
                Image(isSpace ? "ArticleSpaceExploration" : "ArticleDreamyReference").resizable().scaledToFill()
                    .frame(width: 165 * scale, height: 165 * scale)
                    .clipShape(RoundedRectangle(cornerRadius: 16 * scale, style: .continuous))
                VStack(alignment: .leading, spacing: 0) {
                    VStack(alignment: .leading, spacing: 8 * scale) {
                        Text(isSpace ? "Explore our solar system" : ArticlePreviewContent.referenceTitle)
                            .bubbleFont(.title2, size: 28 * scale, weight: .medium, role: .word)
                        Text(isSpace ? "NASA Science · Planets, moons and the world beyond Earth." : ArticlePreviewContent.referenceSummary)
                            .modifier(ArticleBodyTypography(scale: scale))
                    }
                    Spacer(minLength: 8 * scale)
                    Text(referenceURL.absoluteString)
                        .modifier(ArticleBodyTypography(scale: scale))
                        .foregroundStyle(Color.primary.opacity(0.4))
                }
                .padding(.top, 4 * scale).padding(.bottom, 8 * scale)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
            }
            .padding(16.5 * scale)
            .frame(height: 198 * scale)
            .background(ArticleReaderStyle.surface, in: RoundedRectangle(cornerRadius: 32 * scale))
            .overlay(RoundedRectangle(cornerRadius: 32 * scale).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
            .contentShape(RoundedRectangle(cornerRadius: 32 * scale))
        }
        .buttonStyle(.plain).foregroundStyle(.primary)
        .accessibilityIdentifier("articleOriginalReference")
    }
}

private struct ArticlePreviewSkeleton: View {
    enum Kind { case article, image, artifact }
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let kind: Kind
    let scale: CGFloat
    var active = true
    var imageProgress: Double? = nil
    @State private var glowing = false
    var body: some View {
        if kind == .image {
            ArticleImagePlaceholder(scale: scale, active: active, progress: imageProgress)
        } else {
        VStack(alignment: .leading, spacing: 14 * scale) {
                if kind == .article { bar(0.82, height: 34); bar(0.58, height: 34); Color.clear.frame(height: 10 * scale) }
                bar(kind == .artifact ? 0.65 : 1, height: kind == .artifact ? 22 : 12)
                bar(0.94, height: 12)
                bar(0.78, height: 12)
                if kind == .artifact {
                    ForEach(0..<3) { _ in bar(1, height: 34) }
                }
        }
        .padding(kind == .artifact ? 24 * scale : 0)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(kind == .artifact ? Color.primary.opacity(0.035) : .clear,
                    in: RoundedRectangle(cornerRadius: 18 * scale, style: .continuous))
        .opacity(reduceMotion || !active ? 0.8 : glowing ? 1 : 0.42)
        .task(id: active && !reduceMotion) {
            withAnimation(nil) { glowing = false }
            guard active, !reduceMotion else { return }
            withAnimation(.easeInOut(duration: 1.05).repeatForever(autoreverses: true)) { glowing = true }
        }
        .accessibilityElement(children: .ignore).accessibilityLabel("\(active ? "Preparing" : "Pending") \(kind == .image ? "illustration" : kind == .artifact ? "interactive practice" : "article")")
        }
    }
    private func bar(_ fraction: CGFloat, height: CGFloat) -> some View {
        GeometryReader { geometry in
            RoundedRectangle(cornerRadius: min(6, height / 2) * scale, style: .continuous)
                .fill(Color.primary.opacity(0.085)).frame(width: geometry.size.width * fraction)
        }.frame(height: height * scale)
    }
}

/// The requested dot-wave loading treatment keeps the final image's aspect ratio.
private struct ArticleImagePlaceholder: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let scale: CGFloat
    let active: Bool
    let progress: Double?
    var body: some View {
        Color.clear.aspectRatio(803.0 / 389, contentMode: .fit)
            .overlay {
                TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !active || reduceMotion)) { timeline in
                    Canvas { context, size in
                        let time = active && !reduceMotion ? timeline.date.timeIntervalSinceReferenceDate : 0
                        let spacing = 22 * scale
                        let columns = max(2, Int(size.width / spacing))
                        let rows = max(2, Int(size.height / spacing))
                        for row in 0...rows {
                            for column in 0...columns {
                                let x = Double(column) / Double(columns)
                                let y = Double(row) / Double(rows)
                                let dx = x - (0.52 + 0.18 * cos(time * 0.65))
                                let dy = y - (0.40 + 0.15 * sin(time * 0.52))
                                let dx2 = x - (0.23 + 0.10 * sin(time * 0.74))
                                let dy2 = y - (0.73 + 0.12 * cos(time * 0.58))
                                let field = min(1, exp(-(dx * dx * 14 + dy * dy * 12))
                                    + 0.85 * exp(-(dx2 * dx2 * 30 + dy2 * dy2 * 24)))
                                let ripple = 0.76 + 0.24 * sin(x * 15 + y * 10 - time * 1.6)
                                let strength = field * ripple
                                let radius = (0.85 + 1.65 * strength) * scale
                                let point = CGPoint(x: 4 * scale + x * max(0, size.width - 8 * scale),
                                                    y: 4 * scale + y * max(0, size.height - 8 * scale))
                                context.fill(Path(ellipseIn: CGRect(x: point.x - radius, y: point.y - radius,
                                    width: radius * 2, height: radius * 2)),
                                    with: .color(Color(red: 0.28, green: 0.49, blue: 1).opacity(0.14 + 0.72 * strength)))
                            }
                        }
                    }
                }
                .padding(.horizontal, 28 * scale).padding(.top, 62 * scale).padding(.bottom, 24 * scale)
            }
            .overlay(alignment: .topLeading) {
                Text(progress == nil ? "正在准备图片" : "正在生成图片")
                    .bubbleFont(.body, size: 18 * scale).foregroundStyle(.secondary)
                    .padding(.horizontal, 32 * scale).padding(.top, 22 * scale)
            }
            .overlay(alignment: .bottomTrailing) {
                if let progress {
                    Text("\(Int(progress * 100))%")
                        .bubbleFont(.body, size: 18 * scale).monospacedDigit()
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 18 * scale).padding(.vertical, 8 * scale)
                        .background(ArticleReaderStyle.surface, in: Capsule())
                        .overlay(Capsule().strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
                        .shadow(color: .black.opacity(0.06), radius: 8 * scale, y: 4 * scale)
                        .padding(24 * scale)
                }
            }
            .background(ArticleReaderStyle.canvas)
            .clipShape(RoundedRectangle(cornerRadius: 12 * scale))
            .overlay(RoundedRectangle(cornerRadius: 12 * scale).strokeBorder(ArticleReaderStyle.border, lineWidth: 0.5))
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(progress == nil ? "正在准备图片" : "正在生成图片")
            .accessibilityValue(progress.map { "\(Int($0 * 100))%" } ?? "")
    }
}

private struct ArticlePreviewIllustration: View {
    let topic: String
    let scale: CGFloat
    private var cooking: Bool { topic.lowercased().contains("cook") }
    private var music: Bool { topic.lowercased().contains("music") }
    var body: some View {
        VStack(spacing: 28 * scale) {
            HStack(spacing: 22 * scale) {
                Image(systemName: cooking ? "carrot" : music ? "waveform" : "eye")
                Image(systemName: "arrow.right").font(.system(size: 18 * scale, weight: .light))
                Image(systemName: cooking ? "flame" : music ? "music.note" : "slider.horizontal.3")
                Image(systemName: "arrow.right").font(.system(size: 18 * scale, weight: .light))
                Image(systemName: cooking ? "fork.knife" : music ? "headphones" : "arrow.triangle.2.circlepath")
            }.font(.system(size: 44 * scale, weight: .ultraLight))
            Text(cooking ? "Taste. Adjust. Taste again." : music ? "Find the rhythm. Follow the melody." : "Notice. Experiment. Compare.")
                .bubbleFont(.title2, size: 25 * scale, weight: .medium, role: .word)
        }.foregroundStyle(Color(red: 0.32, green: 0.29, blue: 0.23))
            .frame(maxWidth: .infinity).frame(height: 250 * scale)
            .background(LinearGradient(colors: [Color(red: 0.98, green: 0.92, blue: 0.79), Color(red: 0.9, green: 0.94, blue: 0.89)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 18 * scale, style: .continuous))
    }
}

private struct ArticlePreviewQuiz: View {
    @Bindable var preview: ArticleGenerationPreview
    let scale: CGFloat
    var body: some View {
        VStack(alignment: .leading, spacing: 20 * scale) {
            HStack {
                Label("WORD CHECK", systemImage: "sparkles").tracking(1.4 * scale)
                Spacer()
                Text(preview.quizSelection == nil ? "Your turn" : "1 / 1 answered").foregroundStyle(.secondary)
            }.bubbleFont(.caption, size: 12 * scale, weight: .medium)
            if let note = preview.generationNotes[.artifact] {
                Text("Practice focus: " + note).bubbleFont(.caption, size: 14 * scale).foregroundStyle(.secondary)
            }
            Text(preview.practice.question)
                .bubbleFont(.title2, size: 25 * scale, weight: .medium, role: .word)
                .fixedSize(horizontal: false, vertical: true)
            ForEach(Array(preview.practice.choices.enumerated()), id: \.offset) { index, choice in
                Button { preview.quizSelection = index } label: {
                    HStack(spacing: 12 * scale) {
                        Text(preview.practice.label(at: index)).foregroundStyle(.secondary)
                        Text(choice)
                        Spacer()
                        if preview.quizSelection != nil && index == preview.practice.answer {
                            Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                        } else if preview.quizSelection == index {
                            Image(systemName: "xmark.circle").foregroundStyle(.orange)
                        }
                    }.bubbleFont(.body, size: 18 * scale)
                        .padding(15 * scale).frame(maxWidth: .infinity, alignment: .leading)
                        .background(ArticleReaderStyle.surface.opacity(preview.quizSelection == index ? 1 : 0.55), in: RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
                        .contentShape(RoundedRectangle(cornerRadius: 12 * scale, style: .continuous))
                }.buttonStyle(.plain).disabled(preview.quizSelection != nil)
                    .accessibilityIdentifier("articleArtifactChoice-\(index)")
            }
            if let choice = preview.quizSelection {
                Text(choice == preview.practice.answer
                    ? "That's right! " + preview.practice.explanation
                    : "The answer is " + preview.practice.label(at: preview.practice.answer) + ". " + preview.practice.explanation)
                    .modifier(ArticleBodyTypography(scale: scale)).accessibilityIdentifier("articleArtifactFeedback")
                Button("Try again") { preview.quizSelection = nil }.buttonStyle(.plain)
                    .bubbleFont(.caption, size: 15 * scale, weight: .medium)
            }
        }.padding(28 * scale).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.orange.opacity(0.065), in: RoundedRectangle(cornerRadius: 20 * scale, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20 * scale, style: .continuous).strokeBorder(Color.orange.opacity(0.16), lineWidth: 0.5))
            .accessibilityIdentifier("articleInteractiveArtifact")
    }
}
