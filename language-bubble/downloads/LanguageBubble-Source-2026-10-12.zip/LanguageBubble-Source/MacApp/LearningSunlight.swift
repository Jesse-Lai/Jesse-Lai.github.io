import SwiftUI
import AppKit
import MetalKit
import os

/// A transparent shadow layer; the parent supplies the surface, pointer input and controls.
struct LearningSunlight: View {
    var pointer: CGPoint? = nil // Normalized, top-left origin.
    var active = true
    var motionDisabled = false // Callers may opt out; the system setting always wins.
    var softness: Float = 1
    var intensity: Float = 1
    var pointerTravel: Float = 0.30 // Full pointer range maps to 30% of the viewport.
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var visible = false

    var body: some View {
        NativeSunlight(pointer: pointer, running: visible && active && scenePhase == .active,
                       reduceMotion: reduceMotion || motionDisabled, softness: softness, intensity: intensity,
                       pointerTravel: pointerTravel)
            .allowsHitTesting(false)
            .accessibilityHidden(true)
            .onAppear { visible = true }
            .onDisappear { visible = false }
    }
}

struct SunlightUniforms {
    var viewport: SIMD4<Float>
    var light: SIMD4<Float>
}

enum SunlightRenderError: LocalizedError {
    case unavailable, missingLibrary, allocation
    var errorDescription: String? {
        switch self {
        case .unavailable: return "Metal is unavailable."
        case .missingLibrary: return "The bundled sunlight Metal library is missing."
        case .allocation: return "Unable to allocate the sunlight render targets."
        }
    }
}

/// Two half-resolution optical passes, followed by a display-resolution composite.
/// All GPU work is serial on one command queue; no per-frame CPU texture creation.
@MainActor final class SunlightRenderer: NSObject, MTKViewDelegate {
    let device: MTLDevice
    let queue: MTLCommandQueue
    private let fieldPipeline: MTLRenderPipelineState
    private let bokehPipeline: MTLRenderPipelineState
    private let compositePipeline: MTLRenderPipelineState
    private var field: MTLTexture?
    private var blurred: MTLTexture?
    private let inFlight = DispatchSemaphore(value: 2)
    private var lastTick: CFTimeInterval?
    private(set) var elapsed: Float = 4
    private(set) var center = SIMD2<Float>(0.5, 0.5)
    private(set) var renderedFrames = 0
    var target = SIMD2<Float>(0.5, 0.5)
    var softness: Float = 1
    var intensity: Float = 1
    var reducedMotion = false
    var animationEnabled = false

    init(bundle: Bundle = .main) throws {
        guard let gpu = MTLCreateSystemDefaultDevice(), let queue = gpu.makeCommandQueue() else {
            throw SunlightRenderError.unavailable
        }
        self.device = gpu
        self.queue = queue
        let library: MTLLibrary
        if let url = bundle.url(forResource: "Sunlight", withExtension: "metallib") {
            library = try gpu.makeLibrary(URL: url)
        } else if let bundled = try? gpu.makeDefaultLibrary(bundle: bundle) {
            library = bundled
        } else {
            throw SunlightRenderError.missingLibrary
        }
        func pipeline(_ name: String, format: MTLPixelFormat) throws -> MTLRenderPipelineState {
            let descriptor = MTLRenderPipelineDescriptor()
            descriptor.vertexFunction = library.makeFunction(name: "sunlightVertex")
            descriptor.fragmentFunction = library.makeFunction(name: name)
            descriptor.colorAttachments[0].pixelFormat = format
            return try gpu.makeRenderPipelineState(descriptor: descriptor)
        }
        fieldPipeline = try pipeline("sunlightField", format: .r16Float)
        bokehPipeline = try pipeline("sunlightBokeh", format: .r16Float)
        compositePipeline = try pipeline("sunlightComposite", format: .bgra8Unorm)
        super.init()
    }

    func resetClock() { lastTick = nil }

    func setPhase(_ phase: Float, center: SIMD2<Float>) {
        elapsed = phase; self.center = center; target = center
        resetClock()
    }

    private func allocate(width: Int, height: Int) throws {
        guard field?.width != width || field?.height != height else { return }
        let descriptor = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .r16Float,
            width: width, height: height, mipmapped: false)
        descriptor.storageMode = .private
        descriptor.usage = [.renderTarget, .shaderRead]
        guard let field = device.makeTexture(descriptor: descriptor),
              let blurred = device.makeTexture(descriptor: descriptor) else { throw SunlightRenderError.allocation }
        self.field = field; self.blurred = blurred
    }

    /// Also used by the offscreen visual checks; this is the live rendering path.
    func encode(to output: MTLTexture, pointSize: CGSize, command: MTLCommandBuffer) throws {
        let ratio = min(0.5, 960.0 / max(pointSize.width, pointSize.height, 1))
        let width = max(1, Int(pointSize.width * ratio))
        let height = max(1, Int(pointSize.height * ratio))
        try allocate(width: width, height: height)
        guard let field, let blurred else { throw SunlightRenderError.allocation }
        var uniforms = SunlightUniforms(
            viewport: SIMD4(Float(pointSize.width), Float(max(1, pointSize.height)), elapsed, 0.012),
            light: SIMD4(center.x, center.y, softness, intensity))
        for (destination, pipeline, input) in [
            (field, fieldPipeline, Optional<MTLTexture>.none),
            (blurred, bokehPipeline, Optional(field)),
            (output, compositePipeline, Optional(blurred))
        ] {
            let pass = MTLRenderPassDescriptor()
            pass.colorAttachments[0].texture = destination
            pass.colorAttachments[0].loadAction = .dontCare
            pass.colorAttachments[0].storeAction = .store
            guard let encoder = command.makeRenderCommandEncoder(descriptor: pass) else {
                throw SunlightRenderError.allocation
            }
            encoder.setRenderPipelineState(pipeline)
            encoder.setFragmentBytes(&uniforms, length: MemoryLayout<SunlightUniforms>.stride, index: 0)
            if let input { encoder.setFragmentTexture(input, index: 0) }
            encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            encoder.endEncoding()
        }
    }

    func draw(in view: MTKView) {
        if let surface = view as? SunlightMetalView, !surface.isPaused && !surface.shouldAnimate {
            surface.updatePlayback()
            return
        }
        guard inFlight.wait(timeout: .now()) == .success else { return }
        guard let drawable = view.currentDrawable, let command = queue.makeCommandBuffer() else {
            inFlight.signal(); return
        }
        let now = CACurrentMediaTime()
        let dt = Float(min(1.0 / 15.0, max(0, now - (lastTick ?? now))))
        lastTick = now
        if animationEnabled && !reducedMotion {
            elapsed += dt
            // Time-based damping preserves the same response at 30 and 60 Hz.
            center += (target - center) * (1 - exp(-6.32 * dt))
        }
        do { try encode(to: drawable.texture, pointSize: view.bounds.size, command: command) }
        catch {
            inFlight.signal(); view.isPaused = true; view.isHidden = true
            Logger(subsystem: "com.jesselai.languagebubble", category: "sunlight")
                .error("Sunlight render failed: \(error.localizedDescription, privacy: .public)")
            return
        }
        let semaphore = inFlight
        command.addCompletedHandler { completed in
            semaphore.signal()
            if let error = completed.error {
                Logger(subsystem: "com.jesselai.languagebubble", category: "sunlight")
                    .error("Sunlight GPU command failed: \(error.localizedDescription, privacy: .public)")
            }
        }
        command.present(drawable)
        command.commit()
        renderedFrames += 1
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}
}

@MainActor final class SunlightMetalView: MTKView {
    var renderer: SunlightRenderer?
    var requestedRunning = false
    var reducedMotion = false
    private var staticFramePending = true
    private var observers: [NSObjectProtocol] = []

    override var isOpaque: Bool { false }
    override var acceptsFirstResponder: Bool { false }
    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        removeObservers()
        for name in [NSWindow.didChangeOcclusionStateNotification, NSWindow.didMiniaturizeNotification,
                     NSWindow.didDeminiaturizeNotification] {
            observers.append(NotificationCenter.default.addObserver(forName: name, object: window, queue: .main) {
                [weak self] _ in MainActor.assumeIsolated { self?.updatePlayback() }
            })
        }
        for name in [NSApplication.didBecomeActiveNotification, NSApplication.didResignActiveNotification,
                     .NSProcessInfoPowerStateDidChange] {
            observers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) {
                [weak self] _ in MainActor.assumeIsolated { self?.updatePlayback() }
            })
        }
        if let clipView = enclosingScrollView?.contentView {
            clipView.postsBoundsChangedNotifications = true
            observers.append(NotificationCenter.default.addObserver(forName: NSView.boundsDidChangeNotification,
                object: clipView, queue: .main) { [weak self] _ in
                    MainActor.assumeIsolated { self?.updatePlayback() }
                })
        }
        updatePlayback()
    }

    override func layout() {
        super.layout()
        // The final composite is capped at 2x; optical passes use 0.5x point size.
        let scale = min(window?.backingScaleFactor ?? 1, 2)
        let size = CGSize(width: max(1, bounds.width * scale), height: max(1, bounds.height * scale))
        if drawableSize != size { drawableSize = size; staticFramePending = true }
        updatePlayback()
    }

    private var surfaceVisible: Bool {
        window?.occlusionState.contains(.visible) == true && !isHiddenOrHasHiddenAncestor
            && !visibleRect.isEmpty
    }

    var shouldAnimate: Bool {
        requestedRunning && surfaceVisible && NSApp.isActive && !reducedMotion && renderer != nil
    }

    func invalidateStaticFrame() { staticFramePending = true }

    func updatePlayback() {
        let running = shouldAnimate
        renderer?.animationEnabled = running
        let desiredFPS = ProcessInfo.processInfo.isLowPowerModeEnabled ? 30 : 60
        if preferredFramesPerSecond != desiredFPS { preferredFramesPerSecond = desiredFPS }
        if isPaused == running {
            renderer?.resetClock()
            isPaused = !running
        }
        // A paused accessible view still receives a single static frame on resize.
        if !running && surfaceVisible && staticFramePending {
            staticFramePending = false
            setNeedsDisplay(bounds)
        }
    }

    func removeObservers() {
        for observer in observers { NotificationCenter.default.removeObserver(observer) }
        observers.removeAll()
    }

    func tearDown() {
        isPaused = true; requestedRunning = false
        delegate = nil; renderer = nil
        removeObservers()
    }

    deinit { for observer in observers { NotificationCenter.default.removeObserver(observer) } }
}

private struct NativeSunlight: NSViewRepresentable {
    let pointer: CGPoint?
    let running: Bool
    let reduceMotion: Bool
    let softness: Float
    let intensity: Float
    let pointerTravel: Float

    func makeNSView(context: Context) -> SunlightMetalView {
        let view = SunlightMetalView(frame: .zero)
        view.isPaused = true
        view.enableSetNeedsDisplay = true
        view.autoResizeDrawable = false
        view.colorPixelFormat = .bgra8Unorm
        view.depthStencilPixelFormat = .invalid
        view.framebufferOnly = true
        // Core Animation composites the shader's premultiplied alpha over SwiftUI.
        view.wantsLayer = true
        view.layer?.isOpaque = false
        view.layer?.backgroundColor = NSColor.clear.cgColor
        view.clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        view.setAccessibilityElement(false)
        do {
            let renderer = try SunlightRenderer()
            view.device = renderer.device; view.renderer = renderer; view.delegate = renderer
        } catch {
            view.isHidden = true
            Logger(subsystem: "com.jesselai.languagebubble", category: "sunlight")
                .error("Sunlight unavailable, leaving the page unchanged: \(error.localizedDescription, privacy: .public)")
        }
        return view
    }

    func updateNSView(_ view: SunlightMetalView, context: Context) {
        if view.reducedMotion != reduceMotion || view.renderer?.softness != softness || view.renderer?.intensity != intensity {
            view.invalidateStaticFrame()
        }
        view.requestedRunning = running
        view.reducedMotion = reduceMotion
        view.renderer?.reducedMotion = reduceMotion
        view.renderer?.softness = softness
        view.renderer?.intensity = intensity
        let point = pointer ?? CGPoint(x: 0.5, y: 0.5)
        if !reduceMotion {
            let normalized = SIMD2(Float(min(1, max(0, point.x))), Float(1 - min(1, max(0, point.y))))
            // Compress travel around the center; damping below is independent of this range.
            // At the default 0.30, mouse 0...1 maps to light center 0.35...0.65.
            let travel = min(1, max(0, pointerTravel))
            view.renderer?.target = SIMD2<Float>(repeating: 0.5) + (normalized - 0.5) * travel
        }
        view.updatePlayback()
    }

    static func dismantleNSView(_ view: SunlightMetalView, coordinator: ()) { view.tearDown() }
}
