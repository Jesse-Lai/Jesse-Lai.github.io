import AppKit
import ApplicationServices
import CoreGraphics
import Observation
import ScreenCaptureKit
import SwiftUI
import UniformTypeIdentifiers
import ImageIO
import OSLog

@MainActor @Observable
final class MacCaptureController {
    var hoverEnabled = UserDefaults.standard.bool(forKey: "bubbleHoverEnabled") {
        didSet { UserDefaults.standard.set(hoverEnabled, forKey: "bubbleHoverEnabled") }
    }
    var selectionBubbleEnabled = UserDefaults.standard.object(forKey: "bubbleSelectionEnabled") as? Bool ?? true {
        didSet {
            UserDefaults.standard.set(selectionBubbleEnabled, forKey: "bubbleSelectionEnabled")
            if !selectionBubbleEnabled { dismissSelectionBubble() }
        }
    }
    let shortcuts = MacShortcuts()
    private let store: BubbleStore
    private var flagsMonitor: Any?
    private var selectionMonitor: Any?
    private var selectionObservers: [AXObserver] = []
    private var selectionObservedAppPID: pid_t?
    private var selectionObservedElements: [AXUIElement] = []
    private var localMonitor: Any?
    private var selectionTask: Task<Void, Never>?
    private var selectionObserverTask: Task<Void, Never>?
    private var selectionRevision = UUID()
    private var selectionPanel: SelectionBubblePanel?
    private var articleSelectionPanel: SelectionBubblePanel?
    private var articleSelectionOwner: String?
    private var pendingSelection: (source: Source, selection: Selection)?
    private var mouseDownPoint: CGPoint?
    private var resultPanel: MacResultPanel?
    private var overlays: [NSWindow] = []
    private var previousApp: NSRunningApplication?
    private var appObserver: NSObjectProtocol?
    private var sessionObservers: [NSObjectProtocol] = []
    private var accessibilityTrusted = AXIsProcessTrusted()
    private var lastHover = Date.distantPast
    private let gate = DesktopCaptureGate()
    var isCapturing: Bool { gate.active != nil }

    init(store: BubbleStore) {
        self.store = store
        shortcuts.trigger = { [weak self] id in if id == 0 { self?.selected() } else { self?.region() } }
        appObserver = NSWorkspace.shared.notificationCenter.addObserver(forName: NSWorkspace.didActivateApplicationNotification,
            object: nil, queue: .main) { [weak self] notice in
                Task { @MainActor in
                    guard let self else { return }
                    self.dismissSelectionBubble()
                    if let app = notice.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication,
                       app.bundleIdentifier != Bundle.main.bundleIdentifier {
                        self.previousApp = app
                    }
                    self.refreshSelectionMonitoring()
                }
            }
        for name in [NSWorkspace.didWakeNotification, NSWorkspace.sessionDidBecomeActiveNotification] {
            sessionObservers.append(NSWorkspace.shared.notificationCenter.addObserver(forName: name,
                object: nil, queue: .main) { [weak self] _ in
                    Task { @MainActor in self?.refreshSelectionMonitoring(reinstallEvents: true) }
                })
        }
        if NSWorkspace.shared.frontmostApplication?.bundleIdentifier != Bundle.main.bundleIdentifier {
            previousApp = NSWorkspace.shared.frontmostApplication
        }
        refreshSelectionMonitoring(reinstallEvents: true)
    }

    private func refreshSelectionMonitoring(reinstallEvents: Bool = false) {
        selectionObserverTask?.cancel()
        let trusted = AXIsProcessTrusted()
        if reinstallEvents || trusted != accessibilityTrusted {
            accessibilityTrusted = trusted
            dismissSelectionBubble()
            mouseDownPoint = nil
            installSelectionMonitor()
        }
        observeSelectionChanges()
        guard AXIsProcessTrusted(), let source = try? source(), !source.fromBubble,
              Self.needsWebAccessibility(source.app.bundleIdentifier) else { return }
        // Teams builds its web tree asynchronously. The initial focus can still
        // be a native wrapper, so attach again after the editor becomes available.
        selectionObserverTask = Task { [weak self] in
            for delay in [180, 420] {
                do { try await Task.sleep(for: .milliseconds(delay)) } catch { return }
                guard let self, (try? self.checkSource(source)) != nil else { return }
                self.observeSelectionChanges()
            }
        }
    }

    private static func needsWebAccessibility(_ bundleID: String?) -> Bool {
        ["com.microsoft.teams2", "com.microsoft.teams"].contains(bundleID ?? "")
    }

    private func prepareSelectionAccessibility(_ app: AXUIElement, source: Source) {
        guard Self.needsWebAccessibility(source.app.bundleIdentifier) else { return }
        // Teams' Chromium host advertises AXEnhancedUserInterface; Electron
        // versions may advertise AXManualAccessibility instead. This asks the
        // host to build its AX tree under the user's existing accessibility grant.
        for name in ["AXManualAccessibility", "AXEnhancedUserInterface"] {
            guard attribute(app, name as CFString) as? Bool != true else { continue }
            var settable = DarwinBoolean(false)
            if AXUIElementIsAttributeSettable(app, name as CFString, &settable) == .success, settable.boolValue {
                AXUIElementSetAttributeValue(app, name as CFString, kCFBooleanTrue)
            }
        }
    }

    private func selectionAncestors(_ start: AXUIElement?) -> [AXUIElement] {
        let deadline = ProcessInfo.processInfo.systemUptime + 0.35
        return DesktopSelectionProbe.ancestors(from: start,
            parent: { self.element($0, kAXParentAttribute as CFString) },
            shouldContinue: { ProcessInfo.processInfo.systemUptime < deadline })
    }

    /// AX notifications also cover selections made through accessibility, and
    /// hosts whose selection changes after their mouse-up event has completed.
    private func observeSelectionChanges() {
        for observer in selectionObservers {
            CFRunLoopRemoveSource(CFRunLoopGetMain(), AXObserverGetRunLoopSource(observer), .commonModes)
        }
        selectionObservers = []
        selectionObservedAppPID = nil
        selectionObservedElements = []
        guard AXIsProcessTrusted(), let source = try? source(), !source.fromBubble else { return }
        let app = AXUIElementCreateApplication(source.app.processIdentifier)
        AXUIElementSetMessagingTimeout(app, 0.15)
        prepareSelectionAccessibility(app, source: source)
        var candidates = [app]
        candidates += selectionAncestors(element(app, kAXFocusedUIElementAttribute as CFString))
        let context = Unmanaged.passUnretained(self).toOpaque()
        // WebKit can host accessible text in a web-content process. Register
        // notifications with that element's process, but retain the browser as
        // the foreground source for the whole observation session.
        var byProcess: [pid_t: [AXUIElement]] = [:]
        for candidate in candidates {
            var pid: pid_t = 0
            guard AXUIElementGetPid(candidate, &pid) == .success else { continue }
            if byProcess[pid]?.contains(where: { CFEqual($0, candidate) }) != true {
                byProcess[pid, default: []].append(candidate)
            }
        }
        selectionObservedAppPID = source.app.processIdentifier
        for (pid, elements) in byProcess {
            var observer: AXObserver?
            guard AXObserverCreate(pid, { observer, _, notification, context in
                guard let context else { return }
                let controller = Unmanaged<MacCaptureController>.fromOpaque(context).takeUnretainedValue()
                let focusChanged = notification as String == kAXFocusedUIElementChangedNotification as String
                Task { @MainActor in
                    // Discard callbacks queued before an app/focus change. A
                    // renderer PID itself is never the frontmost application.
                    guard controller.selectionObservers.contains(where: { CFEqual($0, observer) }),
                          let sourcePID = controller.selectionObservedAppPID,
                          NSWorkspace.shared.frontmostApplication?.processIdentifier == sourcePID else { return }
                    if focusChanged {
                        controller.dismissSelectionBubble()
                        controller.observeSelectionChanges()
                    }
                    controller.scheduleSelectionBubble()
                }
            }, &observer) == .success, let observer else { continue }
            for candidate in elements {
                if CFEqual(candidate, app) || string(candidate, kAXRoleAttribute as CFString) == "AXWebArea" {
                    AXObserverAddNotification(observer, candidate, kAXFocusedUIElementChangedNotification as CFString, context)
                }
                AXObserverAddNotification(observer, candidate, kAXSelectedTextChangedNotification as CFString, context)
            }
            selectionObservers.append(observer)
            CFRunLoopAddSource(CFRunLoopGetMain(), AXObserverGetRunLoopSource(observer), .commonModes)
        }
        selectionObservedElements = candidates
    }

    private func installSelectionMonitor() {
        // Wake/unlock and newly granted accessibility access can invalidate the
        // original monitor. Replace it instead of adding duplicate callbacks.
        for monitor in [flagsMonitor, selectionMonitor, localMonitor].compactMap({ $0 }) {
            NSEvent.removeMonitor(monitor)
        }
        flagsMonitor = NSEvent.addGlobalMonitorForEvents(matching: .flagsChanged) { [weak self] event in
            guard event.modifierFlags.intersection(.deviceIndependentFlagsMask) == .option else { return }
            MainActor.assumeIsolated {
                guard let self, self.hoverEnabled, Date().timeIntervalSince(self.lastHover) > 0.6 else { return }
                self.lastHover = Date(); self.selected(hover: true)
            }
        }
        selectionMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .leftMouseUp, .rightMouseDown, .scrollWheel, .keyDown]) { [weak self] event in
            MainActor.assumeIsolated { self?.selectionEvent(event) }
        }
        localMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown, .scrollWheel, .keyDown]) { [weak self] event in
            MainActor.assumeIsolated {
                guard let self else { return }
                // The button's mouseDown must reach AppKit without invalidating the
                // snapshot it will translate on mouseUp. It never takes key focus.
                if event.window !== self.selectionPanel && event.window !== self.articleSelectionPanel {
                    self.dismissSelectionBubble()
                }
            }
            return event
        }
    }

    private func selectionEvent(_ event: NSEvent) {
        switch event.type {
        case .leftMouseDown:
            dismissSelectionBubble()
            mouseDownPoint = NSEvent.mouseLocation
        case .leftMouseUp:
            let start = mouseDownPoint
            mouseDownPoint = nil
            let end = NSEvent.mouseLocation
            let dragged = start.map { hypot($0.x - end.x, $0.y - end.y) > 3 } ?? false
            if dragged || event.clickCount >= 2 || event.modifierFlags.contains(.shift) { scheduleSelectionBubble() }
        case .keyDown:
            dismissSelectionBubble()
            let modifiers = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
            let selectAll = modifiers == .command && event.keyCode == 0
            let extendSelection = modifiers.contains(.shift) && [123, 124, 125, 126, 115, 119, 116, 121].contains(event.keyCode)
            if selectAll || extendSelection { scheduleSelectionBubble() }
        default:
            dismissSelectionBubble()
        }
    }

    private func dismissSelectionBubble() {
        selectionRevision = UUID()
        selectionTask?.cancel(); selectionTask = nil
        pendingSelection = nil
        selectionPanel?.orderOut(nil)
        articleSelectionOwner = nil
        articleSelectionPanel?.orderOut(nil)
        articleSelectionPanel?.setActions(quote: {}, translate: {}, polish: {})
    }

    /// In-product selections already provide the exact text and context. They
    /// must never restore or read the last external app's selection through AX.
    func showArticleSelection(owner: String, text: String, context: String,
                              isValid: @escaping () -> Bool, quote: @escaping () -> Void) {
        dismissSelectionBubble()
        guard !text.isEmpty, isValid() else { return }
        let cursor = NSEvent.mouseLocation
        guard let screen = NSScreen.screens.first(where: { $0.frame.contains(cursor) }) ?? NSScreen.main else { return }
        let perform: (SelectionShortcutGeometry.Action) -> Void = { [weak self] action in
            guard let self, self.articleSelectionOwner == owner else { return }
            let valid = isValid()
            self.dismissSelectionBubble()
            guard valid else { return }
            if action == .quote { quote(); return }
            guard let id = self.begin() else { return }
            Task { @MainActor in
                defer { self.gate.release(id) }
                await self.queryInPanel(text, context: context, sourceApp: "Language Bubble", image: nil,
                                        polishing: action == .polish)
            }
        }
        // Reuse the same panel so replacing a selection cancels the old exit animation.
        let panel = articleSelectionPanel ?? SelectionBubblePanel(quote: {}, translate: {}, polish: {})
        panel.setActions(quote: { perform(.quote) }, translate: { perform(.translate) }, polish: { perform(.polish) })
        articleSelectionPanel = panel
        articleSelectionOwner = owner
        panel.position(near: cursor, visible: screen.visibleFrame)
        panel.present()
    }

    func dismissArticleSelection(owner: String) {
        guard articleSelectionOwner == owner else { return }
        dismissSelectionBubble()
    }

    private func scheduleSelectionBubble() {
        dismissSelectionBubble()
        guard selectionBubbleEnabled, !isCapturing, !store.querying, AXIsProcessTrusted(),
              let source = try? source(), !source.fromBubble else { return }
        let revision = selectionRevision
        selectionTask = Task { [weak self] in
            guard let self else { return }
            let app = AXUIElementCreateApplication(source.app.processIdentifier)
            AXUIElementSetMessagingTimeout(app, 0.15)
            self.prepareSelectionAccessibility(app, source: source)
            guard let selected = await DesktopSelectionProbe.read(shouldContinue: {
                self.selectionRevision == revision && (try? self.checkSource(source)) != nil
                    && NSEvent.pressedMouseButtons == 0 && !self.isCapturing && !self.store.querying
            }, read: { self.readSelection(app, source: source) }),
                  self.selectionRevision == revision, NSEvent.pressedMouseButtons == 0 else { return }
            self.pendingSelection = (source, selected)
            let panel = self.selectionPanel ?? SelectionBubblePanel(
                translate: { [weak self] in self?.processPendingSelection() },
                polish: { [weak self] in self?.processPendingSelection(polishing: true) })
            self.selectionPanel = panel
            let screen = NSScreen.screens.first(where: { $0.frame.contains(source.cursor) }) ?? NSScreen.main
            guard let screen else { return }
            panel.position(near: source.cursor, visible: screen.visibleFrame)
            panel.present()
            #if DEBUG
            Logger(subsystem: "com.jesselai.languagebubble.mac", category: "selection").debug(
                "Shortcut presented for \(source.app.bundleIdentifier ?? "unknown", privacy: .public)")
            #endif
        }
    }

    private func processPendingSelection(polishing: Bool = false) {
        guard let pending = pendingSelection else { return }
        dismissSelectionBubble()
        guard let id = begin() else { return }
        let revision = selectionRevision
        Task {
            defer { gate.release(id) }
            do {
                try checkSource(pending.source)
                let app = AXUIElementCreateApplication(pending.source.app.processIdentifier)
                AXUIElementSetMessagingTimeout(app, 0.2)
                guard let current = readSelection(app, source: pending.source), current.text == pending.selection.text else {
                    throw ContextError.service("选区已改变，请重新选择后重试。")
                }
                let url = documentURL(app)
                if polishing {
                    await queryInPanel(current.text, context: current.context, sourceApp: pending.source.app.localizedName,
                                       sourceUrl: url, image: nil, polishing: true,
                                       replacement: MacPolishReplacement(app: pending.source.app, element: current.element))
                    return
                }
                var image: Data?
                var notice: String?
                do { image = try await selectionScreenshot(current, source: pending.source) }
                catch { notice = "未保存选区截图：" + error.localizedDescription }
                try checkSource(pending.source)
                guard selectionRevision == revision else {
                    throw ContextError.service("截图期间选区已改变，请重新选择后翻译。")
                }
                await queryInPanel(current.text, context: current.context, sourceApp: pending.source.app.localizedName,
                                   sourceUrl: url, image: image, notice: notice)
            } catch { fail(error.localizedDescription) }
        }
    }

    private func selectionScreenshot(_ selection: Selection, source: Source) async throws -> Data {
        guard CGPreflightScreenCaptureAccess() else {
            throw ContextError.service("请在设置中开启屏幕录制权限。")
        }
        let anchor = selection.bounds ?? CGRect(origin: source.cursor, size: CGSize(width: 1, height: 1))
        guard let crop = DesktopSceneGeometry.selectionCrop(around: anchor, screens: NSScreen.screens.map(\.frame)) else {
            throw ContextError.service("未找到选区所在的显示器。")
        }
        let png = try await screenshot(screen: NSScreen.screens[crop.screen], rectangle: crop.rectangle, source: source)
        let visibleAnchor = anchor.intersection(crop.rectangle)
        let point = CGPoint(x: (visibleAnchor.midX - crop.rectangle.minX) / crop.rectangle.width,
                            y: (visibleAnchor.midY - crop.rectangle.minY) / crop.rectangle.height)
        let selectedBounds = selection.bounds.map { bounds in
            CGRect(x: (bounds.minX - crop.rectangle.minX) / crop.rectangle.width,
                   y: (bounds.minY - crop.rectangle.minY) / crop.rectangle.height,
                   width: bounds.width / crop.rectangle.width, height: bounds.height / crop.rectangle.height)
        }
        let cropped = try await SceneImporter.selectedImage(png, text: selection.text, near: point, selection: selectedBounds)
        try checkSource(source)
        return cropped
    }

    private func attribute(_ element: AXUIElement, _ name: CFString) -> CFTypeRef? {
        var value: CFTypeRef?
        return AXUIElementCopyAttributeValue(element, name, &value) == .success ? value : nil
    }

    private func string(_ element: AXUIElement, _ name: CFString) -> String? { attribute(element, name) as? String }

    private func parameterized(_ element: AXUIElement, _ name: String, _ parameter: CFTypeRef) -> CFTypeRef? {
        var value: CFTypeRef?
        return AXUIElementCopyParameterizedAttributeValue(element, name as CFString, parameter, &value) == .success ? value : nil
    }

    private func selectionRect(_ value: CFTypeRef?) -> CGRect? {
        guard let value, CFGetTypeID(value) == AXValueGetTypeID() else { return nil }
        var rect = CGRect.zero
        guard AXValueGetValue(unsafeBitCast(value, to: AXValue.self), .cgRect, &rect),
              !rect.isNull, !rect.isInfinite, rect.width > 0, rect.height > 0 else { return nil }
        return DesktopSceneGeometry.appKitRect(rect, primaryHeight: NSScreen.screens.first?.frame.height ?? 0)
    }

    struct Source {
        let app: NSRunningApplication
        let cursor: CGPoint
        let fromBubble: Bool
    }

    struct Selection {
        let text: String
        let context: String?
        let bounds: CGRect?
        let element: AXUIElement
    }

    private func source() throws -> Source {
        let front = NSWorkspace.shared.frontmostApplication
        let fromBubble = front?.processIdentifier == ProcessInfo.processInfo.processIdentifier
        guard let app = fromBubble ? previousApp : front, !app.isTerminated else {
            throw ContextError.service("请先在其他 App 中选择词句。")
        }
        return Source(app: app, cursor: NSEvent.mouseLocation, fromBubble: fromBubble)
    }

    private func begin() -> UUID? {
        guard store.session != nil else { fail("请先在设置中配对，再使用查译。"); return nil }
        return gate.acquire(querying: store.querying)
    }

    private func fail(_ message: String) {
        store.error = message
        showResult(MacQueryResult(message: message))
    }

    // The main-window buttons restore the last external app before reading its selection.
    // Never restore over a different app that the user switched to during capture.
    private func prepare(_ source: Source) async throws {
        let front = NSWorkspace.shared.frontmostApplication?.processIdentifier
        if source.fromBubble && front == ProcessInfo.processInfo.processIdentifier {
            guard source.app.activate(options: []) else { throw ContextError.service("无法返回原 App，请在原文处使用查译快捷键。") }
            try await Task.sleep(for: .milliseconds(180))
        }
        try checkSource(source)
    }

    private func checkSource(_ source: Source) throws {
        try Task.checkCancellation()
        guard !source.app.isTerminated,
              NSWorkspace.shared.frontmostApplication?.processIdentifier == source.app.processIdentifier else {
            throw ContextError.service("查询期间切换了 App，请回到原文重新查译。")
        }
    }

    func selected(hover: Bool = false) {
        // Option is a global monitor; never treat a hover over our own controls as source content.
        if hover && NSWorkspace.shared.frontmostApplication?.processIdentifier == ProcessInfo.processInfo.processIdentifier { return }
        dismissSelectionBubble()
        guard let id = begin() else { return }
        let request: Source
        do { request = try source() } catch { gate.release(id); fail(error.localizedDescription); return }
        Task {
            defer { gate.release(id) }
            do {
                let source = request
                try await prepare(source)
                let axApp = AXUIElementCreateApplication(source.app.processIdentifier)
                AXUIElementSetMessagingTimeout(axApp, 0.5)
                var selection: Selection?
                if AXIsProcessTrusted() {
                    // A deliberate selection always wins, including for Option.
                    selection = readSelection(axApp, source: source)
                }
                let sourceURL = documentURL(axApp)
                if let selection {
                    // A main-window button has no meaningful pointer location in the original content.
                    let anchor = selection.bounds ?? (source.fromBubble ? nil : CGRect(origin: source.cursor, size: CGSize(width: 1, height: 1)))
                    var image: Data?
                    if CGPreflightScreenCaptureAccess(), let anchor,
                       let crop = DesktopSceneGeometry.crop(around: anchor, screens: NSScreen.screens.map(\.frame)) {
                        image = try? await screenshot(screen: NSScreen.screens[crop.screen], rectangle: crop.rectangle, source: source)
                    }
                    try checkSource(source)
                    await queryInPanel(selection.text, context: selection.context, sourceApp: source.app.localizedName, sourceUrl: sourceURL, image: image)
                } else {
                    // Screen Recording alone is sufficient for OCR. AX is an enhancement, not a prerequisite.
                    guard !source.fromBubble else {
                        throw ContextError.service("未读取到选区。请在原 App 中选中文字后使用快捷键，或使用区域 OCR。")
                    }
                    try await pointerOCR(source, sourceURL: sourceURL)
                }
            } catch { fail(error.localizedDescription) }
        }
    }

    private func element(_ owner: AXUIElement, _ name: CFString) -> AXUIElement? {
        guard let value = attribute(owner, name), CFGetTypeID(value) == AXUIElementGetTypeID() else { return nil }
        return unsafeBitCast(value, to: AXUIElement.self)
    }

    func readSelection(_ axApp: AXUIElement, source: Source) -> Selection? {
        prepareSelectionAccessibility(axApp, source: source)
        var candidates = selectionAncestors(element(axApp, kAXFocusedUIElementAttribute as CFString))
        // Browsers can expose the selection on a text node or its web-area parent.
        // Inspect that small ancestor chain, never arbitrary labels elsewhere on the page.
        if !source.fromBubble {
            let point = DesktopSceneGeometry.axPoint(source.cursor, primaryHeight: NSScreen.screens.first?.frame.height ?? 0)
            var hit: AXUIElement?
            AXUIElementCopyElementAtPosition(axApp, Float(point.x), Float(point.y), &hit)
            candidates += selectionAncestors(hit).filter { node in !candidates.contains(where: { CFEqual($0, node) }) }
        }
        if let window = element(axApp, kAXFocusedWindowAttribute as CFString) { candidates.append(window) }
        for candidate in candidates {
            // These candidates originate from the source application's focused
            // element or hit test. A web-content process may own their AX nodes;
            // requiring its PID to equal the browser's would discard valid text.
            guard string(candidate, kAXSubroleAttribute as CFString) != kAXSecureTextFieldSubrole as String else { return nil }
            let full = string(candidate, kAXValueAttribute as CFString) ?? ""
            let rangeValue = attribute(candidate, kAXSelectedTextRangeAttribute as CFString)
            var selectedRange: NSRange?
            if let rangeValue, CFGetTypeID(rangeValue) == AXValueGetTypeID() {
                var range = CFRange()
                if AXValueGetValue(unsafeBitCast(rangeValue, to: AXValue.self), .cfRange, &range),
                   range.location >= 0, range.length > 0 {
                    selectedRange = NSRange(location: range.location, length: range.length)
                }
            }
            // WebKit may expose a text-marker range instead of a numeric range.
            // Ask that same host element for its selected text and precise bounds.
            let marker = attribute(candidate, "AXSelectedTextMarkerRange" as CFString)
            let markerText = marker.flatMap { parameterized(candidate, "AXStringForTextMarkerRange", $0) as? String }
            let explicit = string(candidate, kAXSelectedTextAttribute as CFString)
            let selectedText = (explicit?.isEmpty == false ? explicit : markerText) ?? explicit
            guard let selected = SceneText.selection(in: full,
                explicit: selectedText, range: selectedRange) else { continue }
            var bounds: CGRect?
            // A document-relative range is valid AX geometry even when the host
            // does not expose its full value. Reject a range that contradicts it.
            if let rangeValue, selectedRange != nil, selected.range != nil || full.isEmpty {
                bounds = selectionRect(parameterized(candidate, kAXBoundsForRangeParameterizedAttribute as String, rangeValue))
            }
            if bounds == nil, let marker, markerText == selected.text {
                bounds = selectionRect(parameterized(candidate, "AXBoundsForTextMarkerRange", marker))
            }
            return Selection(text: selected.text,
                context: SceneText.context(in: full, selected: selected.text, range: selected.range), bounds: bounds, element: candidate)
        }
        // AXRangeForPosition is not a reliable character offset in all hosts (Chrome
        // can report the beginning of a text node). With no selection, use OCR word
        // boxes to verify the pointer hit instead of guessing from that offset.
        return nil
    }

    private func documentURL(_ app: AXUIElement) -> String? {
        guard AXIsProcessTrusted(), let window = element(app, kAXFocusedWindowAttribute as CFString) else { return nil }
        let deadline = ProcessInfo.processInfo.systemUptime + 0.6
        return DesktopDocumentURL.find(in: window,
            document: { self.attribute($0, kAXDocumentAttribute as CFString) },
            isWebArea: { self.string($0, kAXRoleAttribute as CFString) == "AXWebArea" },
            webURL: { self.attribute($0, kAXURLAttribute as CFString) },
            children: { node in
                let children = self.attribute(node, kAXChildrenAttribute as CFString) as? [AXUIElement] ?? []
                return children.filter { self.attribute($0, "AXHidden" as CFString) as? Bool != true }
            },
            focused: element(app, kAXFocusedUIElementAttribute as CFString),
            parent: { self.element($0, kAXParentAttribute as CFString) },
            shouldContinue: { ProcessInfo.processInfo.systemUptime < deadline })
    }

    func region() {
        dismissSelectionBubble()
        guard let id = begin() else { return }
        guard CGPreflightScreenCaptureAccess() else {
            gate.release(id); fail("尚未开启屏幕录制，可先导入图片做 OCR。"); return
        }
        let request: Source
        do { request = try source() } catch { gate.release(id); fail(error.localizedDescription); return }
        Task {
            do {
                let source = request
                try await prepare(source)
                showRegion(source: source, id: id)
            } catch { gate.release(id); fail(error.localizedDescription) }
        }
    }

    private func showRegion(source: Source, id: UUID) {
        guard !NSScreen.screens.isEmpty else { gate.release(id); return }
        for screen in NSScreen.screens {
            let window = RegionWindow(contentRect: screen.frame, styleMask: .borderless, backing: .buffered, defer: false)
            window.level = .screenSaver; window.isOpaque = false; window.backgroundColor = .clear
            window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
            let selection = RegionSelectionView(frame: NSRect(origin: .zero, size: screen.frame.size))
            selection.completed = { [weak self] localRect in
                guard let self, self.gate.active == id, !self.overlays.isEmpty else { return }
                self.overlays.forEach { $0.orderOut(nil) }; self.overlays = []
                guard let localRect, localRect.width > 8, localRect.height > 8 else { self.gate.release(id); return }
                let global = localRect.offsetBy(dx: screen.frame.minX, dy: screen.frame.minY)
                Task {
                    defer { self.gate.release(id) }
                    do {
                        // Our overlay may have activated Bubble. Restore only that expected focus change.
                        let restored = Source(app: source.app, cursor: source.cursor, fromBubble: true)
                        try await self.prepare(restored)
                        try await Task.sleep(for: .milliseconds(150))
                        let sourceURL = self.documentURL(AXUIElementCreateApplication(source.app.processIdentifier))
                        let png = try await self.screenshot(screen: screen, rectangle: global, source: source)
                        let content = try await SceneImporter.decode(png)
                        try self.checkSource(source)
                        guard !content.text.isEmpty else { throw ContextError.service("区域中没有识别到文字。") }
                        await self.queryInPanel(String(content.text.unicodeScalars.prefix(6000)), context: String(content.text.unicodeScalars.prefix(12000)), sourceApp: source.app.localizedName, sourceUrl: sourceURL, image: png)
                    } catch { self.fail(error.localizedDescription) }
                }
            }
            window.contentView = selection
            window.makeKeyAndOrderFront(nil)
            window.makeFirstResponder(selection)
            overlays.append(window)
        }
    }

    private func pointerOCR(_ source: Source, sourceURL: String?) async throws {
        guard CGPreflightScreenCaptureAccess() else { throw ContextError.service("宿主未提供文字，OCR 回退需要屏幕录制权限。可在 App 中导入图片。") }
        guard let crop = DesktopSceneGeometry.crop(around: CGRect(origin: source.cursor, size: CGSize(width: 1, height: 1)), screens: NSScreen.screens.map(\.frame)) else { throw ContextError.service("未找到当前显示器。") }
        let rect = crop.rectangle
        guard let point = DesktopSceneGeometry.normalizedPoint(source.cursor, in: rect) else {
            throw ContextError.service("无法确定光标处的词，请使用区域 OCR。")
        }
        let png = try await screenshot(screen: NSScreen.screens[crop.screen], rectangle: rect, source: source)
        let hit = try await SceneImporter.word(png, at: point)
        try checkSource(source)
        await queryInPanel(hit.word, context: hit.line, sourceApp: source.app.localizedName, sourceUrl: sourceURL, image: png)
    }

    private func screenshot(screen: NSScreen, rectangle: NSRect, source: Source) async throws -> Data {
        try checkSource(source)
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        try checkSource(source)
        let screenId = (screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.uint32Value
        guard let display = content.displays.first(where: { $0.displayID == screenId }),
              let app = content.applications.first(where: { $0.processID == source.app.processIdentifier }) else { throw ContextError.service("未找到原 App 的可见窗口，请回到原文重试。") }
        // Limit every scene to its source app, excluding Bubble panels and unrelated applications.
        let filter = SCContentFilter(display: display, including: [app], exceptingWindows: [])
        let config = SCStreamConfiguration()
        config.sourceRect = CGRect(x: rectangle.minX - screen.frame.minX, y: screen.frame.maxY - rectangle.maxY,
                                   width: rectangle.width, height: rectangle.height)
        let scale = min(screen.backingScaleFactor, 2200 / max(rectangle.width, rectangle.height))
        config.width = max(1, Int(rectangle.width * scale))
        config.height = max(1, Int(rectangle.height * scale))
        config.showsCursor = false
        let image = try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: config)
        try checkSource(source)
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil) else { throw ContextError.invalidResponse }
        CGImageDestinationAddImage(destination, image, nil)
        guard CGImageDestinationFinalize(destination) else { throw ContextError.invalidResponse }
        return data as Data
    }

    private func queryInPanel(_ source: String, context: String?, sourceApp: String?, sourceUrl: String? = nil, image: Data?, notice: String? = nil,
                              polishing: Bool = false, replacement: MacPolishReplacement? = nil) async {
        guard store.session != nil, !store.querying else {
            fail("当前连接或查询状态已变化，请重试。"); return
        }
        let result = MacQueryResult(source: source, polishing: polishing)
        result.replacement = replacement
        result.notice = notice
        showResult(result)
        await store.query(source, polishing: polishing, context: context, sourceApp: sourceApp, sourceUrl: sourceUrl, image: image) { [weak result] partial in
            result?.partial = partial
        }
        result.running = false
        result.capture = store.latest
        result.message = store.latest == nil ? (store.error ?? store.status) : nil
    }

    private func showResult(_ result: MacQueryResult) {
        let panel: MacResultPanel
        if let existing = resultPanel {
            panel = existing
        } else {
            panel = MacResultPanel(contentRect: NSRect(x: 0, y: 0, width: 480, height: 200),
                            styleMask: [.titled, .closable, .resizable, .nonactivatingPanel], backing: .buffered, defer: false)
            panel.title = "Language Bubble"
            panel.isFloatingPanel = true; panel.level = .floating
            panel.collectionBehavior = [.moveToActiveSpace, .fullScreenAuxiliary]
            panel.hidesOnDeactivate = false
            panel.isReleasedWhenClosed = false
            panel.contentMinSize = NSSize(width: 400, height: 1)
            resultPanel = panel
        }
        let reopening = !panel.isVisible
        let frame = panel.frame
        panel.backgroundColor = .textBackgroundColor
        let hostingView = NSHostingView(rootView: MacResultView(result: result, contentHeightChanged: { [weak panel] height in
            panel?.fitContent(height: height)
        }).environment(store))
        // Keep the user's width; size only the height from the scroll content.
        hostingView.sizingOptions = []
        panel.contentView = hostingView
        // Refresh the same window and preserve its position and width. A new
        // hosting view starts each result at the top instead of keeping its scroll offset.
        panel.setFrame(frame, display: false)
        if reopening {
            let screen = NSScreen.screens.first(where: { $0.frame.contains(NSEvent.mouseLocation) }) ?? NSScreen.main
            let visible = screen?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1000, height: 800)
            let mouse = NSEvent.mouseLocation
            panel.setFrameOrigin(NSPoint(x: max(visible.minX, min(mouse.x + 15, visible.maxX - panel.frame.width)),
                                         y: max(visible.minY, min(mouse.y - panel.frame.height, visible.maxY - panel.frame.height))))
        }
        panel.orderFrontRegardless()
    }
}

@MainActor
final class MacResultPanel: NSPanel {
    func fitContent(height: CGFloat) {
        guard height.isFinite, height > 0 else { return }
        let visible = screen?.visibleFrame ?? NSScreen.main?.visibleFrame ?? frame
        let desired = frameRect(forContentRect: NSRect(x: 0, y: 0, width: frame.width, height: ceil(height))).height
        let fitted = min(desired, visible.height)
        guard abs(frame.height - fitted) > 0.5 else { return }
        // Keep the top edge stable while content arrives; cap long results to
        // the display so their ScrollView stays usable.
        setFrame(NSRect(x: frame.minX,
                        y: max(visible.minY, min(frame.maxY, visible.maxY) - fitted),
                        width: frame.width, height: fitted), display: true)
    }
}

/// A nonactivating, icon-only arc. Actions keep the host app's text selection intact.
@MainActor
final class SelectionBubblePanel: NSPanel {
    private var quote: (() -> Void)?
    private var translate: () -> Void
    private var polish: () -> Void
    private let surface: SelectionShortcutSurface
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }

    init(quote: (() -> Void)? = nil, translate: @escaping () -> Void, polish: @escaping () -> Void) {
        self.quote = quote
        self.translate = translate
        self.polish = polish
        let geometry = SelectionShortcutGeometry(actions: quote == nil ? [.translate, .polish] : [.quote, .translate, .polish])
        surface = SelectionShortcutSurface(geometry: geometry)
        super.init(contentRect: geometry.displayCanvas,
                   styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        title = quote == nil ? "Language Bubble · Translate / Polish" : "Language Bubble · Quote / Translate / Polish"
        isFloatingPanel = true; level = .floating
        isOpaque = false; backgroundColor = .clear; hasShadow = false
        hidesOnDeactivate = false; isReleasedWhenClosed = false
        becomesKeyOnlyIfNeeded = true
        acceptsMouseMovedEvents = true
        animationBehavior = .none
        collectionBehavior = [.moveToActiveSpace, .fullScreenAuxiliary]
        contentView = surface
        for action in geometry.actions {
            let button = SelectionActionButton(shortcutAction: action, geometry: geometry)
            button.target = self
            switch action {
            case .quote: button.action = #selector(performQuote)
            case .translate: button.action = #selector(performTranslation)
            case .polish: button.action = #selector(performPolish)
            }
            button.onHover = { [weak surface] in surface?.select(action) }
            surface.addSubview(button)
        }
    }

    func setActions(quote: (() -> Void)?, translate: @escaping () -> Void, polish: @escaping () -> Void) {
        self.quote = quote
        self.translate = translate
        self.polish = polish
    }

    func position(near cursor: CGPoint, visible: CGRect) {
        surface.reset()
        setFrame(surface.geometry.frame(near: cursor, visible: visible), display: false)
    }

    func present(animated: Bool = true) {
        ignoresMouseEvents = false
        surface.reveal(animated: animated)
        surface.displayIfNeeded()
        orderFrontRegardless()
    }

    override func orderOut(_ sender: Any?) {
        guard isVisible else { finishDismissal(); return }
        ignoresMouseEvents = true
        surface.conceal { [weak self] in self?.finishDismissal() }
    }

    private func finishDismissal() {
        super.orderOut(nil)
        surface.reset()
    }

    @objc private func performQuote() { quote?() }
    @objc private func performTranslation() { translate() }
    @objc private func performPolish() { polish() }
}

struct SelectionShortcutGeometry {
    enum Action { case quote, translate, polish }
    let actions: [Action]
    let canvas = CGRect(x: 0, y: 0, width: 220, height: 220)
    // Article shortcuts have three actions. Scale their entire native surface,
    // including icons and hit regions, while retaining the external two-action menu.
    var displayScale: CGFloat { actions.contains(.quote) ? 0.7 : 1 }
    var displayCanvas: CGRect { canvas.applying(CGAffineTransform(scaleX: displayScale, y: displayScale)) }
    let width: CGFloat = 54
    // The approved prototype is 20% shorter overall, with its width unchanged.
    private let baseLength: CGFloat = (138 + 54) * 0.8 - 54
    var radius: CGFloat { baseLength / (36 * .pi / 180) }
    private var originalHalfWellRun: CGFloat { ((baseLength + width) / 2 - 10 - 43) / (2 * radius) }
    private var originalItemSpacing: CGFloat { 36 * .pi / 180 - 2 * originalHalfWellRun }
    private var arcCompression: CGFloat {
        guard actions.contains(.quote) else { return 1 }
        let originalRun = radius * (originalItemSpacing * CGFloat(actions.count - 1) + 2 * originalHalfWellRun)
        // Shorten end-to-end arc length another 25%, keeping the tube thickness.
        return ((originalRun + width) * 0.75 - width) / originalRun
    }
    var halfWellRun: CGFloat { originalHalfWellRun * arcCompression }
    private var itemSpacing: CGFloat { originalItemSpacing * arcCompression }
    var span: CGFloat { itemSpacing * CGFloat(actions.count - 1) + 2 * halfWellRun }
    var start: CGFloat { -133 * .pi / 180 - span / 2 }
    var end: CGFloat { start + span }

    // Mirror only the outline and icon positions; the glyphs stay upright.
    func point(radius: CGFloat? = nil, angle: CGFloat) -> CGPoint {
        let radius = radius ?? self.radius
        return CGPoint(x: 10 - radius * cos(angle), y: 215 + radius * sin(angle))
    }

    func angle(for action: Action) -> CGFloat {
        end - halfWellRun - CGFloat(actions.firstIndex(of: action)!) * itemSpacing
    }

    func action(at point: CGPoint) -> Action? {
        guard path().contains(point) else { return nil }
        let angle = atan2(point.y - 215, 10 - point.x)
        return actions.min { abs(self.angle(for: $0) - angle) < abs(self.angle(for: $1) - angle) }
    }

    func frame(near cursor: CGPoint, visible: CGRect) -> CGRect {
        // Reduce the remaining half-gap by another 30%: 0.5 * 0.7 = 0.35.
        let mouseAnchor = point(radius: (radius - width / 2) * 0.65, angle: (start + end) / 2)
        var origin = CGPoint(x: cursor.x - mouseAnchor.x * displayScale,
                             y: cursor.y - (canvas.height - mouseAnchor.y) * displayScale)
        let outline = path().boundingBoxOfPath
        let local = CGRect(x: outline.minX, y: canvas.height - outline.maxY,
                           width: outline.width, height: outline.height).insetBy(dx: -16, dy: -16)
            .applying(CGAffineTransform(scaleX: displayScale, y: displayScale))
        let safe = visible.insetBy(dx: 8, dy: 8)
        origin.x = min(max(origin.x, safe.minX - local.minX), safe.maxX - local.maxX)
        origin.y = min(max(origin.y, safe.minY - local.minY), safe.maxY - local.maxY)
        return CGRect(origin: origin, size: displayCanvas.size)
    }

    func path(from: CGFloat? = nil, to: CGFloat? = nil, width: CGFloat? = nil) -> CGPath {
        let from = from ?? start, to = to ?? end, width = width ?? self.width
        let half = width / 2
        var points: [CGPoint] = []
        func sample(_ center: CGPoint, _ r: CGFloat, _ a: CGFloat, _ b: CGFloat) {
            let count = max(4, Int(ceil(abs(b - a) * r / 1.6)))
            for index in 0..<count {
                let angle = a + (b - a) * CGFloat(index) / CGFloat(count)
                points.append(CGPoint(x: center.x + r * cos(angle), y: center.y + r * sin(angle)))
            }
        }
        let center = CGPoint(x: 210, y: 215)
        func unmirrored(_ angle: CGFloat) -> CGPoint {
            CGPoint(x: center.x + radius * cos(angle), y: center.y + radius * sin(angle))
        }
        sample(center, radius + half, from, to)
        sample(unmirrored(to), half, to, to + .pi)
        sample(center, radius - half, to, from)
        sample(unmirrored(from), half, from + .pi, from + .pi * 2)
        points = points.map { CGPoint(x: canvas.width - $0.x, y: $0.y) }
        func at(_ index: Int) -> CGPoint { points[(index + points.count) % points.count] }
        func blend(_ a: CGPoint, _ b: CGPoint, _ c: CGPoint) -> CGPoint {
            CGPoint(x: (a.x + 4 * b.x + c.x) / 6, y: (a.y + 4 * b.y + c.y) / 6)
        }
        // Closed cubic B-spline keeps curvature continuous through the rounded ends.
        let path = CGMutablePath()
        path.move(to: blend(at(-1), at(0), at(1)))
        for index in points.indices {
            let a = at(index), b = at(index + 1), c = at(index + 2)
            path.addCurve(to: blend(a, b, c),
                          control1: CGPoint(x: (2 * a.x + b.x) / 3, y: (2 * a.y + b.y) / 3),
                          control2: CGPoint(x: (a.x + 2 * b.x) / 3, y: (a.y + 2 * b.y) / 3))
        }
        path.closeSubpath()
        return path
    }
}

private enum SelectionShortcutPalette {
    static let body = color(0xEC840E)
    static let well = color(0xF58B16)
    static let highlight = color(0xFFBA42)
    static let rim = color(0xF8B659)
    static let activeIcon = color(0xFFF9E8)
    static let inactiveIcon = color(0xFFBE78)
    static let insetDepth: CGFloat = 0.66

    static func color(_ hex: UInt32) -> NSColor {
        NSColor(srgbRed: CGFloat((hex >> 16) & 255) / 255,
                green: CGFloat((hex >> 8) & 255) / 255, blue: CGFloat(hex & 255) / 255, alpha: 1)
    }
    static func mix(_ first: NSColor, _ second: NSColor, _ fraction: CGFloat) -> NSColor {
        let a = first.usingColorSpace(.sRGB)!, b = second.usingColorSpace(.sRGB)!
        return NSColor(srgbRed: a.redComponent + (b.redComponent - a.redComponent) * fraction,
                       green: a.greenComponent + (b.greenComponent - a.greenComponent) * fraction,
                       blue: a.blueComponent + (b.blueComponent - a.blueComponent) * fraction, alpha: 1)
    }
}

private final class SelectionShortcutSurface: NSView {
    private typealias G = SelectionShortcutGeometry
    private typealias P = SelectionShortcutPalette
    let geometry: SelectionShortcutGeometry
    // Jesse Agent's RingRevealShape uses a circular sweep, not a scaling popup.
    // Shorten the entire entrance timeline by 30%, preserving the staggered icons.
    private static let entranceTimeScale = 0.7
    private static let entranceDuration = 0.42 * entranceTimeScale
    // One timeline drives both shell and icon opacity; dismissal plays it backwards.
    private var revealTime: TimeInterval = entranceDuration
    private var revealFrom: TimeInterval = entranceDuration
    private var revealStarted: TimeInterval?
    private var concealing = false
    private var concealed: (() -> Void)?
    private var revealProgress: CGFloat { smooth(revealTime / Self.entranceDuration) }
    private var selectedPosition: CGFloat = 0
    private var selectionFrom: CGFloat = 0
    private var selectionTarget: CGFloat = 0
    private var selectionStarted: TimeInterval?
    private var timer: Timer?
    override var isFlipped: Bool { true }
    override var isOpaque: Bool { false }

    init(geometry: SelectionShortcutGeometry) {
        self.geometry = geometry
        super.init(frame: geometry.displayCanvas)
        bounds = geometry.canvas
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func reset() {
        timer?.invalidate(); timer = nil
        revealStarted = nil; selectionStarted = nil
        concealing = false; concealed = nil
        revealTime = Self.entranceDuration; revealFrom = revealTime
        selectedPosition = 0; selectionTarget = 0
        subviews.compactMap { $0 as? NSButton }.forEach { $0.isEnabled = true }
        needsDisplay = true
    }

    func reveal(animated: Bool) {
        reset()
        guard animated, !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else { return }
        revealTime = 0; revealFrom = 0
        revealStarted = ProcessInfo.processInfo.systemUptime
        subviews.compactMap { $0 as? NSButton }.forEach { $0.isEnabled = false }
        startTimer()
    }

    func conceal(completion: @escaping () -> Void) {
        guard !concealing else { return }
        guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion, revealTime > 0 else {
            completion(); return
        }
        concealing = true
        concealed = completion
        // Reverse from the last displayed frame, including an interrupted entrance.
        revealFrom = revealTime
        revealStarted = ProcessInfo.processInfo.systemUptime
        selectionStarted = nil
        subviews.compactMap { $0 as? NSButton }.forEach { $0.isEnabled = false }
        startTimer()
    }

    func select(_ action: SelectionShortcutGeometry.Action) {
        guard let index = geometry.actions.firstIndex(of: action) else { return }
        let target = CGFloat(index)
        guard !concealing, revealStarted == nil, target != selectionTarget else { return }
        selectionTarget = target
        guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else {
            selectedPosition = target; needsDisplay = true; return
        }
        selectionFrom = selectedPosition
        selectionStarted = ProcessInfo.processInfo.systemUptime
        startTimer()
    }

    private func startTimer() {
        guard timer == nil else { return }
        let timer = Timer(timeInterval: 1.0 / 60, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.tick() }
        }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    private func smooth(_ progress: CGFloat) -> CGFloat {
        let t = min(1, max(0, progress))
        return t * t * t * (t * (6 * t - 15) + 10)
    }

    private func tick() {
        let now = ProcessInfo.processInfo.systemUptime
        if let started = revealStarted {
            let elapsed = now - started
            revealTime = min(Self.entranceDuration, max(0, revealFrom + (concealing ? -elapsed : elapsed)))
            if concealing, revealTime <= 0 {
                revealStarted = nil
                timer?.invalidate(); timer = nil
                let completion = concealed
                concealed = nil
                needsDisplay = true
                completion?()
                return
            }
            if !concealing, revealTime >= Self.entranceDuration {
                revealStarted = nil
                subviews.compactMap { $0 as? NSButton }.forEach { $0.isEnabled = true }
                if let window {
                    let point = convert(window.mouseLocationOutsideOfEventStream, from: nil)
                    if let action = geometry.action(at: point) { select(action) }
                }
            }
        }
        if let started = selectionStarted {
            let elapsed = now - started
            selectedPosition = selectionFrom + (selectionTarget - selectionFrom) * smooth(elapsed / 0.18)
            if elapsed >= 0.18 { selectionStarted = nil }
        }
        needsDisplay = true
        if revealStarted == nil, selectionStarted == nil { timer?.invalidate(); timer = nil }
    }

    override func draw(_ dirtyRect: NSRect) {
        guard let context = NSGraphicsContext.current?.cgContext else { return }
        context.clear(bounds)
        guard revealProgress > 0 else { return }
        context.saveGState()
        // Advance clockwise from the upper-left end around the mirrored arc.
        let revealStart = geometry.end - geometry.span * revealProgress
        let shell = geometry.path(from: revealStart)
        context.setAlpha(min(1, revealProgress * 8))
        context.saveGState()
        context.setShadow(offset: CGSize(width: 0, height: 6), blur: 13,
                          color: P.mix(P.body, .black, 0.65).withAlphaComponent(0.14).cgColor)
        context.setFillColor(P.rim.cgColor); context.addPath(shell); context.fillPath()
        context.restoreGState()
        linear(shell, colors: [P.rim, P.mix(P.rim, P.body, 0.25)], in: context)
        linear(geometry.path(from: revealStart, width: 51.5), colors: [P.body, P.mix(P.body, .black, 0.04)], in: context)
        context.addPath(geometry.path(from: revealStart, width: 51.5)); context.clip()

        let angle = geometry.end - geometry.halfWellRun
            - (geometry.span - 2 * geometry.halfWellRun) * selectedPosition / CGFloat(geometry.actions.count - 1)
        let well = geometry.path(from: angle - geometry.halfWellRun, to: angle + geometry.halfWellRun, width: 43)
        let center = geometry.point(angle: angle)
        context.saveGState()
        context.addPath(well); context.clip()
        if let gradient = CGGradient(colorsSpace: CGColorSpace(name: CGColorSpace.sRGB),
                                     colors: [P.mix(P.well, P.body, 0.2).cgColor, P.well.cgColor, P.highlight.cgColor] as CFArray,
                                     locations: [0, 0.54, 1]) {
            context.drawRadialGradient(gradient, startCenter: CGPoint(x: center.x + 2, y: center.y + 5), startRadius: 5,
                                       endCenter: center, endRadius: 39, options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
        }
        context.restoreGState()
        innerShadow(well, color: P.mix(P.well, .black, 0.5).withAlphaComponent(0.32 * P.insetDepth),
                    offset: CGSize(width: 1, height: 4), in: context)
        innerShadow(well, color: P.mix(P.highlight, .white, 0.35).withAlphaComponent(0.8 * P.insetDepth),
                    offset: CGSize(width: -1, height: -4), in: context)
        context.restoreGState()

        for (index, action) in geometry.actions.enumerated() {
            let selected = max(0, 1 - abs(CGFloat(index) - selectedPosition))
            let delay = (0.06 + 0.22 * Double(index) / Double(geometry.actions.count - 1)) * Self.entranceTimeScale
            let opacity = smooth((revealTime - delay) / (0.14 * Self.entranceTimeScale))
            drawIcon(action, color: P.mix(P.inactiveIcon, P.activeIcon, selected).withAlphaComponent(opacity), in: context)
        }
    }

    private func linear(_ path: CGPath, colors: [NSColor], in context: CGContext) {
        context.saveGState(); defer { context.restoreGState() }
        context.addPath(path); context.clip()
        guard let gradient = CGGradient(colorsSpace: CGColorSpace(name: CGColorSpace.sRGB),
                                         colors: colors.map(\.cgColor) as CFArray, locations: [0, 1]) else { return }
        context.drawLinearGradient(gradient, start: CGPoint(x: 60, y: 55), end: CGPoint(x: 175, y: 190),
                                   options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
    }

    private func innerShadow(_ path: CGPath, color: NSColor, offset: CGSize, in context: CGContext) {
        context.saveGState(); defer { context.restoreGState() }
        context.addPath(path); context.clip()
        let outside = CGMutablePath()
        outside.addRect(bounds.insetBy(dx: -100, dy: -100)); outside.addPath(path)
        context.setShadow(offset: offset, blur: 8, color: color.cgColor)
        context.setFillColor(color.cgColor); context.addPath(outside); context.drawPath(using: .eoFill)
    }

    private func drawIcon(_ action: G.Action, color: NSColor, in context: CGContext) {
        let center = geometry.point(angle: geometry.angle(for: action))
        if action == .quote {
            if let image = NSImage(systemSymbolName: "quote.closing", accessibilityDescription: nil)?
                .withSymbolConfiguration(.init(pointSize: 25, weight: .semibold)) {
                let tinted = NSImage(size: image.size, flipped: false) { rect in
                    image.draw(in: rect)
                    color.setFill()
                    rect.fill(using: .sourceIn)
                    return true
                }
                // SF Symbols have intrinsic aspect ratios; fitting the symbol
                // inside the icon slot avoids stretching it into a square.
                let scale = 26 / max(image.size.width, image.size.height)
                let size = CGSize(width: image.size.width * scale, height: image.size.height * scale)
                tinted.draw(in: CGRect(x: center.x - size.width / 2, y: center.y - size.height / 2,
                                       width: size.width, height: size.height),
                            from: .zero, operation: .sourceOver, fraction: 1, respectFlipped: true, hints: nil)
            }
            return
        }
        if action == .translate {
            let attributes: [NSAttributedString.Key: Any] = [.font: NSFont.systemFont(ofSize: 30, weight: .bold), .foregroundColor: color]
            let size = ("T" as NSString).size(withAttributes: attributes)
            ("T" as NSString).draw(at: CGPoint(x: center.x - size.width / 2, y: center.y - size.height / 2), withAttributes: attributes)
            return
        }
        context.saveGState(); defer { context.restoreGState() }
        context.translateBy(x: center.x - 13, y: center.y - 13)
        context.scaleBy(x: 26 / 24, y: 26 / 24)
        context.setStrokeColor(color.cgColor); context.setLineWidth(2.7)
        context.setLineCap(.round); context.setLineJoin(.round)
        // Wand and three sparkles, matching the prototype's compact outline icon.
        context.move(to: CGPoint(x: 3, y: 18))
        context.addLine(to: CGPoint(x: 17, y: 4))
        context.addQuadCurve(to: CGPoint(x: 19, y: 4), control: CGPoint(x: 18, y: 3))
        context.addLine(to: CGPoint(x: 21, y: 6))
        context.addQuadCurve(to: CGPoint(x: 21, y: 8), control: CGPoint(x: 22, y: 7))
        context.addLine(to: CGPoint(x: 7, y: 22))
        context.addQuadCurve(to: CGPoint(x: 5, y: 22), control: CGPoint(x: 6, y: 23))
        context.addLine(to: CGPoint(x: 3, y: 20))
        context.addQuadCurve(to: CGPoint(x: 3, y: 18), control: CGPoint(x: 2, y: 19))
        context.move(to: CGPoint(x: 14, y: 7)); context.addLine(to: CGPoint(x: 18, y: 11))
        for (x, y, r): (CGFloat, CGFloat, CGFloat) in [(5, 8, 2), (11, 3, 1), (20, 17, 2)] {
            context.move(to: CGPoint(x: x - r, y: y)); context.addLine(to: CGPoint(x: x + r, y: y))
            context.move(to: CGPoint(x: x, y: y - r)); context.addLine(to: CGPoint(x: x, y: y + r))
        }
        context.strokePath()
    }
}

private final class SelectionActionButton: NSButton {
    let shortcutAction: SelectionShortcutGeometry.Action
    private let geometry: SelectionShortcutGeometry
    var onHover: (() -> Void)?
    override var acceptsFirstResponder: Bool { false }
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    init(shortcutAction: SelectionShortcutGeometry.Action, geometry: SelectionShortcutGeometry) {
        self.shortcutAction = shortcutAction
        self.geometry = geometry
        // Full bounds allow each native button to claim its curved slice exactly.
        super.init(frame: geometry.path().boundingBoxOfPath.integral)
        title = ""; isBordered = false
        let key: String
        let identifier: String
        switch shortcutAction {
        case .quote: key = "引用"; identifier = "quoteArticleSelection"
        case .translate: key = "selectionShortcut.translate"; identifier = "selectionBubbleTranslate"
        case .polish: key = "润色"; identifier = "selectionBubblePolish"
        }
        toolTip = BubbleLocalization.text(key)
        setAccessibilityLabel(BubbleLocalization.text(key))
        setAccessibilityIdentifier(identifier)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func hitTest(_ point: NSPoint) -> NSView? {
        guard isEnabled, geometry.action(at: point) == shortcutAction else { return nil }
        return self
    }
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(rect: bounds, options: [.mouseEnteredAndExited, .mouseMoved, .activeAlways, .inVisibleRect], owner: self))
    }
    override func mouseEntered(with event: NSEvent) { updateHover(event) }
    override func mouseMoved(with event: NSEvent) { updateHover(event) }
    private func updateHover(_ event: NSEvent) {
        guard isEnabled, let superview,
              geometry.action(at: superview.convert(event.locationInWindow, from: nil)) == shortcutAction else { return }
        onHover?()
    }
    override func mouseDown(with event: NSEvent) { onHover?(); super.mouseDown(with: event) }
    // The shared surface paints the inset and upright icons; native buttons only handle interaction.
    override func draw(_ dirtyRect: NSRect) {}
}

/// Retains only the original editable field and selection for an explicit write-back.
/// Never replaces a whole document or sends a paste keystroke to the current focus.
@MainActor
final class MacPolishReplacement {
    private let app: NSRunningApplication
    private let element: AXUIElement
    private let selection: DesktopPolishSelection

    init?(app: NSRunningApplication, element: AXUIElement) {
        guard Self.canReplace(element),
              let text = Self.value(element, kAXSelectedTextAttribute) as? String,
              let range = Self.range(element),
              let selection = DesktopPolishSelection(text: text, range: range,
                  fullValue: Self.value(element, kAXValueAttribute) as? String) else { return nil }
        self.app = app; self.element = element; self.selection = selection
    }

    func apply(_ text: String) async throws {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ContextError.invalidResponse }
        try validate()
        if NSWorkspace.shared.frontmostApplication?.processIdentifier != app.processIdentifier {
            guard app.activate(options: []) else { throw ContextError.service("无法返回原软件，请重新选择文字。") }
            try await Task.sleep(for: .milliseconds(180))
        }
        try Task.checkCancellation()
        try validate()
        let error = AXUIElementSetAttributeValue(element, kAXSelectedTextAttribute as CFString, selection.replacement(text) as CFString)
        guard error == .success else { throw ContextError.service("原软件不支持直接回填，请复制润色结果。") }
    }

    private func validate() throws {
        guard !app.isTerminated, Self.canReplace(element) else {
            throw ContextError.service("原输入位置已不可用，请重新选择文字。")
        }
        let application = AXUIElementCreateApplication(app.processIdentifier)
        var focused = Self.elementValue(application, kAXFocusedUIElementAttribute)
        var sameField = false
        for _ in 0..<12 {
            guard let current = focused else { break }
            if CFEqual(current, element) { sameField = true; break }
            focused = Self.elementValue(current, kAXParentAttribute)
        }
        guard sameField, selection.matches(text: Self.value(element, kAXSelectedTextAttribute) as? String,
            range: Self.range(element), fullValue: Self.value(element, kAXValueAttribute) as? String) else {
            throw ContextError.service("原文或选区已改变，请重新选择后润色。")
        }
    }

    private static func value(_ element: AXUIElement, _ attribute: String) -> CFTypeRef? {
        var value: CFTypeRef?
        return AXUIElementCopyAttributeValue(element, attribute as CFString, &value) == .success ? value : nil
    }
    private static func elementValue(_ owner: AXUIElement, _ attribute: String) -> AXUIElement? {
        guard let value = value(owner, attribute), CFGetTypeID(value) == AXUIElementGetTypeID() else { return nil }
        return unsafeBitCast(value, to: AXUIElement.self)
    }
    private static func range(_ element: AXUIElement) -> NSRange? {
        guard let value = value(element, kAXSelectedTextRangeAttribute), CFGetTypeID(value) == AXValueGetTypeID() else { return nil }
        var range = CFRange()
        guard AXValueGetValue(unsafeBitCast(value, to: AXValue.self), .cfRange, &range),
              range.location >= 0, range.length > 0 else { return nil }
        return NSRange(location: range.location, length: range.length)
    }
    private static func canReplace(_ element: AXUIElement) -> Bool {
        guard let role = value(element, kAXRoleAttribute) as? String,
              [kAXTextAreaRole, kAXTextFieldRole, kAXComboBoxRole].contains(role),
              value(element, kAXSubroleAttribute) as? String != kAXSecureTextFieldSubrole else { return false }
        var settable = DarwinBoolean(false)
        return AXUIElementIsAttributeSettable(element, kAXSelectedTextAttribute as CFString, &settable) == .success && settable.boolValue
    }
}

@MainActor @Observable
final class MacQueryResult {
    var source: String
    var partial = ""
    var capture: BubbleCapture?
    var message: String?
    var notice: String?
    var running: Bool
    let polishing: Bool
    var replacement: MacPolishReplacement?
    var replacing = false
    var replaced = false
    var replacementMessage: String?
    init(source: String = "", message: String? = nil, polishing: Bool = false) {
        self.polishing = polishing
        self.source = source; self.message = message; self.running = message == nil
    }
}

final class RegionWindow: NSWindow { override var canBecomeKey: Bool { true } }

final class RegionSelectionView: NSView {
    var completed: ((NSRect?) -> Void)?
    private var start: NSPoint?
    private var current: NSPoint?
    override var acceptsFirstResponder: Bool { true }
    override var isOpaque: Bool { false }
    override func draw(_ dirtyRect: NSRect) {
        // Clear the previous frame before redrawing, including the old selection.
        // A transparent hole lets the actual source window show through unchanged.
        NSColor.clear.setFill(); bounds.fill(using: .copy)
        let shade = NSBezierPath(rect: bounds)
        shade.windingRule = .evenOdd
        var selection: NSRect?
        if let start, let current {
            let rect = NSRect(x: min(start.x, current.x), y: min(start.y, current.y), width: abs(current.x - start.x), height: abs(current.y - start.y))
            if rect.width > 0, rect.height > 0 {
                let clipped = rect.intersection(bounds)
                if !clipped.isEmpty {
                    selection = clipped
                    shade.appendRect(clipped)
                }
            }
        }
        NSColor.black.withAlphaComponent(0.3).setFill(); shade.fill()
        if let rect = selection {
            NSColor.white.setStroke(); let path = NSBezierPath(rect: rect); path.lineWidth = 2; path.stroke()
        }
        ("拖动选择区域 · Esc 取消" as NSString).draw(at: NSPoint(x: 28, y: bounds.height - 60), withAttributes: [.foregroundColor: NSColor.white, .font: BubbleTypography.nativeFont(size: 20)])
    }
    override func mouseDown(with event: NSEvent) { start = convert(event.locationInWindow, from: nil); current = start; needsDisplay = true }
    override func mouseDragged(with event: NSEvent) { current = convert(event.locationInWindow, from: nil); needsDisplay = true }
    override func mouseUp(with event: NSEvent) {
        guard let start else { return }
        let end = convert(event.locationInWindow, from: nil)
        completed?(NSRect(x: min(start.x, end.x), y: min(start.y, end.y), width: abs(end.x - start.x), height: abs(end.y - start.y)))
    }
    override func keyDown(with event: NSEvent) { if event.keyCode == 53 { completed?(nil) } }
}

struct MacResultView: View {
    @AppStorage("bubbleInterfaceLanguage") private var interfaceLanguage = "zh-Hans"
    @Environment(BubbleStore.self) private var store
    let result: MacQueryResult
    var contentHeightChanged: (CGFloat) -> Void = { _ in }
    var body: some View {
        GeometryReader { geometry in
            let scale = min(1, max(0.72, geometry.size.width / 720))
            ScrollView {
                VStack(alignment: .leading, spacing: 36 * scale) {
                    if let message = result.message {
                        Text(BubbleLocalization.text(message)).foregroundStyle(.secondary)
                            .accessibilityIdentifier("selectionResultMessage")
                    }
                    if result.running {
                        VStack(alignment: .leading, spacing: 24 * scale) {
                            Text(result.source)
                                .bubbleFont(.largeTitle, size: 34 * scale, weight: .medium, role: .word)
                                .textSelection(.enabled)
                            HStack(spacing: 10) {
                                ProgressView().controlSize(.small)
                                Text(result.partial.isEmpty ? BubbleLocalization.text(result.polishing ? "正在润色…" : "正在处理…") : result.partial)
                                    .foregroundStyle(.secondary)
                            }
                            Button("取消查询") { store.cancelQuery() }.buttonStyle(.plain)
                        }
                    }
                    if result.polishing, let capture = result.capture {
                        MacPolishResultView(result: result, capture: capture, scale: scale, availableWidth: geometry.size.width - 56)
                    } else if let capture = result.capture, store.state.captures[capture.id] != nil,
                       let record = store.record(BubbleRecord.key(for: capture)) {
                        // Keep the lookup's own result at the head while sharing dictionary
                        // enrichment and all saved scene images with the library.
                        let displayed = BubbleRecord(id: record.id,
                            encounters: [capture] + record.encounters.filter { $0.id != capture.id })
                        BubbleMacRecordDefinition(record: displayed, scale: scale, showsFavorite: false)
                            .accessibilityIdentifier("selectionResultDefinition")
                        if capture.isMock {
                            Text("AI Mock · 测试数据").bubbleFont(.caption).foregroundStyle(.secondary)
                        }
                        if displayed.sources.contains(where: { !$0.assetIds.isEmpty }) {
                            BubbleMacSourceGallery(record: displayed, scale: scale)
                                .padding(.top, 16 * scale)
                                .padding(.bottom, 12 * scale)
                                .clipped()
                        }
                    } else if result.capture != nil {
                        Text("记录已删除").foregroundStyle(.secondary)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(28)
                .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { contentHeightChanged($0) }
            }
            .scrollIndicators(.hidden)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(BubbleRecordPalette.panel)
        .bubbleAppearance(paintsBackground: false)
            .environment(\.locale, Locale(identifier: interfaceLanguage))
            .task(id: result.capture?.id) {
                guard !result.polishing, let capture = result.capture, capture.kind == "translation",
                      let record = store.record(BubbleRecord.key(for: capture)) else { return }
                let displayed = BubbleRecord(id: record.id,
                    encounters: [capture] + record.encounters.filter { $0.id != capture.id })
                _ = try? await store.loadDictionary(for: displayed)
            }
    }
}

/// Temporary polish results deliberately have no dictionary/record controls or gallery.
struct MacPolishResultView: View {
    let result: MacQueryResult
    let capture: BubbleCapture
    let scale: CGFloat
    let availableWidth: CGFloat
    @State private var copied = false

    private var sentenceSize: CGFloat {
        let passages = [capture.source, capture.result]
        let long = passages.contains { SceneText.ranges(in: $0).count > 1 || $0.count > 40 }
        let base = (long ? 26.0 : 48.0) * scale
        guard !long else { return base }
        let font = BubbleTypography.nativeFont(size: base, role: .word, weight: .medium)
        let longest = passages.map { ($0 as NSString).size(withAttributes: [.font: font]).width }.max() ?? 1
        // Fit the pair together: neither sentence independently shrinks to a different size.
        return base * min(1, max(0.6, availableWidth / max(1, longest)))
    }

    private func sentence(_ text: String) -> some View {
        Text(text)
            .bubbleFont(.largeTitle, size: sentenceSize, weight: .medium, role: .word)
            .foregroundStyle(BubbleContentStyle.text)
            .fixedSize(horizontal: false, vertical: true)
            .textSelection(.enabled)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 32 * scale) {
            sentence(capture.source)
                .accessibilityAddTraits(.isHeader)
                .accessibilityIdentifier("polishSource")
            VStack(alignment: .leading, spacing: 14 * scale) {
                Text("修改建议").bubbleFont(.headline)
                sentence(capture.result).accessibilityIdentifier("polishSuggestion")
            }
            if !capture.explanation.isEmpty {
                VStack(alignment: .leading, spacing: 14 * scale) {
                    Text("简短讲解").bubbleFont(.headline)
                    Text(capture.explanation)
                        .font(.custom("PingFangSC-Regular", size: 20 * scale))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .textSelection(.enabled)
                }
            }
            HStack(spacing: 16) {
                Button {
                    guard let target = result.replacement, !result.replacing, !result.replaced else { return }
                    result.replacing = true; result.replacementMessage = nil
                    Task { @MainActor in
                        defer { result.replacing = false }
                        do { try await target.apply(capture.result); result.replaced = true }
                        catch { result.replacementMessage = error.localizedDescription }
                    }
                } label: {
                    Label {
                        if result.replaced { Text("已回填") }
                        else { Text("回填到 \(capture.sourceApp ?? BubbleLocalization.text("原软件"))") }
                    } icon: {
                        Image(systemName: result.replaced ? "checkmark" : "arrow.up.left")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(result.replacement == nil || result.replacing || result.replaced)
                .help(result.replacement == nil ? "原软件不支持直接回填，请复制润色结果。" : "替换原选区")
                .accessibilityIdentifier("polishReplace")
                Button(LocalizedStringKey(copied ? "已复制" : "复制润色结果")) {
                    NSPasteboard.general.clearContents()
                    copied = NSPasteboard.general.setString(capture.result, forType: .string)
                }
                .buttonStyle(.plain)
                .accessibilityIdentifier("selectionCopyResult")
            }
            if let message = result.replacementMessage {
                Text(BubbleLocalization.text(message)).foregroundStyle(.secondary)
                    .accessibilityIdentifier("polishReplacementMessage")
            }
            if capture.isMock { Text("AI Mock · 测试数据").bubbleFont(.caption).foregroundStyle(.secondary) }
        }
    }
}
