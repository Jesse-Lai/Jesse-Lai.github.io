import AppKit
import Carbon
import Observation

struct CaptureShortcut: Codable, Equatable {
    var key: String
    var control = true
    var option = true
    var command = false
    var shift = false
    static let keys: [String: UInt32] = ["T": 17, "R": 15, "C": 8, "L": 37, "P": 35, "H": 4, "S": 1, "Y": 16, "B": 11]
    var flags: UInt32 { (control ? UInt32(controlKey) : 0) | (option ? UInt32(optionKey) : 0) | (command ? UInt32(cmdKey) : 0) | (shift ? UInt32(shiftKey) : 0) }
    var label: String { (control ? "⌃" : "") + (option ? "⌥" : "") + (shift ? "⇧" : "") + (command ? "⌘" : "") + key }
}

@MainActor @Observable
final class MacShortcuts {
    var selection: CaptureShortcut
    var region: CaptureShortcut
    var error: String?
    private var references: [EventHotKeyRef] = []
    private var handler: EventHandlerRef?
    var trigger: ((UInt32) -> Void)?
    init() {
        let decoder = JSONDecoder()
        selection = UserDefaults.standard.data(forKey: "selectionShortcut").flatMap { try? decoder.decode(CaptureShortcut.self, from: $0) } ?? CaptureShortcut(key: "T")
        region = UserDefaults.standard.data(forKey: "regionShortcut").flatMap { try? decoder.decode(CaptureShortcut.self, from: $0) } ?? CaptureShortcut(key: "R")
        var type = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        InstallEventHandler(GetApplicationEventTarget(), { _, event, pointer in
            guard let event, let pointer else { return OSStatus(eventNotHandledErr) }
            var identifier = EventHotKeyID()
            let status = GetEventParameter(event, EventParamName(kEventParamDirectObject), EventParamType(typeEventHotKeyID), nil,
                                          MemoryLayout<EventHotKeyID>.size, nil, &identifier)
            if status == noErr {
                let manager = Unmanaged<MacShortcuts>.fromOpaque(pointer).takeUnretainedValue()
                let id = identifier.id
                Task { @MainActor in manager.trigger?(id) }
            }
            return status
        }, 1, &type, Unmanaged.passUnretained(self).toOpaque(), &handler)
        apply()
    }
    func apply() {
        error = nil
        guard selection != region, selection.control || selection.command, region.control || region.command else {
            error = "两个快捷键需不同，且必须包含 Control 或 Command。"; return
        }
        references.forEach { UnregisterEventHotKey($0) }; references = []
        for (index, shortcut) in [selection, region].enumerated() {
            var reference: EventHotKeyRef?
            let result = RegisterEventHotKey(CaptureShortcut.keys[shortcut.key] ?? 17, shortcut.flags,
                EventHotKeyID(signature: 0x4c42424c, id: UInt32(index)), GetApplicationEventTarget(), 0, &reference)
            guard result == noErr, let reference else {
                references.forEach { UnregisterEventHotKey($0) }; references = []
                error = "快捷键被系统或其他 App 占用，请换一个组合。"; return
            }
            references.append(reference)
        }
        UserDefaults.standard.set(try? JSONEncoder().encode(selection), forKey: "selectionShortcut")
        UserDefaults.standard.set(try? JSONEncoder().encode(region), forKey: "regionShortcut")
    }
    func reset() { selection = CaptureShortcut(key: "T"); region = CaptureShortcut(key: "R"); apply() }
}
