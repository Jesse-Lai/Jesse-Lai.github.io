#include <metal_stdlib>
using namespace metal;

// Native reconstruction of the optical structure studied at microsoft.ai.
// No website assets or JavaScript are bundled. See docs/prototypes/sunlight/README.md.
struct SunlightUniforms {
    float4 viewport; // width, height, elapsed seconds, grain strength
    float4 light;    // center x/y (bottom-left origin), softness, intensity
};

struct SunlightVertex { float4 position [[position]]; float2 uv; };

vertex SunlightVertex sunlightVertex(uint index [[vertex_id]]) {
    float2 p = float2((index << 1) & 2, index & 2);
    return { float4(p * 2.0 - 1.0, 0, 1), float2(p.x, 1.0 - p.y) };
}

// Integer hashing avoids the large sin() multipliers that vary across GPU families.
uint sunlightHash(uint n) {
    n ^= n >> 16; n *= 0x7feb352du;
    n ^= n >> 15; n *= 0x846ca68bu;
    return n ^ (n >> 16);
}
float2 sunlightSeed(int2 cell) {
    uint n = uint(cell.x) * 1597334677u ^ uint(cell.y) * 3812015801u;
    return float2(sunlightHash(n), sunlightHash(n ^ 0x68bc21ebu)) / 4294967295.0;
}

// Quintic easing keeps both slope and curvature continuous at each end.
float sunlightFeather(float start, float end, float radius) {
    float t = clamp((radius - start) / (end - start), 0.0, 1.0);
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

fragment half4 sunlightField(SunlightVertex in [[stage_in]],
                            constant SunlightUniforms &u [[buffer(0)]]) {
    float2 uv = float2(in.uv.x, 1.0 - in.uv.y);
    float aspect = u.viewport.x / max(u.viewport.y, 1.0);
    float angle = 0.76794487; // Long, diagonal patches, not round spotlight dots.
    float2 p = (uv - 0.5) * float2(aspect, 1.0) * 26.7;
    p = float2(p.x * cos(angle) - p.y * sin(angle),
               p.x * sin(angle) + p.y * cos(angle)) * float2(1.0, 0.16);
    int2 cell = int2(floor(p));
    float2 local = fract(p);
    float nearest = 100.0;
    float2 displacement = 0;
    for (int y = -1; y <= 1; ++y) {
        for (int x = -1; x <= 1; ++x) {
            int2 neighbor = int2(x, y);
            float2 seed = sunlightSeed(cell + neighbor);
            float2 moving = 0.5 + 0.5 * sin(5.0 + u.viewport.z * 0.4 + seed * 6.2831853);
            float2 delta = float2(neighbor) + moving - local;
            float distanceSquared = dot(delta, delta);
            if (distanceSquared < nearest) {
                nearest = distanceSquared;
                displacement = (moving - 0.5) * 0.4;
            }
        }
    }
    // Compose the spatial transforms before shading, avoiding intermediate passes.
    float2 warped = clamp(uv + displacement, 0.0, 1.0);
    warped.x += sin((warped.y * 2.0 - 0.5) * 7.0 + u.viewport.z * 0.5235464) * 0.118;
    warped = clamp(warped, 0.0, 1.0);
    float radius = length((warped - u.light.xy) * float2(aspect * 0.54, 0.46));
    float shade = smoothstep(0.0885, 0.2655, radius);
    // Stacked translucent masks in the reference make the lit regions broad.
    float illumination = 1.0 - shade * shade * shade;
    return half4(half3(illumination), 1);
}

fragment half4 sunlightBokeh(SunlightVertex in [[stage_in]],
                            constant SunlightUniforms &u [[buffer(0)]],
                            texture2d<half> field [[texture(0)]]) {
    constexpr sampler linearClamp(coord::normalized, address::clamp_to_edge, filter::linear);
    float aspect = u.viewport.x / max(u.viewport.y, 1.0);
    float sum = 0, weights = 0;
    uint2 pixel = uint2(in.position.xy);
    float apertureRotation = float(sunlightHash(pixel.x ^ (pixel.y * 65537u))) / 4294967295.0 * 6.2831853;
    // A disk aperture gives the diffuse photographic edges. The final fine grain
    // is static in screen space so a still frame does not sparkle or flicker.
    for (uint i = 0; i < 40; ++i) {
        float angle = float(i) * 2.39996323 + apertureRotation;
        float radius = sqrt((float(i) + 0.5) / 40.0) * 0.022 * u.light.z;
        float2 offset = float2(cos(angle) / aspect, sin(angle)) * radius;
        float value = float(field.sample(linearClamp, in.uv + offset).r);
        float weight = 1.0 + pow(value, 8.0) * 1.7;
        sum += value * weight;
        weights += weight;
    }
    return half4(half3(sum / weights), 1);
}

fragment half4 sunlightComposite(SunlightVertex in [[stage_in]],
                                constant SunlightUniforms &u [[buffer(0)]],
                                texture2d<half> blurred [[texture(0)]]) {
    constexpr sampler linearClamp(coord::normalized, address::clamp_to_edge, filter::linear);
    float illumination = float(blurred.sample(linearClamp, in.uv).r);
    // One transparent shadow mask spans the page, including artwork and text.
    // Premultiplied black preserves underlying hues; lit regions reveal the page.
    // Viewport-relative ellipses follow the broad regions in the reference sketch.
    // Overlapping feathers give 1% near the top-left, about 3% in the middle,
    // and 8% outside. The base stays fixed while the light patches move over it.
    // The inner arc changes only slightly. The outer arc reaches farther right
    // but turns upward below the cards, following the revised, flatter sketch.
    float innerDistance = length(in.uv / float2(1.06, 0.94));
    float outerDistance = length(in.uv / float2(1.09, 0.75));
    float innerFeather = sunlightFeather(0.20, 0.78, innerDistance);
    float outerFeather = sunlightFeather(0.72, 1.08, outerDistance);
    float shadowOpacity = clamp((0.01 + 0.02 * innerFeather + 0.05 * outerFeather) * u.light.w,
                                0.0, 1.0);
    uint2 pixel = uint2(in.position.xy);
    float grain = float(sunlightHash(pixel.x ^ (pixel.y * 65537u))) / 4294967295.0 - 0.5;
    float shadow = clamp((1.0 - illumination) * shadowOpacity, 0.0, shadowOpacity);
    // Static subpixel dithering prevents the 8-bit surface from turning this
    // shallow gradient into visible contour bands; it never flickers with time.
    float ditherStrength = max(u.viewport.w * shadowOpacity, 1.0 / 255.0);
    float alpha = clamp(shadow + grain * ditherStrength, 0.0,
                        clamp(0.08 * u.light.w, 0.0, 1.0));
    return half4(0, 0, 0, half(alpha));
}
