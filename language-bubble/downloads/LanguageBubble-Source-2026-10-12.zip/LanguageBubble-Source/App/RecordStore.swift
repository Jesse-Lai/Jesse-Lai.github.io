import SwiftUI
import SwiftData

@Model
final class StoredRecord {
    @Attribute(.unique) var id: UUID
    var epoch: Int
    var kind: String
    var source: String
    var result: String
    var explanation: String
    var category: String?
    var originalSpan: String?
    var replacement: String?
    var createdAt: Date

    init(_ record: CapturedRecord) {
        id = record.id; epoch = record.epoch; kind = record.kind.rawValue
        source = record.source; result = record.result; explanation = record.explanation
        category = record.category; originalSpan = record.originalSpan; replacement = record.replacement
        createdAt = record.createdAt
    }
    var captured: CapturedRecord {
        CapturedRecord(id: id, epoch: epoch, kind: RecordKind(rawValue: kind) ?? .translation,
                       source: source, result: result, explanation: explanation, category: category,
                       originalSpan: originalSpan, replacement: replacement, createdAt: createdAt)
    }
}

@MainActor @Observable
final class RecordStore {
    let journal: SharedJournal
    let container: ModelContainer
    let demo: Bool
    private let context: ModelContext
    var records: [CapturedRecord] = []
    var preferences = CapturePreferences()
    var error: String?

    init(demo: Bool = false) throws {
        self.demo = demo
        if demo {
            journal = try SharedJournal(root: FileManager.default.temporaryDirectory.appendingPathComponent("ContextDemo-" + UUID().uuidString))
        } else {
            journal = try SharedJournal.live()
            let serviceURL = Bundle.main.object(forInfoDictionaryKey: "ContextServiceURL") as? String ?? ""
            let serviceToken = Bundle.main.object(forInfoDictionaryKey: "ContextServiceToken") as? String ?? ""
            if !serviceURL.isEmpty, !serviceURL.contains("$("), try journal.state().preferences.serviceURL.isEmpty {
                try journal.updatePreferences { $0.serviceURL = serviceURL; $0.serviceToken = serviceToken }
            }
        }
        let config = ModelConfiguration(isStoredInMemoryOnly: demo)
        container = try ModelContainer(for: StoredRecord.self, configurations: config)
        context = ModelContext(container)
        context.autosaveEnabled = false
        #if DEBUG
        if demo { try seedDemo() }
        #endif
        refresh()
    }

    func refresh() {
        do {
            error = nil
            try journal.consume { snapshot in
                do {
                    let existing = try context.fetch(FetchDescriptor<StoredRecord>())
                    var ids = Set<UUID>()
                    for item in existing {
                        if item.epoch != snapshot.state.epoch || snapshot.state.tombstones.contains(item.id) {
                            context.delete(item)
                        } else { ids.insert(item.id) }
                    }
                    for record in snapshot.records where !ids.contains(record.id) {
                        context.insert(StoredRecord(record)); ids.insert(record.id)
                    }
                    if context.hasChanges { try context.save() }
                    preferences = snapshot.state.preferences
                } catch {
                    context.rollback()
                    throw error
                }
            }
            records = try context.fetch(FetchDescriptor<StoredRecord>(sortBy: [SortDescriptor(\.createdAt, order: .reverse)])).map(\.captured)
        } catch { self.error = error.localizedDescription }
    }

    func update(_ update: (inout CapturePreferences) -> Void) {
        do { try journal.updatePreferences(update); refresh() }
        catch { self.error = error.localizedDescription }
    }

    func delete(_ record: CapturedRecord) {
        do { try journal.remove(record.id); refresh() }
        catch { self.error = error.localizedDescription }
    }

    func clear() {
        do { try journal.clear(); refresh() }
        catch { self.error = error.localizedDescription }
    }

    func export() throws -> Data {
        refresh()
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return try encoder.encode(records)
    }

    #if DEBUG
    private func seedDemo() throws {
        try journal.updatePreferences {
            $0.automaticChecking = true; $0.saveTranslations = true; $0.saveWritingIssues = true
        }
        let examples: [(RecordKind, String, String, String, String?, String?, String?)] = [
            (.translation, "It’s a work in progress.", "这件事还在完善中。", "work in progress 指尚未完成、仍在推进的工作，也可以用来形容仍在改进的作品。", nil, nil, nil),
            (.translation, "products", "产品；商品", "product 的复数形式，通常指生产或提供给用户使用的东西。具体含义需要结合原句判断。", nil, nil, nil),
            (.translation, "That makes sense.", "有道理；说得通。", "用于表示理解或认同对方的解释，是日常交流中常见的表达。", nil, nil, nil),
            (.writing, "I am agree with you.", "I agree with you.", "agree 本身是动词，这里不需要 be 动词 am。", "grammar", "am agree", "agree"),
            (.writing, "I look forward to hear from you.", "I look forward to hearing from you.", "look forward to 中的 to 是介词，后面的动词应使用 -ing 形式。", "collocation", "to hear", "to hearing")
        ]
        for (index, value) in examples.enumerated() {
            let ticket = try journal.ticket()
            let record = CapturedRecord(id: ticket.id, epoch: ticket.epoch, kind: value.0,
                source: value.1, result: value.2, explanation: value.3, category: value.4,
                originalSpan: value.5, replacement: value.6, createdAt: Date().addingTimeInterval(Double(-index * 2700)))
            try journal.enqueue(record, ticket: ticket)
        }
    }
    #endif
}
