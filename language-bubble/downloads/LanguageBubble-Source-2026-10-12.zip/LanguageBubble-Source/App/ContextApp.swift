import SwiftUI

@main
struct ContextApp: App {
    init() { BubbleTypography.configureNavigation() }
    var body: some Scene {
        WindowGroup { AppBootstrap() }
    }
}

struct AppBootstrap: View {
    @State private var store: RecordStore?
    @State private var bubble: BubbleStore?
    @State private var error: String?
    var body: some View {
        Group {
            if let error {
                ContentUnavailableView("记录暂时无法打开", systemImage: "externaldrive.badge.exclamationmark", description: Text(error))
            } else if let store {
                if store.demo {
                    RecordListView().environment(store)
                } else if let bubble {
                    BubbleRootView().environment(bubble).environment(store)
                }
            } else {
                ProgressView().task {
                    do {
                        #if DEBUG
                        store = try RecordStore(demo: ProcessInfo.processInfo.arguments.contains("--demo"))
                        #else
                        store = try RecordStore()
                        #endif
                        if let store, !store.demo {
                            let value = try BubbleStore()
                            value.configureBridge = { session, endpoint in
                                try store.journal.bindSyncUser(session, endpoint: endpoint); store.refresh()
                            }
                            value.bridgeSnapshot = {
                                store.refresh()
                                if let error = store.error { throw ContextError.service(error) }
                                return JournalSnapshot(state: try store.journal.state(), records: store.records)
                            }
                            value.syncBridge = { _ = try await store.journal.syncPending() }
                            value.clearBridge = { try store.journal.clear(); store.refresh() }
                            value.configureBridgeProfile = { profile in
                                try store.journal.updatePreferences { $0.primaryLanguage = profile.primaryLanguage; $0.secondaryLanguage = profile.secondaryLanguage }
                            }
                            value.removeBridgeRecord = { id in
                                if let uuid = UUID(uuidString: id) { try? store.journal.remove(uuid, enqueueSync: false); store.refresh() }
                            }
                            bubble = value
                        }
                    } catch { self.error = error.localizedDescription }
                }
            }
        }.bubbleAppearance()
    }
}
