import SwiftUI

struct RecordListView: View {
    @Environment(RecordStore.self) private var store
    @Environment(\.scenePhase) private var scenePhase
    @State private var selected = RecordKind.translation
    @State private var showSettings = false
    private var visible: [CapturedRecord] { store.records.filter { $0.kind == selected } }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(alignment: .firstTextBaseline) {
                        Text("记录").bubbleFont(.largeTitle, size: 34, weight: .bold)
                        Spacer()
                        Text("CONTEXT").bubbleFont(.caption, size: 11, weight: .semibold).tracking(2).foregroundStyle(.secondary)
                    }
                    Text("查过的表达，写过的问题。").bubbleFont(.subheadline).foregroundStyle(.secondary).padding(.top, -12)
                    Picker("记录类型", selection: $selected) {
                        ForEach(RecordKind.allCases, id: \.self) { kind in Text(kind.title).tag(kind) }
                    }.pickerStyle(.segmented).accessibilityIdentifier("recordKindPicker")
                }.padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 16)

                if store.demo {
                    Label("示例预览 · 非真实采集记录", systemImage: "eye")
                        .bubbleFont(.caption).foregroundStyle(.secondary).padding(.bottom, 10)
                }

                if visible.isEmpty {
                    ContentUnavailableView {
                        Label(selected == .translation ? "下一次查译，从这里留下" : "写作中的问题，会出现在这里", systemImage: selected.symbol)
                    } description: {
                        Text(selected == .translation
                             ? "将 Context 设为默认翻译应用，选中文字并点击“翻译”。开启记录后，就能回来查看。"
                             : "启用 Context 英文键盘，开启自动检查和问题记录。发现的错误会保存在这里。")
                    } actions: {
                        Button("设置收集入口") { showSettings = true }.buttonStyle(.borderedProminent)
                    }
                } else {
                    List {
                        Section {
                            ForEach(visible) { record in
                                NavigationLink {
                                    RecordDetailView(record: record)
                                } label: {
                                    RecordRow(record: record)
                                }.swipeActions {
                                    Button("删除", role: .destructive) { store.delete(record) }
                                }
                                .listRowBackground(Color(uiColor: .secondarySystemGroupedBackground))
                            }
                        } header: {
                            Text("最近 · \(visible.count) 条").bubbleFont(.caption)
                        }
                    }.listStyle(.insetGrouped).scrollContentBackground(.hidden)
                        .refreshable { store.refresh() }
                }
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("设置", systemImage: "slider.horizontal.3") { showSettings = true }
                        .accessibilityIdentifier("openSettings")
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView().environment(store) }
            .onChange(of: scenePhase) { _, value in if value == .active { store.refresh() } }
            .task {
                while !Task.isCancelled {
                    if scenePhase == .active { store.refresh() }
                    try? await Task.sleep(for: .seconds(2))
                }
            }
            .alert("操作未完成", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                Button("好") { store.error = nil }
            } message: { Text(store.error ?? "") }
        }
    }
}

struct RecordRow: View {
    let record: CapturedRecord
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label(record.kind == .translation ? "查译" : categoryTitle, systemImage: record.kind.symbol)
                Spacer()
                Text(record.createdAt, style: .time)
            }.bubbleFont(.caption).foregroundStyle(.secondary)
            Text(record.source).bubbleFont(.body, weight: .medium).lineLimit(3)
            Text(record.result).bubbleFont(.subheadline).foregroundStyle(record.kind == .translation ? Color.secondary : Color.accentColor).lineLimit(2)
        }.padding(.vertical, 10)
    }
    private var categoryTitle: String {
        ["grammar": "语法", "spelling": "拼写", "collocation": "搭配", "word_choice": "用词"][record.category ?? ""] ?? "写作问题"
    }
}

struct RecordDetailView: View {
    let record: CapturedRecord
    @Environment(RecordStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var confirmDelete = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                Text(record.createdAt.formatted(date: .abbreviated, time: .shortened)).bubbleFont(.caption).foregroundStyle(.secondary)
                block(record.kind == .translation ? "选中的原文" : "原句", text: record.source)
                if let original = record.originalSpan, let replacement = record.replacement {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("问题位置").bubbleFont(.caption).foregroundStyle(.secondary)
                        Text(original).strikethrough().foregroundStyle(.secondary)
                        Label(replacement.isEmpty ? "删除此处" : replacement, systemImage: "arrow.turn.down.right").foregroundStyle(Color.accentColor)
                    }.padding(18).frame(maxWidth: .infinity, alignment: .leading).background(Color.accentColor.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
                }
                block(record.kind == .translation ? "中文解释" : "修改建议", text: record.result)
                if !record.explanation.isEmpty { block(record.kind == .translation ? "表达说明" : "为什么这样改", text: record.explanation) }
                if record.kind == .writing {
                    Button("这是误判，移除记录", role: .destructive) { remove() }.bubbleFont(.subheadline)
                }
            }.padding(24)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle(record.kind.title).navigationBarTitleDisplayMode(.inline)
        .toolbar {
            Button("删除", systemImage: "trash", role: .destructive) { confirmDelete = true }
        }
        .confirmationDialog("删除这条记录？", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("删除记录", role: .destructive) { remove() }
        }
    }
    private func block(_ label: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(label).bubbleFont(.caption).foregroundStyle(.secondary)
            Text(text).bubbleFont(label == "选中的原文" || label == "原句" ? .title3 : .body).textSelection(.enabled)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private func remove() { store.delete(record); if store.error == nil { dismiss() } }
}
