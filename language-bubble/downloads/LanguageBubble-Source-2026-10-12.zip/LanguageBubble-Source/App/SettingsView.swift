import SwiftUI
import UniformTypeIdentifiers

struct JSONExport: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data = Data()
    init(data: Data = Data()) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

struct SettingsView: View {
    var showDataControls = true
    @Environment(RecordStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var confirmClear = false
    @State private var exportFile = JSONExport()
    @State private var showExport = false
    @State private var endpoint = ""
    @State private var token = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("收集入口") {
                    Label("系统翻译", systemImage: "character.bubble")
                    Text("在系统设置 → App → 默认 App → 翻译中选择 Language Bubble。然后在支持的 App 中选中文字并点击“翻译”。")
                        .bubbleFont(.footnote).foregroundStyle(.secondary)
                    Label("英文键盘", systemImage: "keyboard")
                    Text("在系统设置 → 通用 → 键盘 → 键盘 → 添加新键盘中添加 Language Bubble。联网检查需要允许完全访问。")
                        .bubbleFont(.footnote).foregroundStyle(.secondary)
                    Button("打开系统设置") {
                        if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                    }
                }
                Section {
                    Toggle("自动检查英文输入", isOn: binding(\.automaticChecking))
                    Toggle("保存翻译记录", isOn: binding(\.saveTranslations))
                    Toggle("保存写作问题", isOn: binding(\.saveWritingIssues))
                } header: { Text("分析与记录") } footer: {
                    Text("点击系统“翻译”即开始查译。开启自动检查后，键盘会分析当前可获取的英文句子。关闭记录不会影响查译或删除已有内容。")
                }
                if showDataControls { Section("数据") {
                    Button("导出记录", systemImage: "square.and.arrow.up") {
                        do { exportFile = JSONExport(data: try store.export()); showExport = true }
                        catch { store.error = error.localizedDescription }
                    }
                    Button("清空全部记录", systemImage: "trash", role: .destructive) { confirmClear = true }
                        .accessibilityIdentifier("requestClearRecords")
                } }
                Section("隐私") {
                    Text("查译及待检查句子会发送到已配置的代理服务。当前测试使用 AI Mock 固定样例，不调用模型提供方；样例结果会明确标注。启用真实 AI 后，代理才会将内容发送给所配置的提供方。服务不把原文写入运行日志；记录保存在这台设备上。")
                    Text("键盘不会持续保存逐键日志。问题记录只包含必要的原句片段与修改建议。不要在启用分析的输入框中提交密码或敏感信息。")
                }.bubbleFont(.footnote).foregroundStyle(.secondary)
                #if DEBUG
                Section("开发连接 · 仅调试版本") {
                    TextField("代理服务 HTTPS 地址", text: $endpoint).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    SecureField("代理访问令牌（非模型 API Key）", text: $token)
                    Text("AI Mock 样例：It is a work in progress. / I am agree with you. / I agree with you.")
                        .bubbleFont(.footnote).foregroundStyle(.secondary)
                    Button("保存服务连接") { store.update { $0.serviceURL = endpoint.trimmingCharacters(in: .whitespacesAndNewlines); $0.serviceToken = token } }
                    NavigationLink("输入框验收工具") { ComposerLabView() }
                }
                #endif
            }
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
            .onAppear { endpoint = store.preferences.serviceURL; token = store.preferences.serviceToken }
            .confirmationDialog("清空全部记录？此操作无法撤销。", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("清空全部记录", role: .destructive) { store.clear() }
                    .accessibilityIdentifier("confirmClearRecords")
            }
            .fileExporter(isPresented: $showExport, document: exportFile, contentType: .json, defaultFilename: "Language-Bubble-records") { result in
                if case .failure(let error) = result { store.error = error.localizedDescription }
            }
        }
    }
    private func binding(_ key: WritableKeyPath<CapturePreferences, Bool>) -> Binding<Bool> {
        Binding(get: { store.preferences[keyPath: key] }, set: { value in store.update { $0[keyPath: key] = value } })
    }
}

#if DEBUG
struct ComposerLabView: View {
    @State private var text = ""
    var body: some View {
        Form {
            Section("用于验证真实键盘扩展") {
                Text("使用地球键切换到 Language Bubble，再输入英文。此工具不会自行模拟纠错或保存记录。")
                TextEditor(text: $text).frame(minHeight: 180).autocorrectionDisabled().accessibilityIdentifier("composerLab")
            }
            Section("用于验证系统翻译扩展") {
                Text("It is a work in progress.").textSelection(.enabled)
                Text("长按英文并选择系统“翻译”。需要先在系统设置中选择 Language Bubble 为默认翻译应用。")
                    .bubbleFont(.footnote).foregroundStyle(.secondary)
            }
        }.navigationTitle("入口验收")
    }
}
#endif
