#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift test --scratch-path /private/tmp/context-core-build
(cd server && .venv/bin/python -m unittest discover -s tests)
git diff --check
