#!/usr/bin/env python3
"""Build source-backed paper cutouts; original artwork is cropped, never repainted.

Text clippings are re-typeset excerpts, not fabricated screenshots. Source URLs,
verbatim excerpts, crop coordinates and native placements live in manifest.json.
"""
import json
import re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'design/record-workspace/curated-20261011'
SCALE = 3
FONTS = Path('/System/Library/Fonts/Supplemental')
SPECS = [
 dict(word='resilient', file='resilient.jpg', crop=[.20,.065,.80,.66], width=258,
      poster_title='Resilient — Rick Hanson & Forrest Hanson', poster_source='Walmart · book cover',
      poster_url='https://www.walmart.com/ip/868197292',
      quote='When you learn how to learn, you gain the strength that builds the other strengths of resilient well-being.',
      source='Rick Hanson · The Importance of Learning', url='https://rickhanson.com/the-importance-of-learning/',
      lines=['When you learn how to learn,','you gain the strength that builds','the other strengths of','resilient well-being.'],
      font='Arial.ttf', size=22, ink='#353325', paper='#f1efb5', highlight='#e2cb77', x=244,y=53,style='stepped'),
 dict(word='clarity', file='clarity-book.jpg', crop=[.228,.268,.775,.81], width=264,
      poster_title='Clarity — Jamie Smart', poster_source='Apple Books · book cover',
      poster_url='https://books.apple.com/nz/book/clarity/id6445520381',
      quote='Clarity is the elimination of mental clutter.',source='James Clear',
      url='https://jamesclear.com/quotes/clarity-is-the-elimination-of-mental-clutter',
      lines=['Clarity is the elimination','of mental clutter.'],font='Baskerville.ttc',size=34,
      ink='#25394f',paper='#dce7ed',highlight='#b9cfdf',x=248,y=68,style='stepped'),
 dict(word='converge',file='converge.jpg',crop=[0,0,1,.90],width=285,
      poster_title='Converge · Latin America 2024',poster_source='Deathwish Inc · tour poster',
      poster_url='https://deathwishinc.com/blogs/news/converge-latin-america-2024',
      quote='Some lenses will diverge light while others will converge light, bringing the light rays together.',
      source='Siyavula · Natural Sciences',url='https://www.siyavula.com/downloads/books/science/Gr8_B_learner_eng.pdf',
      lines=['Some lenses will diverge light','while others will converge light,','bringing the light rays together.'],
      font='AmericanTypewriter.ttc',size=22,ink='#27332f',paper='#edf0d9',highlight='#d9e6a5',x=265,y=67,style='stepped'),
 dict(word='misery',file='misery.jpg',crop=[.045,.205,.955,.846],width=270,
      poster_title='Misery (1990) · film poster',poster_source='Pinterest · film poster',
      poster_url='https://ar.pinterest.com/pin/930415604249371562/',quote='Misery loves company.',
      source='Cambridge Dictionary · English idiom',url='https://dictionary.cambridge.org/us/dictionary/english/misery-loves-company',
      lines=['Misery loves','company.'],font='Bodoni 72.ttc',size=49,
      ink='#60252e',paper='#f4dce0',highlight='#edb5be',x=261,y=67,style='ticket'),
 dict(word='setbacks',file='setbacks.jpg',quad=[.243,.126,.752,.133,.765,.878,.244,.881],crop=[.08,.12,.94,.89],width=226,
      poster_title='Resilience turns setbacks into comebacks',poster_source='DomAndHyoPrints · poster',
      poster_url='https://www.etsy.com/listing/1540781681/resilience-poster-resilience-quote',
      quote='Setbacks and disappointments prepare you for greater success in life.',source='Germany Kent · Goodreads',
      url='https://www.goodreads.com/quotes/10819032-setbacks-and-disappointments-prepare-you-for-greater-success-in-life',
      lines=['Setbacks and disappointments','prepare you for greater','success in life.'],font='Baskerville.ttc',size=29,
      ink='#224a43',paper='#daeee5',highlight='#b7daca',x=233,y=71,style='stepped'),
 dict(word='transistor',file='transistor.jpg',quad=[.267,.169,.643,.213,.68,.843,.29,.874],crop=[0,0,1,.79],width=242,
      poster_title='Transistor · Supergiant Games',poster_source='98 Types Studio · game poster',
      poster_url='https://98types.co.uk/products/transistor-video-game-posters',
      quote='A transistor is a semiconductor device used to amplify or switch electrical signals and power.',
      source='Wikipedia · Transistor',url='https://en.wikipedia.org/wiki/Transistor',
      lines=['A transistor is a semiconductor','device used to amplify or switch','electrical signals and power.'],
      font='Arial.ttf',size=23,ink='#253c3d',paper='#d5e8e4',highlight='#a9d2c9',x=244,y=70,style='stepped'),
 dict(word='photography',file='photography-book.jpg',crop=[.207,.023,.793,.56],width=275,
      poster_title='On Photography — Susan Sontag',poster_source='Photo Museum Ireland · book cover',
      poster_url='https://shop.photomuseumireland.ie/products/on-photography-by-susan-sontag',
      quote='The word Photography literally means ‘drawing with light’',source='IMMA · What Is Art?',
      url='https://imma.ie/what-is-art/series-3-materials-methodologies/photography/',
      lines=['The word Photography','literally means','‘drawing with light’'],font='Baskerville.ttc',size=32,
      ink='#49332c',paper='#f1dbc1',highlight='#e7b58d',x=263,y=60,style='stepped'),
 dict(word='frame',file='frame.jpg',crop=[0,0,1,.88],width=257,
      poster_title='FRAME · The Next Space · Issue 146',poster_source='Unique Magazines · magazine cover',
      poster_url='https://www.uniquemagazines.co.uk/Frame-Magazine-Subscription-p349211',
      quote='Almost anything in nature can be used as a frame within a photograph.',source='B&H eXplora · Framing',
      url='https://www.bhphotovideo.com/explora/photography/tips-and-solutions/framing-photographic-composition',
      lines=['Almost anything in nature','can be used as a frame','within a photograph.'],font='Arial.ttf',size=26,
      ink='#2f3825',paper='#eef0ca',highlight='#c9da68',x=247,y=63,style='stepped'),
 dict(word='read',file='read.jpg',crop=[.06,0,.98,1],width=182,
      poster_title='READ — Fidel Peña',poster_source='Alliance Graphique Internationale · poster',
      poster_url='https://a-g-i.org/user/FidelPena/',
      quote='a reader lives a thousand lives before he dies, and a man who does not read lives only one.',
      source='George R. R. Martin · The Brown Daily Herald',
      url='https://www.browndailyherald.com/article/2014/10/in-conversation-george-r-r-martin',
      lines=['a reader lives a thousand lives','before he dies, and a man who','does not read lives only one.'],font='Baskerville.ttc',size=29,
      ink='#302f2c',paper='#f5eaa9',highlight='#e7d268',x=190,y=63,style='stepped'),
 dict(word='workhorse',file='workhorse.jpg',crop=[0,.325,1,.95],width=267,
      poster_title='Workhorse — Kim Reed',poster_source='Kitchen Arts & Letters · book cover',
      poster_url='https://www.kitchenartsandletters.com/products/workhorse-my-sublime-and-absurd-years-in-new-york-citys-restaurant-scene',
      quote='WFC3 has become the telescope’s workhorse camera, responsible for many of Hubble’s spectacular pictures.',
      source='NASA · Hubble’s Instruments',
      url='https://science.nasa.gov/asset/hubble/hubbles-instruments-including-control-and-support-systems-cutaway/',
      lines=['WFC3 has become the telescope’s','workhorse camera, responsible','for many of Hubble’s','spectacular pictures.'],font='Arial.ttf',size=23,
      ink='#393443',paper='#e8dff1',highlight='#cdbade',x=291,y=50,style='stepped'),
]


def font(name, size):
    return ImageFont.truetype(str(FONTS / name), round(size*SCALE))


def rounded(im, radius=13):
    im=im.convert('RGBA');mask=Image.new('L',im.size,0)
    ImageDraw.Draw(mask).rounded_rectangle((0,0,im.width-1,im.height-1),radius=radius*SCALE,fill=255)
    im.putalpha(mask);return im


def poster(spec):
    im=Image.open(BASE/'originals'/spec['file']).convert('RGB')
    if 'quad' in spec:
        # PIL QUAD uses top-left, bottom-left, bottom-right, top-right.
        q=spec['quad'];p=[(q[i]*im.width,q[i+1]*im.height) for i in range(0,8,2)]
        im=im.transform((750,1100),Image.Transform.QUAD,tuple(v for i in [0,3,2,1] for v in p[i]),Image.Resampling.BICUBIC)
    c=spec['crop'];im=im.crop(tuple(round(v*(im.width if i%2==0 else im.height)) for i,v in enumerate(c)))
    h=min(242,round(spec['width']*im.height/im.width));w=round(h*im.width/im.height)
    im=im.resize((w*SCALE,h*SCALE),Image.Resampling.LANCZOS)
    return rounded(im),w,h


def clipping(spec):
    f=font(spec['font'],spec['size']);credit=font('Arial.ttf',10)
    lines=spec['lines'];assert ' '.join(lines)==spec['quote']
    assert re.search(r'\b'+spec['word']+r'\b',spec['quote'],re.I)
    line_h=round(spec['size']*1.2*SCALE);pad=22*SCALE
    lengths=[round(f.getlength(s)) for s in lines]
    credit_w=round(credit.getlength(spec['source']))
    width=max(max(lengths),credit_w)+2*pad
    height=len(lines)*line_h+2*pad+23*SCALE
    im=Image.new('RGBA',(width,height));d=ImageDraw.Draw(im)
    if spec['style']=='ticket':
        d.rounded_rectangle((0,0,width-1,height-1),radius=18*SCALE,fill=spec['paper'])
        for yy in [height*.47,height*.55]:d.ellipse((-7*SCALE,yy-7*SCALE,7*SCALE,yy+7*SCALE),fill=(0,0,0,0))
    else:
        # The edge follows the excerpt's line lengths, like a clipping cut from a page.
        for i,length in enumerate(lengths):
            right=max(length+2*pad,credit_w+2*pad if i==len(lines)-1 else 0)
            bottom=pad+(i+1)*line_h+10*SCALE
            if i==len(lines)-1:bottom=height
            d.rounded_rectangle((0,max(0,i*line_h),right,bottom),radius=11*SCALE,fill=spec['paper'])
    for i,line in enumerate(lines):
        x=pad;y=pad+i*line_h
        match=re.search(r'\b'+spec['word']+r'\b',line,re.I)
        if match:
            start=x+f.getlength(line[:match.start()]);end=x+f.getlength(line[:match.end()])
            d.rounded_rectangle((start-2*SCALE,y+2*SCALE,end+2*SCALE,y+spec['size']*SCALE+5*SCALE),radius=2*SCALE,fill=spec['highlight'])
        d.text((x,y),line,font=f,fill=spec['ink'],anchor='lt')
    d.text((pad,height-21*SCALE),spec['source'],font=credit,fill=spec['ink'],anchor='lt')
    return im,width/SCALE,height/SCALE


def main():
    (BASE/'cutouts').mkdir(exist_ok=True)
    manifest=[];previews=[]
    for spec in SPECS:
        p,pw,ph=poster(spec);q,qw,qh=clipping(spec)
        x=min(spec['x'],709-qw)
        # Keep both clippings inside the existing native gallery.
        placements=[dict(x=20,y=2,width=pw,height=ph,rotation=2),
                    dict(x=x,y=spec['y'],width=qw,height=qh,rotation=-2)]
        assert qh+spec['y']<262,(spec['word'],qh)
        row=dict(word=spec['word'],scenes=[],crop=spec['crop'])
        canvas=Image.new('RGBA',(760*SCALE,290*SCALE),'white')
        dots=ImageDraw.Draw(canvas)
        for yy in range(12,290,36):
            for xx in range(12,760,38):dots.ellipse((xx*SCALE,yy*SCALE,(xx+4)*SCALE,(yy+4)*SCALE),fill='#dddddd')
        for role,im,placement in [('poster',p,placements[0]),('quote',q,placements[1])]:
            name='Curated'+spec['word'].capitalize()+role.capitalize()
            asset=ROOT/'Resources/Assets.xcassets'/(name+'.imageset');asset.mkdir(exist_ok=True)
            im.save(asset/'cutout.png');im.save(BASE/'cutouts'/(spec['word']+'-'+role+'.png'))
            (asset/'Contents.json').write_text(json.dumps({'images':[{'filename':'cutout.png','idiom':'universal'}],'info':{'author':'xcode','version':1}},indent=2)+'\n')
            row['scenes'].append(dict(role=role,display_image_name=name,placement=placement,
                file='originals/'+spec['file'] if role=='poster' else 'cutouts/'+spec['word']+'-quote.png',
                source_url=spec['poster_url'] if role=='poster' else spec['url'],
                source_app=spec['poster_source'] if role=='poster' else spec['source'],
                text=spec['poster_title'] if role=='poster' else spec['quote'],
                treatment='Crop of original artwork' if role=='poster' else 'Verbatim source excerpt, re-typeset as a paper clipping'))
            rot=im.rotate(-placement['rotation'],resample=Image.Resampling.BICUBIC,expand=True)
            shadow=Image.new('RGBA',rot.size,(0,0,0,0));shadow.putalpha(rot.getchannel('A').point(lambda a:round(a*.15)))
            shadow=ImageOps.expand(shadow,30*SCALE).filter(ImageFilter.GaussianBlur(12*SCALE))
            px=round((placement['x']+12)*SCALE);py=round((placement['y']+15)*SCALE)
            canvas.alpha_composite(shadow,(px-30*SCALE,py-26*SCALE));canvas.alpha_composite(rot,(px,py))
        row['quote']=spec['quote'];manifest.append(row)
        canvas.convert('RGB').save(BASE/(spec['word']+'-preview.jpg'),quality=94)
        previews.append((spec['word'],canvas))
    (BASE/'manifest.json').write_text(json.dumps(dict(version=1,keep=['journey','bubble']+[x['word'] for x in SPECS],words=manifest),ensure_ascii=False,indent=2)+'\n')
    out=Image.new('RGB',(1520,5*340),'#f5f5f5');d=ImageDraw.Draw(out)
    for i,(word,im) in enumerate(previews):
        x=(i%2)*760;y=(i//2)*340;im=im.resize((760,290),Image.Resampling.LANCZOS)
        out.paste(im,(x,y+40));d.text((x+25,y+10),word.capitalize(),font=ImageFont.truetype(str(FONTS/'Baskerville.ttc'),26),fill='#222')
    out.save(BASE/'contact-sheet.jpg',quality=95)
    print('Built 20 clippings for 10 existing words; source manifest and contact sheet saved.')

if __name__=='__main__':main()
