#!/usr/bin/env python3
"""Generate a deterministic Xcode project without a third-party project generator."""
import argparse
import hashlib
import json
import plistlib
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--bundle-prefix", default="app.context.capture")
args = parser.parse_args()
prefix = args.bundle_prefix
group = "group." + prefix
objects = {}
existing_project = ROOT / "Context.xcodeproj/project.pbxproj"
existing_objects = json.loads(subprocess.check_output(
    ["plutil", "-convert", "json", "-o", "-", str(existing_project)]
)).get("objects", {}) if existing_project.exists() else {}


def uid(name):
    return hashlib.sha256(name.encode()).hexdigest()[:24].upper()


def obj(object_key, **fields):
    identifier = uid(object_key)
    objects[identifier] = fields
    return identifier


def plist(path, value):
    destination = ROOT / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(plistlib.dumps(value, sort_keys=False))


base_info = {
    "CFBundleDevelopmentRegion": "zh_CN", "CFBundleExecutable": "$(EXECUTABLE_NAME)",
    "CFBundleIdentifier": "$(PRODUCT_BUNDLE_IDENTIFIER)", "CFBundleInfoDictionaryVersion": "6.0",
    "CFBundleName": "$(PRODUCT_NAME)", "CFBundleShortVersionString": "$(MARKETING_VERSION)",
    "CFBundleVersion": "$(CURRENT_PROJECT_VERSION)", "ContextAppGroup": group,
    "NSAppTransportSecurity": {"NSAllowsLocalNetworking": True},
    "NSLocalNetworkUsageDescription": "连接同一 Wi-Fi 下的 Mac 测试服务，同步你的语言记录和学习内容。",
}
plist("Config/App-Info.plist", base_info | {
    "CFBundlePackageType": "APPL", "CFBundleDisplayName": "Language Bubble", "LSRequiresIPhoneOS": True,
    # iOS reads this declaration from the containing app, even though the extension sends the request.
    # https://developer.apple.com/documentation/translationuiprovider/preparing-your-app-to-be-the-default-translation-app
    "com.apple.developer.translation-ui-provider.network-access": True,
    "UILaunchScreen": {}, "UIApplicationSceneManifest": {"UIApplicationSupportsMultipleScenes": False},
    "UISupportedInterfaceOrientations": ["UIInterfaceOrientationPortrait"],
    "UISupportedInterfaceOrientations~ipad": ["UIInterfaceOrientationPortrait", "UIInterfaceOrientationPortraitUpsideDown", "UIInterfaceOrientationLandscapeLeft", "UIInterfaceOrientationLandscapeRight"],
    "ContextServiceURL": "$(CONTEXT_SERVICE_URL)", "ContextServiceToken": "$(CONTEXT_SERVICE_TOKEN)",
})
plist("Config/Translation-Info.plist", base_info | {
    "CFBundlePackageType": "XPC!", "CFBundleDisplayName": "Language Bubble 翻译",
    "EXAppExtensionAttributes": {"EXExtensionPointIdentifier": "com.apple.public.translation-ui-provider"},
    "com.apple.developer.translation-ui-provider.network-access": True,
})
plist("Config/Keyboard-Info.plist", base_info | {
    "CFBundlePackageType": "XPC!", "CFBundleDisplayName": "Language Bubble 英文",
    "NSExtension": {"NSExtensionPointIdentifier": "com.apple.keyboard-service",
                    "NSExtensionPrincipalClass": "$(PRODUCT_MODULE_NAME).KeyboardViewController",
                    "NSExtensionAttributes": {"IsASCIICapable": True, "PrefersRightToLeft": False,
                                              "PrimaryLanguage": "en-US", "RequestsOpenAccess": True}},
})
for name in ["App", "Translation", "Keyboard"]:
    entitlements = {"com.apple.security.application-groups": [group]}
    if name == "App":
        entitlements["com.apple.developer.translation-app"] = True
    plist(f"Config/{name}.entitlements", entitlements)

plist("Resources/PrivacyInfo.xcprivacy", {
    "NSPrivacyTracking": False, "NSPrivacyTrackingDomains": [],
    "NSPrivacyCollectedDataTypes": [{
        "NSPrivacyCollectedDataType": "NSPrivacyCollectedDataTypeOtherUserContent",
        "NSPrivacyCollectedDataTypeLinked": True, "NSPrivacyCollectedDataTypeTracking": False,
        "NSPrivacyCollectedDataTypePurposes": ["NSPrivacyCollectedDataTypePurposeAppFunctionality"],
    }],
    "NSPrivacyAccessedAPITypes": [],
})

refs = {}
localized_refs = []
for language in ["en", "zh-Hans"]:
    localized_refs.append(obj("localization:" + language, isa="PBXFileReference", lastKnownFileType="text.plist.strings", name=language, path=f"Resources/{language}.lproj/Localizable.strings", sourceTree="<group>"))
refs["Localizable.strings"] = obj("localizations", isa="PBXVariantGroup", children=localized_refs, name="Localizable.strings", sourceTree="<group>")
sources = list(ROOT.glob("Shared/*.swift")) + list(ROOT.glob("Client/*.swift")) + list(ROOT.glob("App/*.swift")) + list(ROOT.glob("MacApp/*.swift")) + list(ROOT.glob("MacApp/*.metal")) + list(ROOT.glob("TranslationExtension/*.swift")) + list(ROOT.glob("KeyboardExtension/*.swift")) + list(ROOT.glob("Tests/UITests/*.swift"))
for path in sources + [ROOT / "Resources/PrivacyInfo.xcprivacy", ROOT / "Resources/ThirdPartyLicenses.txt"]:
    relative = str(path.relative_to(ROOT))
    refs[relative] = obj("file:" + relative, isa="PBXFileReference", lastKnownFileType="sourcecode.swift" if path.suffix == ".swift" else "sourcecode.metal" if path.suffix == ".metal" else "text" if path.suffix == ".txt" else "text.xml", path=relative, sourceTree="<group>")

refs["Resources/CameraStudy"] = obj("camera-study", isa="PBXFileReference", lastKnownFileType="folder", path="Resources/CameraStudy", sourceTree="<group>")
asset_path = ROOT / "Resources/Assets.xcassets"
refs["Resources/Fonts"] = obj("fonts", isa="PBXFileReference", lastKnownFileType="folder", path="Resources/Fonts", sourceTree="<group>")
if asset_path.exists():
    refs["Resources/Assets.xcassets"] = obj("assets", isa="PBXFileReference", lastKnownFileType="folder.assetcatalog", path="Resources/Assets.xcassets", sourceTree="<group>")

config_ref = obj("config:base", isa="PBXFileReference", lastKnownFileType="text.xcconfig", path="Config/Base.xcconfig", sourceTree="<group>")
if (ROOT / "Config/BetaConnection.json").exists():
    refs["Config/BetaConnection.json"] = obj("beta-config", isa="PBXFileReference", lastKnownFileType="text.json", path="Config/BetaConnection.json", sourceTree="<group>")
products = []
targets = []
target_ids = {name: uid("target:" + name) for name in ["Context", "ContextTranslation", "ContextKeyboard", "ContextUITests", "LanguageBubbleMac"]}
product_refs = {}
shadkit_ref = obj("package:ShadKit", isa="XCRemoteSwiftPackageReference",
                  repositoryURL="https://github.com/jasonkneen/ShadKit.git",
                  requirement={"kind": "revision", "revision": "6dbefdeb72a276708b7ca748c71ac166c0f4f17d"})

def configs(name, settings):
    ids = []
    for mode in ["Debug", "Release"]:
        cfg = dict(settings)
        # Preserve the team selected in Xcode when regenerating the project.
        previous = existing_objects.get(uid(name + ":" + mode), {}).get("buildSettings", {})
        if previous.get("DEVELOPMENT_TEAM"):
            cfg["DEVELOPMENT_TEAM"] = previous["DEVELOPMENT_TEAM"]
        cfg["SWIFT_OPTIMIZATION_LEVEL"] = "-Onone" if mode == "Debug" else "-O"
        # Match Swift packages to the selected simulator architecture in Debug.
        # The Mac packaging script explicitly builds both architectures.
        cfg["ONLY_ACTIVE_ARCH"] = "YES" if mode == "Debug" else "NO"
        cfg["SWIFT_ACTIVE_COMPILATION_CONDITIONS"] = "DEBUG $(inherited)" if mode == "Debug" else "$(inherited)"
        if mode == "Release": cfg["EXCLUDED_SOURCE_FILE_NAMES"] = "BetaConnection.json $(inherited)"
        ids.append(obj(name + ":" + mode, isa="XCBuildConfiguration", baseConfigurationReference=config_ref, buildSettings=cfg, name=mode))
    return obj(name + ":configlist", isa="XCConfigurationList", buildConfigurations=ids, defaultConfigurationIsVisible=0, defaultConfigurationName="Release")


for name, folder, config_name, suffix, product_type in [
    ("Context", "App", "App", "", "com.apple.product-type.application"),
    ("ContextTranslation", "TranslationExtension", "Translation", ".translation", "com.apple.product-type.extensionkit-extension"),
    ("ContextKeyboard", "KeyboardExtension", "Keyboard", ".keyboard", "com.apple.product-type.app-extension"),
    ("ContextUITests", "Tests/UITests", None, ".uitests", "com.apple.product-type.bundle.ui-testing"),
    ("LanguageBubbleMac", "MacApp", "Mac", ".mac", "com.apple.product-type.application"),
]:
    ext = "app" if name in ["Context", "LanguageBubbleMac"] else "xctest" if name == "ContextUITests" else "appex"
    file_type = {"app": "wrapper.application", "xctest": "wrapper.cfbundle"}.get(ext,
        "wrapper.extensionkit-extension" if name == "ContextTranslation" else "wrapper.app-extension")
    product_refs[name] = obj(name + ":product", isa="PBXFileReference", explicitFileType=file_type, includeInIndex=0, path=name + "." + ext, sourceTree="BUILT_PRODUCTS_DIR")
    products.append(product_refs[name])
    source_refs = []
    for relative, ref in refs.items():
        if relative.endswith((".swift", ".metal")) and (relative.startswith(folder + "/") or (relative.startswith("Shared/") and name != "ContextUITests") or (relative.startswith("Client/") and name in ["Context", "LanguageBubbleMac"])):
            source_refs.append(obj(name + ":source:" + relative, isa="PBXBuildFile", fileRef=ref))
    phases = [obj(name + ":sources", isa="PBXSourcesBuildPhase", buildActionMask=2147483647, files=source_refs, runOnlyForDeploymentPostprocessing=0),
              obj(name + ":frameworks", isa="PBXFrameworksBuildPhase", buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)]
    resources = []
    if name in ["Context", "LanguageBubbleMac"]:
        resources.append(obj(name + ":localizations", isa="PBXBuildFile", fileRef=refs["Localizable.strings"]))
        resources.append(obj(name + ":licenses", isa="PBXBuildFile", fileRef=refs["Resources/ThirdPartyLicenses.txt"]))
        resources.append(obj(name + ":fonts", isa="PBXBuildFile", fileRef=refs["Resources/Fonts"]))
    if name == "LanguageBubbleMac":
        resources.append(obj(name + ":camera-study", isa="PBXBuildFile", fileRef=refs["Resources/CameraStudy"]))
    if config_name:
        resources.append(obj(name + ":privacy", isa="PBXBuildFile", fileRef=refs["Resources/PrivacyInfo.xcprivacy"]))
    if name in ["Context", "LanguageBubbleMac"] and "Resources/Assets.xcassets" in refs:
        resources.append(obj(name + ":assets", isa="PBXBuildFile", fileRef=refs["Resources/Assets.xcassets"]))
    if name in ["Context", "LanguageBubbleMac"] and "Config/BetaConnection.json" in refs:
        resources.append(obj(name + ":beta-config", isa="PBXBuildFile", fileRef=refs["Config/BetaConnection.json"]))
    phases.append(obj(name + ":resources", isa="PBXResourcesBuildPhase", buildActionMask=2147483647, files=resources, runOnlyForDeploymentPostprocessing=0))
    settings = {"PRODUCT_BUNDLE_IDENTIFIER": prefix + suffix, "PRODUCT_NAME": "$(TARGET_NAME)", "SWIFT_VERSION": "5.0", "TARGETED_DEVICE_FAMILY": "1,2", "CODE_SIGN_STYLE": "Automatic", "GENERATE_INFOPLIST_FILE": "NO", "SWIFT_EMIT_LOC_STRINGS": "YES", "SKIP_INSTALL": "NO" if name == "Context" else "YES"}
    if name == "LanguageBubbleMac":
        settings.update({"INFOPLIST_FILE": "Config/Mac-Info.plist", "PRODUCT_BUNDLE_IDENTIFIER": "com.jesselai.languagebubble.mac",
                         "EXECUTABLE_NAME": "LanguageBubble", "SDKROOT": "macosx", "SUPPORTED_PLATFORMS": "macosx",
                         "MACOSX_DEPLOYMENT_TARGET": "14.0", "TARGETED_DEVICE_FAMILY": "", "CODE_SIGN_IDENTITY": "-",
                         "CODE_SIGN_STYLE": "Manual", "SKIP_INSTALL": "NO", "ENABLE_APP_SANDBOX": "NO"})
    elif config_name:
        settings.update({"INFOPLIST_FILE": f"Config/{config_name}-Info.plist", "CODE_SIGN_ENTITLEMENTS": f"Config/{config_name}.entitlements"})
    else:
        settings.update({"GENERATE_INFOPLIST_FILE": "YES", "INFOPLIST_FILE": "Config/Tests-Info.plist", "TEST_TARGET_NAME": "Context"})
    if name in ["Context", "LanguageBubbleMac"]:
        settings["ASSETCATALOG_COMPILER_APPICON_NAME"] = "AppIcon"
    elif config_name and name != "LanguageBubbleMac":
        settings["APPLICATION_EXTENSION_API_ONLY"] = "YES"
        settings["LD_RUNPATH_SEARCH_PATHS"] = "$(inherited) @executable_path/Frameworks @executable_path/../../Frameworks"
    targets.append(obj("target:" + name, isa="PBXNativeTarget", buildConfigurationList=configs(name, settings), buildPhases=phases, buildRules=[], dependencies=[], name=name, productName=name, productReference=product_refs[name], productType=product_type))
    if name in ["Context", "LanguageBubbleMac"]:
        product = obj(name + ":ShadcnUI", isa="XCSwiftPackageProductDependency", package=shadkit_ref, productName="ShadcnUI")
        objects[target_ids[name]]["packageProductDependencies"] = [product]
        objects[uid(name + ":frameworks")]["files"].append(
            obj(name + ":ShadcnUI:link", isa="PBXBuildFile", productRef=product))

for child, dest, subfolder in [("ContextTranslation", "$(CONTENTS_FOLDER_PATH)/Extensions", 16), ("ContextKeyboard", "", 13)]:
    build_ref = obj(child + ":embed", isa="PBXBuildFile", fileRef=product_refs[child], settings={"ATTRIBUTES": ["RemoveHeadersOnCopy"]})
    phase = obj(child + ":copy", isa="PBXCopyFilesBuildPhase", buildActionMask=2147483647, dstPath=dest, dstSubfolderSpec=subfolder, files=[build_ref], name="Embed " + child, runOnlyForDeploymentPostprocessing=0)
    objects[target_ids["Context"]]["buildPhases"].append(phase)
    proxy = obj(child + ":proxy", isa="PBXContainerItemProxy", containerPortal=uid("project"), proxyType=1, remoteGlobalIDString=target_ids[child], remoteInfo=child)
    dep = obj(child + ":dependency", isa="PBXTargetDependency", target=target_ids[child], targetProxy=proxy)
    objects[target_ids["Context"]]["dependencies"].append(dep)

test_proxy = obj("test:proxy", isa="PBXContainerItemProxy", containerPortal=uid("project"), proxyType=1, remoteGlobalIDString=target_ids["Context"], remoteInfo="Context")
objects[target_ids["ContextUITests"]]["dependencies"].append(obj("test:dependency", isa="PBXTargetDependency", target=target_ids["Context"], targetProxy=test_proxy))
products_group = obj("products", isa="PBXGroup", children=products, name="Products", sourceTree="<group>")
main_group = obj("main", isa="PBXGroup", children=list(refs.values()) + [config_ref, products_group], sourceTree="<group>")
project = obj("project", isa="PBXProject", attributes={"BuildIndependentTargetsInParallel": True, "LastUpgradeCheck": "2640", "TargetAttributes": {target_ids["ContextUITests"]: {"TestTargetID": target_ids["Context"]}}}, buildConfigurationList=configs("project", {"IPHONEOS_DEPLOYMENT_TARGET": "18.4", "SDKROOT": "iphoneos", "CLANG_ENABLE_MODULES": "YES", "CLANG_ENABLE_OBJC_ARC": "YES", "ENABLE_USER_SCRIPT_SANDBOXING": "YES", "DEBUG_INFORMATION_FORMAT": "dwarf-with-dsym"}), compatibilityVersion="Xcode 15.0", developmentRegion="zh_CN", hasScannedForEncodings=0, knownRegions=["zh_CN", "zh-Hans", "en", "Base"], mainGroup=main_group, productRefGroup=products_group, projectDirPath="", projectRoot="", targets=targets)

objects[project]["packageReferences"] = [shadkit_ref]

def serialize(value, depth=0):
    if isinstance(value, dict):
        return "{\n" + "".join("\t" * (depth + 1) + json.dumps(str(k)) + " = " + serialize(v, depth + 1) + ";\n" for k, v in value.items()) + "\t" * depth + "}"
    if isinstance(value, list):
        return "(" + ", ".join(serialize(x, depth) for x in value) + ")"
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, int):
        return str(value)
    return json.dumps(value, ensure_ascii=False)

project_dir = ROOT / "Context.xcodeproj"
project_dir.mkdir(exist_ok=True)
(project_dir / "project.pbxproj").write_text("// !$*UTF8*$!\n" + serialize({"archiveVersion": 1, "classes": {}, "objectVersion": 60, "objects": objects, "rootObject": project}) + "\n")
scheme_dir = project_dir / "xcshareddata/xcschemes"
scheme_dir.mkdir(parents=True, exist_ok=True)
appref = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target_ids["Context"]}" BuildableName="Context.app" BlueprintName="Context" ReferencedContainer="container:Context.xcodeproj"/>'
testref = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target_ids["ContextUITests"]}" BuildableName="ContextUITests.xctest" BlueprintName="ContextUITests" ReferencedContainer="container:Context.xcodeproj"/>'
(scheme_dir / "Context.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="2640" version="1.3">
  <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{appref}</BuildActionEntry></BuildActionEntries></BuildAction>
  <TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO">{testref}</TestableReference></Testables></TestAction>
  <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{appref}</BuildableProductRunnable></LaunchAction>
  <ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{appref}</BuildableProductRunnable></ProfileAction>
  <AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''')
macref = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target_ids["LanguageBubbleMac"]}" BuildableName="LanguageBubbleMac.app" BlueprintName="LanguageBubbleMac" ReferencedContainer="container:Context.xcodeproj"/>'
(scheme_dir / "LanguageBubbleMac.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="2640" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{macref}</BuildActionEntry></BuildActionEntries></BuildAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{macref}</BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO"><BuildableProductRunnable runnableDebuggingMode="0">{macref}</BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''')
print(f"Generated Context.xcodeproj; bundle={prefix}; group={group}")
