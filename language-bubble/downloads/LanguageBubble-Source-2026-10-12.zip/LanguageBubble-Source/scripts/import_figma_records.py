#!/usr/bin/env python3
"""Import the explicitly requested Figma words into a stopped local app.

Dry-run by default. Originals are copied intact, changes are backed up, and
capture/image operations use the app's existing offline sync queue.
"""
import argparse
import copy
import json
import os
from pathlib import Path
import shutil
import time
import uuid

DESIGN_URL = "https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1470-2919"
ASSETS = Path(__file__).resolve().parents[1] / "design/record-workspace/assets"
WORDS = [
    ("Bubble", [("n.", "气泡，泡沫；经济泡沫；（欲表达的）一点感情；气泡框；泡状物；安全的地方（或位置）；泡螺"),
                ("v.", "冒泡，沸腾；发出冒泡的声音；忙碌，活跃；兴奋，激动；（情绪、感情等）涌动")]),
    ("Journey", [("n.", "旅行，旅程；历程，过程"), ("v.", "旅行")]),
    ("Resilient", [("adj.", "弹回的，有弹力的"), ("vt.", "构成，设计，定制，使适合")]),
    ("Frame", [("n.", "框，结构，体格"), ("vt.", "构成，设计，定制，使适合，陷害")]),
    ("Clarity", [("n.", "清楚，明晰；透明度；透明性；清晰性")]),
    ("Converge", [("vi.", "聚合，集中于一点"), ("vt.", "使集合")]),
    ("Misery", [("n.", "痛苦，悲悯，不幸，穷困")]),
    ("Setbacks", [("n.", "挫折，倒退；（建筑）建筑退让或阶梯式缩进")]),
    ("Transistor", [("n.", "晶体管；晶体管收音机（transistor radio）")]),
]
SCENES = [
    ("book", 244 / 214.3887176513672, 1.0183, 1.4487, -0.0022, 0.0032),
    ("bath", 189.1372833251953 / 137.90875244140625, 1.7384, 1.7037, -0.0134, -0.6958),
    ("feedback", 231.5612335205078 / 107.09356689453125, 2.2284, 1.3982, -0.6616, -0.1246),
]


def stable_id(key):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, DESIGN_URL + "/" + key))


def prepare(state, now):
    result = copy.deepcopy(state)
    copies, added = [], []
    existing = {c["source"].strip().lower() for c in state["captures"].values()
                if c.get("kind") == "translation" and not c.get("is_mock", False)}
    imported = set(result.get("imported_ids", []))
    for index, (word, groups) in enumerate(WORDS):
        # Existing entries and their dictionary/history are never rewritten.
        if word.lower() in existing and word != "Bubble":
            continue
        scenes = SCENES if word == "Bubble" else [None]
        dictionary = {"word": word, "phonetic": "", "language": "zh",
                      "groups": [{"pos": pos, "meanings": meanings.split("；")} for pos, meanings in groups],
                      "source": "Figma 设计稿", "url": DESIGN_URL, "license": "设计稿内容"}
        for scene_index, scene in enumerate(scenes):
            key = word.lower() + ("/" + scene[0] if scene else "")
            capture_id = stable_id("capture/" + key)
            if capture_id in result["captures"] or capture_id in imported:
                continue
            capture = {"id": capture_id, "kind": "translation", "source": word,
                       "result": groups[0][1], "explanation": "", "created_at": now - index - scene_index * 0.01,
                       "source_app": "Figma 设计稿", "source_url": DESIGN_URL,
                       "asset_ids": [], "is_mock": False, "source_language": "en", "target_language": "zh",
                       "dictionary": dictionary}
            if scene:
                name, aspect, width, height, x, y = scene
                asset_id = stable_id("asset/" + key)
                filename = asset_id + ".png"
                capture["asset_ids"] = [asset_id]
                copies.append((ASSETS / ("bubble-source-" + name + ".png"), filename))
                result.setdefault("images", []).append({"id": asset_id, "capture_id": capture_id, "file": filename})
                result.setdefault("scene_presentations", {})[asset_id] = {
                    "aspect_ratio": aspect, "image_width": width, "image_height": height, "image_x": x, "image_y": y}
            result["captures"][capture_id] = capture
            result.setdefault("outbox", []).append({"op_id": stable_id("operation/" + key),
                                                    "action": "capture.put", "entity_id": capture_id, "capture": capture})
            imported.add(capture_id)
            added.append(key)
    if any(key.startswith("bubble/") for key in added):
        result["favorite_records"] = sorted(set(result.get("favorite_records", [])) | {"translation:bubble"})
    result["imported_ids"] = sorted(imported)
    return result, copies, added


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.home() / "Library/Application Support/LanguageBubble")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    path = args.root / "state.json"
    original = path.read_bytes()
    state = json.loads(original)
    updated, copies, added = prepare(state, time.time())
    for source, _ in copies:
        if not source.is_file() or source.stat().st_size == 0:
            raise RuntimeError("Missing source asset: " + str(source))
    print("New records:", ", ".join(added) or "none; already imported")
    print("Original screenshots:", len(copies))
    if not args.apply or not added:
        return
    if path.read_bytes() != original:
        raise RuntimeError("App state changed; quit the app before importing")
    backup = args.root / ("state.before-figma-" + time.strftime("%Y%m%d-%H%M%S") + ".json")
    backup.write_bytes(original)
    backup.chmod(0o600)
    for source, filename in copies:
        destination = args.root / filename
        if destination.exists():
            if destination.read_bytes() != source.read_bytes():
                raise RuntimeError("Existing asset differs: " + filename)
        else:
            shutil.copyfile(source, destination)
            destination.chmod(0o600)
    temporary = args.root / "state.figma-import.tmp"
    temporary.write_text(json.dumps(updated, ensure_ascii=False, separators=(",", ":")))
    temporary.chmod(0o600)
    if path.read_bytes() != original:
        raise RuntimeError("App state changed; backup retained, import not committed")
    os.replace(temporary, path)
    print("Imported; backup:", backup)


if __name__ == "__main__":
    main()
