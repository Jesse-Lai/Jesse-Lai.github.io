#!/usr/bin/env python3
"""Apply the user's 12-word selection and 20 source-backed clippings.

Dry-run by default. Quit Language Bubble before --apply. Keep a private backup,
use normal capture.delete/put and image upload queues, and commit state atomically.
The selection applies to this snapshot only; future captures remain unrestricted.
"""
import argparse
import copy
import io
import json
import os
import re
import shutil
import subprocess
import time
import uuid
from pathlib import Path
from PIL import Image

BASE = Path(__file__).resolve().parents[1] / 'design/record-workspace/curated-20261011'
MANIFEST = BASE / 'manifest.json'
PROTECTED = {'journey', 'bubble'}

def stable_id(key):
    return str(uuid.uuid5(uuid.NAMESPACE_URL,'https://languagebubble.local/curated/2026-10-11/'+key))

def term(c):
    return ' '.join(c['source'].split()).lower()

def record_key(c):
    return (c['kind'], term(c) if c['kind']=='translation' else c['id'], c.get('is_mock',False))

def prepare(state, manifest):
    result=copy.deepcopy(state)
    keep=set(manifest['keep'])
    assert len(keep)==12 and PROTECTED<=keep
    assert {w['word'] for w in manifest['words']}==keep-PROTECTED
    retained={c['id'] for c in state['captures'].values()
              if term(c) in keep and c['kind']=='translation' and not c.get('is_mock',False)}
    assert {term(state['captures'][i]) for i in retained}==keep, 'A selected existing word is missing'
    removed=set(state['captures'])-retained
    result['captures']={i:c for i,c in result['captures'].items() if i in retained}
    result['outbox']=[o for o in result.get('outbox',[]) if o['entity_id'] not in removed]
    result['images']=[x for x in result.get('images',[]) if x['capture_id'] not in removed]
    imported=set(result.get('imported_ids',[]))|removed
    for i in sorted(removed):
        result['outbox'].append({'op_id':stable_id('delete/'+i),'action':'capture.delete','entity_id':i})
    if removed:result.pop('plan',None)
    removed_learning=set()
    for i,item in list(result.get('learning',{}).items()):
        ids=[x for x in item['capture_ids'] if x in retained]
        if not ids:
            del result['learning'][i];removed_learning.add(i)
        elif ids!=item['capture_ids']:
            item['capture_ids']=ids;capture=result['captures'][ids[0]]
            item['example']=capture.get('surrounding_text') or capture['source']
            item['explanation']=capture['explanation']
    result['reviews']={i:r for i,r in result.get('reviews',{}).items() if r['learning_id'] not in removed_learning}
    result['outbox']=[o for o in result['outbox'] if o['entity_id'] not in removed_learning
                      and o.get('review',{}).get('learning_id') not in removed_learning]
    result['articles']={i:a for i,a in result.get('articles',{}).items() if all(x in retained for x in a['capture_ids'])}
    result['context_meanings']={i:c for i,c in result.get('context_meanings',{}).items() if i in retained}
    result['favorite_records']=[k for k in result.get('favorite_records',[]) if k in {'translation:'+w for w in keep}]
    presentations=result.setdefault('scene_presentations',{})
    assets={a for c in result['captures'].values() for a in c.get('asset_ids',[])}
    presentations={i:p for i,p in presentations.items() if i in assets}
    result['scene_presentations']=presentations
    copies=[];added=[]
    for word in manifest['words']:
        name=word['word'];scenes=word['scenes'];assert 1<=len(scenes)<=3
        originals=[c for c in result['captures'].values() if term(c)==name]
        original=max(originals,key=lambda c:c['created_at'])
        new_assets={stable_id('asset/'+name+'/'+s['role']) for s in scenes}
        for c in originals:
            for asset in c.get('asset_ids',[]):
                if asset not in new_assets:
                    p=presentations.setdefault(asset,dict(aspect_ratio=1,image_width=1,image_height=1,image_x=0,image_y=0))
                    p['artwork']='superseded'
        for j,scene in enumerate(scenes):
            key=name+'/'+scene['role'];cid=stable_id('capture/'+key);aid=stable_id('asset/'+key)
            source=BASE/scene['file'];assert source.is_file(),source
            assert re.search(r'\b'+name+r'\b',scene['text'],re.I)
            if cid not in result['captures']:
                if cid in imported:raise ValueError('A curated source was deleted; refusing to restore it: '+key)
                c={k:copy.deepcopy(original[k]) for k in ('kind','source','result','explanation','source_language','target_language','dictionary') if k in original}
                c.update(id=cid,asset_ids=[aid],created_at=original['created_at']-.01*(j+1),is_mock=False,
                    source_app=scene['source_app'],source_url=scene['source_url'],surrounding_text=scene['text'])
                result['captures'][cid]=c
                result['outbox'].append(dict(op_id=stable_id('put/'+key),action='capture.put',entity_id=cid,capture=copy.deepcopy(c)))
                result['images'].append(dict(id=aid,capture_id=cid,file=aid+'.png'))
                imported.add(cid);added.append(key)
            copies.append((source,aid+'.png'))
            p=scene['placement']
            presentations[aid]=dict(aspect_ratio=p['width']/p['height'],image_width=1,image_height=1,image_x=0,image_y=0,
                artwork='curatedCutout',display_image_name=scene['display_image_name'],placement=p)
    result['imported_ids']=sorted(imported)
    assert len({record_key(c) for c in result['captures'].values()})==12
    # Regression guard: the two approved records and every one of their treatments stay byte-equivalent as JSON values.
    for i,c in state['captures'].items():
        if term(c) in PROTECTED:
            assert result['captures'][i]==c
            for aid in c.get('asset_ids',[]):assert presentations.get(aid)==state.get('scene_presentations',{}).get(aid)
    return result,copies,removed,added

def image_bytes(path):
    with Image.open(path) as im:
        output=io.BytesIO();im.save(output,format='PNG');return output.getvalue()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path.home()/'Library/Application Support/LanguageBubble')
    parser.add_argument('--apply',action='store_true')
    args=parser.parse_args();path=args.root/'state.json'
    original=path.read_bytes();state=json.loads(original);manifest=json.loads(MANIFEST.read_text())
    updated,copies,removed,added=prepare(state,manifest)
    print(json.dumps(dict(before_records=len({record_key(c) for c in state['captures'].values()}),after_records=12,
        removed_captures=len(removed),new_clippings=len(added),keep=manifest['keep']),ensure_ascii=False))
    if not args.apply or updated==state:return
    running=subprocess.run(['pgrep','-f','/Contents/MacOS/LanguageBubble'],capture_output=True,text=True)
    if running.returncode==0:raise RuntimeError('Quit Language Bubble before applying')
    if path.read_bytes()!=original:raise RuntimeError('State changed; rerun after quitting the app')
    # Validate every asset before any changes to the live state.
    prepared=[(name,image_bytes(source)) for source,name in copies]
    backup=args.root/('backup-before-curated-'+time.strftime('%Y%m%d-%H%M%S'));backup.mkdir(mode=0o700)
    (backup/'state.json').write_bytes(original);(backup/'state.json').chmod(0o600)
    for c in state['captures'].values():
        for a in c.get('asset_ids',[]):
            asset=args.root/(a+'.png')
            if asset.exists():shutil.copy2(asset,backup/asset.name)
    for name,data in prepared:
        destination=args.root/name
        if destination.exists() and destination.read_bytes()!=data:raise RuntimeError('Existing asset differs: '+name)
        destination.write_bytes(data);destination.chmod(0o600)
    temporary=args.root/'state.curated-import.tmp'
    temporary.write_text(json.dumps(updated,ensure_ascii=False,separators=(',',':')));temporary.chmod(0o600)
    if path.read_bytes()!=original:raise RuntimeError('State changed; backup kept, import not committed')
    os.replace(temporary,path)
    print('Applied. Private recovery backup:',backup)
    print('Normal sync queue:',len(updated['outbox']),'operations;',len(updated['images']),'image uploads')

if __name__=='__main__':main()
