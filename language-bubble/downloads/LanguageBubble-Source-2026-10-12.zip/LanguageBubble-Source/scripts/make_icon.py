"""Reproducible iOS and macOS app icons; Pillow is only needed to regenerate PNGs."""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

root = Path(__file__).resolve().parents[1] / "Resources/Assets.xcassets"
folder = root / "AppIcon.appiconset"
folder.mkdir(parents=True, exist_ok=True)
image = Image.new("RGB", (1024, 1024), "#285DD4")
draw = ImageDraw.Draw(image)
draw.rounded_rectangle((214, 206, 810, 728), radius=130, fill="#FFFFFF")
draw.polygon([(304, 660), (304, 834), (488, 682)], fill="#FFFFFF")
draw.rounded_rectangle((337, 355, 687, 403), radius=24, fill="#285DD4")
draw.rounded_rectangle((337, 484, 591, 532), radius=24, fill="#285DD4")
image.save(folder / "AppIcon.png")
images = [{"filename": "AppIcon.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"}]

# macOS does not apply the iOS icon mask. Inset the same artwork in a rounded
# tile with transparent margins so it sits at the native size in the Dock.
tile = image.resize((832, 832), Image.Resampling.LANCZOS).convert("RGBA")
mask = Image.new("L", tile.size, 0)
ImageDraw.Draw(mask).rounded_rectangle((0, 0, 831, 831), radius=185, fill=255)
tile.putalpha(mask)
shadow = Image.new("RGBA", image.size, (0, 0, 0, 0))
ImageDraw.Draw(shadow).rounded_rectangle((96, 108, 927, 939), radius=185, fill=(0, 0, 0, 45))
mac_image = shadow.filter(ImageFilter.GaussianBlur(12))
mac_image.alpha_composite(tile, (96, 96))
for size in (16, 32, 128, 256, 512):
    for scale in (1, 2):
        filename = f"AppIcon-mac-{size}@{scale}x.png"
        pixels = size * scale
        mac_image.resize((pixels, pixels), Image.Resampling.LANCZOS).save(folder / filename)
        images.append({"filename": filename, "idiom": "mac", "size": f"{size}x{size}", "scale": f"{scale}x"})

(folder / "Contents.json").write_text(json.dumps({"images": images, "info": {"author": "xcode", "version": 1}}, indent=2))
(root / "Contents.json").write_text(json.dumps({"info": {"author": "xcode", "version": 1}}))
