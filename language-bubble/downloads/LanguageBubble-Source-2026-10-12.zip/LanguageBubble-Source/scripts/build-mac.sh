#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
app_path="$PWD/build/Language Bubble.app"
signing_identity="${BUBBLE_SIGNING_IDENTITY:-}"
if [ -z "$signing_identity" ]; then
  # A stable development identity keeps macOS privacy grants valid across rebuilds.
  # Only choose automatically when there is exactly one eligible identity.
  identities=$(security find-identity -v -p codesigning | awk '/"Apple Development:/ { print $2 }')
  identity_count=$(printf '%s\n' "$identities" | awk 'NF { n++ } END { print n+0 }')
  if [ "$identity_count" -eq 1 ]; then signing_identity="$identities"; else signing_identity="-"; fi
fi
mkdir -p "$app_path/Contents/MacOS"
mkdir -p "$app_path/Contents/Resources"
cp -R Resources/en.lproj Resources/zh-Hans.lproj "$app_path/Contents/Resources/"
/usr/libexec/PlistBuddy -c 'Print' Config/Mac-Info.plist >/dev/null
cp Config/Mac-Info.plist "$app_path/Contents/Info.plist"
if [ -f Config/BetaConnection.json ]; then cp Config/BetaConnection.json "$app_path/Contents/Resources/BetaConnection.json"; fi
# Xcode resolves the pinned ShadKit package for both architectures.
xcodebuild -quiet -project Context.xcodeproj -scheme LanguageBubbleMac \
  -configuration Debug -destination 'generic/platform=macOS' \
  -derivedDataPath build/mac-derived ARCHS='arm64 x86_64' ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO build
ditto build/mac-derived/Build/Products/Debug/LanguageBubbleMac.app "$app_path"
for library in "$app_path"/Contents/MacOS/*.dylib; do
  if [ -f "$library" ]; then codesign --force --sign "$signing_identity" "$library"; fi
done
codesign --force --sign "$signing_identity" --identifier com.jesselai.languagebubble.mac "$app_path"
codesign --verify --deep --strict "$app_path"
if [ "$signing_identity" = "-" ]; then
  echo "Warning: ad hoc signing; privacy grants may need renewal after rebuilding. Set BUBBLE_SIGNING_IDENTITY to an Apple Development identity."
fi
echo "Built $app_path"
