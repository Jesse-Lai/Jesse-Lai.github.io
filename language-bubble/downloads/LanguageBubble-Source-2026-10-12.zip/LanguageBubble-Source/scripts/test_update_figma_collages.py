import copy
import unittest

from import_figma_records import prepare as prepare_words
from update_figma_collages import prepare, stable_id


class CollageImportTests(unittest.TestCase):
    def setUp(self):
        self.state, _, _ = prepare_words({"captures": {}, "outbox": [], "images": []}, 1000)

    def test_preserves_history_and_order_and_is_idempotent(self):
        before = copy.deepcopy(self.state)
        updated, copies, added = prepare(self.state)
        self.assertEqual(self.state, before)
        self.assertEqual(len(added), 4)
        self.assertEqual(len(copies), 4)
        for key, capture in before["captures"].items():
            self.assertEqual(updated["captures"][key], capture)
        self.assertEqual(updated["outbox"][:len(before["outbox"])], before["outbox"])
        self.assertLessEqual(max(c["created_at"] for c in updated["captures"].values()), 1000)
        again, files, new = prepare(updated)
        self.assertEqual(again, updated)
        self.assertEqual(files, [])
        self.assertEqual(new, [])

    def test_does_not_resurrect_deleted_artwork(self):
        updated, _, _ = prepare(self.state)
        deleted = stable_id("capture/journey/quote")
        del updated["captures"][deleted]
        again, files, added = prepare(updated)
        self.assertNotIn(deleted, again["captures"])
        self.assertEqual(files, [])
        self.assertEqual(added, [])

    def test_scoped_ticket_update_preserves_original_and_other_records(self):
        # Model an existing installation with the two older Journey cutouts.
        state, _, _ = prepare(self.state)
        ticket_id = stable_id("capture/journey/ticket")
        ticket_asset = stable_id("asset/journey/ticket")
        source = state["captures"].pop(ticket_id)
        source["id"] = "existing-user-capture"
        source["asset_ids"] = ["existing-user-image"]
        state["captures"][source["id"]] = source
        state["imported_ids"].remove(ticket_id)
        source["source_app"] = "Google Chrome"
        source["source_url"] = "https://www.journey.com/"
        del state["scene_presentations"][ticket_asset]
        ticket_asset = "existing-user-image"
        state["scene_presentations"]["unrelated"] = {"artwork": "bubblePost"}
        before = copy.deepcopy(state)
        updated, copies, added = prepare(state, "journey", ticket_asset)
        self.assertEqual(updated["captures"], before["captures"])
        self.assertEqual(updated["outbox"], before["outbox"])
        self.assertEqual(updated["images"], before["images"])
        self.assertEqual(copies, [])
        self.assertEqual(added, [])
        for asset, presentation in before["scene_presentations"].items():
            self.assertEqual(updated["scene_presentations"][asset], presentation)
        self.assertEqual(updated["scene_presentations"][ticket_asset]["display_image_name"], "JourneyTicketContent")
        self.assertEqual(prepare(updated, "journey", ticket_asset)[0], updated)
        self.assertEqual(prepare(updated, "journey")[0], updated)
        with self.assertRaises(ValueError):
            prepare(state, "journey", "missing")


if __name__ == "__main__":
    unittest.main()
