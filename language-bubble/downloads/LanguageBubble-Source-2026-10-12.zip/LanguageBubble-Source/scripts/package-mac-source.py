#!/usr/bin/env python3
"""Prepare a portable source snapshot; never package local credentials or data."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--output-dir", required=True, type=Path)
args = parser.parse_args()
output = args.output_dir.resolve()
stage = output / "LanguageBubble-Source"
stage.mkdir(parents=True, exist_ok=False)

excluded_parts = {".git", ".codex", ".agents", "node_modules", ".venv", ".build", "build",
                  "dist", "__pycache__", ".pytest_cache", ".local-data", "xcuserdata"}
excluded_names = {".DS_Store", "BetaConnection.json", "Local.xcconfig"}
excluded_suffixes = {".sqlite", ".sqlite3", ".db", ".p12", ".pem", ".key", ".mobileprovision", ".xcuserstate"}


def include(path):
    relative = path.relative_to(ROOT)
    return not (excluded_parts.intersection(relative.parts) or path.name in excluded_names
                or path.suffix in excluded_suffixes or path.name.endswith(("-wal", "-shm"))
                or (path.name.startswith(".env") and path.name != ".env.example"))


def copy(path):
    if not include(path):
        return
    if path.is_symlink():
        raise SystemExit(f"Unexpected symlink; inspect before packaging: {path.relative_to(ROOT)}")
    if path.is_dir():
        for child in sorted(path.iterdir()):
            copy(child)
    elif path.is_file():
        destination = stage / path.relative_to(ROOT)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)


for name in ["App", "Client", "Shared", "MacApp", "KeyboardExtension", "TranslationExtension",
             "Resources", "Tests", "Config", "Context.xcodeproj", "server", "scripts",
             "Package.swift", ".gitignore"]:
    copy(ROOT / name)
for path in (ROOT / "docs").glob("*.md"):
    if path.name not in {"OVERNIGHT_EXECUTION_PLAN.md"}:
        copy(path)
for path in (ROOT / "design").iterdir():
    if path.name != "serif-word-studio":
        copy(path)
# Include the compact browser motion references, but no node_modules or QA captures.
for path in (ROOT / "docs/prototypes").rglob("*"):
    if path.suffix in {".md", ".html", ".js", ".css", ".json", ".svg"} and include(path):
        copy(path)
shutil.copy2(ROOT / "README.md", stage / "docs/ORIGINAL_PROJECT_README.md")
shutil.copy2(ROOT / "docs/CODEX_HANDOFF.md", stage / "README.md")
(stage / "AGENTS.md").write_text(
    "# Language Bubble source handoff\n\n"
    "Read README.md and docs/CODEX_HANDOFF.md first. This is a native SwiftUI/AppKit macOS app.\n"
    "Use the LanguageBubbleMac scheme and scripts/build-mac.sh for macOS.\n"
    "Start with independent Mock configuration via scripts/setup-local-demo.py; keep local credentials private.\n"
    "Historical validation notes refer to the original author's machine, not this installation.\n"
    "The learning article preview is deterministic and in memory; distinguish it from the server AI pipeline.\n"
    "Preserve current native interactions and assets when making scoped changes.\n")

# Regenerate only the copied project: remove the reference to the excluded private config.
project = stage / "Context.xcodeproj/project.pbxproj"
project.write_text(re.sub(r'^\s*"DEVELOPMENT_TEAM" = .*?;\s*$', '', project.read_text(), flags=re.M))
subprocess.run(["python3", "scripts/generate_project.py"], cwd=stage, check=True, stdout=subprocess.DEVNULL)

# Fail closed if any real local credential was copied into a source file or asset.
secrets = []
local_env = ROOT / "server/.env"
if local_env.exists():
    for line in local_env.read_text().splitlines():
        key, sep, value = line.partition("=")
        value = value.strip().strip('\"\'')
        if sep and re.search(r"KEY|TOKEN|SECRET|PASSWORD", key) and len(value) >= 8:
            secrets.append(value.encode())
local_config = ROOT / "Config/BetaConnection.json"
if local_config.exists():
    secrets.extend(value.encode() for value in json.loads(local_config.read_text()).values()
                   if isinstance(value, str) and len(value) >= 8)
credential_pattern = re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bghp_[A-Za-z0-9]{30,}|\bsk-[A-Za-z0-9_-]{32,}")
files = sorted(path for path in stage.rglob("*") if path.is_file())
for path in files:
    data = path.read_bytes()
    if any(secret in data for secret in secrets) or credential_pattern.search(data):
        raise SystemExit(f"Credential scan failed: {path.relative_to(stage)} (value omitted)")
manifest = stage / "SOURCE_MANIFEST.sha256"
manifest.write_text("".join(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(stage)}\n" for path in files))
archive = output / "LanguageBubble-Source.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zip_file:
    for path in sorted(stage.rglob("*")):
        if path.is_file():
            zip_file.write(path, path.relative_to(output))
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(output / "LanguageBubble-Source.zip.sha256").write_text(f"{digest}  {archive.name}\n")
print(f"Source archive: {archive}")
print(f"Files: {len(files) + 1}; size: {archive.stat().st_size / 1024 / 1024:.1f} MiB")
print("Local credentials, private configuration, databases, Git history and build products excluded.")
