#!/usr/bin/env python3
"""Update the requested Bubble/Journey artwork in a stopped local app.

Dry-run by default. Keeps immutable captures, dictionaries, and original files;
new source screenshots use the existing offline sync queue.
"""
import argparse
import copy
import json
import os
from pathlib import Path
import shutil
import time
import uuid

from import_figma_records import stable_id as previous_id

ASSETS = Path(__file__).resolve().parents[1] / "design/record-workspace/assets/collages"
DESIGN = "https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id="
SCENES = [
    ("bubble", "post", "1487-7177", "bubblePost", 454.0155, 187.1214,
     406.5698, 146.6841, 23.72298, 16.83036),
    ("journey", "travel", "1487-7644", "journeyTravel", 358, 231.8104,
     370.4827, 232.5252, 0.443329, -0.515786),
    ("journey", "quote", "1487-7644", "journeyQuote", 358, 78.98591,
     367.2321 / 0.96894449, 163.1636, -0.51298, -13.855445),
    ("journey", "ticket", "1521-15891", "journeyTicket", 244, 147.2018738,
     241.4798126, 119.594368, 3.207552, 13.745315),
]


def stable_id(key):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, DESIGN + "1487-collages/" + key))


def prepare(state, word_filter=None, ticket_asset=None):
    result = copy.deepcopy(state)
    copies, added = [], []
    imported = set(result.get("imported_ids", []))
    presentations = result.setdefault("scene_presentations", {})
    if ticket_asset is None and word_filter != "bubble":
        ticket_asset = next((asset for asset, presentation in presentations.items()
                             if presentation.get("artwork") == "journeyTicket"
                             and presentation.get("display_image_name") == "JourneyTicketContent"
                             and any(asset in c.get("asset_ids", []) and c["source"].strip().lower() == "journey"
                                     for c in state["captures"].values())), None)
    ticket_capture = None
    if ticket_asset:
        ticket_capture = next((c for c in state["captures"].values()
                               if ticket_asset in c.get("asset_ids", [])
                               and c["source"].strip().lower() == "journey"), None)
        if ticket_capture is None or word_filter == "bubble":
            raise ValueError("Ticket asset must belong to the Journey record being updated")
    for word, name, node, artwork, width, height, iw, ih, ix, iy in SCENES:
        if word_filter is not None and word != word_filter:
            continue
        key = word + "/" + name
        capture_id, asset_id = stable_id("capture/" + key), stable_id("asset/" + key)
        if name == "ticket" and ticket_capture is not None:
            capture_id, asset_id = ticket_capture["id"], ticket_asset
        if capture_id not in result["captures"]:
            # Preserve user deletions on rerun.
            if capture_id in imported:
                continue
            originals = [c for c in state["captures"].values()
                         if c["source"].strip().lower() == word
                         and c.get("kind") == "translation" and not c.get("is_mock", False)]
            if not originals:
                raise ValueError("Missing existing word: " + word)
            original = max(originals, key=lambda c: c["created_at"])
            capture = {k: copy.deepcopy(original[k]) for k in (
                "kind", "source", "result", "explanation", "source_language", "target_language", "dictionary")
                       if k in original}
            capture.update(id=capture_id, created_at=original["created_at"] - 0.001 * (len(added) + 1),
                           source_app="Figma 设计稿", source_url=DESIGN + node,
                           asset_ids=[asset_id], is_mock=False)
            result["captures"][capture_id] = capture
            result.setdefault("outbox", []).append({"op_id": stable_id("operation/" + key),
                "action": "capture.put", "entity_id": capture_id, "capture": copy.deepcopy(capture)})
            filename = asset_id + ".png"
            result.setdefault("images", []).append({"id": asset_id, "capture_id": capture_id, "file": filename})
            copies.append((ASSETS / (word + "-" + name + ".png"), filename))
            imported.add(capture_id)
            added.append(key)
        presentations[asset_id] = dict(aspect_ratio=width / height,
            image_width=iw / width, image_height=ih / height, image_x=ix / width, image_y=iy / height,
            artwork=artwork)
        if name == "ticket" and ticket_capture is not None:
            # Reuse the explicitly selected source in the collage without modifying
            # its original screenshot, capture, timestamp, or sync operations.
            presentations[asset_id]["display_image_name"] = "JourneyTicketContent"

    book = previous_id("asset/bubble/book")
    if word_filter != "journey" and any(book in c.get("asset_ids", []) for c in result["captures"].values()):
        presentations[book] = dict(aspect_ratio=261.4119 / 250.2001,
            image_width=1 / 0.99303323, image_height=1 / 0.76035410,
            image_x=0.0001741054 / 0.99303323, image_y=-0.000784786 / 0.76035410,
            artwork="bubbleBook")
    # Hide the two superseded design samples from the showcase only.
    # They remain available in the record's source-history sheet.
    for name in ("bath", "feedback"):
        asset_id = previous_id("asset/bubble/" + name)
        if word_filter != "journey" and asset_id in presentations:
            presentations[asset_id]["artwork"] = "superseded"
    if imported != set(state.get("imported_ids", [])):
        result["imported_ids"] = sorted(imported)
    return result, copies, added


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.home() / "Library/Application Support/LanguageBubble")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--word", choices=("bubble", "journey"), help="Update only this word")
    parser.add_argument("--ticket-asset", help="Reuse this existing Journey source; keep its original for preview")
    args = parser.parse_args()
    path = args.root / "state.json"
    original = path.read_bytes()
    state = json.loads(original)
    updated, copies, added = prepare(state, args.word, args.ticket_asset)
    for source, _ in copies:
        if not source.is_file() or not source.stat().st_size:
            raise RuntimeError("Missing source image: " + str(source))
    print("New source screenshots:", ", ".join(added) or "none")
    print("Presentation changed:", state != updated)
    if not args.apply or state == updated:
        return
    if path.read_bytes() != original:
        raise RuntimeError("App state changed; quit the app before importing")
    backup = args.root / ("state.before-collages-" + time.strftime("%Y%m%d-%H%M%S") + ".json")
    backup.write_bytes(original)
    backup.chmod(0o600)
    for source, filename in copies:
        destination = args.root / filename
        if destination.exists():
            if destination.read_bytes() != source.read_bytes():
                raise RuntimeError("Existing source image differs: " + filename)
        else:
            shutil.copyfile(source, destination)
            destination.chmod(0o600)
    temporary = args.root / "state.collage-import.tmp"
    temporary.write_text(json.dumps(updated, ensure_ascii=False, separators=(",", ":")))
    temporary.chmod(0o600)
    if path.read_bytes() != original:
        raise RuntimeError("App state changed; backup retained, import not committed")
    os.replace(temporary, path)
    print("Updated collage artwork; backup:", backup)


if __name__ == "__main__":
    main()
