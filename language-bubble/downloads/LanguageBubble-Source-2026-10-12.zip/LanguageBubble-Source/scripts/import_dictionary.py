#!/usr/bin/env python3
"""Build the local ECDICT index from an upstream CSV; no runtime network requests."""
import argparse
import csv
import hashlib
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
REVISION = "bc015ed2e24a7abef49fc6dbbb7fe32c1dadaf8b"


def build(source: Path, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = destination.with_suffix(".importing.sqlite3")
    try:
        with sqlite3.connect(staging) as db:
            db.execute("DROP TABLE IF EXISTS entries")
            db.execute("CREATE TABLE entries(word TEXT PRIMARY KEY COLLATE NOCASE, phonetic TEXT NOT NULL, translation TEXT NOT NULL, definition TEXT NOT NULL)")
            with source.open(encoding="utf-8-sig", newline="") as stream:
                reader = csv.DictReader(stream)
                if not {"word", "phonetic", "translation", "definition"}.issubset(reader.fieldnames or []):
                    raise ValueError("Not an ECDICT CSV")
                db.executemany("INSERT OR REPLACE INTO entries VALUES(?,?,?,?)", (
                    (row["word"].strip(), row["phonetic"], row["translation"], row["definition"])
                    for row in reader if row["word"].strip()))
            count = db.execute("SELECT count(*) FROM entries").fetchone()[0]
            if not count:
                raise ValueError("Empty dictionary")
        staging.replace(destination)
    finally:
        staging.unlink(missing_ok=True)
    print(f"Imported {count:,} entries to {destination}")
    print(f"CSV SHA-256: {hashlib.sha256(source.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "server/.local-data/ecdict.sqlite3")
    args = parser.parse_args()
    build(args.csv, args.output)
