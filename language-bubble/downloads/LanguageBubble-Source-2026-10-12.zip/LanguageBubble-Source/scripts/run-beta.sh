#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../server"
bubble_host=127.0.0.1
bubble_background=false
bubble_stop=false
bubble_login=false
bubble_uninstall=false
for argument in "$@"; do
  case "$argument" in
    --lan) bubble_host=0.0.0.0 ;;
    --background) bubble_background=true ;;
    --login) bubble_background=true; bubble_login=true ;;
    --stop) bubble_stop=true ;;
    --uninstall) bubble_uninstall=true ;;
    *) echo "Usage: scripts/run-beta.sh [--lan] [--background | --login] | --stop | --uninstall"; exit 1 ;;
  esac
done
bubble_job="gui/$(id -u)/com.jesselai.languagebubble.beta-server"
if $bubble_stop || $bubble_uninstall; then
  if $bubble_background || [ "$bubble_host" != 127.0.0.1 ] || { $bubble_stop && $bubble_uninstall; }; then
    echo "Use --stop or --uninstall on its own."
    exit 1
  fi
  if launchctl print "$bubble_job" >/dev/null 2>&1; then
    bubble_pid=$(launchctl print "$bubble_job" | awk '$1 == "pid" && $2 == "=" { print $3; exit }')
    launchctl bootout "$bubble_job"
    # bootout can return while the old process is still shutting down. Wait before
    # reporting success so a following bootstrap cannot race the outgoing job.
    if [ -n "$bubble_pid" ]; then
      for ((bubble_attempt = 0; bubble_attempt < 100; bubble_attempt++)); do
        if ! kill -0 "$bubble_pid" 2>/dev/null; then break; fi
        sleep 0.1
      done
      if kill -0 "$bubble_pid" 2>/dev/null; then
        echo "Service is still shutting down. Wait before restarting it."
        exit 1
      fi
    fi
  fi
  if $bubble_uninstall; then
    /usr/bin/python3 - <<'PY'
from pathlib import Path
import plistlib

path = Path.home() / "Library/LaunchAgents/com.jesselai.languagebubble.beta-server.plist"
if path.exists():
    with path.open("rb") as file:
        if plistlib.load(file).get("Label") != "com.jesselai.languagebubble.beta-server":
            raise SystemExit("Unexpected login agent; left unchanged.")
    path.unlink()
print("Removed automatic login startup for the translation service.")
PY
  fi
  echo "Stopped the managed background translation service."
  exit 0
fi
if [ ! -x .venv/bin/python ] || [ ! -f .env ]; then
  echo "Read README.md to install server dependencies and create the private local configuration."
  exit 1
fi
if [ "$bubble_host" = 0.0.0.0 ]; then
  echo "LAN testing enabled on port 8788. Use this Mac's .local hostname on a trusted Wi-Fi."
fi
if $bubble_background; then
  # launchd owns the process, so closing the invoking terminal cannot stop it.
  # --background lasts until logout; --login also installs this job for future logins.
  if launchctl print "$bubble_job" >/dev/null 2>&1; then
    echo "Background service already registered. Use --stop before changing its options."
  else
    .venv/bin/python - "$bubble_host" <<'PY'
import os
from pathlib import Path
import plistlib
import socket
import sys

with socket.socket() as probe:
    if probe.connect_ex(("127.0.0.1", 8788)) == 0:
        raise SystemExit("Port 8788 is already in use. Leave the existing service running, or stop it from its own terminal first.")
root = Path.cwd()
output = root.parent / "build" / "beta-service"
output.mkdir(parents=True, exist_ok=True)
os.chmod(output, 0o700)
job = {
    "Label": "com.jesselai.languagebubble.beta-server",
    "ProgramArguments": [str(root / ".venv/bin/python"), "-m", "uvicorn", "main:app",
                         "--host", sys.argv[1], "--port", "8788", "--env-file", str(root / ".env"), "--no-access-log"],
    "WorkingDirectory": str(root),
    "RunAtLoad": True,
    "KeepAlive": True,
    "ThrottleInterval": 10,
    "StandardOutPath": str(output / "server.log"),
    "StandardErrorPath": str(output / "server.log"),
}
with (output / "service.plist").open("wb") as file:
    plistlib.dump(job, file)
PY
    launchctl bootstrap "gui/$(id -u)" "$PWD/../build/beta-service/service.plist"
  fi
  .venv/bin/python - <<'PY'
import json
import time
import urllib.request

opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
for _ in range(30):
    try:
        with opener.open("http://127.0.0.1:8788/health", timeout=1) as response:
            health = json.load(response)
        if health.get("status") == "ok" and health.get("ai_mode") in {"mock", "live"}:
            print(f"Background translation service ready: http://127.0.0.1:8788 ({health['ai_mode']}).")
            break
    except (OSError, ValueError):
        pass
    time.sleep(0.5)
else:
    raise SystemExit("Service is not ready. Check build/beta-service/server.log; stop with: bash scripts/run-beta.sh --stop")
PY
  if $bubble_login; then
    .venv/bin/python - <<'PY'
from pathlib import Path
import os
import plistlib

source = Path.cwd().parent / "build/beta-service/service.plist"
with source.open("rb") as file:
    job = plistlib.load(file)
if job.get("Label") != "com.jesselai.languagebubble.beta-server":
    raise SystemExit("Unexpected service configuration; login startup was not installed.")
directory = Path.home() / "Library/LaunchAgents"
directory.mkdir(parents=True, exist_ok=True)
destination = directory / "com.jesselai.languagebubble.beta-server.plist"
temporary = destination.with_suffix(".plist.tmp")
with temporary.open("wb") as file:
    plistlib.dump(job, file)
os.chmod(temporary, 0o600)
temporary.replace(destination)
print("Translation service will start automatically at login. Remove with: bash scripts/run-beta.sh --uninstall")
PY
  fi
  exit 0
fi
exec .venv/bin/python -m uvicorn main:app --host "$bubble_host" --port 8788 --env-file .env --no-access-log
