#!/usr/bin/env python3
"""Create independent local Mock credentials for a fresh source checkout."""
import json
import os
from pathlib import Path
import secrets


def main():
    root = Path(__file__).resolve().parents[1]
    env = root / "server/.env"
    config = root / "Config/BetaConnection.json"
    if env.exists() or config.exists():
        print("Existing local configuration found; nothing was changed. See README.md.")
        return
    token = secrets.token_urlsafe(32)
    template = (root / "server/.env.example").read_text()
    if "AI_MODE=mock" not in template or "CONTEXT_CLIENT_TOKEN=\n" not in template:
        raise SystemExit("Unexpected configuration template; nothing was changed.")
    env_text = template.replace("CONTEXT_CLIENT_TOKEN=\n", f"CONTEXT_CLIENT_TOKEN={token}\n", 1)
    config_text = json.dumps({"token": token}, indent=2) + "\n"
    for path, content in [(env, env_text), (config, config_text)]:
        with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w") as file:
            file.write(content)
    print("Created independent Mock configuration (permissions 0600); no model API key is required.")
    print("Next: python3 scripts/generate_project.py, then bash scripts/build-mac.sh")
    print("Keep server/.env and Config/BetaConnection.json private; do not share Debug app bundles.")


if __name__ == "__main__":
    main()
