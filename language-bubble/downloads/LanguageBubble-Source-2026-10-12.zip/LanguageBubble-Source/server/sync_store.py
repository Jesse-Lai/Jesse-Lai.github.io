"""Transactional, tenant-scoped local beta storage. Tokens and pairing codes are hashed."""
from __future__ import annotations

import hashlib
import json
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4, uuid5, NAMESPACE_URL

from fastapi import HTTPException
from learning_plan import default_profile, make_plan, pending_plan, live_plan, PROFILE_ID


def digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


class SyncStore:
    def __init__(self, directory: str, *, live_learning=False):
        self.live_learning = live_learning
        root = Path(directory).resolve()
        root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path = root / "bubble.sqlite3"
        with self.connection() as db:
            if db.execute("PRAGMA user_version").fetchone()[0] > 3:
                raise RuntimeError("Database is newer than this application")
            db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, epoch INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, user_id TEXT NOT NULL, token_hash TEXT UNIQUE NOT NULL, name TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS pairs(code_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires REAL NOT NULL, used INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS entities(user_id TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL, data TEXT, deleted INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id,kind,id));
            CREATE TABLE IF NOT EXISTS changes(seq INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL, data TEXT, deleted INTEGER NOT NULL);
            CREATE INDEX IF NOT EXISTS changes_user_seq ON changes(user_id,seq);
            CREATE TABLE IF NOT EXISTS operations(user_id TEXT NOT NULL, id TEXT NOT NULL, fingerprint TEXT NOT NULL, PRIMARY KEY(user_id,id));
            CREATE TABLE IF NOT EXISTS assets(user_id TEXT NOT NULL, id TEXT NOT NULL, capture_id TEXT NOT NULL, mime TEXT NOT NULL, hash TEXT NOT NULL, body BLOB NOT NULL, PRIMARY KEY(user_id,id));
            CREATE TABLE IF NOT EXISTS learning_jobs(user_id TEXT NOT NULL, capture_id TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id,capture_id));
            CREATE TABLE IF NOT EXISTS plan_jobs(user_id TEXT PRIMARY KEY, revision TEXT NOT NULL, fingerprint TEXT NOT NULL, snapshot TEXT NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, next_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS articles(user_id TEXT NOT NULL, id TEXT NOT NULL, generation_id TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY(user_id,id));
            PRAGMA user_version=3;
            """)
            db.execute("UPDATE plan_jobs SET status='pending',next_at=0 WHERE status='running'")
        self.path.chmod(0o600)

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def _device(self, db, user, name):
        token, device = secrets.token_urlsafe(32), str(uuid4())
        db.execute("INSERT INTO devices(id,user_id,token_hash,name) VALUES(?,?,?,?)", (device, user, digest(token), name))
        epoch = db.execute("SELECT epoch FROM users WHERE id=?", (user,)).fetchone()[0]
        return {"user_id": user, "device_id": device, "token": token, "epoch": epoch}

    def account(self, name):
        with self.connection() as db:
            user = str(uuid4())
            db.execute("INSERT INTO users(id) VALUES(?)", (user,))
            return self._device(db, user, name)

    def session(self, token):
        with self.connection() as db:
            row = db.execute("SELECT id,user_id,name FROM devices WHERE token_hash=? AND revoked=0", (digest(token),)).fetchone()
            return dict(row) if row else None

    def pair_code(self, user):
        code = secrets.token_hex(6).upper()
        expires = time.time() + 600
        with self.connection() as db:
            db.execute("DELETE FROM pairs WHERE expires<? OR (user_id=? AND used=0)", (time.time(), user))
            db.execute("INSERT INTO pairs(code_hash,user_id,expires) VALUES(?,?,?)", (digest(code), user, expires))
        return {"code": code, "expires_at": expires}

    def pair(self, code, name):
        with self.connection() as db:
            row = db.execute("SELECT * FROM pairs WHERE code_hash=? AND used=0 AND expires>?", (digest(code.strip().upper()), time.time())).fetchone()
            if not row:
                raise HTTPException(400, "Pairing code is invalid or expired")
            db.execute("UPDATE pairs SET used=1 WHERE code_hash=?", (row["code_hash"],))
            return self._device(db, row["user_id"], name)

    def revoke(self, device):
        with self.connection() as db:
            db.execute("UPDATE devices SET revoked=1 WHERE id=?", (device,))

    def entity(self, db, user, kind, identifier):
        return db.execute("SELECT * FROM entities WHERE user_id=? AND kind=? AND id=?", (user, kind, identifier)).fetchone()

    def put(self, db, user, kind, identifier, data=None, deleted=False):
        body = json.dumps(data, ensure_ascii=False, sort_keys=True) if data is not None else None
        if deleted:
            # Remove prior payloads too; retained change rows contain only deletion metadata.
            db.execute("UPDATE changes SET data=NULL,deleted=1 WHERE user_id=? AND kind=? AND id=?", (user, kind, identifier))
        db.execute("INSERT INTO entities VALUES(?,?,?,?,?) ON CONFLICT(user_id,kind,id) DO UPDATE SET data=excluded.data,deleted=excluded.deleted", (user, kind, identifier, body, int(deleted)))
        db.execute("INSERT INTO changes(user_id,kind,id,data,deleted) VALUES(?,?,?,?,?)", (user, kind, identifier, body, int(deleted)))

    def _learn(self, db, user, capture):
        if not capture["result"] or "暂无" in capture["result"]:
            return
        # Group identical expressions and meanings. No invented source context or model claims.
        key = " ".join(capture["source"].lower().split()) + "|" + capture["result"]
        identifier = str(uuid5(NAMESPACE_URL, user + key))
        old = self.entity(db, user, "learning", identifier)
        if old and not old["deleted"]:
            item = json.loads(old["data"])
            if capture["id"] not in item["capture_ids"]:
                item["capture_ids"].append(capture["id"])
        else:
            item = {"id": identifier, "term": capture["source"], "meaning": capture["result"],
                    "explanation": capture["explanation"], "capture_ids": [capture["id"]],
                    "example": capture.get("surrounding_text") or capture["source"], "example_source": "captured",
                    "is_mock": capture["is_mock"], "state": "unassessed", "successes": 0,
                    "reviews": 0, "due_at": time.time(), "interval_days": 0.0,
                    "last_review_at": None, "last_success_at": None, "paused": False}
        self.put(db, user, "learning", identifier, item)

    def _plan(self, db, user, force=False):
        profile = self.entity(db, user, "profile", PROFILE_ID)
        profile = json.loads(profile["data"]) if profile and not profile["deleted"] else default_profile()
        items = [json.loads(r["data"]) for r in db.execute("SELECT data FROM entities WHERE user_id=? AND kind='learning' AND deleted=0", (user,))]
        if not items or (self.live_learning and not any(not i["paused"] for i in items)):
            old = self.entity(db, user, "plan", "current")
            if old and not old["deleted"]: self.put(db, user, "plan", "current", deleted=True)
            db.execute("DELETE FROM plan_jobs WHERE user_id=?", (user,))
            return
        if self.live_learning:
            # A small, bounded evidence set prioritizes recent queries and weak recall.
            records = []
            for item in items:
                if item["paused"]: continue
                captures = [self.entity(db, user, "capture", i) for i in item["capture_ids"]]
                captures = [json.loads(c["data"]) for c in captures if c and not c["deleted"]]
                if not captures: continue
                capture = max(captures, key=lambda c: c["created_at"])
                records.append({"learning_id": item["id"], "capture_id": capture["id"], "text": capture["source"][:1500],
                    "meaning_or_correction": capture["result"][:1500], "kind": capture["kind"],
                    "explanation": capture["explanation"][:1000],
                    "original_context": (capture.get("surrounding_text") or capture["source"])[:3000],
                    "source_app": capture.get("source_app"), "source_is_mock": capture["is_mock"],
                    "reviews": item["reviews"], "successful_recalls": item["successes"],
                    "last_review_at": item["last_review_at"], "due_at": item["due_at"],
                    "captured_at": capture["created_at"]})
            records.sort(key=lambda r: (r["successful_recalls"], -r["captured_at"], r["learning_id"]))
            snapshot = {"profile": profile, "records": records[:6]}
            body = json.dumps(snapshot, sort_keys=True, ensure_ascii=False)
            fingerprint = digest(body)
            old = db.execute("SELECT * FROM plan_jobs WHERE user_id=?", (user,)).fetchone()
            if old and (old["fingerprint"] == fingerprint and (not force or old["status"] != "failed")):
                return
            revision = str(uuid4())
            db.execute("INSERT INTO plan_jobs VALUES(?,?,?,?,?,0,?) ON CONFLICT(user_id) DO UPDATE SET revision=excluded.revision, fingerprint=excluded.fingerprint, snapshot=excluded.snapshot, status='pending', attempts=0, next_at=excluded.next_at",
                       (user, revision, fingerprint, body, "pending", time.time() + 4))
            self.put(db, user, "plan", "current", pending_plan(profile))
            return
        self.put(db, user, "plan", "current", make_plan(profile, items, time.time()))

    def retry_plan(self, user):
        with self.connection() as db:
            self._plan(db, user, force=True)
        return {"queued": True}

    def claim_plan(self):
        with self.connection() as db:
            job = db.execute("SELECT * FROM plan_jobs WHERE status IN ('pending','running') AND next_at<=? ORDER BY next_at LIMIT 1", (time.time(),)).fetchone()
            if not job: return None
            # Expiring lease also recovers a transient database failure while saving an answer.
            db.execute("UPDATE plan_jobs SET status='running',next_at=? WHERE user_id=?", (time.time() + 90, job["user_id"]))
            return dict(job)

    def finish_plan(self, job, raw=None):
        with self.connection() as db:
            current = db.execute("SELECT * FROM plan_jobs WHERE user_id=? AND revision=? AND status='running'", (job["user_id"], job["revision"])).fetchone()
            # Changed goals, deleted evidence and clear-account operations supersede an in-flight answer.
            if not current: return False
            snapshot = json.loads(job["snapshot"])
            if raw is not None:
                plan = live_plan(raw, snapshot, job["revision"], time.time())
                self.put(db, job["user_id"], "plan", "current", plan)
                db.execute("UPDATE plan_jobs SET status='ready' WHERE user_id=?", (job["user_id"],))
            else:
                attempts = current["attempts"] + 1
                status = "failed" if attempts >= 3 else "pending"
                db.execute("UPDATE plan_jobs SET status=?,attempts=?,next_at=? WHERE user_id=?", (status, attempts, time.time() + 15 * attempts, job["user_id"]))
                self.put(db, job["user_id"], "plan", "current", pending_plan(snapshot["profile"], "failed" if status == "failed" else "retrying"))
            return True

    def process_jobs(self):
        with self.connection() as db:
            jobs = db.execute("SELECT * FROM learning_jobs WHERE status='pending' AND attempts<3 LIMIT 100").fetchall()
            for job in jobs:
                db.execute("SAVEPOINT learning_job")
                try:
                    row = self.entity(db, job["user_id"], "capture", job["capture_id"])
                    if row and not row["deleted"]:
                        self._learn(db, job["user_id"], json.loads(row["data"]))
                        self._plan(db, job["user_id"])
                    db.execute("UPDATE learning_jobs SET status='done' WHERE user_id=? AND capture_id=?", (job["user_id"], job["capture_id"]))
                    db.execute("RELEASE learning_job")
                except Exception:
                    db.execute("ROLLBACK TO learning_job")
                    db.execute("RELEASE learning_job")
                    db.execute("UPDATE learning_jobs SET attempts=attempts+1, status=CASE WHEN attempts>=2 THEN 'failed' ELSE 'pending' END WHERE user_id=? AND capture_id=?", (job["user_id"], job["capture_id"]))

    def _milestones(self, db, user):
        items = [json.loads(r["data"]) for r in db.execute("SELECT data FROM entities WHERE user_id=? AND kind='learning' AND deleted=0", (user,))]
        reviews = sum(i["reviews"] for i in items)
        stable = sum(i["state"] == "stable" for i in items)
        for key, achieved, title in [("first-review", reviews >= 1, "第一次主动回忆"), ("ten-reviews", reviews >= 10, "完成 10 次回忆"), ("first-stable", stable >= 1, "第一个较稳固的表达")]:
            identifier = str(uuid5(NAMESPACE_URL, user + ":milestone:" + key))
            if achieved and not self.entity(db, user, "milestone", identifier):
                self.put(db, user, "milestone", identifier, {"id": identifier, "title": title, "achieved_at": time.time(), "acknowledged": False})

    def _delete_capture(self, db, user, identifier):
        # Derived articles and conversations must not retain deleted source text.
        for row in db.execute("SELECT id,data FROM articles WHERE user_id=?", (user,)).fetchall():
            if identifier in json.loads(row["data"])["capture_ids"]:
                db.execute("DELETE FROM articles WHERE user_id=? AND id=?", (user, row["id"]))
        self.put(db, user, "capture", identifier, deleted=True)
        db.execute("DELETE FROM assets WHERE user_id=? AND capture_id=?", (user, identifier))
        db.execute("DELETE FROM learning_jobs WHERE user_id=? AND capture_id=?", (user, identifier))
        for row in db.execute("SELECT * FROM entities WHERE user_id=? AND kind='learning' AND deleted=0", (user,)).fetchall():
            item = json.loads(row["data"])
            if identifier not in item["capture_ids"]:
                continue
            item["capture_ids"].remove(identifier)
            if item["capture_ids"]:
                evidence = self.entity(db, user, "capture", item["capture_ids"][0])
                capture = json.loads(evidence["data"])
                item["example"] = capture.get("surrounding_text") or capture["source"]
                item["explanation"] = capture["explanation"]
                # Historical learning revisions must not retain the deleted scene.
                for revision in db.execute("SELECT seq,data FROM changes WHERE user_id=? AND kind='learning' AND id=? AND deleted=0", (user, row["id"])).fetchall():
                    prior = json.loads(revision["data"])
                    prior["capture_ids"] = [i for i in prior["capture_ids"] if i != identifier]
                    prior["example"] = item["example"]
                    prior["explanation"] = item["explanation"]
                    db.execute("UPDATE changes SET data=? WHERE seq=?", (json.dumps(prior, ensure_ascii=False), revision["seq"]))
                self.put(db, user, "learning", row["id"], item)
            else:
                self.put(db, user, "learning", row["id"], deleted=True)
                for review in db.execute("SELECT * FROM entities WHERE user_id=? AND kind='review' AND deleted=0", (user,)).fetchall():
                    if json.loads(review["data"])["learning_id"] == row["id"]:
                        self.put(db, user, "review", review["id"], deleted=True)
        # Plans contain original source excerpts; scrub their history and regenerate.
        self.put(db, user, "plan", "current", deleted=True)
        db.execute("DELETE FROM plan_jobs WHERE user_id=?", (user,))
        self._plan(db, user)

    def push(self, user, epoch, operations):
        with self.connection() as db:
            current_epoch = db.execute("SELECT epoch FROM users WHERE id=?", (user,)).fetchone()[0]
            if epoch != current_epoch:
                raise HTTPException(409, "Account was cleared; pull before retrying")
            for op in operations:
                fingerprint = digest(json.dumps(op, sort_keys=True, ensure_ascii=False))
                previous = db.execute("SELECT fingerprint FROM operations WHERE user_id=? AND id=?", (user, op["op_id"])).fetchone()
                if previous:
                    if previous[0] != fingerprint:
                        raise HTTPException(409, "Operation ID cannot be reused with different content")
                    continue
                action, identifier = op["action"], op["entity_id"]
                if action == "capture.put":
                    existing = self.entity(db, user, "capture", identifier)
                    # Captures are immutable. A tombstone always wins, including offline retries.
                    if not existing:
                        capture = op["capture"]
                        for asset in capture["asset_ids"]:
                            if not db.execute("SELECT 1 FROM assets WHERE user_id=? AND id=? AND capture_id=?", (user, asset, identifier)).fetchone():
                                raise HTTPException(422, "Attachment is missing or belongs to another capture")
                        self.put(db, user, "capture", identifier, capture)
                        db.execute("INSERT OR IGNORE INTO learning_jobs(user_id,capture_id) VALUES(?,?)", (user, identifier))
                elif action == "capture.delete":
                    self._delete_capture(db, user, identifier)
                elif action == "review.put":
                    review = op["review"]
                    target = self.entity(db, user, "learning", review["learning_id"])
                    if target and not target["deleted"] and not self.entity(db, user, "review", identifier):
                        item = json.loads(target["data"])
                        now = time.time()
                        review["reviewed_at"] = now
                        item["reviews"] += 1
                        rating = review["rating"]
                        if rating == "again":
                            item["successes"] = 0
                            interval = 10 / 1440
                        elif rating == "hard":
                            item["successes"] = max(0, item["successes"] - 1)
                            interval = max(0.5, item["interval_days"] * 1.2)
                        else:
                            # Repeated taps on the same day are not multi-day mastery evidence.
                            if not item["last_success_at"] or now - item["last_success_at"] >= 43200:
                                item["successes"] += 1
                                item["last_success_at"] = now
                                interval = min(180, max(1, item["interval_days"] * (2.5 if rating == "easy" else 2)))
                            else:
                                interval = item["interval_days"]
                        item.update(state="stable" if item["successes"] >= 3 else "learning",
                                    interval_days=interval, due_at=now + interval * 86400, last_review_at=now)
                        self.put(db, user, "review", identifier, review)
                        self.put(db, user, "learning", item["id"], item)
                        self._milestones(db, user)
                        self._plan(db, user)
                elif action == "learning.pause":
                    target = self.entity(db, user, "learning", identifier)
                    if target and not target["deleted"]:
                        item = json.loads(target["data"])
                        item["paused"] = op["paused"]
                        self.put(db, user, "learning", identifier, item)
                        self._plan(db, user)
                elif action == "profile.put":
                    self.put(db, user, "profile", PROFILE_ID, op["profile"])
                    self._plan(db, user)
                elif action == "milestone.ack":
                    target = self.entity(db, user, "milestone", identifier)
                    if target and not target["deleted"]:
                        value = json.loads(target["data"]); value["acknowledged"] = True
                        self.put(db, user, "milestone", identifier, value)
                db.execute("INSERT INTO operations VALUES(?,?,?)", (user, op["op_id"], fingerprint))
        self.process_jobs()
        return {"accepted": [op["op_id"] for op in operations]}

    def pull(self, user, cursor, limit=300):
        with self.connection() as db:
            epoch = db.execute("SELECT epoch FROM users WHERE id=?", (user,)).fetchone()[0]
            rows = db.execute("SELECT * FROM changes WHERE user_id=? AND seq>? ORDER BY seq LIMIT ?", (user, cursor, limit + 1)).fetchall()
            page = rows[:limit]
            return {"epoch": epoch, "cursor": page[-1]["seq"] if page else cursor, "has_more": len(rows) > limit,
                    "changes": [{"seq": r["seq"], "kind": r["kind"], "id": r["id"],
                                 "deleted": bool(r["deleted"]), "data": json.loads(r["data"]) if r["data"] else None} for r in page]}

    def clear(self, user):
        with self.connection() as db:
            for row in db.execute("SELECT kind,id FROM entities WHERE user_id=? AND deleted=0", (user,)).fetchall():
                self.put(db, user, row["kind"], row["id"], deleted=True)
            db.execute("DELETE FROM assets WHERE user_id=?", (user,))
            db.execute("DELETE FROM learning_jobs WHERE user_id=?", (user,))
            db.execute("DELETE FROM plan_jobs WHERE user_id=?", (user,))
            db.execute("UPDATE users SET epoch=epoch+1 WHERE id=?", (user,))
            db.execute("DELETE FROM articles WHERE user_id=?", (user,))
        return {"cleared": True}

    def upload(self, user, identifier, capture_id, mime, body):
        checksum = hashlib.sha256(body).hexdigest()
        with self.connection() as db:
            capture = self.entity(db, user, "capture", capture_id)
            if capture:
                raise HTTPException(409, "Upload attachments before creating the capture")
            old = db.execute("SELECT hash,capture_id FROM assets WHERE user_id=? AND id=?", (user, identifier)).fetchone()
            if old and (old["hash"] != checksum or old["capture_id"] != capture_id):
                raise HTTPException(409, "Attachment ID conflict")
            total = db.execute("SELECT COALESCE(SUM(length(body)),0) FROM assets WHERE user_id=?", (user,)).fetchone()[0]
            if not old and total + len(body) > 256 * 1024 * 1024:
                raise HTTPException(413, "Local beta attachment quota reached")
            db.execute("INSERT OR IGNORE INTO assets VALUES(?,?,?,?,?,?)", (user, identifier, capture_id, mime, checksum, body))
        return {"id": identifier, "sha256": checksum}

    def asset(self, user, identifier):
        with self.connection() as db:
            row = db.execute("SELECT * FROM assets WHERE user_id=? AND id=?", (user, identifier)).fetchone()
            capture = self.entity(db, user, "capture", row["capture_id"]) if row else None
            if not row or not capture or capture["deleted"] or identifier not in json.loads(capture["data"])["asset_ids"]:
                raise HTTPException(404, "Attachment not found")
            return row["mime"], row["body"]
