"""Explicit real-model learning smoke, using synthetic records and isolated sessions."""
import asyncio
import json
import os
from pathlib import Path
import time
from uuid import uuid4
import httpx
from dotenv import load_dotenv

async def main():
    load_dotenv(Path(__file__).with_name('.env'))
    async with httpx.AsyncClient(base_url='http://127.0.0.1:8788', timeout=65) as client:
        async def call(method, path, token=None, **kwargs):
            r = await client.request(method, path, headers={'Authorization': 'Bearer ' + token} if token else {}, **kwargs)
            assert r.status_code == 200, f'{path}: HTTP {r.status_code}'
            return r.json()
        assert (await call('GET', '/health'))['ai_mode'] == 'live'
        first = await call('POST', '/v2/accounts', os.environ['CONTEXT_CLIENT_TOKEN'], json={'device_name': 'AI learning smoke Mac'})
        code = (await call('POST', '/v2/pair-codes', first['token']))['code']
        second = await call('POST', '/v2/pair', json={'code': code, 'device_name': 'AI learning smoke iPhone'})
        started = time.monotonic()
        try:
            text = 'Could you walk me through the launch plan?'
            translation = await call('POST', '/v1/translate', first['token'], json={'text': text, 'request_id': str(uuid4()), 'target_language': 'zh'})
            sentence = "She don't like coffee."
            checked = await call('POST', '/v1/check', first['token'], json={'text': sentence, 'request_id': str(uuid4())})
            issue = checked['issues'][0]
            captures = [
                dict(id=str(uuid4()), kind='translation', source=text, result=translation['translation'], explanation=translation['explanation'],
                     surrounding_text='At the project kickoff, I asked: Could you walk me through the launch plan?', source_app='Synthetic meeting note', is_mock=False, created_at=time.time()),
                dict(id=str(uuid4()), kind='writing', source=sentence, result=sentence.replace(issue['original'], issue['replacement']),
                     explanation=issue['explanation'], original_span=issue['original'], replacement=issue['replacement'],
                     source_app='Synthetic composer', is_mock=False, created_at=time.time())]
            profile = {'id': '00000000-0000-0000-0000-000000000001', 'goal': 'work', 'daily_minutes': 10, 'primary_language': 'zh', 'secondary_language': 'en'}
            ops = [{'op_id': str(uuid4()), 'action': 'profile.put', 'entity_id': profile['id'], 'profile': profile}]
            ops += [{'op_id': str(uuid4()), 'action': 'capture.put', 'entity_id': c['id'], 'capture': c} for c in captures]
            await call('POST', '/v2/sync/push', first['token'], json={'epoch': 0, 'operations': ops})
            plan = None
            for _ in range(45):
                page = await call('GET', '/v2/sync/pull', second['token'])
                plans = [c['data'] for c in page['changes'] if c['kind'] == 'plan' and not c['deleted']]
                plan = plans[-1] if plans else None
                if plan and plan.get('status') == 'ready': break
                assert not plan or plan.get('status') != 'failed', 'Learning generation failed'
                await asyncio.sleep(2)
            assert plan and plan.get('status') == 'ready', 'Learning did not finish in time'
            assert not plan['is_mock'] and plan['goal'] == 'work'
            assert {t['skill'] for t in plan['tasks']} == {'reading', 'listening', 'speaking', 'writing'}
            ids = {c['id'] for c in page['changes'] if c['kind'] == 'learning' and not c['deleted']}
            assert all(t['learning_id'] in ids and t['material_source'] == 'generated' for t in plan['tasks'])
            mac_page = await call('GET', '/v2/sync/pull', first['token'])
            assert [c['data'] for c in mac_page['changes'] if c['kind'] == 'plan' and not c['deleted']][-1] == plan
            review_id = str(uuid4())
            await call('POST', '/v2/sync/push', second['token'], json={'epoch': 0, 'operations': [
                {'op_id': str(uuid4()), 'entity_id': review_id, 'action': 'review.put',
                 'review': {'id': review_id, 'learning_id': plan['tasks'][0]['learning_id'], 'rating': 'good'}}]})
            returned = await call('GET', '/v2/sync/pull', first['token'])
            assert any(c['id'] == review_id and c['kind'] == 'review' for c in returned['changes'])
            print(json.dumps({'ok': True, 'real_ai_tasks': len(plan['tasks']), 'goal': plan['goal'], 'title': plan['title'],
                'reason': plan['explanation'], 'tasks': plan['tasks'], 'same_plan_on_two_sessions': True, 'review_returned': True,
                'elapsed_seconds': round(time.monotonic()-started, 1)}, ensure_ascii=False))
        finally:
            await call('POST', '/v2/clear', first['token'])
            await call('POST', '/v2/logout', first['token'])
            await call('POST', '/v2/logout', second['token'])

if __name__ == '__main__':
    try: asyncio.run(main())
    except (AssertionError, httpx.HTTPError, KeyError) as error:
        print(json.dumps({'ok': False, 'error': str(error) if isinstance(error, AssertionError) else type(error).__name__}))
        raise SystemExit(1) from None
