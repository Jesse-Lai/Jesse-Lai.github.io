"""Deterministic, explicitly labeled fixtures. This provider has no network client."""
from __future__ import annotations

from copy import deepcopy


LABEL = "[AI Mock · 测试数据] "
TRANSLATIONS = {
    "it is a work in progress.": ("这件事还在完善中。", "work in progress 指尚未完成、仍在推进的工作。"),
    "it's a work in progress.": ("这件事还在完善中。", "work in progress 指尚未完成、仍在推进的工作。"),
    "work in progress": ("进行中的工作；尚在完善的事物", "这是固定测试样例，具体含义需要结合原句。"),
    "products": ("产品；商品", "product 的复数形式，具体含义需要结合原句。"),
    "that makes sense.": ("有道理；说得通。", "用于表示理解或认同对方的解释。"),
    "i agree with you.": ("我同意你的看法。", "agree with someone 表示同意某人的观点。"),
    "hola": ("你好", "西班牙语问候语。"),
    "olá": ("你好", "葡萄牙语问候语。"),
    "bonjour": ("你好；早上好", "法语问候语。"),
    "guten tag": ("你好；日安", "德语问候语。"),
    "こんにちは": ("你好", "日语日间问候语。"),
    "안녕하세요": ("你好", "韩语礼貌问候语。"),
}
GREETINGS = {"en": "Hello", "zh": "你好", "es": "Hola", "pt": "Olá", "fr": "Bonjour", "de": "Guten Tag", "ja": "こんにちは", "ko": "안녕하세요"}
CHECKS = {
    "i am agree with you.": {
        "original": "am agree", "replacement": "agree", "category": "grammar",
        "explanation": LABEL + "agree 本身是动词，这里不需要 am。", "confidence": 0.99,
    },
    "i look forward to hear from you.": {
        "original": "to hear", "replacement": "to hearing", "category": "collocation",
        "explanation": LABEL + "look forward to 中的 to 是介词，后面接 -ing 形式。", "confidence": 0.99,
    },
}
CORRECT = {"i agree with you.", "i look forward to hearing from you."}


class MockProvider:
    mode = "mock"

    async def close(self) -> None:
        pass

    async def generate(self, mode: str, text: str, target_language: str = "zh", context: str | None = None) -> dict:
        normalized = " ".join(text.strip().replace("’", "'").lower().split())
        if mode == "translate":
            if normalized in {s.lower() for s in GREETINGS.values()}:
                return {"translation": GREETINGS[target_language], "explanation": LABEL + "多语言问候语固定样例；不代表真实模型语言质量。"}
            value = TRANSLATIONS.get(normalized) if target_language == "zh" else None
            if value:
                return {"translation": value[0], "explanation": LABEL + value[1]}
            return {"translation": "AI Mock：此输入暂无翻译样例。",
                    "explanation": LABEL + "未调用真实模型。可试用：It is a work in progress. / products / That makes sense."}
        if mode == "check":
            issue = deepcopy(CHECKS.get(normalized))
            # Return the exact source span so normal client safety checks still apply.
            if issue:
                start = text.lower().find(issue["original"])
                if start >= 0:
                    issue["original"] = text[start:start + len(issue["original"])]
                    return {"complete": True, "issues": [issue]}
            return {"complete": normalized in CORRECT, "issues": []}
        if mode == "polish":
            examples = {
                "recieve": ("receive", "纠正单词拼写。"),
                "i am agree with you.": ("I agree with you.", "agree 是动词，不需要 am。"),
                "she go to school everyday.": ("She goes to school every day.", "修正主谓一致，并用 every day 表示每天。"),
                "我以经完成了。": ("我已经完成了。", "将错别字「以经」改为「已经」。"),
                "i agree with you.": ("I agree with you.", "这句话已经正确，无需修改。"),
            }
            value = examples.get(normalized)
            return {"polished": value[0] if value else text,
                    "explanation": LABEL + (value[1] if value else "暂无润色样例，原文未改动；未调用真实模型。")}
        raise ValueError("Unsupported mock operation")
