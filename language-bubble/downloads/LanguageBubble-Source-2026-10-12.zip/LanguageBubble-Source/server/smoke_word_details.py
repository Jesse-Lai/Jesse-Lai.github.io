"""Read-only smoke check against the configured local proxy; creates no captures."""
import json
import os
from pathlib import Path
from uuid import uuid4

import httpx
from dotenv import load_dotenv

load_dotenv(Path(__file__).with_name(".env"))
with httpx.Client(base_url="http://127.0.0.1:8788", timeout=90,
                  headers={"Authorization": "Bearer " + os.environ["CONTEXT_CLIENT_TOKEN"]}) as client:
    for word in ["dilute", "Frame"]:
        result = client.post("/v1/dictionary", json={"text": word})
        result.raise_for_status()
        entry = result.json()["entry"]
        assert entry and len(entry["groups"]) >= 2
        print(json.dumps(entry, ensure_ascii=False))
    result = client.post("/v1/translate", json={"text": "Frame", "request_id": str(uuid4()),
        "surrounding_text": "Frame 3", "source_app": "Figma", "target_language": "zh"})
    result.raise_for_status()
    body = result.json()
    assert body.get("context_meaning") and body.get("dictionary")
    print(json.dumps({"translation": body["translation"], "context_meaning": body["context_meaning"]}, ensure_ascii=False))
