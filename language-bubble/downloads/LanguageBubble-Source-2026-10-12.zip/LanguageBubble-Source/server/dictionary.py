"""Read-only ECDICT lookup. Import once with scripts/import_dictionary.py."""
from __future__ import annotations

import os
from pathlib import Path
import re
import sqlite3

from pydantic import BaseModel, ConfigDict, Field


class DictionaryGroup(BaseModel):
    model_config = ConfigDict(extra="forbid")
    pos: str = Field(max_length=40)
    meanings: list[str] = Field(min_length=1, max_length=200)


class DictionaryEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")
    word: str = Field(max_length=200)
    phonetic: str = Field(max_length=400)
    language: str = Field(max_length=20)
    groups: list[DictionaryGroup] = Field(min_length=1, max_length=40)
    source: str
    url: str
    license: str


class ContextMeaning(BaseModel):
    model_config = ConfigDict(extra="forbid")
    pos: str = Field(max_length=40)
    meaning: str = Field(min_length=1, max_length=1000)
    explanation: str = Field(max_length=2000)


# Match the dictionary's actual labels, including combined vt. & vi. labels.
_POS = r"(?:vt|vi|v|n|adj|adv|a|ad|prep|pron|conj|interj|int|aux|num|art|det|abbr|pl)\."
_LABEL = re.compile(rf"^\s*({_POS}(?:\s*(?:&|/|and)\s*{_POS})*)\s*", re.I)
_ALIASES = {"a.": "adj.", "ad.": "adv.", "int.": "interj."}


def parse_groups(value: str) -> list[dict]:
    """Preserve every sense, including unlabeled domain notes and continuation lines."""
    groups: dict[str, list[str]] = {}
    current = ""
    for line in value.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n").splitlines():
        line = line.strip()
        if not line:
            continue
        match = _LABEL.match(line)
        if match:
            current = re.sub(r"\s+", " ", match[1].lower())
            current = _ALIASES.get(current, current)
            line = line[match.end():].strip()
        elif line.startswith(("[", "【")):
            # A domain note is not necessarily the preceding verb's sense.
            current = ""
        if line and line not in groups.setdefault(current, []):
            groups[current].append(line)
    return [{"pos": pos, "meanings": meanings} for pos, meanings in groups.items() if meanings]


def dictionary_path() -> Path:
    return Path(os.environ.get("ECDICT_PATH", Path(__file__).parent / ".local-data" / "ecdict.sqlite3"))


def lookup(text: str, language: str = "zh") -> dict:
    word = " ".join(text.strip().split()).lower()
    if language not in {"zh", "en"} or not re.fullmatch(r"[a-z][a-z '\-]{0,99}", word):
        return {"status": "unsupported", "entry": None}
    path = dictionary_path()
    if not path.is_file():
        return {"status": "unavailable", "entry": None}
    try:
        with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as db:
            db.row_factory = sqlite3.Row
            row = db.execute("SELECT word,phonetic,translation,definition FROM entries WHERE word=? COLLATE NOCASE", (word,)).fetchone()
        if not row:
            return {"status": "not_found", "entry": None}
        groups = parse_groups(row["translation"] if language == "zh" else row["definition"])
        if not groups:
            return {"status": "not_found", "entry": None}
        entry = DictionaryEntry(word=row["word"], phonetic=row["phonetic"], language=language, groups=groups,
                                source="ECDICT", url="https://github.com/skywind3000/ECDICT", license="MIT")
        return {"status": "found", "entry": entry.model_dump()}
    except (sqlite3.Error, ValueError):
        # A missing/corrupt optional dictionary must not break translation.
        return {"status": "unavailable", "entry": None}
