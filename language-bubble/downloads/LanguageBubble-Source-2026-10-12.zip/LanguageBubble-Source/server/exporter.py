"""Private exports using only the standard library. No client tokens or account IDs."""
import csv
import hashlib
import html
import io
import json
import re
import sqlite3
import tempfile
import time
import zipfile
from pathlib import Path


def filter_items(items, state, now):
    return [i for i in items if state == "all" or
            (state == "paused" and i["paused"]) or
            (not i["paused"] and (state == "due" and i["state"] != "unassessed" and i["due_at"] <= now or
                                  state == i["state"] and (state == "unassessed" or i["due_at"] > now)))]


def csv_cell(value):
    value = str(value or "")
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value


def export(items, captures, format):
    rows = []
    for item in items:
        contexts = [captures[i] for i in item["capture_ids"] if i in captures]
        rows.append([item["term"], item["meaning"], item["example"],
                     "\n".join(c.get("source_url") or "" for c in contexts).strip(), item["explanation"], "AI Mock" if item["is_mock"] else ""])
    if format == "txt":
        # The target vocabulary format accepts English single words, not phrases.
        return ("\n".join(dict.fromkeys(r[0] for r in rows if re.fullmatch(r"[A-Za-z]+(?:['-][A-Za-z]+)*", r[0]))) + "\n").encode(), "text/plain; charset=utf-8"
    if format == "csv":
        stream = io.StringIO(newline="")
        writer = csv.writer(stream)
        writer.writerow(["expression", "meaning", "original_context", "source_url", "explanation", "ai_mode"])
        writer.writerows([[csv_cell(c) for c in row] for row in rows])
        return ("\ufeff" + stream.getvalue()).encode(), "text/csv; charset=utf-8"
    return anki(rows), "application/octet-stream"


def anki(rows):
    now = int(time.time())
    model_id, deck_id = 1760000000001, 1760000000002
    fields = ["Expression", "Meaning", "Context", "Source", "Explanation", "AIMode"]
    model = {"id": model_id, "name": "Language Bubble Scene", "type": 0, "mod": now, "usn": -1, "sortf": 0, "did": deck_id,
             "flds": [{"name": name, "ord": i, "sticky": False, "rtl": False, "font": "Arial", "size": 20, "media": []} for i, name in enumerate(fields)],
             "tmpls": [{"name": "Recall", "ord": 0, "qfmt": "{{Expression}}<hr>{{Context}}", "afmt": "{{FrontSide}}<hr id=answer>{{Meaning}}<br>{{Explanation}}<br>{{Source}}<br>{{AIMode}}", "bqfmt": "", "bafmt": "", "did": None}],
             "css": ".card {font-family:Arial;font-size:22px;text-align:left;color:#222;background:#fff;line-height:1.6}",
             "req": [[0, "all", [0]]], "latexPre": "", "latexPost": "", "tags": [], "vers": []}
    deck = {"id": deck_id, "name": "Language Bubble", "desc": "Original text and scene context. Images/audio are retained in the app and not included in this export.",
            "mod": now, "usn": -1, "dyn": 0, "collapsed": False, "extendNew": 10, "extendRev": 50,
            "conf": 1, "newToday": [0, 0], "revToday": [0, 0], "lrnToday": [0, 0], "timeToday": [0, 0]}
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "collection.anki2"
        db = sqlite3.connect(path)
        db.executescript("""
        CREATE TABLE col (id integer primary key, crt integer not null, mod integer not null, scm integer not null, ver integer not null, dty integer not null, usn integer not null, ls integer not null, conf text not null, models text not null, decks text not null, dconf text not null, tags text not null);
        CREATE TABLE notes (id integer primary key, guid text not null, mid integer not null, mod integer not null, usn integer not null, tags text not null, flds text not null, sfld integer not null, csum integer not null, flags integer not null, data text not null);
        CREATE TABLE cards (id integer primary key, nid integer not null, did integer not null, ord integer not null, mod integer not null, usn integer not null, type integer not null, queue integer not null, due integer not null, ivl integer not null, factor integer not null, reps integer not null, lapses integer not null, left integer not null, odue integer not null, odid integer not null, flags integer not null, data text not null);
        CREATE TABLE revlog (id integer primary key, cid integer not null, usn integer not null, ease integer not null, ivl integer not null, lastIvl integer not null, factor integer not null, time integer not null, type integer not null);
        CREATE TABLE graves (usn integer not null, oid integer not null, type integer not null);
        CREATE INDEX ix_notes_usn ON notes(usn); CREATE INDEX ix_cards_usn ON cards(usn); CREATE INDEX ix_cards_nid ON cards(nid); CREATE INDEX ix_cards_sched ON cards(did,queue,due); CREATE INDEX ix_revlog_usn ON revlog(usn); CREATE INDEX ix_revlog_cid ON revlog(cid); CREATE INDEX ix_notes_csum ON notes(csum);
        """)
        db.execute("INSERT INTO col VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (1, now, now*1000, now*1000, 11, 0, 0, 0, "{}", json.dumps({str(model_id): model}), json.dumps({str(deck_id): deck}), "{}", "{}"))
        for index, row in enumerate(rows):
            nid = now * 1000 + index
            guid = hashlib.sha256((row[0] + "|" + row[1]).encode()).hexdigest()[:12]
            checksum = int(hashlib.sha1(row[0].encode()).hexdigest()[:8], 16)
            db.execute("INSERT INTO notes VALUES(?,?,?,?,?,?,?,?,?,?,?)", (nid, guid, model_id, now, -1, " LanguageBubble ", "\x1f".join(html.escape(c).replace("\n", "<br>") for c in row), row[0], checksum, 0, ""))
            db.execute("INSERT INTO cards VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (nid, nid, deck_id, 0, now, -1, 0, 0, index+1, 0, 2500, 0, 0, 0, 0, 0, 0, ""))
        db.commit(); db.close()
        output = io.BytesIO()
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.write(path, "collection.anki2"); archive.writestr("media", "{}")
        return output.getvalue()
