"""Private-beta proxy with an explicit offline mock mode; no raw text logs."""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
from contextlib import suppress
import secrets
import sqlite3
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from typing import Literal
from uuid import UUID

from fastapi import Depends, FastAPI, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from mock_provider import MockProvider
from ai_provider import AIProvider
from sync_store import SyncStore
from sync_api import router as sync_router
from dictionary import DictionaryEntry, ContextMeaning, lookup as dictionary_lookup


class CaptureRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    text: str = Field(min_length=1, max_length=6000)
    request_id: UUID
    surrounding_text: str | None = Field(default=None, max_length=12000)
    source_app: str | None = Field(default=None, max_length=200)
    target_language: Literal["zh", "en", "es", "pt", "fr", "de", "ja", "ko"] | None = None

    @field_validator("text")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("text must not be blank")
        return value


class TranslationResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    translation: str = Field(min_length=1, max_length=12000)
    explanation: str = Field(max_length=4000)
    is_mock: bool = False
    dictionary: DictionaryEntry | None = None
    context_meaning: ContextMeaning | None = None

    @field_validator("translation")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("empty translation")
        return value


class PolishResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    polished: str = Field(min_length=1, max_length=12000)
    explanation: str = Field(max_length=4000)
    is_mock: bool = False

    @field_validator("polished")
    @classmethod
    def nonblank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("empty polished text")
        return value


class WritingIssue(BaseModel):
    model_config = ConfigDict(extra="forbid")
    original: str = Field(min_length=1, max_length=500)
    replacement: str = Field(max_length=700)
    category: Literal["grammar", "spelling", "collocation", "word_choice"]
    explanation: str = Field(min_length=1, max_length=1000)
    confidence: float = Field(ge=0, le=1)


class CheckResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    complete: bool
    issues: list[WritingIssue] = Field(max_length=3)
    is_mock: bool = False


@asynccontextmanager
async def lifespan(app: FastAPI):
    mode = os.environ.get("AI_MODE", "mock")
    if mode not in {"mock", "live"}:
        raise RuntimeError("AI_MODE must be mock or live")
    app.state.provider = MockProvider() if mode == "mock" else AIProvider()
    app.state.db = SyncStore(os.environ.get("CONTEXT_DATA_DIR", ".local-data"), live_learning=mode == "live")
    store = app.state.db
    app.state.learning_worker = "ready"
    async def process_learning():
        while True:
            try:
                await asyncio.to_thread(store.process_jobs)
                if mode == "live":
                    job = await asyncio.to_thread(store.claim_plan)
                    if job:
                        try:
                            raw = await app.state.provider.generate("plan", job["snapshot"])
                            await asyncio.to_thread(store.finish_plan, job, raw)
                        except (HTTPException, ValueError):
                            await asyncio.to_thread(store.finish_plan, job)
                app.state.learning_worker = "ready"
            except sqlite3.OperationalError:
                # Temporary storage unavailability must not permanently kill the worker.
                app.state.learning_worker = "retrying"
            await asyncio.sleep(2)
    worker = asyncio.create_task(process_learning())
    try:
        yield
    finally:
        worker.cancel()
        with suppress(asyncio.CancelledError):
            await worker
        await app.state.provider.close()


app = FastAPI(title="Context private-beta proxy", version="0.1.0", lifespan=lifespan)
app.include_router(sync_router)
security = HTTPBearer(auto_error=False)
attempts: dict[str, deque] = defaultdict(deque)


async def authorize(credentials: HTTPAuthorizationCredentials | None = Depends(security)) -> str:
    expected = os.environ.get("CONTEXT_CLIENT_TOKEN", "")
    if not expected:
        raise HTTPException(503, "Client access is not configured")
    token = credentials.credentials if credentials else ""
    device = app.state.db.session(token) if token and hasattr(app.state, "db") else None
    if not token or not (secrets.compare_digest(token, expected) or device):
        raise HTTPException(401, "Unauthorized")
    fingerprint = hashlib.sha256(token.encode()).hexdigest()
    now = time.monotonic()
    history = attempts[fingerprint]
    while history and now - history[0] >= 60:
        history.popleft()
    if len(history) >= int(os.environ.get("CONTEXT_RATE_LIMIT", "120")):
        raise HTTPException(429, "Rate limit exceeded")
    history.append(now)
    return fingerprint


def get_provider() -> AIProvider | MockProvider:
    return app.state.provider


@app.get("/health")
async def health():
    # Do not disclose provider credentials or user configuration.
    return {"status": "ok", "ai_mode": getattr(app.state.provider, "mode", "unknown"), "learning_worker": getattr(app.state, "learning_worker", "unknown")}


@app.post("/v1/translate", response_model=TranslationResult, response_model_exclude_defaults=True)
async def translate(request: CaptureRequest, _: str = Depends(authorize), provider: AIProvider = Depends(get_provider)):
    context = request.surrounding_text
    if context and request.source_app:
        context = json.dumps({"source_app": request.source_app, "surrounding_text": context}, ensure_ascii=False)
    if request.target_language or request.surrounding_text:
        raw = await provider.generate("translate", request.text, target_language=request.target_language or "zh", context=context)
    else:
        raw = await provider.generate("translate", request.text)
    try:
        result = TranslationResult.model_validate(raw)
        result.is_mock = getattr(provider, "mode", "live") == "mock"
        # Only the local dictionary can supply dictionary attribution.
        found = await asyncio.to_thread(dictionary_lookup, request.text, request.target_language or "zh")
        result.dictionary = DictionaryEntry.model_validate(found["entry"]) if found["entry"] else None
        if not (request.surrounding_text or "").strip():
            result.context_meaning = None
        return result
    except ValidationError:
        raise HTTPException(502, "Invalid translation result") from None


class DictionaryRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    text: str = Field(min_length=1, max_length=6000)
    language: str = Field(default="zh", max_length=20)


@app.post("/v1/dictionary")
async def dictionary(request: DictionaryRequest, _: str = Depends(authorize)):
    return await asyncio.to_thread(dictionary_lookup, request.text, request.language)


@app.post("/v1/translate/stream")
async def stream_translate(request: CaptureRequest, _: str = Depends(authorize), provider: AIProvider = Depends(get_provider)):
    if getattr(provider, "mode", None) != "mock":
        raise HTTPException(503, "Streaming beta currently supports mock mode only")
    raw = await provider.generate("translate", request.text, target_language=request.target_language or "zh", context=request.surrounding_text)
    result = TranslationResult.model_validate(raw).model_copy(update={"is_mock": True})
    found = await asyncio.to_thread(dictionary_lookup, request.text, request.target_language or "zh")
    result.dictionary = DictionaryEntry.model_validate(found["entry"]) if found["entry"] else None
    if not (request.surrounding_text or "").strip():
        result.context_meaning = None
    async def events():
        # Exercise real streaming transport with explicit mock chunks, not a live-model claim.
        for index in range(0, len(result.translation), 4):
            yield json.dumps({"delta": result.translation[index:index+4]}, ensure_ascii=False) + "\n"
            await asyncio.sleep(0.04)
        yield json.dumps({"result": result.model_dump()}, ensure_ascii=False) + "\n"
    return StreamingResponse(events(), media_type="application/x-ndjson", headers={"Cache-Control": "no-store"})


@app.post("/v1/polish", response_model=PolishResult, response_model_exclude_defaults=True)
async def polish(request: CaptureRequest, _: str = Depends(authorize), provider: AIProvider = Depends(get_provider)):
    context = request.surrounding_text
    if request.source_app:
        context = json.dumps({"source_app": request.source_app, "surrounding_text": context}, ensure_ascii=False)
    raw = await provider.generate("polish", request.text, context=context)
    try:
        result = PolishResult.model_validate(raw)
    except ValidationError:
        raise HTTPException(502, "Invalid polishing result") from None
    result.is_mock = getattr(provider, "mode", "live") == "mock"
    return result


@app.post("/v1/check", response_model=CheckResult, response_model_exclude_defaults=True)
async def check(request: CaptureRequest, _: str = Depends(authorize), provider: AIProvider = Depends(get_provider)):
    if len(request.text) > 500:
        raise HTTPException(422, "Only a short current sentence is accepted")
    raw = await provider.generate("check", request.text)
    try:
        result = CheckResult.model_validate(raw)
    except ValidationError:
        raise HTTPException(502, "Invalid checking result") from None
    result.is_mock = getattr(provider, "mode", "live") == "mock"
    if not result.complete:
        return CheckResult(complete=False, issues=[], is_mock=result.is_mock)
    result.issues = [issue for issue in result.issues
                     if issue.confidence >= 0.92 and issue.original != issue.replacement
                     and request.text.count(issue.original) == 1][:1]
    return result
