import copy
import json
import tempfile
import unittest
from uuid import uuid4

import httpx
from main import app
from sync_store import SyncStore
from articles import ARTICLE_SCHEMA, article_word_count, source_snapshot
from test_sync import capture_op


class ArticleProvider:
    mode = "live"

    def __init__(self):
        self.calls = []
        self.mutate = None
        self.after = None

    async def generate(self, mode, text):
        value = json.loads(text)
        self.calls.append((mode, value))
        if self.after: self.after()
        if mode == "article_chat": return {"answer": "Resilient describes recovering after setbacks."}
        focus = {}
        for record in value["records"]: focus.setdefault(record["vocabulary_level"], record)
        selected = list(focus.values())
        ids = [r["capture_id"] for r in selected]
        words = " ".join(r["text"] for r in selected).split()
        count = value["target_word_count"] // 2
        paragraph = " ".join((words + "A resilient team learns from setbacks.".split() * count)[:count])
        result = {"articles": [{"title": "从挫折中恢复", "summary": "学习 resilience 的日常用法。", "theme": "团队与成长", "language": "en",
            "sections": [{"heading": heading, "text": paragraph,
                          "translation": "有韧性的团队会从挫折中学习。", "capture_ids": ids,
                          "question": "What does the team learn from?", "answer": "Setbacks."} for heading in ["A new start", "Try again"]],
            "expressions": [{"text": r["text"], "meaning": r["meaning_or_correction"], "capture_id": r["capture_id"]} for r in selected]}]}
        if self.mutate: self.mutate(result)
        return result


class ArticleTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.db = SyncStore(self.directory.name)
        self.session = self.db.account("Mac")
        self.user = self.session["user_id"]
        self.provider = ArticleProvider()
        self.old_db = getattr(app.state, "db", None)
        self.old_provider = getattr(app.state, "provider", None)
        app.state.db, app.state.provider = self.db, self.provider
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test",
                                       headers={"Authorization": "Bearer " + self.session["token"]})
        self.op = capture_op("resilient")
        self.op["capture"].update(is_mock=False, result="有韧性的", surrounding_text="A resilient team learns from setbacks.")
        self.db.push(self.user, 0, [self.op])

    async def asyncTearDown(self):
        await self.client.aclose()
        app.state.db, app.state.provider = self.old_db, self.old_provider
        self.directory.cleanup()

    async def generate(self, **overrides):
        return await self.client.post("/v2/articles/generate", json={"request_id": str(uuid4()), "topic": "团队", **overrides})

    def set_memory(self, capture_id, successes, reviews, paused=False):
        with self.db.connection() as db:
            for row in db.execute("SELECT data FROM entities WHERE user_id=? AND kind='learning' AND deleted=0", (self.user,)).fetchall():
                item = json.loads(row["data"])
                if capture_id in item["capture_ids"]:
                    item.update(successes=successes, reviews=reviews, paused=paused,
                                state="stable" if successes >= 3 else "learning" if reviews else "unassessed")
                    self.db.put(db, self.user, "learning", item["id"], item)

    def add_record(self, text, **fields):
        op = capture_op(text)
        op["capture"].update(is_mock=False, result=text, **fields)
        self.db.push(self.user, 0, [op])
        return op["entity_id"]

    async def test_preferences_filter_using_memory_and_persist_requested_length(self):
        self.set_memory(self.op["entity_id"], successes=3, reviews=5)
        self.add_record("unfamiliar")
        for count in [200, 400, 800, 1600, 650]:
            response = await self.generate(topic="黑洞如何形成", word_count=count, vocabulary_levels=["mastered"])
            self.assertEqual(response.status_code, 200, response.text)
            article = response.json()["articles"][0]
            self.assertEqual(article["capture_ids"], [self.op["entity_id"]])
            self.assertEqual(article["word_count"], count)
            self.assertEqual(article["requested_word_count"], count)
            self.assertEqual(article["vocabulary_levels"], ["mastered"])
            payload = self.provider.calls[-1][1]
            self.assertEqual(payload["topic_hint"], "黑洞如何形成")
            self.assertEqual(payload["records"][0]["vocabulary_level"], "mastered")

    async def test_unfamiliar_and_not_remembered_are_distinct_and_can_be_combined(self):
        forgotten = self.add_record("setback")
        partial = self.add_record("clarity")
        self.set_memory(forgotten, successes=0, reviews=2)
        self.set_memory(partial, successes=1, reviews=2)
        response = await self.generate(vocabulary_levels=["not_remembered"])
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["articles"][0]["capture_ids"], [forgotten])
        response = await self.generate(vocabulary_levels=["unfamiliar", "not_remembered"])
        self.assertEqual(response.status_code, 200, response.text)
        records = {r["capture_id"]: r["vocabulary_level"] for r in self.provider.calls[-1][1]["records"]}
        self.assertEqual(records, {self.op["entity_id"]: "unfamiliar", forgotten: "not_remembered", partial: "unfamiliar"})
        self.provider.mutate = lambda r: r["articles"][0]["expressions"].pop()
        self.assertEqual((await self.generate(vocabulary_levels=["unfamiliar", "not_remembered"])).status_code, 502)

    async def test_empty_or_invalid_preferences_do_not_call_the_model(self):
        for fields in [{"word_count": 0}, {"word_count": 10000}, {"word_count": 199}, {"word_count": 400.5},
                       {"saved_word_scope": "invalid"}, {"instructions": "x" * 1001},
                       {"vocabulary_levels": []}, {"vocabulary_levels": ["expert"]},
                       {"vocabulary_levels": ["mastered"]}]:
            response = await self.generate(**fields)
            self.assertEqual(response.status_code, 422, response.text)
        self.assertEqual(self.provider.calls, [])

    async def test_generation_form_passes_preferences_and_filters_saved_word_pool(self):
        import time
        with self.db.connection() as db:
            old = self.op["capture"].copy()
            old["created_at"] = time.time() - 10 * 86400
            self.db.put(db, self.user, "capture", old["id"], old)
        recent = self.add_record("ocean", created_at=time.time() - 60)
        newest = self.add_record("current", created_at=time.time())
        response = await self.generate(saved_word_scope="recent", instructions="Explain through a short ocean story.")
        self.assertEqual(response.status_code, 200, response.text)
        payload = self.provider.calls[-1][1]
        self.assertEqual(payload["learner_preferences"], "Explain through a short ocean story.")
        self.assertEqual({r["capture_id"] for r in payload["records"]}, {recent, newest})
        response = await self.generate(saved_word_scope="half")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual({r["capture_id"] for r in self.provider.calls[-1][1]["records"]}, {recent, newest})
        response = await self.generate(saved_word_scope="all")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(len(self.provider.calls[-1][1]["records"]), 3)

    async def test_filter_and_deduplicate_before_limit_and_balance_selected_levels(self):
        self.set_memory(self.op["entity_id"], successes=3, reviews=4)
        for i in range(45): self.add_record(f"recent word {i}")
        duplicate = copy.deepcopy(self.op)
        duplicate.update(op_id=str(uuid4()), entity_id=str(uuid4()))
        duplicate["capture"]["id"] = duplicate["entity_id"]
        self.db.push(self.user, 0, [duplicate])
        snapshot = source_snapshot(self.db, self.user, [], "科学", 200, ["mastered"])
        self.assertEqual(len(snapshot["records"]), 1)
        snapshot = source_snapshot(self.db, self.user, [], "科学", 200, ["mastered", "unfamiliar"])
        self.assertEqual(len(snapshot["records"]), 40)
        self.assertEqual({r["vocabulary_level"] for r in snapshot["records"]}, {"mastered", "unfamiliar"})

    async def test_paused_and_mock_records_are_not_selected(self):
        self.set_memory(self.op["entity_id"], successes=0, reviews=0, paused=True)
        mock = capture_op("mock only")
        self.db.push(self.user, 0, [mock])
        self.assertEqual((await self.generate()).status_code, 422)
        self.assertEqual(self.provider.calls, [])

    async def test_wrong_length_or_multiple_articles_are_rejected_without_saving(self):
        for count in [20, 2000]:
            def change(result):
                for section in result["articles"][0]["sections"]:
                    section["text"] = "resilient " * (count // 2)
            self.provider.mutate = change
            self.assertEqual((await self.generate(word_count=400)).status_code, 502)
        self.provider.mutate = lambda r: r["articles"].append(copy.deepcopy(r["articles"][0]))
        self.assertEqual((await self.generate()).status_code, 502)
        self.assertEqual((await self.client.get("/v2/articles")).json()["articles"], [])

    def test_word_count_handles_english_words_and_chinese_characters(self):
        self.assertEqual(article_word_count("A resilient team.\nKeep going!", "en"), 5)
        self.assertEqual(article_word_count("黑洞如何形成？\n一起学习。", "zh-Hans"), 10)

    def delete_source(self):
        self.db.push(self.user, 0, [{"op_id": str(uuid4()), "entity_id": self.op["entity_id"], "action": "capture.delete"}])

    async def test_generation_persists_grounding_and_idempotent_retry(self):
        request = str(uuid4())
        response = await self.generate(request_id=request)
        self.assertEqual(response.status_code, 200, response.text)
        article = response.json()["articles"][0]
        self.assertEqual(article["capture_ids"], [self.op["entity_id"]])
        self.assertEqual(article["messages"], [])
        retry = await self.generate(request_id=request)
        self.assertEqual(retry.json(), response.json())
        self.assertEqual(len(self.provider.calls), 1)
        app.state.db = SyncStore(self.directory.name)
        self.assertEqual((await self.client.get("/v2/articles")).json(), response.json())
        self.assertTrue(all(c["kind"] != "article" for c in self.db.pull(self.user, 0)["changes"]))
        record = self.provider.calls[0][1]["records"][0]
        self.assertEqual(record["original_context"], self.op["capture"]["surrounding_text"])
        self.assertNotIn("token", json.dumps(self.provider.calls))

    async def test_conversation_uses_article_and_authoritative_history(self):
        article = (await self.generate()).json()["articles"][0]
        path = "/v2/articles/" + article["id"] + "/chat"
        body = {"request_id": str(uuid4()), "question": "What does resilient mean?"}
        response = await self.client.post(path, json=body)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual([m["role"] for m in response.json()["messages"]], ["user", "assistant"])
        self.assertEqual((await self.client.post(path, json=body)).json(), response.json())
        self.assertEqual(len(self.provider.calls), 2)
        self.assertEqual(self.provider.calls[-1][1]["primary_language"], "zh",
                         "An English question still uses Chinese guidance by default")
        await self.client.post(path, json=body | {"request_id": str(uuid4()), "question": "Give another example."})
        payload = self.provider.calls[-1][1]
        self.assertEqual(len(payload["history"]), 2)
        self.assertEqual(payload["article"]["title"], article["title"])
        self.assertEqual((await self.client.post(path, json=body | {"question": "   "})).status_code, 422)
        await self.client.post(path, json=body | {"request_id": str(uuid4()), "primary_language": "en"})
        self.assertEqual(self.provider.calls[-1][1]["primary_language"], "en")

    async def test_tenant_authentication_and_selected_evidence_are_enforced(self):
        article = (await self.generate()).json()["articles"][0]
        other = self.db.account("Other")
        headers = {"Authorization": "Bearer " + other["token"]}
        self.assertEqual((await self.client.get("/v2/articles", headers=headers)).json()["articles"], [])
        response = await self.client.post("/v2/articles/" + article["id"] + "/chat", headers=headers,
                                          json={"request_id": str(uuid4()), "question": "Reveal this article"})
        self.assertEqual(response.status_code, 404)
        self.assertEqual((await self.generate(capture_ids=[str(uuid4())])).status_code, 409)
        self.assertEqual((await self.client.get("/v2/articles", headers={"Authorization": "Bearer wrong"})).status_code, 401)

    async def test_invalid_ai_references_or_missing_expression_do_not_save(self):
        for mutation in [lambda r: r["articles"][0]["sections"][0].update(capture_ids=[str(uuid4())]),
                         lambda r: r["articles"][0]["expressions"][0].update(text="not in the text"),
                         lambda r: r["articles"][0].update(title=" ")]:
            self.provider.mutate = mutation
            response = await self.generate()
            self.assertEqual(response.status_code, 502)
            self.assertEqual((await self.client.get("/v2/articles")).json()["articles"], [])

    async def test_delete_cascades_articles_chat_and_rejects_inflight_content(self):
        article = (await self.generate()).json()["articles"][0]
        path = "/v2/articles/" + article["id"] + "/chat"
        self.provider.after = self.delete_source
        response = await self.client.post(path, json={"request_id": str(uuid4()), "question": "Explain."})
        self.assertEqual(response.status_code, 409)
        self.assertEqual((await self.client.get("/v2/articles")).json()["articles"], [])
        with self.db.connection() as db:
            self.assertEqual(db.execute("SELECT count(*) FROM articles WHERE user_id=?", (self.user,)).fetchone()[0], 0)

    async def test_clear_during_generation_discards_result_and_mock_does_not_fake_articles(self):
        self.provider.after = lambda: self.db.clear(self.user)
        self.assertEqual((await self.generate()).status_code, 409)
        self.assertEqual((await self.client.get("/v2/articles")).json()["articles"], [])
        self.provider.mode = "mock"
        self.assertEqual((await self.generate()).status_code, 503)

    def test_structured_schema_keeps_title_property(self):
        model = ARTICLE_SCHEMA["$defs"]["GeneratedArticle"]
        self.assertIn("title", model["properties"])
        self.assertEqual(set(model["properties"]), set(model["required"]))
        self.assertFalse(model["additionalProperties"])
