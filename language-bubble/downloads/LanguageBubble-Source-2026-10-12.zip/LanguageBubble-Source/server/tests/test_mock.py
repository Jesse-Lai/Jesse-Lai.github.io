import os
import unittest
import tempfile
from unittest.mock import patch
from uuid import uuid4

import httpx

from main import app, attempts


class MockTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"AI_MODE": "mock", "AI_API_KEY": "unused-test-only",
                                          "CONTEXT_CLIENT_TOKEN": "mock-test-token", "CONTEXT_RATE_LIMIT": "120", "CONTEXT_DATA_DIR": self.directory.name})
        self.env.start()
        # A stale credential must never cause Mock mode to construct a real provider.
        self.live = patch("main.AIProvider", side_effect=AssertionError("Live provider forbidden"))
        self.live.start()
        self.network = patch("httpx.AsyncHTTPTransport.handle_async_request", side_effect=AssertionError("External HTTP forbidden"))
        self.network.start()
        attempts.clear()
        self.lifecycle = app.router.lifespan_context(app)
        await self.lifecycle.__aenter__()
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test")

    async def asyncTearDown(self):
        await self.client.aclose()
        await self.lifecycle.__aexit__(None, None, None)
        self.network.stop()
        self.live.stop()
        self.env.stop()
        self.directory.cleanup()

    async def post(self, endpoint, text, token="mock-test-token"):
        return await self.client.post("/v1/" + endpoint, json={"text": text, "request_id": str(uuid4())},
                                      headers={"Authorization": "Bearer " + token})

    async def test_mock_translation_and_health_are_labeled(self):
        self.assertEqual((await self.client.get("/health")).json()["ai_mode"], "mock")
        response = await self.post("translate", "It is a work in progress.")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["is_mock"])
        self.assertEqual(response.json()["translation"], "这件事还在完善中。")
        self.assertIn("AI Mock", response.json()["explanation"])

    async def test_corrections_use_exact_source_and_preserve_label(self):
        for source, corrected in [("I am agree with you.", "I agree with you."),
                                  ("I look forward to hear from you.", "I look forward to hearing from you.")]:
            response = (await self.post("check", source)).json()
            self.assertTrue(response["is_mock"])
            self.assertTrue(response["complete"])
            issue, = response["issues"]
            self.assertEqual(source.replace(issue["original"], issue["replacement"]), corrected)
            self.assertIn("AI Mock", issue["explanation"])

    async def test_correct_fixture_vs_unknown_text(self):
        correct = (await self.post("check", "I agree with you.")).json()
        self.assertEqual(correct, {"complete": True, "issues": [], "is_mock": True})
        unknown = (await self.post("check", "He go to school.")).json()
        self.assertEqual(unknown, {"complete": False, "issues": [], "is_mock": True})
        unknown_translation = (await self.post("translate", "unlisted")).json()
        self.assertIn("暂无翻译样例", unknown_translation["translation"])
        self.assertTrue(unknown_translation["is_mock"])

    async def test_polish_fixtures_and_unknown_inputs_are_explicitly_mock(self):
        for source, expected in [("recieve", "receive"), ("She go to school everyday.", "She goes to school every day."),
                                 ("我以经完成了。", "我已经完成了。"), ("I agree with you.", "I agree with you."),
                                 ("Unlisted draft", "Unlisted draft")]:
            response = await self.post("polish", source)
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json()["polished"], expected)
            self.assertTrue(response.json()["is_mock"])
            self.assertIn("AI Mock", response.json()["explanation"])

    async def test_auth_still_required(self):
        self.assertEqual((await self.post("translate", "products", token="wrong")).status_code, 401)

    async def test_multilingual_mock_targets_without_external_calls(self):
        from mock_provider import GREETINGS
        for target, expected in GREETINGS.items():
            response = await self.client.post("/v1/translate", json={"text": "Hello", "request_id": str(uuid4()),
                "target_language": target, "surrounding_text": "Hello, welcome to our classroom."},
                headers={"Authorization": "Bearer mock-test-token"})
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json()["translation"], expected)
            self.assertTrue(response.json()["is_mock"])

    async def test_stream_has_deltas_then_one_complete_mock_result(self):
        import json
        response = await self.client.post("/v1/translate/stream", json={"text": "products", "request_id": str(uuid4())}, headers={"Authorization": "Bearer mock-test-token"})
        self.assertEqual(response.status_code, 200)
        events = [json.loads(line) for line in response.text.splitlines()]
        self.assertTrue(all("delta" in e for e in events[:-1]))
        self.assertEqual("".join(e["delta"] for e in events[:-1]), events[-1]["result"]["translation"])
        self.assertTrue(events[-1]["result"]["is_mock"])

    async def test_default_is_mock_and_unknown_mode_fails_closed(self):
        with patch.dict(os.environ):
            os.environ.pop("AI_MODE", None)
            async with app.router.lifespan_context(app):
                self.assertEqual(app.state.provider.mode, "mock")
        with patch.dict(os.environ, {"AI_MODE": "typo"}):
            with self.assertRaises(RuntimeError):
                async with app.router.lifespan_context(app):
                    self.fail("Invalid mode must not start")

    async def test_learning_worker_recovers_after_storage_error(self):
        import asyncio
        import sqlite3
        from fastapi import FastAPI
        from main import lifespan
        isolated = FastAPI()
        with patch("main.SyncStore.process_jobs", side_effect=[sqlite3.OperationalError("temporary storage outage"), None, None]) as jobs:
            async with lifespan(isolated):
                async with asyncio.timeout(5):
                    while isolated.state.learning_worker != "retrying":
                        await asyncio.sleep(0.01)
                    while isolated.state.learning_worker != "ready":
                        await asyncio.sleep(0.01)
                self.assertGreaterEqual(jobs.call_count, 2)
