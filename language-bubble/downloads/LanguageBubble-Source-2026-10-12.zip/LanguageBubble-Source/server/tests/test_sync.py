import os
import tempfile
import time
import unittest
from unittest.mock import patch
from uuid import uuid4

import httpx

from main import app
from sync_api import pair_attempts
from sync_store import SyncStore


def capture_op(text="products", identifier=None, assets=None):
    identifier = identifier or str(uuid4())
    return {"op_id": str(uuid4()), "action": "capture.put", "entity_id": identifier,
            "capture": {"id": identifier, "kind": "translation", "source": text, "result": "产品",
                        "explanation": "AI Mock · 测试数据", "created_at": time.time(), "is_mock": True, "asset_ids": assets or []}}


class SyncTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"AI_MODE": "mock", "CONTEXT_DATA_DIR": self.directory.name,
                                          "CONTEXT_CLIENT_TOKEN": "bootstrap-test"})
        self.env.start()
        pair_attempts.clear()
        self.lifecycle = app.router.lifespan_context(app)
        await self.lifecycle.__aenter__()
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test")
        self.owner = (await self.client.post("/v2/accounts", headers=self.auth("bootstrap-test"), json={"device_name": "Mac"})).json()
        code = (await self.client.post("/v2/pair-codes", headers=self.auth(self.owner["token"]))).json()["code"]
        self.phone = (await self.client.post("/v2/pair", json={"device_name": "iOS", "code": code})).json()
        self.other = (await self.client.post("/v2/accounts", headers=self.auth("bootstrap-test"), json={"device_name": "Other"})).json()

    async def asyncTearDown(self):
        await self.client.aclose()
        await self.lifecycle.__aexit__(None, None, None)
        self.env.stop()
        self.directory.cleanup()

    def auth(self, token):
        return {"Authorization": "Bearer " + token}

    async def push(self, ops, session=None, epoch=0):
        return await self.client.post("/v2/sync/push", headers=self.auth((session or self.owner)["token"]), json={"epoch": epoch, "operations": ops})

    async def pull(self, session=None, cursor=0):
        return (await self.client.get("/v2/sync/pull", params={"cursor": cursor}, headers=self.auth((session or self.phone)["token"]))).json()

    async def test_two_devices_persist_and_isolate_tenants(self):
        self.assertEqual(self.owner["user_id"], self.phone["user_id"])
        self.assertNotEqual(self.owner["token"], self.phone["token"])
        op = capture_op()
        self.assertEqual((await self.push([op])).status_code, 200)
        page = await self.pull()
        self.assertEqual({row["kind"] for row in page["changes"]}, {"capture", "learning", "plan"})
        self.assertEqual((await self.pull(self.other))["changes"], [])
        app.state.db = SyncStore(self.directory.name)
        self.assertEqual((await self.pull())["changes"], page["changes"])
        self.assertEqual((await self.pull(cursor=page["cursor"]))["changes"], [])

    async def test_dictionary_and_each_context_sense_survive_sync(self):
        op = capture_op("frame")
        op["capture"]["context_meaning"] = {"pos": "n.", "meaning": "画框", "explanation": "设计中的容器"}
        op["capture"]["dictionary"] = {"word": "frame", "phonetic": "", "language": "zh",
            "groups": [{"pos": "n.", "meanings": ["框"]}, {"pos": "vt.", "meanings": ["设计"]}],
            "source": "ECDICT", "url": "https://github.com/skywind3000/ECDICT", "license": "MIT"}
        self.assertEqual((await self.push([op])).status_code, 200)
        saved = next(c["data"] for c in (await self.pull())["changes"] if c["kind"] == "capture")
        for key in ["dictionary", "context_meaning"]:
            self.assertEqual(saved[key], op["capture"][key])

    async def test_idempotency_conflict_and_deletion_wins(self):
        op = capture_op()
        await self.push([op])
        before = await self.pull()
        await self.push([op])
        self.assertEqual((await self.pull())["cursor"], before["cursor"])
        conflict = dict(op, action="capture.delete")
        self.assertEqual((await self.push([conflict])).status_code, 409)
        await self.push([{"op_id": str(uuid4()), "action": "capture.delete", "entity_id": op["entity_id"]}], self.phone)
        op["op_id"] = str(uuid4())
        await self.push([op])
        self.assertTrue(all(row["deleted"] and row["data"] is None for row in (await self.pull())["changes"]))

    async def test_pair_expiry_reuse_revocation_and_rate_limit(self):
        code = (await self.client.post("/v2/pair-codes", headers=self.auth(self.owner["token"]))).json()["code"]
        payload = {"code": code, "device_name": "third"}
        self.assertEqual((await self.client.post("/v2/pair", json=payload)).status_code, 200)
        self.assertEqual((await self.client.post("/v2/pair", json=payload)).status_code, 400)
        with app.state.db.connection() as db:
            db.execute("UPDATE pairs SET expires=0,used=0")
        self.assertEqual((await self.client.post("/v2/pair", json=payload)).status_code, 400)
        await self.client.post("/v2/logout", headers=self.auth(self.phone["token"]))
        self.assertEqual((await self.client.get("/v2/sync/pull", headers=self.auth(self.phone["token"]))).status_code, 401)
        for _ in range(11):
            response = await self.client.post("/v2/pair", json=payload)
        self.assertEqual(response.status_code, 429)

    async def test_clear_invalidates_offline_uploads(self):
        await self.push([capture_op()])
        await self.client.post("/v2/clear", headers=self.auth(self.owner["token"]))
        self.assertEqual((await self.push([capture_op("offline")], self.phone)).status_code, 409)
        page = await self.pull()
        self.assertEqual(page["epoch"], 1)
        self.assertTrue(all(row["deleted"] for row in page["changes"]))
        self.assertEqual((await self.push([capture_op("new")], epoch=1)).status_code, 200)

    async def test_attachment_ownership_delete_and_atomic_batch(self):
        identifier, asset = str(uuid4()), str(uuid4())
        body = b"\x89PNG\r\n\x1a\nfixture"
        response = await self.client.put("/v2/assets/" + asset, params={"capture_id": identifier}, content=body,
                                         headers=self.auth(self.owner["token"]) | {"Content-Type": "image/png"})
        self.assertEqual(response.status_code, 200)
        op = capture_op(identifier=identifier, assets=[asset])
        self.assertEqual((await self.push([op], self.other)).status_code, 422)
        self.assertEqual((await self.push([op])).status_code, 200)
        self.assertEqual((await self.client.get("/v2/assets/" + asset, headers=self.auth(self.phone["token"]))).content, body)
        self.assertEqual((await self.client.get("/v2/assets/" + asset, headers=self.auth(self.other["token"]))).status_code, 404)
        valid, invalid = capture_op("valid"), capture_op("invalid", assets=[str(uuid4())])
        self.assertEqual((await self.push([valid, invalid])).status_code, 422)
        self.assertFalse(any(row["id"] == valid["entity_id"] for row in (await self.pull())["changes"]))
        await self.push([{"op_id": str(uuid4()), "action": "capture.delete", "entity_id": identifier}])
        self.assertEqual((await self.client.get("/v2/assets/" + asset, headers=self.auth(self.phone["token"]))).status_code, 404)

    async def test_learning_reviews_are_shared_and_not_instant_mastery(self):
        await self.push([capture_op()])
        learning = next(c["data"] for c in (await self.pull())["changes"] if c["kind"] == "learning")
        self.assertEqual(learning["state"], "unassessed")
        for _ in range(4):
            identifier = str(uuid4())
            op = {"op_id": str(uuid4()), "entity_id": identifier, "action": "review.put",
                  "review": {"id": identifier, "learning_id": learning["id"], "rating": "good"}}
            self.assertEqual((await self.push([op], self.phone)).status_code, 200)
        changed = [c["data"] for c in (await self.pull(self.owner))["changes"] if c["kind"] == "learning"][-1]
        self.assertEqual(changed["reviews"], 4)
        self.assertEqual(changed["successes"], 1)
        self.assertEqual(changed["interval_days"], 1)
        self.assertEqual(changed["state"], "learning")
        self.assertGreater(changed["due_at"], time.time())
        for days in [1, 2]:
            identifier = str(uuid4())
            with patch("sync_store.time.time", return_value=time.time() + days * 86400):
                await self.push([{"op_id": str(uuid4()), "entity_id": identifier, "action": "review.put",
                                 "review": {"id": identifier, "learning_id": learning["id"], "rating": "good"}}])
        changed = [c["data"] for c in (await self.pull())["changes"] if c["kind"] == "learning"][-1]
        self.assertEqual(changed["state"], "stable")

    async def test_same_meaning_merges_context_without_reviving_deleted_evidence(self):
        first, second = capture_op(), capture_op()
        first["capture"]["surrounding_text"] = "private first scene to erase"
        second["capture"]["surrounding_text"] = "surviving scene"
        await self.push([first, second])
        learning = [c["data"] for c in (await self.pull())["changes"] if c["kind"] == "learning"][-1]
        self.assertEqual(set(learning["capture_ids"]), {first["entity_id"], second["entity_id"]})
        await self.push([{"op_id": str(uuid4()), "action": "capture.delete", "entity_id": first["entity_id"]}])
        learning = [c["data"] for c in (await self.pull())["changes"] if c["kind"] == "learning"][-1]
        self.assertEqual(learning["capture_ids"], [second["entity_id"]])
        page = await self.pull()
        self.assertNotIn("private first scene to erase", str(page))
        for row in page["changes"]:
            if row["kind"] == "learning" and not row["deleted"]:
                self.assertNotIn(first["entity_id"], row["data"]["capture_ids"])

    async def test_goal_plan_and_milestone_ack_sync(self):
        from learning_plan import default_profile
        profile = default_profile() | {"goal": "work", "daily_minutes": 15}
        await self.push([{"op_id": str(uuid4()), "action": "profile.put", "entity_id": profile["id"], "profile": profile}])
        op = capture_op(); op["capture"]["surrounding_text"] = "We build products for curious people."
        await self.push([op])
        page = await self.pull()
        plan = [c["data"] for c in page["changes"] if c["kind"] == "plan"][-1]
        self.assertEqual(plan["goal"], "work")
        self.assertEqual({t["skill"] for t in plan["tasks"]}, {"listening", "speaking", "reading", "writing"})
        self.assertEqual(plan["tasks"][0]["prompt"], op["capture"]["surrounding_text"])
        identifier = str(uuid4())
        await self.push([{"op_id": str(uuid4()), "action": "review.put", "entity_id": identifier,
                         "review": {"id": identifier, "learning_id": plan["tasks"][0]["learning_id"], "rating": "good"}}], self.phone)
        milestone = [c["data"] for c in (await self.pull())["changes"] if c["kind"] == "milestone"][-1]
        await self.push([{"op_id": str(uuid4()), "action": "milestone.ack", "entity_id": milestone["id"]}], self.phone)
        result = [c["data"] for c in (await self.pull(self.owner))["changes"] if c["kind"] == "milestone"][-1]
        self.assertTrue(result["acknowledged"])

    async def test_exports_require_device_and_filter_by_owner(self):
        await self.push([capture_op()])
        missing = await self.client.get('/v2/export/csv')
        self.assertEqual(missing.status_code, 401)
        owner = await self.client.get('/v2/export/csv', headers=self.auth(self.phone['token']))
        self.assertEqual(owner.status_code, 200)
        self.assertIn('products', owner.text)
        other = await self.client.get('/v2/export/csv', headers=self.auth(self.other['token']))
        self.assertNotIn('products', other.text)
        self.assertNotIn(self.phone['token'], owner.text)

    async def test_learning_job_retries_after_restart_and_delete_cancels(self):
        op = capture_op()
        with patch.object(app.state.db, "_learn", side_effect=RuntimeError("temporary test failure")):
            self.assertEqual((await self.push([op])).status_code, 200)
        self.assertFalse(any(c["kind"] == "learning" for c in (await self.pull())["changes"]))
        app.state.db = SyncStore(self.directory.name)
        app.state.db.process_jobs()
        self.assertTrue(any(c["kind"] == "learning" for c in (await self.pull())["changes"]))
        other = capture_op("another")
        with patch.object(app.state.db, "_learn", side_effect=RuntimeError("temporary test failure")):
            await self.push([other])
            await self.push([{"op_id": str(uuid4()), "action": "capture.delete", "entity_id": other["entity_id"]}])
        app.state.db.process_jobs()
        self.assertFalse(any(c["kind"] == "learning" and not c["deleted"] and other["entity_id"] in c["data"]["capture_ids"] for c in (await self.pull())["changes"]))
