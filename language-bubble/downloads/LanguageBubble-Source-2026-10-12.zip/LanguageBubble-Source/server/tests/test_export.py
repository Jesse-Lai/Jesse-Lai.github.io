import csv
import io
import json
import sqlite3
import tempfile
import unittest
import zipfile
from pathlib import Path

from exporter import export, filter_items


class ExportTests(unittest.TestCase):
    def item(self, term="products"):
        return {"term": term, "meaning": "产品", "example": "We build products.", "explanation": "AI Mock", "is_mock": True,
                "capture_ids": [], "state": "unassessed", "paused": False, "due_at": 0}

    def test_csv_unicode_and_formula_escape(self):
        body, mime = export([self.item("=SUM(1,2)"), self.item("line\nwith,comma")], {}, "csv")
        rows = list(csv.reader(io.StringIO(body.decode("utf-8-sig"))))
        self.assertEqual(rows[1][0], "'=SUM(1,2)")
        self.assertEqual(rows[2][0], "line\nwith,comma")
        self.assertEqual(rows[1][1], "产品")

    def test_single_word_format_excludes_phrases_and_unicode(self):
        body, _ = export([self.item(s) for s in ["products", "products", "make sense", "hello!", "你好", "don't"]], {}, "txt")
        self.assertEqual(body.decode().splitlines(), ["products", "don't"])

    def test_anki_has_valid_linked_notes_cards_and_escaped_html(self):
        body, _ = export([self.item("<script>alert(1)</script>"), self.item()], {}, "apkg")
        with zipfile.ZipFile(io.BytesIO(body)) as archive, tempfile.TemporaryDirectory() as directory:
            self.assertEqual(set(archive.namelist()), {"collection.anki2", "media"})
            self.assertEqual(json.loads(archive.read("media")), {})
            path = Path(directory) / "collection.anki2"
            path.write_bytes(archive.read("collection.anki2"))
            db = sqlite3.connect(path)
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(db.execute("SELECT count(*) FROM cards JOIN notes ON cards.nid=notes.id").fetchone()[0], 2)
            fields = db.execute("SELECT flds FROM notes ORDER BY id").fetchone()[0]
            self.assertIn("&lt;script&gt;", fields)
            self.assertEqual(len(fields.split("\x1f")), 6)
            db.close()

    def test_filters_do_not_count_unassessed_as_overdue(self):
        items = [self.item(), self.item("stable") | {"state": "stable", "due_at": 10}, self.item("paused") | {"paused": True}]
        self.assertEqual([i["term"] for i in filter_items(items, "due", 20)], ["stable"])
        self.assertEqual([i["term"] for i in filter_items(items, "unassessed", 20)], ["products"])
