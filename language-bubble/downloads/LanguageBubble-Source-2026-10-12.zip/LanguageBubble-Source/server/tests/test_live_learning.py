import json
import tempfile
import time
import unittest
from unittest.mock import patch
from uuid import uuid4
from sync_store import SyncStore
from test_sync import capture_op

class LiveLearningTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = SyncStore(self.directory.name, live_learning=True)
        self.user = self.store.account('Mac')['user_id']
    def tearDown(self): self.directory.cleanup()
    def add(self, text='get the ball rolling'):
        op = capture_op(text)
        op['capture'].update(is_mock=False, result='开始行动', explanation='开始推进工作',
            surrounding_text='We should get the ball rolling on the launch plan.', source_app='Safari')
        self.store.push(self.user, 0, [op])
        return op
    def claim(self):
        with patch('sync_store.time.time', return_value=time.time() + 120): return self.store.claim_plan()
    def result(self, job):
        identifier = json.loads(job['snapshot'])['records'][0]['learning_id']
        return {'title': '启动会议练习', 'explanation': '根据 get the ball rolling 练习工作沟通。',
                'tasks': [dict(learning_id=identifier, skill=s, instruction='结合原场景练习',
                    prompt='How can we get the ball rolling?', answer='我们怎么开始行动？')
                    for s in ['reading', 'listening', 'speaking', 'writing']]}
    def plan(self):
        with self.store.connection() as db:
            row = self.store.entity(db, self.user, 'plan', 'current')
            return None if row['deleted'] else json.loads(row['data'])
    def test_queries_coalesce_bounded_evidence_and_persist_shared_plan(self):
        for i in range(8): self.add('expression ' + str(i))
        self.assertEqual(self.plan()['status'], 'pending')
        job = self.claim()
        self.assertIsNone(self.claim())
        records = json.loads(job['snapshot'])['records']
        self.assertEqual(len(records), 6)
        self.assertEqual(records[0]['source_app'], 'Safari')
        self.assertIn('original_context', records[0])
        self.assertTrue(self.store.finish_plan(job, self.result(job)))
        self.assertFalse(self.plan()['is_mock'])
        self.assertTrue(all(t['material_source'] == 'generated' for t in self.plan()['tasks']))
        reopened = SyncStore(self.directory.name, live_learning=True)
        self.assertEqual(reopened.pull(self.user, 0), self.store.pull(self.user, 0))
        self.assertEqual(reopened.pull(reopened.account('Other')['user_id'], 0)['changes'], [])
    def test_restart_retries_failure_and_explicit_retry_without_mock(self):
        self.add()
        self.claim()
        self.store = SyncStore(self.directory.name, live_learning=True)
        for _ in range(3):
            job = self.claim()
            self.assertIsNotNone(job)
            self.store.finish_plan(job)
        self.assertEqual(self.plan()['status'], 'failed')
        self.assertFalse(self.plan()['is_mock'])
        self.assertEqual(self.plan()['tasks'], [])
        self.store.retry_plan(self.user)
        self.assertEqual(self.plan()['status'], 'pending')
        self.assertIsNotNone(self.claim())
    def test_delete_during_generation_discards_answer_and_scrubs_source(self):
        op = self.add('private phrase')
        job = self.claim()
        self.store.push(self.user, 0, [{'op_id': str(uuid4()), 'entity_id': op['entity_id'], 'action': 'capture.delete'}])
        self.assertFalse(self.store.finish_plan(job, self.result(job)))
        self.assertIsNone(self.plan())
        self.assertNotIn('private phrase', json.dumps(self.store.pull(self.user, 0)))
        with self.store.connection() as db:
            self.assertEqual(db.execute('SELECT count(*) FROM plan_jobs').fetchone()[0], 0)
    def test_goal_capture_pause_clear_invalidate_inflight_result(self):
        for action in ['goal', 'capture', 'pause', 'clear']:
            with self.subTest(action=action):
                self.add(action)
                job = self.claim()
                if action == 'goal':
                    profile = json.loads(job['snapshot'])['profile'] | {'goal': 'ielts'}
                    self.store.push(self.user, 0, [{'op_id': str(uuid4()), 'entity_id': profile['id'], 'action': 'profile.put', 'profile': profile}])
                elif action == 'capture': self.add('new evidence')
                elif action == 'pause':
                    identifier = json.loads(job['snapshot'])['records'][0]['learning_id']
                    self.store.push(self.user, 0, [{'op_id': str(uuid4()), 'entity_id': identifier, 'action': 'learning.pause', 'paused': True}])
                else: self.store.clear(self.user)
                self.assertFalse(self.store.finish_plan(job, self.result(job)))
    def test_review_history_changes_generation_input(self):
        self.add()
        job = self.claim()
        self.store.finish_plan(job, self.result(job))
        learning_id = json.loads(job['snapshot'])['records'][0]['learning_id']
        identifier = str(uuid4())
        self.store.push(self.user, 0, [{'op_id': str(uuid4()), 'entity_id': identifier, 'action': 'review.put',
            'review': {'id': identifier, 'learning_id': learning_id, 'rating': 'again'}}])
        next_job = self.claim()
        self.assertEqual(json.loads(next_job['snapshot'])['records'][0]['reviews'], 1)
        self.assertNotEqual(next_job['revision'], job['revision'])
    def test_invalid_sources_skills_and_blank_answers_fail_closed(self):
        self.add()
        job = self.claim()
        for mutation in ['id', 'skill', 'blank']:
            raw = self.result(job)
            if mutation == 'id': raw['tasks'][0]['learning_id'] = str(uuid4())
            elif mutation == 'skill': raw['tasks'][0]['skill'] = 'writing'
            else: raw['tasks'][0]['answer'] = '   '
            with self.assertRaises(ValueError): self.store.finish_plan(job, raw)
        self.assertEqual(self.plan()['status'], 'pending')
    def test_manual_retries_do_not_reset_running_job(self):
        self.add()
        job = self.claim()
        for _ in range(4): self.store.retry_plan(self.user)
        self.assertTrue(self.store.finish_plan(job, self.result(job)))

    def test_duplicate_expression_keeps_the_exact_scene_used_by_ai(self):
        self.add()
        newest = self.add()
        job = self.claim()
        self.assertEqual(json.loads(job['snapshot'])['records'][0]['capture_id'], newest['entity_id'])
        self.store.finish_plan(job, self.result(job))
        self.assertTrue(all(t['capture_id'] == newest['entity_id'] for t in self.plan()['tasks']))
