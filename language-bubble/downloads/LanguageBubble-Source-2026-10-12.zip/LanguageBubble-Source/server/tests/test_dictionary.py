import csv
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from dictionary import lookup, parse_groups


class DictionaryTests(unittest.TestCase):
    def test_all_pos_and_domain_notes_are_preserved_without_mislabeling(self):
        self.assertEqual(parse_groups(r"vt. 冲淡, 稀释\na. 淡的, 稀释的"), [
            {"pos": "vt.", "meanings": ["冲淡, 稀释"]},
            {"pos": "adj.", "meanings": ["淡的, 稀释的"]},
        ])
        groups = parse_groups("n. 框\nvt. 设计\n[计] 框架, 帧\nn. 体格\nn. 框")
        self.assertEqual(groups[0], {"pos": "n.", "meanings": ["框", "体格"]})
        self.assertEqual(groups[-1], {"pos": "", "meanings": ["[计] 框架, 帧"]})
        self.assertEqual(parse_groups("vt. & vi. 稀释")[0]["pos"], "vt. & vi.")
        self.assertEqual(parse_groups(r"n. 框\r\nvt. 设计"), parse_groups("n. 框\nvt. 设计"))

    def test_import_exact_lookup_language_and_missing_database(self):
        with tempfile.TemporaryDirectory() as folder:
            source, destination = Path(folder) / "test.csv", Path(folder) / "test.sqlite3"
            with source.open("w") as stream:
                writer = csv.writer(stream)
                writer.writerow(["word", "phonetic", "translation", "definition"])
                writer.writerow(["frame", "freɪm", r"n. 框\nvt. 设计", r"n. framework\nv. construct"])
            spec = importlib.util.spec_from_file_location("import_dictionary", Path(__file__).resolve().parents[2] / "scripts/import_dictionary.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            with patch.dict(os.environ, {"ECDICT_PATH": str(destination)}):
                self.assertEqual(lookup("frame")["status"], "unavailable")
                module.build(source, destination)
                entry = lookup(" Frame ")["entry"]
                self.assertEqual([g["pos"] for g in entry["groups"]], ["n.", "vt."])
                self.assertEqual(lookup("frame", "en")["entry"]["groups"][1]["meanings"], ["construct"])
                self.assertEqual(lookup("frame", "ja")["status"], "unsupported")
                self.assertEqual(lookup("unknown")["status"], "not_found")
                self.assertEqual(lookup("frame'; DROP TABLE entries; --")["status"], "unsupported")
                destination.write_text("corrupt")
                self.assertEqual(lookup("frame")["status"], "unavailable")
