"""Exercise the real app lifecycle and offline fixtures, never a live AI provider."""
import asyncio
import json
import os
from pathlib import Path
from uuid import uuid4

import httpx
from dotenv import load_dotenv

from main import app


async def run() -> int:
    load_dotenv(Path(__file__).with_name(".env"), override=True)
    os.environ["AI_MODE"] = "mock"
    token = os.environ.get("CONTEXT_CLIENT_TOKEN")
    if not token:
        print(json.dumps({"passed": False, "reason": "Missing local client token"}))
        return 1
    passed = True
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://local-test") as client:
            for label, endpoint, source in [
                ("translation", "translate", "It is a work in progress."),
                ("grammar_error", "check", "I am agree with you."),
                ("correct_sentence", "check", "I agree with you."),
                ("unknown_sentence", "check", "An unlisted fixture."),
            ]:
                response = await client.post("/v1/" + endpoint,
                    headers={"Authorization": "Bearer " + token},
                    json={"text": source, "request_id": str(uuid4())})
                result = response.json()
                valid = response.status_code == 200 and result.get("is_mock") is True
                if label == "translation":
                    valid &= result.get("translation") == "这件事还在完善中。"
                elif label == "grammar_error":
                    issues = result.get("issues", [])
                    valid &= len(issues) == 1 and source.replace(issues[0]["original"], issues[0]["replacement"]) == "I agree with you."
                else:
                    valid &= result.get("complete") is (label == "correct_sentence") and result.get("issues") == []
                passed &= valid
                print(json.dumps({"case": label, "ai_mode": "mock", "http_status": response.status_code, "passed": valid}))
    print(json.dumps({"passed": passed, "ai_mode": "mock", "live_ai_called": False}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
