from __future__ import annotations

import os
import secrets
import time
import json
import asyncio
from articles import source_snapshot, validate_articles, list_articles, save_articles, chat_snapshot, save_answer, ArticleAnswer, VocabularyLevel, VOCABULARY_LEVELS
from exporter import export, filter_items
from collections import defaultdict, deque
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, ConfigDict, Field, model_validator
from dictionary import DictionaryEntry, ContextMeaning

router = APIRouter(prefix="/v2")
bearer = HTTPBearer(auto_error=False)
pair_attempts: dict[str, deque] = defaultdict(deque)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class DeviceRequest(StrictModel):
    device_name: str = Field(min_length=1, max_length=80)


class PairRequest(DeviceRequest):
    code: str = Field(min_length=12, max_length=12, pattern=r"^[a-fA-F0-9]{12}$")


class Capture(StrictModel):
    id: UUID
    kind: Literal["translation", "writing"]
    source: str = Field(min_length=1, max_length=6000)
    result: str = Field(max_length=12000)
    explanation: str = Field(max_length=4000)
    created_at: float = Field(ge=0)
    category: str | None = Field(default=None, max_length=40)
    original_span: str | None = Field(default=None, max_length=500)
    replacement: str | None = Field(default=None, max_length=700)
    source_app: str | None = Field(default=None, max_length=200)
    source_url: str | None = Field(default=None, max_length=4000)
    surrounding_text: str | None = Field(default=None, max_length=12000)
    asset_ids: list[UUID] = Field(default_factory=list, max_length=5)
    is_mock: bool = False
    source_language: str | None = Field(default=None, max_length=20)
    target_language: str | None = Field(default=None, max_length=20)
    dictionary: DictionaryEntry | None = None
    context_meaning: ContextMeaning | None = None

    @model_validator(mode="after")
    def validate_content(self):
        if not self.source.strip():
            raise ValueError("Empty source")
        if self.source_url and not self.source_url.startswith(("https://", "http://")):
            raise ValueError("Source URL must use HTTP or HTTPS")
        return self


class Review(StrictModel):
    id: UUID
    learning_id: UUID
    rating: Literal["again", "hard", "good", "easy"]

class StudyProfile(StrictModel):
    id: Literal["00000000-0000-0000-0000-000000000001"]
    goal: Literal["daily", "work", "ielts", "gaokao", "grammar"]
    daily_minutes: int = Field(ge=5, le=60)
    primary_language: Literal["zh", "en", "es", "pt", "fr", "de", "ja", "ko"] = "zh"
    secondary_language: Literal["zh", "en", "es", "pt", "fr", "de", "ja", "ko"] = "en"

    @model_validator(mode="after")
    def distinct_languages(self):
        if self.primary_language == self.secondary_language: raise ValueError("Choose two different target languages")
        return self


class Operation(StrictModel):
    op_id: UUID
    action: Literal["capture.put", "capture.delete", "review.put", "learning.pause", "profile.put", "milestone.ack"]
    entity_id: UUID
    capture: Capture | None = None
    review: Review | None = None
    paused: bool | None = None
    profile: StudyProfile | None = None

    @model_validator(mode="after")
    def payload_matches(self):
        if self.action == "capture.put" and (not self.capture or self.capture.id != self.entity_id):
            raise ValueError("Capture identity required")
        if self.action == "review.put" and (not self.review or self.review.id != self.entity_id):
            raise ValueError("Review identity required")
        if self.action == "learning.pause" and self.paused is None:
            raise ValueError("Pause value required")
        if self.action == "profile.put" and (not self.profile or str(self.entity_id) != self.profile.id):
            raise ValueError("Profile required")
        return self


class PushRequest(StrictModel):
    epoch: int = Field(ge=0)
    operations: list[Operation] = Field(min_length=1, max_length=100)


async def device_session(request: Request, credentials: HTTPAuthorizationCredentials | None = Depends(bearer)):
    session = request.app.state.db.session(credentials.credentials) if credentials else None
    if not session:
        raise HTTPException(401, "Device session is invalid or revoked")
    return session


class ArticleRequest(StrictModel):
    request_id: UUID
    capture_ids: list[UUID] = Field(default_factory=list, max_length=40)
    topic: str = Field(default="", max_length=200)
    word_count: int = Field(default=400, ge=200, le=2000, strict=True)
    vocabulary_levels: list[VocabularyLevel] = Field(default_factory=lambda: list(VOCABULARY_LEVELS), min_length=1, max_length=3)
    saved_word_scope: Literal["all", "half", "recent"] = "all"
    instructions: str = Field(default="", max_length=1000)


class ArticleChatRequest(StrictModel):
    request_id: UUID
    question: str = Field(min_length=1, max_length=2000)
    primary_language: Literal["zh", "en", "es", "pt", "fr", "de", "ja", "ko"] = "zh"


# Prevent duplicate concurrent model calls without holding a SQLite transaction
# across network I/O. Persistent request IDs also make completed retries safe.
article_busy: set[tuple[str, str]] = set()


@router.get("/articles")
async def articles(request: Request, session=Depends(device_session)):
    return {"articles": await asyncio.to_thread(list_articles, request.app.state.db, session["user_id"])}


@router.post("/articles/generate")
async def generate_articles(body: ArticleRequest, request: Request, session=Depends(device_session)):
    db, user = request.app.state.db, session["user_id"]
    request_id = str(body.request_id)
    existing = [a for a in await asyncio.to_thread(list_articles, db, user) if a["generation_id"] == request_id]
    if existing: return {"articles": existing}
    if request.app.state.provider.mode != "live":
        raise HTTPException(503, "Article generation requires the live AI service")
    key = (user, "generate")
    if key in article_busy: raise HTTPException(429, "Article generation is already in progress")
    article_busy.add(key)
    try:
        snapshot = await asyncio.to_thread(source_snapshot, db, user, [str(i) for i in body.capture_ids],
                                          body.topic.strip(), body.word_count, body.vocabulary_levels,
                                          body.saved_word_scope, body.instructions.strip())
        raw = await request.app.state.provider.generate("article", json.dumps(snapshot, ensure_ascii=False))
        try: values = validate_articles(raw, snapshot, request_id)
        except ValueError: raise HTTPException(502, "Article generation returned invalid content; retry") from None
        values = await asyncio.to_thread(save_articles, db, user, snapshot, values, request_id)
        return {"articles": values}
    finally:
        article_busy.discard(key)


@router.post("/articles/{identifier}/chat")
async def article_chat(identifier: UUID, body: ArticleChatRequest, request: Request, session=Depends(device_session)):
    db, user = request.app.state.db, session["user_id"]
    if not body.question.strip(): raise HTTPException(422, "Question cannot be blank")
    article, evidence = await asyncio.to_thread(chat_snapshot, db, user, str(identifier))
    request_id = str(body.request_id)
    if any(m["id"] == request_id for m in article["messages"]): return article
    if request.app.state.provider.mode != "live": raise HTTPException(503, "Article chat requires the live AI service")
    key = (user, str(identifier))
    if key in article_busy: raise HTTPException(429, "A reply is already in progress")
    article_busy.add(key)
    try:
        payload = {"article": {k: article[k] for k in ["title", "sections", "expressions"]},
                   "evidence": evidence, "history": article["messages"][-20:],
                   "question": body.question.strip(), "primary_language": body.primary_language}
        raw = await request.app.state.provider.generate("article_chat", json.dumps(payload, ensure_ascii=False))
        try: answer = ArticleAnswer.model_validate(raw).answer
        except ValueError: raise HTTPException(502, "The AI reply was invalid; retry") from None
        return await asyncio.to_thread(save_answer, db, user, article, request_id, body.question.strip(), answer)
    finally:
        article_busy.discard(key)


@router.post("/accounts")
async def account(body: DeviceRequest, request: Request, credentials: HTTPAuthorizationCredentials | None = Depends(bearer)):
    expected = os.environ.get("CONTEXT_CLIENT_TOKEN", "")
    if not expected or not credentials or not secrets.compare_digest(credentials.credentials, expected):
        raise HTTPException(401, "Local beta bootstrap token required")
    return request.app.state.db.account(body.device_name)


@router.post("/pair-codes")
async def pair_code(request: Request, session=Depends(device_session)):
    return request.app.state.db.pair_code(session["user_id"])


@router.post("/pair")
async def pair(body: PairRequest, request: Request):
    host = request.client.host if request.client else "local"
    history = pair_attempts[host]
    now = time.monotonic()
    while history and now - history[0] > 60:
        history.popleft()
    if len(history) >= 10:
        raise HTTPException(429, "Too many pairing attempts")
    history.append(now)
    return request.app.state.db.pair(body.code, body.device_name)


@router.post("/logout")
async def logout(request: Request, session=Depends(device_session)):
    request.app.state.db.revoke(session["id"])
    return {"revoked": True}


@router.post("/plan/retry")
async def retry_plan(request: Request, session=Depends(device_session)):
    return request.app.state.db.retry_plan(session["user_id"])


@router.post("/sync/push")
async def push(body: PushRequest, request: Request, session=Depends(device_session)):
    return request.app.state.db.push(session["user_id"], body.epoch, [op.model_dump(mode="json", exclude_none=True) for op in body.operations])


@router.get("/sync/pull")
async def pull(request: Request, cursor: int = 0, session=Depends(device_session)):
    if cursor < 0:
        raise HTTPException(422, "Invalid cursor")
    return request.app.state.db.pull(session["user_id"], cursor)


@router.post("/clear")
async def clear(request: Request, session=Depends(device_session)):
    return request.app.state.db.clear(session["user_id"])


@router.put("/assets/{identifier}")
async def upload(identifier: UUID, capture_id: UUID, request: Request, session=Depends(device_session)):
    mime = request.headers.get("content-type", "")
    if mime not in {"image/png", "image/jpeg"}:
        raise HTTPException(415, "PNG or JPEG required")
    body = bytearray()
    async for chunk in request.stream():
        body.extend(chunk)
        if len(body) > 8 * 1024 * 1024:
            raise HTTPException(413, "Attachment exceeds 8 MB")
    if not (mime == "image/png" and body.startswith(b"\x89PNG\r\n\x1a\n") or mime == "image/jpeg" and body.startswith(b"\xff\xd8\xff")):
        raise HTTPException(415, "Image signature does not match")
    return request.app.state.db.upload(session["user_id"], str(identifier), str(capture_id), mime, bytes(body))


@router.get("/assets/{identifier}")
async def asset(identifier: UUID, request: Request, session=Depends(device_session)):
    mime, body = request.app.state.db.asset(session["user_id"], str(identifier))
    return Response(body, media_type=mime, headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@router.get("/export/{format}")
async def export_learning(format: Literal["csv", "txt", "apkg"], request: Request,
                          state: Literal["all", "unassessed", "learning", "stable", "due", "paused"] = "all",
                          session=Depends(device_session)):
    with request.app.state.db.connection() as db:
        rows = db.execute("SELECT kind,id,data FROM entities WHERE user_id=? AND deleted=0 AND kind IN ('learning','capture')", (session["user_id"],)).fetchall()
        items = [json.loads(r["data"]) for r in rows if r["kind"] == "learning"]
        captures = {r["id"]: json.loads(r["data"]) for r in rows if r["kind"] == "capture"}
    body, mime = export(filter_items(items, state, time.time()), captures, format)
    return Response(body, media_type=mime, headers={"Cache-Control": "no-store", "Content-Disposition": f'attachment; filename="language-bubble.{format}"'})
