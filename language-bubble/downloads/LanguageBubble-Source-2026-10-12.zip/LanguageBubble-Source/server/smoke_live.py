"""Explicit live-model smoke test with synthetic text and two isolated local device sessions.

Run manually: .venv/bin/python smoke_live.py
Never prints credentials or provider error bodies. Does not read users' saved captures.
"""
import asyncio
import json
import os
from pathlib import Path
import time
from uuid import uuid4

import httpx
from dotenv import load_dotenv


async def main():
    load_dotenv(Path(__file__).with_name(".env"))
    bootstrap = os.environ.get("CONTEXT_CLIENT_TOKEN", "")
    assert bootstrap, "Configure the private local service token first"
    async with httpx.AsyncClient(base_url="http://127.0.0.1:8788", timeout=65) as client:
        async def call(method, path, token=None, **kwargs):
            response = await client.request(method, path, headers={"Authorization": "Bearer " + token} if token else {}, **kwargs)
            assert response.status_code == 200, f"Local endpoint {path} returned HTTP {response.status_code}"
            return response.json()

        assert (await call("GET", "/health"))["ai_mode"] == "live", "Service must be explicitly in live mode"
        first = await call("POST", "/v2/accounts", bootstrap, json={"device_name": "Live smoke Mac fixture"})
        code = (await call("POST", "/v2/pair-codes", first["token"]))["code"]
        second = await call("POST", "/v2/pair", json={"code": code, "device_name": "Live smoke iPhone fixture"})
        assert first["user_id"] == second["user_id"] and first["token"] != second["token"]
        started = time.monotonic()
        text = "We are on the same page."
        context = "Before shipping the new feature, let us make sure we are on the same page."
        translated = await call("POST", "/v1/translate", first["token"], json={
            "text": text, "surrounding_text": context, "target_language": "zh", "request_id": str(uuid4()),
        })
        assert translated.get("is_mock", False) is False
        assert translated["translation"] and "Mock" not in translated["translation"]
        record_id = str(uuid4())
        record = {"id": record_id, "kind": "translation", "source": text, "result": translated["translation"],
                  "explanation": translated["explanation"], "created_at": time.time(), "is_mock": False,
                  "surrounding_text": context, "source_app": "Live model test fixture", "source_language": "en", "target_language": "zh"}
        await call("POST", "/v2/sync/push", first["token"], json={"epoch": first["epoch"], "operations": [
            {"op_id": str(uuid4()), "action": "capture.put", "entity_id": record_id, "capture": record}]})
        changes = (await call("GET", "/v2/sync/pull", second["token"]))["changes"]
        saved = [c["data"] for c in changes if c["kind"] == "capture" and c["id"] == record_id][-1]
        assert saved["result"] == translated["translation"] and saved["surrounding_text"] == context
        item = [c["data"] for c in changes if c["kind"] == "learning"][-1]
        assert item["is_mock"] is False and item["example"] == context
        review_id = str(uuid4())
        await call("POST", "/v2/sync/push", second["token"], json={"epoch": second["epoch"], "operations": [
            {"op_id": str(uuid4()), "action": "review.put", "entity_id": review_id,
             "review": {"id": review_id, "learning_id": item["id"], "rating": "good"}}]})
        returned = (await call("GET", "/v2/sync/pull", first["token"]))["changes"]
        assert any(c["kind"] == "review" and c["id"] == review_id for c in returned)
        sentence = "She don't like coffee."
        checked = await call("POST", "/v1/check", second["token"], json={"text": sentence, "request_id": str(uuid4())})
        assert checked.get("is_mock", False) is False and checked["complete"] and len(checked["issues"]) == 1
        issue = checked["issues"][0]
        corrected = sentence.replace(issue["original"], issue["replacement"])
        assert corrected == "She doesn't like coffee."
        correct = await call("POST", "/v1/check", second["token"], json={"text": corrected, "request_id": str(uuid4())})
        assert correct["complete"] and not correct["issues"]
        print(json.dumps({"ok": True, "ai_mode": "live", "translation": translated["translation"],
              "corrected": corrected, "independent_devices": 2, "context_preserved": True, "review_returned": True,
              "elapsed_seconds": round(time.monotonic() - started, 1)}, ensure_ascii=False))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (AssertionError, httpx.HTTPError) as error:
        # HTTP errors can contain request URLs; only print a controlled assertion or the error class.
        print(json.dumps({"ok": False, "error": str(error) if isinstance(error, AssertionError) else type(error).__name__}))
        raise SystemExit(1) from None
