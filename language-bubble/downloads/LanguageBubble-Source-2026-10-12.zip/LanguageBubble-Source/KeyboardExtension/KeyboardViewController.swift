import UIKit

final class KeyboardViewController: UIInputViewController {
    private let rootStack = UIStackView()
    private let rowsStack = UIStackView()
    private let status = UILabel()
    private let applyButton = UIButton(type: .system)
    private let pauseButton = UIButton(type: .system)
    private var shift = false
    private var numbers = false
    private var latest: TextSnapshot?
    private var version = 0
    private var debounce: Task<Void, Never>?
    private var network: Task<Void, Never>?
    private var pending: (TextSnapshot, Int)?
    private var suggestion: (snapshot: TextSnapshot, text: String, issue: WritingIssue)?
    private var sentenceAnchor = ""
    private var recordID = UUID()
    private var applying = false
    private var visible = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGray5
        rootStack.axis = .vertical; rootStack.spacing = 8
        rootStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(rootStack)
        NSLayoutConstraint.activate([
            rootStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            rootStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -6),
            rootStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 6),
            rootStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -6)
        ])
        let height = view.heightAnchor.constraint(equalToConstant: 310); height.priority = .defaultHigh; height.isActive = true
        status.font = .systemFont(ofSize: 12); status.numberOfLines = 3
        status.text = "Language Bubble · 英文输入"
        let header = UIStackView(); header.spacing = 8; header.alignment = .center
        pauseButton.setImage(UIImage(systemName: "pause.circle"), for: .normal)
        pauseButton.accessibilityLabel = "暂停或开启自动检查"
        pauseButton.widthAnchor.constraint(equalToConstant: 38).isActive = true
        pauseButton.heightAnchor.constraint(equalToConstant: 44).isActive = true
        pauseButton.addTarget(self, action: #selector(toggleAnalysis), for: .touchUpInside)
        applyButton.setTitle("应用", for: .normal); applyButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        applyButton.isHidden = true
        applyButton.widthAnchor.constraint(equalToConstant: 42).isActive = true
        applyButton.heightAnchor.constraint(equalToConstant: 44).isActive = true
        applyButton.addTarget(self, action: #selector(applySuggestion), for: .touchUpInside)
        header.addArrangedSubview(pauseButton); header.addArrangedSubview(status); header.addArrangedSubview(applyButton)
        header.heightAnchor.constraint(equalToConstant: 64).isActive = true
        rootStack.addArrangedSubview(header)
        rowsStack.axis = .vertical; rowsStack.spacing = 7; rowsStack.distribution = .fillEqually
        rootStack.addArrangedSubview(rowsStack)
        rebuildKeys()
    }

    override func viewDidAppear(_ animated: Bool) { super.viewDidAppear(animated); visible = true; updatePermissionStatus(); changed() }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated); visible = false; version += 1
        debounce?.cancel(); network?.cancel(); pending = nil; suggestion = nil; latest = nil
    }
    override func textDidChange(_ textInput: (any UITextInput)?) { if !applying { changed() } }
    override func selectionDidChange(_ textInput: (any UITextInput)?) { if !applying { changed() } }

    private func snapshot() -> TextSnapshot {
        TextSnapshot(document: textDocumentProxy.documentIdentifier,
                     before: textDocumentProxy.documentContextBeforeInput ?? "",
                     selected: textDocumentProxy.selectedText ?? "",
                     after: textDocumentProxy.documentContextAfterInput ?? "")
    }

    private func changed() {
        guard visible else { return }
        let current = snapshot()
        guard current != latest else { return }
        latest = current; version += 1; suggestion = nil; applyButton.isHidden = true; pending = nil
        debounce?.cancel()
        guard hasFullAccess else { updatePermissionStatus(); return }
        guard let settings = try? SharedJournal.live().state().preferences,
              settings.automaticChecking else { updatePermissionStatus(); return }
        guard current.analysisText != nil else { status.text = "Language Bubble · 输入一句英文后检查"; return }
        status.text = "Language Bubble · 等待输入完成"
        let revision = version
        debounce = Task { [weak self] in
            do { try await Task.sleep(for: .milliseconds(1500)) } catch { return }
            guard let self, self.visible, self.version == revision else { return }
            self.submit(current, revision: revision)
        }
    }

    private func submit(_ current: TextSnapshot, revision: Int) {
        guard hasFullAccess, visible, current == snapshot(), version == revision,
              let text = current.analysisText else { return }
        if network != nil { pending = (current, revision); return }
        // A sentence's leading context is stable as the user edits it; new sentences get new identities.
        let prefix = current.before.range(of: text, options: .backwards).map { String(current.before[..<$0.lowerBound]) } ?? ""
        let anchor = current.document.uuidString + "|" + prefix
        if sentenceAnchor != anchor { sentenceAnchor = anchor; recordID = UUID() }
        let id = recordID
        status.text = "Language Bubble · 正在检查…"
        network = Task { [weak self] in
            guard let self else { return }
            defer {
                self.network = nil
                if let next = self.pending {
                    self.pending = nil
                    self.submit(next.0, revision: next.1)
                }
            }
            do {
                let journal = try SharedJournal.live()
                let (preferences, ticket) = try journal.capture(id: id)
                guard preferences.automaticChecking, self.hasFullAccess else { self.updatePermissionStatus(); return }
                let result = try await AIClient(preferences: preferences).check(text, id: id)
                try Task.checkCancellation()
                let fresh = try journal.state()
                guard self.visible, self.hasFullAccess, self.version == revision, self.snapshot() == current,
                      fresh.preferences.automaticChecking,
                      fresh.consentRevision == ticket.consentRevision else { return }
                guard let issue = result.actionable(in: text) else {
                    if result.isMock == true {
                        self.status.text = result.complete ? "AI Mock · 正确句子样例" : "AI Mock · 此输入暂无检查样例"
                    } else {
                        self.status.text = result.complete ? "Language Bubble · 未发现明确错误" : "Language Bubble · 等句子完整后再检查"
                    }
                    return
                }
                self.suggestion = (current, text, issue)
                let corrected = text.replacingOccurrences(of: issue.original, with: issue.replacement)
                let replacement = WritingIssue(original: text, replacement: corrected, category: issue.category,
                                               explanation: issue.explanation, confidence: issue.confidence)
                self.applyButton.isHidden = current.safeReplacement(for: replacement) == nil
                self.status.text = "\(issue.original) → \(issue.replacement)\n\(issue.explanation)"
                let record = CapturedRecord(id: ticket.id, epoch: ticket.epoch, kind: .writing, source: text,
                    result: corrected, explanation: issue.explanation, category: issue.category,
                    originalSpan: issue.original, replacement: issue.replacement)
                _ = try journal.enqueue(record, ticket: ticket)
            } catch {
                if self.version == revision && self.visible && !Task.isCancelled {
                    self.status.text = error.localizedDescription
                }
            }
        }
    }

    @objc private func toggleAnalysis() {
        guard hasFullAccess else { updatePermissionStatus(); return }
        do {
            let journal = try SharedJournal.live()
            try journal.updatePreferences { $0.automaticChecking.toggle() }
            version += 1; pending = nil; debounce?.cancel(); network?.cancel(); latest = nil
            updatePermissionStatus(); changed()
        } catch { status.text = error.localizedDescription }
    }

    private func updatePermissionStatus() {
        guard hasFullAccess else { status.text = "Language Bubble · 基本输入可用\n请允许完全访问以启用 AI 检查"; return }
        guard let prefs = try? SharedJournal.live().state().preferences else { status.text = "请先在主 App 中完成设置"; return }
        pauseButton.setImage(UIImage(systemName: prefs.automaticChecking ? "pause.circle" : "play.circle"), for: .normal)
        status.text = prefs.automaticChecking ? "Language Bubble · 自动检查已开启" : "Language Bubble · 自动检查已暂停"
    }

    @objc private func applySuggestion() {
        guard let suggestion, suggestion.snapshot == snapshot() else { changed(); return }
        let corrected = suggestion.text.replacingOccurrences(of: suggestion.issue.original, with: suggestion.issue.replacement)
        let issue = WritingIssue(original: suggestion.text, replacement: corrected, category: suggestion.issue.category,
                                 explanation: suggestion.issue.explanation, confidence: suggestion.issue.confidence)
        guard let replacement = snapshot().safeReplacement(for: issue) else { return }
        applying = true
        for _ in 0..<replacement.deleteCount { textDocumentProxy.deleteBackward() }
        textDocumentProxy.insertText(replacement.insert)
        applying = false
        version += 1; debounce?.cancel(); pending = nil; latest = snapshot(); self.suggestion = nil
        applyButton.isHidden = true; status.text = "Language Bubble · 已应用修改"
    }

    private func rebuildKeys() {
        rowsStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let layouts: [[String]]
        if numbers {
            layouts = ["1234567890".map { String($0) }, ["-", "/", ":", ";", "(", ")", "$", "&", "@", "\""], ["ABC", ".", ",", "?", "!", "'", "⌫"]]
        } else {
            let top = "qwertyuiop".map { String($0) }
            let middle = "asdfghjkl".map { String($0) }
            let bottom = ["⇧"] + "zxcvbnm".map { String($0) } + ["⌫"]
            layouts = [top, middle, bottom]
        }
        for keys in layouts { addRow(keys) }
        addRow([numbers ? "ABC" : "123", "🌐", "space", "return"])
    }

    private func addRow(_ keys: [String]) {
        let row = UIStackView(); row.spacing = 5
        row.distribution = keys.contains("space") ? .fill : .fillEqually
        var rowButtons: [(String, UIButton)] = []
        for key in keys {
            let button = UIButton(type: .system)
            button.backgroundColor = key == "space" || key.count == 1 && key != "⌫" && key != "⇧" && key != "🌐" ? .systemBackground : .systemGray3
            button.layer.cornerRadius = 6; button.setTitleColor(.label, for: .normal)
            button.setTitle(shift && !numbers && key.count == 1 ? key.uppercased() : key, for: .normal)
            if let symbol = ["🌐": "globe", "⇧": shift ? "shift.fill" : "shift", "⌫": "delete.left"][key] {
                button.setTitle(nil, for: .normal)
                button.setImage(UIImage(systemName: symbol), for: .normal)
            }
            button.titleLabel?.font = .systemFont(ofSize: key.count > 1 ? 14 : 21)
            button.accessibilityLabel = ["⌫": "删除", "⇧": "大写", "🌐": "切换键盘", "space": "空格", "return": "换行"][key] ?? key
            if key == "🌐" {
                button.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)
            } else {
                button.addAction(UIAction { [weak self] _ in self?.press(key) }, for: .touchUpInside)
            }
            row.addArrangedSubview(button)
            rowButtons.append((key, button))
        }
        if let unit = rowButtons.first?.1, keys.contains("space") {
            for (key, button) in rowButtons.dropFirst() {
                button.widthAnchor.constraint(equalTo: unit.widthAnchor, multiplier: key == "space" ? 3.4 : 1.2).isActive = true
            }
        }
        rowsStack.addArrangedSubview(row)
    }

    private func press(_ key: String) {
        switch key {
        case "⇧": shift.toggle(); rebuildKeys(); return
        case "123", "ABC", "#+=": numbers.toggle(); rebuildKeys(); return
        case "⌫": textDocumentProxy.deleteBackward()
        case "space": textDocumentProxy.insertText(" ")
        case "return": textDocumentProxy.insertText("\n")
        default:
            textDocumentProxy.insertText(shift && !numbers ? key.uppercased() : key)
            if shift { shift = false; rebuildKeys() }
        }
        changed()
    }
}
