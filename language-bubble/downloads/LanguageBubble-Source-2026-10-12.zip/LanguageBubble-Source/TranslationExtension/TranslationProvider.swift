import SwiftUI
import TranslationUIProvider
import ExtensionKit

@main
final class ContextTranslationProvider: TranslationUIProviderExtension {
    required init() {}
    var body: some TranslationUIProviderExtensionScene {
        TranslationUIProviderSelectedTextScene { context in TranslationSheet(context: context) }
    }
}

@MainActor @Observable
final class TranslationModel {
    var result: TranslationResult?
    var error: String?
    var loading = false
    var saved = false
    var discarded = false
    var syncing = false
    var synced = false
    var syncMessage: String?
    private var source = ""
    private var recordID = UUID()
    private var runID = UUID()

    func load(_ text: String) async {
        if source != text {
            source = text; recordID = UUID(); discarded = false; result = nil; saved = false
            syncing = false; synced = false; syncMessage = nil
        }
        let run = UUID(); runID = run
        loading = true; error = nil
        defer { if runID == run { loading = false } }
        do {
            guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, text.count <= 6000 else {
                throw ContextError.service("请选择 1–6000 字符的词句再试。")
            }
            let journal = try SharedJournal.live()
            let (preferences, ticket) = try journal.capture(id: recordID)
            let translated = try await AIClient(preferences: preferences).translate(text, id: recordID)
            try Task.checkCancellation()
            guard runID == run, source == text else { return }
            result = translated
            if !discarded {
                saved = try journal.enqueue(CapturedRecord(id: ticket.id, epoch: ticket.epoch, kind: .translation,
                    source: text, result: translated.translation, explanation: translated.explanation,
                    dictionary: translated.dictionary, contextMeaning: translated.contextMeaning), ticket: ticket)
                if saved { await syncSavedRecords() }
            }
        } catch is CancellationError { }
        catch { if runID == run && !Task.isCancelled { self.error = error.localizedDescription } }
    }

    func undoSave() {
        do {
            try SharedJournal.live().remove(recordID)
            discarded = true; saved = false; synced = false
            Task { await syncSavedRecords() }
        }
        catch { self.error = error.localizedDescription }
    }

    func syncSavedRecords() async {
        let run = runID
        syncing = true; syncMessage = nil
        defer { if runID == run { syncing = false } }
        do {
            let complete = try await SharedJournal.live().syncPending()
            guard runID == run else { return }
            synced = complete
            if !complete { syncMessage = "已保存在手机，请打开 Language Bubble 完成连接后同步。" }
        } catch {
            guard runID == run, !Task.isCancelled else { return }
            syncMessage = discarded ? "撤销已保存在手机，联网后会继续同步。" : "已保存在手机，暂未同步到其他设备。联网后会继续同步。"
        }
    }
}

struct TranslationSheet: View {
    let context: any TranslationUIProviderContext
    @State private var model = TranslationModel()
    private var source: String { context.inputText.map { String($0.characters) } ?? "" }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack {
                    Label("Language Bubble", systemImage: "character.bubble.fill").font(.headline).foregroundStyle(Color.accentColor)
                    Spacer()
                }
                VStack(alignment: .leading, spacing: 8) {
                    Text("选中的原文").font(.caption).foregroundStyle(.secondary)
                    Text(source).font(source.count < 35 ? .title2.weight(.semibold) : .body).textSelection(.enabled)
                }
                if model.loading {
                    HStack(spacing: 10) { ProgressView(); Text("正在理解这段表达…").foregroundStyle(.secondary) }
                }
                if let result = model.result {
                    VStack(alignment: .leading, spacing: 12) {
                        if result.isMock == true {
                            Label("AI Mock · 测试数据", systemImage: "testtube.2")
                                .font(.caption.weight(.semibold)).foregroundStyle(.orange)
                        }
                        Text(result.translation).font(.title3.weight(.medium)).textSelection(.enabled)
                        if !result.explanation.isEmpty { Text(result.explanation).font(.subheadline).foregroundStyle(.secondary).textSelection(.enabled) }
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(20)
                        .background(Color.accentColor.opacity(0.07), in: RoundedRectangle(cornerRadius: 20))
                    if model.saved {
                        Button(action: model.undoSave) {
                            Label("已保存到记录 · 撤销", systemImage: "checkmark.circle.fill")
                                .frame(maxWidth: .infinity).padding(.vertical, 8)
                        }.buttonStyle(.bordered).accessibilityIdentifier("undoTranslationSave")
                    } else {
                        Label(model.discarded ? "本次不保存" : "仅本次查看 · 未开启保存或记录设置已变更", systemImage: "eye")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if model.syncing {
                        HStack { ProgressView(); Text("正在同步到其他设备…") }.font(.caption)
                    } else if let message = model.syncMessage {
                        Text(message).font(.caption).foregroundStyle(.secondary)
                        Button("重试同步") { Task { await model.syncSavedRecords() } }
                    } else if model.synced {
                        Label(model.discarded ? "撤销已同步" : "已同步到其他设备", systemImage: "checkmark.icloud")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                if let error = model.error {
                    Text(error).font(.subheadline).foregroundStyle(.secondary)
                    Button("重试") { Task { await model.load(source) } }.buttonStyle(.borderedProminent).disabled(model.loading)
                }
            }.padding(24)
        }
        .tint(Color(red: 0.16, green: 0.36, blue: 0.83))
        .task(id: source) {
            if source.count > 180 { context.expandSheet() }
            await model.load(source)
        }
    }
}
