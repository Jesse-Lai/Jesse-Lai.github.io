# App typography

Matches Naive/naive-website-final-cn-font-editor:

- Record list and detail word titles: Literata Medium Italic (native variable font, `wght=500`, optical size follows title size).
- Latin headings: Manrope (`Manrope-wght.ttf`).
- Latin body and controls: Inter Variable (`InterVariable.ttf`).
- Chinese headings: Chill Yunmo Gothic (`ChillYunmoGothic-Regular.otf`, website selection 04).
- Chinese body and controls: Source Han Sans CN (`SourceHanSansCN-Regular.otf`, website selection 03).

The Chinese selections are the defaults in `type-settings.js` and `type-preview.css`.
The OTF files and Manrope are copied unchanged from the website assets. Inter is the
native TTF from Naive/deliverables/Naive-Website-Fonts-2026-09-21/fonts/desktop,
converted there from the same website WOFF2. All four fonts use SIL OFL 1.1;
license texts are included here and in ThirdPartyLicenses.txt.

BubbleTypography registers these process-local fonts before displaying the app,
uses explicit CJK cascades for mixed-language text, and preserves Dynamic Type.
System symbols and the numeric pairing code retain their native font.

Literata is bundled unchanged from Google Fonts (google/fonts/ofl/literata),
with its SIL OFL 1.1 license in Literata-OFL.txt.
