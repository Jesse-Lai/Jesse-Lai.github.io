// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "ContextCore",
    platforms: [.macOS(.v14), .iOS("18.4")],
    products: [.library(name: "ContextCore", targets: ["ContextCore"])],
    targets: [
        .target(name: "ContextCore", path: ".",
                exclude: ["App", "MacApp", "Config", "Context.xcodeproj", "KeyboardExtension", "TranslationExtension", "Resources", "Tests", "build", "docs", "scripts", "server", "README.md", "Client/BubbleStyle.swift", "Client/BubbleTypography.swift", "Client/BubbleLookupView.swift", "Client/BubbleViews.swift", "Client/BubbleStudyViews.swift", "Client/BubbleExportView.swift"],
                sources: ["Shared", "Client/BubbleStore.swift", "Client/BubbleLookup.swift", "Client/SceneImporter.swift"]),
        .testTarget(name: "ContextCoreTests", dependencies: ["ContextCore"], path: "Tests/CoreTests")
    ],
    swiftLanguageModes: [.v5]
)
