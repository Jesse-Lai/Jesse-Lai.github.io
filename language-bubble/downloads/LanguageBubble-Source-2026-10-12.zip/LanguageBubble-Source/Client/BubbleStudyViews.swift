import SwiftUI

struct BubbleGoalView: View {
    @Environment(BubbleStore.self) private var store
    @State private var profile = StudyProfile()
    @State private var saved = false
    var body: some View {
        Form {
            Picker("目前想提高什么", selection: $profile.goal) { ForEach(StudyProfile.goals, id: \.0) { Text(LocalizedStringKey($0.1)).tag($0.0) } }
            Stepper("每天 \(profile.dailyMinutes) 分钟", value: $profile.dailyMinutes, in: 5...60, step: 5)
            Picker("主要翻译为", selection: $profile.primaryLanguage) { ForEach(LanguageRouting.languages, id: \.0) { Text(LocalizedStringKey($0.1)).tag($0.0) } }
            Picker("原文与主要语言相同时翻译为", selection: $profile.secondaryLanguage) { ForEach(LanguageRouting.languages, id: \.0) { Text(LocalizedStringKey($0.1)).tag($0.0) } }
            Text("查询仍是主要入口。学习安排会结合目标，从你已经保存的原文中选取练习材料。").foregroundStyle(.secondary)
            Button("保存并更新安排") { Task { await store.updateProfile(profile); saved = store.error == nil } }.disabled(profile.primaryLanguage == profile.secondaryLanguage)
            if saved { Text("目标已保存，学习页会显示更新后的安排。").foregroundStyle(.secondary) }
            ConnectionStatus()
        }.bubbleListStyle().navigationTitle(BubbleLocalization.text("学习目标")).onAppear { profile = store.state.profile ?? StudyProfile() }
    }
}

struct BubblePlanView: View {
    @Environment(BubbleStore.self) private var store
    @State private var skill = "reading"
    private let skills = [("listening", "听"), ("speaking", "说"), ("reading", "读"), ("writing", "写")]
    var body: some View {
        List {
            if let plan = store.state.plan {
                Section {
                    Text(plan.title).bubbleFont(.title3, weight: .bold)
                    if !plan.explanation.isEmpty { Text(plan.explanation).bubbleFont(.caption).foregroundStyle(.secondary) }
                    if ["pending", "retrying"].contains(plan.status ?? "") {
                        ProgressView(plan.status == "retrying" ? "生成暂未成功，正在重试…" : "正在根据你的记录生成练习…")
                        Text("可以继续查询，生成后会自动同步到两端。").bubbleFont(.caption).foregroundStyle(.secondary)
                    } else if plan.status == "failed" {
                        Text("这次没有生成成功，原记录已保存。")
                        Button("重试生成") { Task { await store.retryPlan() } }.disabled(store.requestingPlan)
                    } else if plan.isMock && store.aiMode == "live" {
                        Button("用我的记录生成 AI 练习") { Task { await store.retryPlan() } }.disabled(store.requestingPlan)
                    } else if !plan.isMock {
                        Label("AI 根据你的记录生成", systemImage: "sparkles").bubbleFont(.caption).foregroundStyle(.secondary).accessibilityIdentifier("liveStudyReady")
                    }
                    Picker("练习", selection: $skill) { ForEach(skills, id: \.0) { Text(LocalizedStringKey($0.1)).tag($0.0) } }.pickerStyle(.segmented)
                }
                ForEach(plan.tasks.filter { $0.skill == skill && store.state.learning[$0.learningId] != nil }) { task in
                    NavigationLink { BubbleExerciseView(task: task) } label: {
                        VStack(alignment: .leading, spacing: 7) {
                            Text(store.state.learning[task.learningId]?.term ?? "原场景练习").bubbleFont(.headline)
                            Text(task.instruction).bubbleFont(.caption).foregroundStyle(.secondary)
                        }
                    }.accessibilityIdentifier("study-task-" + task.skill)
                }
            } else { Text("查询后会自动准备基于原场景的练习。") }
            ConnectionStatus()
        }.bubbleListStyle().navigationTitle(BubbleLocalization.text("今日练习"))
    }
}

struct BubbleExerciseView: View {
    @Environment(BubbleStore.self) private var store
    let task: StudyTask
    @State private var revealed = false
    @State private var writing = ""
    @FocusState private var writingFocused: Bool
    private var currentTask: StudyTask? {
        // Keep an open exercise usable while a new query prepares the next plan.
        // Deleting any evidence used by this version invalidates it immediately.
        if task.materialSource == "generated", let ids = task.evidenceIds {
            return !ids.isEmpty && ids.allSatisfy { store.state.captures[$0] != nil } ? task : nil
        }
        return store.state.plan?.tasks.first(where: { $0.id == task.id })
    }
    var body: some View {
        List {
            if let task = currentTask, let item = store.state.learning[task.learningId] {
                Section { Text(task.instruction).bubbleFont(.headline) }
                Section("原来的场景") {
                    if let id = task.captureId ?? item.captureIds.first, let capture = store.state.captures[id], task.skill != "listening" || revealed {
                        CaptureSceneView(capture: capture)
                        Text(capture.surroundingText ?? capture.source).textSelection(.enabled)
                    }
                }
                Section(task.materialSource == "generated" ? "AI 场景练习" : "练习内容") {
                    if task.skill != "listening" || revealed { Text(task.prompt).textSelection(.enabled).accessibilityIdentifier("studyPrompt") }
                    SpeechControls(text: task.prompt)
                }
                if task.skill == "writing" {
                    Section("试着写一句") {
                        BubbleEditor(text: $writing, focus: $writingFocused, placeholder: "试着写一句", identifier: "studyWritingInput")
                        Button("检查这句话") {
                            writingFocused = false
                            Task { await store.query(writing, writing: true, context: task.prompt, sourceApp: "场景写作练习") }
                        }
                            .buttonStyle(.bubblePrimary).disabled(writing.isEmpty || store.querying)
                        if let latest = store.latest, latest.kind == "writing", latest.source == writing {
                            Text(latest.result).accessibilityIdentifier("studyWritingResult")
                            Text(latest.explanation).foregroundStyle(.secondary)
                        }
                        ConnectionStatus()
                    }
                }
                Section {
                    Button(revealed ? "隐藏参考" : "查看参考") { revealed.toggle() }.buttonStyle(.bubblePrimary)
                    if revealed {
                        Text(task.answer).accessibilityIdentifier("studyAnswer")
                        Text(task.materialSource != "generated" ? "AI Mock · 参考来自原场景与固定练习模板" : "AI 根据已记录场景编写，供练习参考，不是原文摘录。")
                            .bubbleFont(.caption).foregroundStyle(.secondary)
                    }
                    NavigationLink("记录这次回忆反馈") { BubbleReviewView(itemId: item.id) }
                }
            } else { Text("原学习项已删除，练习不再可用。") }
        }.bubbleListStyle().navigationTitle(BubbleLocalization.text("场景练习"))
    }
}

struct BubbleActivityGrid: View {
    @Environment(BubbleStore.self) private var store
    @State private var selected: Date?
    private var calendar: Calendar { .current }
    private var days: [Date] { (0..<84).compactMap { calendar.date(byAdding: .day, value: $0 - 83, to: calendar.startOfDay(for: Date())) } }
    private func events(_ day: Date) -> [ReviewEvent] {
        store.reviews.filter { event in event.reviewedAt.map { calendar.isDate(Date(timeIntervalSince1970: $0), inSameDayAs: day) } ?? false }
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("最近 12 周的回忆足迹").bubbleFont(.headline)
            Text("每格代表一天，深浅代表当天的回忆次数。只展示实际反馈。").bubbleFont(.caption).foregroundStyle(.secondary)
            ScrollView(.horizontal) {
                LazyHGrid(rows: Array(repeating: GridItem(.fixed(18), spacing: 5), count: 7), spacing: 5) {
                    ForEach(days, id: \.self) { day in
                        let count = events(day).count
                        Button { selected = day } label: {
                            RoundedRectangle(cornerRadius: 3).fill(count == 0 ? Color.gray.opacity(0.15) : Color.green.opacity(min(1, 0.3 + Double(count) * 0.15))).frame(width: 18, height: 18)
                        }.buttonStyle(.plain).accessibilityLabel(day.formatted(date: .abbreviated, time: .omitted) + "，\(count) 次回忆")
                    }
                }
            }
            if let selected {
                Text(selected.formatted(date: .abbreviated, time: .omitted) + " · \(events(selected).count) 次回忆").bubbleFont(.subheadline)
                ForEach(events(selected)) { event in
                    if let item = store.state.learning[event.learningId] { NavigationLink(item.term) { BubbleReviewView(itemId: item.id) } }
                }
            }
        }
    }
}
