import SwiftUI
import UniformTypeIdentifiers

struct BubbleExportFile: FileDocument {
    static var readableContentTypes: [UTType] { [.data] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

struct BubbleExportView: View {
    @Environment(BubbleStore.self) private var store
    @State private var filter = "all"
    @State private var format = "csv"
    @State private var file: BubbleExportFile?
    @State private var exporting = false
    @State private var loading = false
    @State private var message: String?
    var body: some View {
        Form {
            Picker("范围", selection: $filter) {
                Text("全部").tag("all"); Text("待评估").tag("unassessed"); Text("学习中").tag("learning")
                Text("较稳固").tag("stable"); Text("建议复习").tag("due"); Text("已暂停").tag("paused")
            }
            Picker("格式", selection: $format) { Text("CSV 表格").tag("csv"); Text("Anki 卡片 .apkg").tag("apkg"); Text("不背单词 .txt").tag("txt") }
            Text("CSV 与 Anki 包含表达、释义、原场景文字、链接和 Mock 标记。图片与音频保留在 App 内，本次不打包。TXT 仅导出英文单词，跳过短语与句子。").bubbleFont(.caption).foregroundStyle(.secondary)
            Button(loading ? "正在准备…" : "导出当前范围") {
                loading = true; message = nil
                Task {
                    do { file = BubbleExportFile(data: try await store.client.raw("v2/export/\(format)?state=\(filter)")); exporting = true }
                    catch { message = error.localizedDescription }
                    loading = false
                }
            }.disabled(loading || store.session == nil)
            if let message { Text(message).foregroundStyle(.secondary) }
        }.bubbleListStyle().navigationTitle(BubbleLocalization.text("导出学习内容"))
        .fileExporter(isPresented: $exporting, document: file, contentType: format == "csv" ? .commaSeparatedText : format == "txt" ? .plainText : .data, defaultFilename: "language-bubble." + format) { result in
            switch result { case .success: message = "导出完成"; case .failure(let error): message = error.localizedDescription }
        }
    }
}
