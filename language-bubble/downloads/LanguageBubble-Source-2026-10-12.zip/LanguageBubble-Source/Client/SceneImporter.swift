import Foundation
import Vision
import ImageIO
import UniformTypeIdentifiers

enum SceneImporter {
    /// Keep original pixels, highlights and complete visible paragraph lines.
    /// The broad working image is transient; only the rounded text cutout is saved.
    static func selectedImage(_ data: Data, text: String, near point: CGPoint, selection: CGRect? = nil) async throws -> Data {
        try await Task.detached(priority: .userInitiated) {
            guard let source = CGImageSourceCreateWithData(data as CFData, nil),
                  let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else { throw ContextError.invalidResponse }
            let request = VNRecognizeTextRequest()
            request.recognitionLevel = .accurate; request.automaticallyDetectsLanguage = true
            try VNImageRequestHandler(cgImage: image).perform([request])
            let size = CGSize(width: image.width, height: image.height)
            func pixels(_ bounds: CGRect) -> CGRect {
                CGRect(x: bounds.minX * size.width, y: bounds.minY * size.height,
                       width: bounds.width * size.width, height: bounds.height * size.height)
            }
            var fragments: [SceneText.ArtworkLine] = []
            for observation in request.results ?? [] {
                guard let candidate = observation.topCandidates(1).first else { continue }
                var tokens: [(text: String, bounds: CGRect)] = []
                for range in SceneText.ranges(in: candidate.string) {
                    if let box = try? candidate.boundingBox(for: range) {
                        tokens.append((String(candidate.string[range]), pixels(box.boundingBox)))
                    }
                }
                fragments.append(.init(text: candidate.string, bounds: pixels(observation.boundingBox), tokens: tokens))
            }
            let lines = SceneText.artworkLines(text, in: fragments,
                near: CGPoint(x: point.x * size.width, y: point.y * size.height), selection: selection.map(pixels))
            guard !lines.isEmpty else {
                throw ContextError.service("未能准确定位所选文字，可使用截图 OCR。")
            }
            try Task.checkCancellation()
            let crop = try textCutout(image, lines: lines.map(\.bounds))
            let output = NSMutableData()
            guard let destination = CGImageDestinationCreateWithData(output, UTType.png.identifier as CFString, 1, nil) else { throw ContextError.invalidResponse }
            CGImageDestinationAddImage(destination, crop, nil)
            guard CGImageDestinationFinalize(destination) else { throw ContextError.invalidResponse }
            return output as Data
        }.value
    }

    /// One continuous outline avoids seams between line strips. Round both the
    /// outer corners and the indents where adjacent lines have different lengths.
    private static func textCutout(_ image: CGImage, lines: [CGRect]) throws -> CGImage {
        let imageBounds = CGRect(x: 0, y: 0, width: image.width, height: image.height)
        let lineHeight = lines.map(\.height).sorted()[lines.count / 2]
        let padding = max(8, lineHeight * 0.45)
        var bands = lines.map { $0.insetBy(dx: -padding, dy: -max(6, lineHeight * 0.3)).intersection(imageBounds) }
        // OCR boxes vary by a few pixels with glyph shapes. Align near-equal
        // edges so a shared margin does not acquire little bumps on every row.
        let left = bands.map(\.minX).min()!, right = bands.map(\.maxX).max()!
        for index in bands.indices {
            let minX = bands[index].minX - left < lineHeight * 0.5 ? left : bands[index].minX
            let maxX = right - bands[index].maxX < lineHeight * 0.5 ? right : bands[index].maxX
            bands[index] = CGRect(x: minX, y: bands[index].minY, width: maxX - minX, height: bands[index].height)
        }
        for index in bands.indices.dropLast() {
            let seam = (bands[index].minY + bands[index + 1].maxY) / 2
            bands[index] = CGRect(x: bands[index].minX, y: seam, width: bands[index].width, height: bands[index].maxY - seam)
            bands[index + 1].size.height = seam - bands[index + 1].minY
        }
        var vertices = [CGPoint(x: bands[0].minX, y: bands[0].maxY), CGPoint(x: bands[0].maxX, y: bands[0].maxY)]
        for (index, band) in bands.enumerated() {
            vertices.append(CGPoint(x: band.maxX, y: band.minY))
            if index + 1 < bands.count { vertices.append(CGPoint(x: bands[index + 1].maxX, y: band.minY)) }
        }
        for index in bands.indices.reversed() {
            let band = bands[index]
            vertices.append(CGPoint(x: band.minX, y: band.minY))
            vertices.append(CGPoint(x: band.minX, y: band.maxY))
        }
        // Remove duplicate and collinear vertices before rounding the perimeter.
        vertices = vertices.enumerated().filter { index, point in
            point != vertices[(index + vertices.count - 1) % vertices.count]
        }.map(\.element)
        var simplified: [CGPoint] = []
        for index in vertices.indices {
            let previous = vertices[(index + vertices.count - 1) % vertices.count]
            let point = vertices[index], next = vertices[(index + 1) % vertices.count]
            if (point.x - previous.x) * (next.y - point.y) != (point.y - previous.y) * (next.x - point.x) {
                simplified.append(point)
            }
        }
        let path = CGMutablePath()
        for index in simplified.indices {
            let previous = simplified[(index + simplified.count - 1) % simplified.count]
            let point = simplified[index], next = simplified[(index + 1) % simplified.count]
            let before = hypot(previous.x - point.x, previous.y - point.y)
            let after = hypot(next.x - point.x, next.y - point.y)
            let radius = min(lineHeight * 0.4, min(before, after) / 2)
            let entry = CGPoint(x: point.x + (previous.x - point.x) * radius / before,
                                y: point.y + (previous.y - point.y) * radius / before)
            let exit = CGPoint(x: point.x + (next.x - point.x) * radius / after,
                               y: point.y + (next.y - point.y) * radius / after)
            if index == 0 { path.move(to: entry) } else { path.addLine(to: entry) }
            path.addQuadCurve(to: exit, control: point)
        }
        path.closeSubpath()
        let bounds = path.boundingBoxOfPath.integral.intersection(imageBounds)
        guard bounds.width > 0, bounds.height > 0,
              let context = CGContext(data: nil, width: Int(bounds.width), height: Int(bounds.height),
                bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpace(name: CGColorSpace.sRGB)!,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { throw ContextError.invalidResponse }
        context.translateBy(x: -bounds.minX, y: -bounds.minY)
        context.addPath(path); context.clip()
        context.draw(image, in: imageBounds)
        guard let cutout = context.makeImage() else { throw ContextError.invalidResponse }
        return cutout
    }

    static func word(_ data: Data, at point: CGPoint) async throws -> (word: String, line: String) {
        try await Task.detached(priority: .userInitiated) {
            guard point.x.isFinite, point.y.isFinite, (0...1).contains(point.x), (0...1).contains(point.y),
                  let source = CGImageSourceCreateWithData(data as CFData, nil),
                  let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else { throw ContextError.invalidResponse }
            let request = VNRecognizeTextRequest()
            request.recognitionLevel = .accurate; request.automaticallyDetectsLanguage = true
            try VNImageRequestHandler(cgImage: image).perform([request])
            let dx = 2 / CGFloat(image.width), dy = 2 / CGFloat(image.height)
            var words: [(word: String, line: String, contains: Bool, distance: CGFloat)] = []
            for observation in request.results ?? [] {
                guard observation.boundingBox.insetBy(dx: -dx, dy: -dy).contains(point),
                      let candidate = observation.topCandidates(1).first else { continue }
                for range in SceneText.ranges(in: candidate.string) {
                    guard let box = try? candidate.boundingBox(for: range) else { continue }
                    let rect = box.boundingBox
                    // A nearby line or the nearest word is not evidence of a hit.
                    // Only allow two image pixels of tolerance at the word boundary.
                    guard rect.width > 0, rect.height > 0, rect.insetBy(dx: -dx, dy: -dy).contains(point) else { continue }
                    let x = (rect.midX - point.x) * CGFloat(image.width)
                    let y = (rect.midY - point.y) * CGFloat(image.height)
                    words.append((String(candidate.string[range]), candidate.string, rect.contains(point), x * x + y * y))
                }
            }
            guard let hit = words.min(by: {
                if $0.contains != $1.contains { return $0.contains }
                return $0.distance < $1.distance
            }) else { throw ContextError.service("无法确定光标处的词，请使用区域 OCR。") }
            return (hit.word, hit.line)
        }.value
    }
    static func read(_ url: URL) async throws -> (png: Data, text: String) {
        let data = try Data(contentsOf: url)
        return try await decode(data)
    }
    static func decode(_ data: Data) async throws -> (png: Data, text: String) {
        try await Task.detached(priority: .userInitiated) {
            guard data.count <= 20 * 1024 * 1024,
                  let source = CGImageSourceCreateWithData(data as CFData, nil),
                  let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceThumbnailMaxPixelSize: 2200,
                    kCGImageSourceCreateThumbnailWithTransform: true
                  ] as CFDictionary) else { throw ContextError.service("无法读取此图片，或图片超过 20 MB。") }
            let request = VNRecognizeTextRequest()
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true
            request.automaticallyDetectsLanguage = true
            try VNImageRequestHandler(cgImage: image).perform([request])
            let text = (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
            // OCR may use a smaller working image. Keep an original PNG intact
            // when it fits the attachment limit, including its full resolution.
            if CGImageSourceGetType(source) as String? == UTType.png.identifier,
               data.count <= 8 * 1024 * 1024 {
                return (data, text)
            }
            let output = NSMutableData()
            guard let destination = CGImageDestinationCreateWithData(output, UTType.png.identifier as CFString, 1, nil) else { throw ContextError.invalidResponse }
            CGImageDestinationAddImage(destination, image, nil)
            guard CGImageDestinationFinalize(destination) else { throw ContextError.invalidResponse }
            return (output as Data, text)
        }.value
    }
}
