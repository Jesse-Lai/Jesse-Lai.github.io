import Foundation
import Observation

/// Keeps editing, debouncing and results together across tab changes.
@MainActor @Observable
final class BubbleLookup {
    private(set) var text = ""
    private(set) var isComposing = false
    private(set) var isSearching = false
    private(set) var result: BubbleCapture?
    private(set) var error: String?
    private let delay: Duration
    private var task: Task<Void, Never>?
    private var generation = UUID()
    private var requestedText: String?

    init(delay: Duration = .milliseconds(800)) { self.delay = delay }

    var visibleResult: BubbleCapture? {
        result?.source == text.trimmingCharacters(in: .whitespacesAndNewlines) ? result : nil
    }

    func update(_ value: String, composing: Bool = false, immediately: Bool = false,
                lookup: @escaping @MainActor (String) async throws -> BubbleCapture) {
        text = value
        isComposing = composing
        let source = value.trimmingCharacters(in: .whitespacesAndNewlines)
        // Return during an active request must not issue the same query twice.
        if !composing, requestedText == source, isSearching { return }
        let previous = task
        previous?.cancel()
        let request = UUID()
        generation = request
        requestedText = nil
        isSearching = false
        error = nil
        guard !composing, !source.isEmpty, visibleResult == nil else { return }
        requestedText = source
        task = Task {
            do {
                if !immediately { try await Task.sleep(for: delay) }
                // Wait for cancellation cleanup before sharing the app's query transport.
                await previous?.value
                try Task.checkCancellation()
                guard generation == request else { return }
                isSearching = true
                let value = try await lookup(source)
                try Task.checkCancellation()
                guard generation == request else { return }
                result = value
            } catch {
                if generation == request, !Task.isCancelled {
                    self.error = error.localizedDescription
                }
            }
            if generation == request {
                isSearching = false
                requestedText = nil
            }
        }
    }

    func cancel() {
        generation = UUID()
        task?.cancel()
        requestedText = nil
        isSearching = false
    }

    func reset() {
        cancel()
        text = ""
        result = nil
        error = nil
        isComposing = false
    }
}

enum BubbleLookupSuggestions {
    static func matches(_ input: String, history: [String], dictionary: [String], limit: Int = 6) -> [String] {
        let prefix = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prefix.isEmpty else { return [] }
        var seen = Set<String>()
        return (history + dictionary).filter { candidate in
            let key = candidate.lowercased()
            return candidate.count <= 100 && key != prefix.lowercased()
                && candidate.range(of: prefix, options: [.anchored, .caseInsensitive, .diacriticInsensitive]) != nil
                && seen.insert(key).inserted
        }.prefix(limit).map { $0 }
    }
}
