import SwiftUI
import CoreText
#if os(macOS)
import AppKit
#else
import UIKit
#endif

/// Matches the Naive website's final Chinese/English pairing. Explicit cascades
/// keep mixed-language strings in the intended CJK face, regardless of locale.
enum BubbleTypography {
    enum Role { case body, heading, word }

    private static let registered: Void = {
        for name in ["InterVariable.ttf", "Manrope-wght.ttf", "Literata-Italic.ttf", "SourceHanSansCN-Regular.otf", "ChillYunmoGothic-Regular.otf"] {
            guard let url = Bundle.main.url(forResource: name, withExtension: nil, subdirectory: "Fonts") else {
                assertionFailure("Missing bundled font: \(name)")
                continue
            }
            var error: Unmanaged<CFError>?
            if !CTFontManagerRegisterFontsForURL(url as CFURL, .process, &error) {
                let code = error.map { CFErrorGetCode($0.takeRetainedValue()) }
                assert(code == CTFontManagerError.alreadyRegistered.rawValue, "Could not register \(name)")
            }
        }
    }()

    static func register() { _ = registered }

    static func font(size: CGFloat, role: Role = .body, weight: Font.Weight = .regular) -> CTFont {
        register()
        let values: [Font.Weight: CGFloat] = [.ultraLight: 100, .thin: 200, .light: 300, .regular: 400,
                                             .medium: 500, .semibold: 600, .bold: 700, .heavy: 800, .black: 900]
        let cjkName = role == .body ? "SourceHanSansCN-Regular" : "ChillYunmoGothicRegular"
        let cjk = CTFontDescriptorCreateWithNameAndSize(cjkName as CFString, size)
        let name = role == .word ? "Literata-Italic" : (role == .heading ? "Manrope-Regular" : "InterVariable")
        var variations: [Int: CGFloat] = [
            0x77676874: min(role == .heading ? 800 : 900, max(role == .body ? 100 : 200, values[weight] ?? 400))
        ]
        if role == .word { variations[0x6F70737A] = min(72, max(7, size)) }
        let attributes: [CFString: Any] = [
            kCTFontNameAttribute: name,
            kCTFontSizeAttribute: size,
            kCTFontCascadeListAttribute: [cjk],
            // Native weight axis; Literata also adapts optical size to the title.
            kCTFontVariationAttribute: variations
        ]
        return CTFontCreateWithFontDescriptor(CTFontDescriptorCreateWithAttributes(attributes as CFDictionary), size, nil)
    }

    static func role(for style: Font.TextStyle) -> Role {
        switch style {
        case .largeTitle, .title, .title2, .title3, .headline: return .heading
        default: return .body
        }
    }

    static func size(for style: Font.TextStyle) -> CGFloat {
        #if os(macOS)
        switch style {
        case .largeTitle: return 26
        case .title: return 22
        case .title2: return 17
        case .title3: return 15
        case .headline, .body: return 13
        case .callout: return 12
        case .subheadline: return 11
        case .footnote, .caption, .caption2: return 10
        default: return 13
        }
        #else
        switch style {
        case .largeTitle: return 34
        case .title: return 28
        case .title2: return 22
        case .title3: return 20
        case .headline, .body: return 17
        case .callout: return 16
        case .subheadline: return 15
        case .footnote: return 13
        case .caption: return 12
        case .caption2: return 11
        default: return 17
        }
        #endif
    }

    #if os(macOS)
    static func nativeFont(size: CGFloat, role: Role = .body, weight: Font.Weight = .regular) -> NSFont {
        font(size: size, role: role, weight: weight) as NSFont
    }
    #else
    static func nativeFont(size: CGFloat, role: Role = .body, weight: Font.Weight = .regular) -> UIFont {
        font(size: size, role: role, weight: weight) as UIFont
    }

    static func configureNavigation() {
        register()
        let appearance = UINavigationBar.appearance()
        appearance.titleTextAttributes = [.font: nativeFont(size: 17, role: .heading, weight: .semibold)]
        appearance.largeTitleTextAttributes = [.font: nativeFont(size: 34, role: .heading, weight: .bold)]
        UITabBarItem.appearance().setTitleTextAttributes([.font: nativeFont(size: 10)], for: .normal)
    }
    #endif
}

private struct BubbleFontModifier: ViewModifier {
    let role: BubbleTypography.Role
    let weight: Font.Weight
    @ScaledMetric private var size: CGFloat

    init(style: Font.TextStyle, size: CGFloat?, weight: Font.Weight?, role: BubbleTypography.Role?) {
        self.role = role ?? BubbleTypography.role(for: style)
        self.weight = weight ?? (style == .headline ? .semibold : .regular)
        _size = ScaledMetric(wrappedValue: size ?? BubbleTypography.size(for: style), relativeTo: style)
    }

    func body(content: Content) -> some View {
        content.font(Font(BubbleTypography.font(size: size, role: role, weight: weight)))
    }
}

extension View {
    func bubbleFont(_ style: Font.TextStyle = .body, size: CGFloat? = nil, weight: Font.Weight? = nil, role: BubbleTypography.Role? = nil) -> some View {
        modifier(BubbleFontModifier(style: style, size: size, weight: weight, role: role))
    }
}
