import SwiftUI
import ShadcnUI

enum BubbleContentStyle {
    static let text = Color(.sRGB, red: 43.0 / 255, green: 43.0 / 255, blue: 43.0 / 255, opacity: 1)
}

// Keep the temporary visual library behind app-owned components so a later
// redesign does not affect stores, sync, capture, or study logic.
private struct BubbleAppearance: ViewModifier {
    @AppStorage("bubbleTheme") private var appearance = "system"
    var paintsBackground: Bool

    func body(content: Content) -> some View {
        content
            .bubbleFont()
            .modifier(BubbleForeground(paintsBackground: paintsBackground))
            .shadcnTheme(ShadcnTheme(radius: ShadcnRadius(base: 12)), glass: false)
            .preferredColorScheme(appearance == "light" ? .light : appearance == "dark" ? .dark : nil)
    }
}

private struct BubbleForeground: ViewModifier {
    @Environment(\.shadcnPalette) private var palette
    var paintsBackground: Bool
    func body(content: Content) -> some View {
        content.foregroundStyle(palette.foreground).tint(palette.primary)
            .background(paintsBackground ? palette.background : .clear)
    }
}

struct BubbleCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        ShadcnCard { ShadcnCardContent { content } }
    }
}

struct BubbleBadge: View {
    let title: String
    var body: some View {
        ShadcnBadge(variant: .secondary) { Text(LocalizedStringKey(title)).bubbleFont(.caption, size: 12, weight: .medium) }
    }
}

struct BubbleButtonStyle: ButtonStyle {
    var primary = false
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment(\.shadcnPalette) private var palette
    @Environment(\.isEnabled) private var isEnabled
    @State private var isHovering = false

    func makeBody(configuration: Configuration) -> some View {
        // Preserve a larger, wrapping label at accessibility sizes instead of
        // ShadKit's fixed-height, single-line web button.
        if dynamicTypeSize.isAccessibilitySize {
            configuration.label.labelStyle(.titleAndIcon).bubbleFont(.body, weight: .medium)
                .padding(12).frame(minHeight: 44)
                .foregroundStyle(primary ? palette.primaryForeground : palette.foreground)
                .background(primary ? palette.primary : palette.secondary, in: RoundedRectangle(cornerRadius: 8))
                .opacity(!isEnabled ? 0.5 : configuration.isPressed ? 0.7 : 1)
        } else {
            configuration.label.labelStyle(.titleAndIcon)
                .bubbleFont(.body, size: 14, weight: .medium)
                .foregroundStyle(primary ? palette.primaryForeground : palette.foreground)
                .lineLimit(1)
                .padding(.horizontal, 24)
                .frame(height: 40)
                .background(primary ? palette.primary.opacity(isHovering ? 0.9 : 1) : isHovering ? palette.accent : palette.background,
                            in: RoundedRectangle(cornerRadius: 8))
                .overlay { RoundedRectangle(cornerRadius: 8).strokeBorder(primary ? .clear : palette.border) }
                .opacity(!isEnabled ? 0.5 : configuration.isPressed ? 0.7 : 1)
                .padding(.vertical, 2)
                .contentShape(Rectangle())
                .onHover { isHovering = $0 && isEnabled }
        }
    }
}

struct BubbleDisclosureStyle: DisclosureGroupStyle {
    func makeBody(configuration: Configuration) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Button { withAnimation { configuration.isExpanded.toggle() } } label: {
                HStack {
                    configuration.label
                    Spacer()
                    Image(systemName: configuration.isExpanded ? "chevron.down" : "chevron.right")
                        .bubbleFont(.caption, weight: .semibold).foregroundStyle(.secondary)
                }.frame(minHeight: 32).contentShape(Rectangle())
            }.buttonStyle(.plain)
            if configuration.isExpanded { configuration.content }
        }
    }
}

extension ButtonStyle where Self == BubbleButtonStyle {
    static var bubblePrimary: BubbleButtonStyle { BubbleButtonStyle(primary: true) }
    static var bubbleSecondary: BubbleButtonStyle { BubbleButtonStyle() }
}

struct BubbleEditor: View {
    @Binding var text: String
    var focus: FocusState<Bool>.Binding
    var placeholder: String
    var identifier: String
    @ScaledMetric(relativeTo: .body) private var fontSize = 17.0
    @Environment(\.shadcnPalette) private var palette
    @State private var contentHeight: CGFloat = 88

    var body: some View {
        ZStack(alignment: .topLeading) {
            TextEditor(text: $text)
                .focused(focus)
                .font(Font(BubbleTypography.font(size: fontSize)))
                .scrollContentBackground(.hidden)
            if text.isEmpty {
                Text(LocalizedStringKey(placeholder))
                    .font(Font(BubbleTypography.font(size: fontSize)))
                    .foregroundStyle(palette.mutedForeground)
                    .padding(.horizontal, 5).padding(.vertical, 8)
                    .allowsHitTesting(false)
            }
        }
            .frame(height: min(220, max(88, contentHeight)))
            .background {
                Text(text.isEmpty ? " " : text)
                    .font(Font(BubbleTypography.font(size: fontSize)))
                    .padding(.horizontal, 5).padding(.vertical, 8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)
                    .hidden()
                    .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { contentHeight = $0 }
            }
            .accessibilityIdentifier(identifier)
            .accessibilityLabel(LocalizedStringKey(placeholder))
            .padding(10)
            .background(palette.background, in: RoundedRectangle(cornerRadius: 10))
            .overlay { RoundedRectangle(cornerRadius: 10).strokeBorder(focus.wrappedValue ? palette.ring : palette.input) }
            #if os(iOS)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("完成") { focus.wrappedValue = false }
                        .accessibilityIdentifier("dismissBubbleKeyboard")
                }
            }
            #endif
    }
}

private struct BubbleListAppearance: ViewModifier {
    @Environment(\.shadcnPalette) private var palette
    func body(content: Content) -> some View {
        #if os(macOS)
        content.listStyle(.inset).scrollContentBackground(.hidden)
            .background(palette.muted.opacity(0.4))
        #else
        content.listStyle(.insetGrouped).scrollContentBackground(.hidden)
            .background(palette.muted.opacity(0.4))
        #endif
    }
}

private struct BubbleRowAppearance: ViewModifier {
    @Environment(\.shadcnPalette) private var palette
    func body(content: Content) -> some View {
        content.padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(palette.card, in: RoundedRectangle(cornerRadius: 12))
            .overlay { RoundedRectangle(cornerRadius: 12).strokeBorder(palette.border) }
    }
}

extension View {
    func bubbleAppearance(paintsBackground: Bool = true) -> some View {
        modifier(BubbleAppearance(paintsBackground: paintsBackground))
    }
    func bubbleListStyle() -> some View { modifier(BubbleListAppearance()) }
    func bubbleRow() -> some View { modifier(BubbleRowAppearance()) }
}
