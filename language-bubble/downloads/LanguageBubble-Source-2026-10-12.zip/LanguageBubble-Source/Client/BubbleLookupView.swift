import SwiftUI
#if os(macOS)
import AppKit
#else
import UIKit
#endif

struct BubbleLookupView: View {
    @Environment(BubbleStore.self) private var store
    @Bindable var lookup: BubbleLookup
    @State private var suggestions: [String] = []

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                BubbleLookupField(text: lookup.text, onEdit: { text, composing in
                    update(text, composing: composing)
                }, onSubmit: {
                    update(lookup.text, immediately: true)
                })
                .frame(height: 44)

                if !suggestions.isEmpty, lookup.visibleResult == nil {
                    VStack(spacing: 0) {
                        ForEach(suggestions, id: \.self) { suggestion in
                            Button {
                                update(suggestion, immediately: true)
                            } label: {
                                HStack {
                                    Text(suggestion)
                                    Spacer()
                                    Image(systemName: "arrow.up.left").foregroundStyle(.secondary)
                                }
                                .padding(.vertical, 10).padding(.horizontal, 12)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityIdentifier("lookupSuggestion-" + suggestion)
                        }
                    }
                    .background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 10))
                }

                if lookup.isSearching {
                    HStack(spacing: 10) {
                        ProgressView().controlSize(.small)
                        Text("正在查询…").foregroundStyle(.secondary)
                    }.accessibilityIdentifier("lookupProgress")
                }
                if let result = lookup.visibleResult {
                    VStack(alignment: .leading, spacing: 18) {
                        VStack(alignment: .leading, spacing: 10) {
                            Text(result.source).bubbleFont(.title2, weight: .semibold).textSelection(.enabled)
                            SpeechControls(text: result.source, iconOnly: true, phonetic: result.dictionary?.phonetic)
                        }
                        if let dictionary = result.dictionary {
                            WordDictionaryView(entry: dictionary).accessibilityIdentifier("latestQueryResult")
                        } else {
                            Text(result.result).bubbleFont(.title3).textSelection(.enabled)
                                .accessibilityIdentifier("latestQueryResult")
                            if !result.explanation.isEmpty {
                                Text(result.explanation).foregroundStyle(.secondary).textSelection(.enabled)
                            }
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 8)
                }
                if let error = lookup.error {
                    Text(LocalizedStringKey(error)).bubbleFont(.callout).foregroundStyle(.secondary)
                        .accessibilityIdentifier("lookupError")
                }
            }
            .padding(24)
            .frame(maxWidth: 880, alignment: .leading)
            .frame(maxWidth: .infinity, alignment: .topLeading)
        }
        .navigationTitle(BubbleLocalization.text("查词"))
        .onAppear { update(lookup.text) }
        .onDisappear { lookup.cancel() }
        .onChange(of: store.selectedTab) { if store.selectedTab != 1 { lookup.cancel() } }
        .task(id: lookup.text + String(lookup.isComposing)) {
            suggestions = []
            guard !lookup.isComposing else { return }
            do { try await Task.sleep(for: .milliseconds(100)) } catch { return }
            let text = lookup.text.trimmingCharacters(in: .whitespacesAndNewlines)
            suggestions = BubbleLookupSuggestions.matches(text, history: store.captures.map(\.source),
                                                           dictionary: dictionaryCompletions(text))
        }
    }

    private func update(_ text: String, composing: Bool = false, immediately: Bool = false) {
        lookup.update(text, composing: composing, immediately: immediately) { source in
            guard store.session != nil else {
                throw ContextError.service("请先在设置中配对，再使用查译。")
            }
            guard !store.querying else {
                throw ContextError.service("另一项查询正在进行，请稍后按回车重试。")
            }
            await store.query(source, sourceApp: "Language Bubble")
            try Task.checkCancellation()
            guard let result = store.latest, result.source == source else {
                throw ContextError.service(store.error ?? "暂时无法完成查询，请按回车重试。")
            }
            return result
        }
    }

    private func dictionaryCompletions(_ text: String) -> [String] {
        guard !text.isEmpty, text.count <= 60, !text.contains(where: \.isWhitespace) else { return [] }
        let range = NSRange(location: 0, length: text.utf16.count)
        #if os(macOS)
        return NSSpellChecker.shared.completions(forPartialWordRange: range, in: text,
                                                 language: "en_US", inSpellDocumentWithTag: 0) ?? []
        #else
        return UITextChecker().completions(forPartialWordRange: range, in: text, language: "en_US") ?? []
        #endif
    }
}

// Native fields expose marked text, so composing with an IME cannot start a
// lookup. Return keeps its normal input-method behavior before submitting.
#if os(macOS)
private struct BubbleLookupField: NSViewRepresentable {
    let text: String
    var onEdit: (String, Bool) -> Void
    var onSubmit: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeNSView(context: Context) -> NSSearchField {
        let field = NSSearchField()
        field.controlSize = .large
        field.font = BubbleTypography.nativeFont(size: 17)
        field.sendsWholeSearchString = true
        field.sendsSearchStringImmediately = false
        field.delegate = context.coordinator
        field.target = context.coordinator
        field.action = #selector(Coordinator.submit(_:))
        field.identifier = NSUserInterfaceItemIdentifier("bubbleQuery")
        field.setAccessibilityIdentifier("bubbleQuery")
        return field
    }

    func updateNSView(_ field: NSSearchField, context: Context) {
        context.coordinator.parent = self
        field.placeholderString = BubbleLocalization.text("输入单词或短语")
        field.setAccessibilityLabel(BubbleLocalization.text("输入单词或短语"))
        if field.stringValue != text { field.stringValue = text }
    }

    final class Coordinator: NSObject, NSSearchFieldDelegate {
        var parent: BubbleLookupField
        init(_ parent: BubbleLookupField) { self.parent = parent }

        func controlTextDidChange(_ notification: Notification) {
            guard let field = notification.object as? NSSearchField else { return }
            parent.onEdit(field.stringValue, (field.currentEditor() as? NSTextView)?.hasMarkedText() == true)
        }

        @objc func submit(_ field: NSSearchField) {
            guard (field.currentEditor() as? NSTextView)?.hasMarkedText() != true else { return }
            parent.onSubmit()
        }
    }
}
#else
private struct BubbleLookupField: UIViewRepresentable {
    let text: String
    var onEdit: (String, Bool) -> Void
    var onSubmit: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: UIViewRepresentableContext<Self>) -> UITextField {
        let field = UITextField()
        field.borderStyle = .roundedRect
        field.font = UIFontMetrics(forTextStyle: .body).scaledFont(for: BubbleTypography.nativeFont(size: 17))
        field.adjustsFontForContentSizeCategory = true
        field.returnKeyType = .search
        field.clearButtonMode = .whileEditing
        field.autocorrectionType = .no
        field.autocapitalizationType = .none
        field.spellCheckingType = .no
        field.accessibilityIdentifier = "bubbleQuery"
        field.delegate = context.coordinator
        field.addTarget(context.coordinator, action: #selector(Coordinator.edit(_:)), for: .editingChanged)
        return field
    }

    func updateUIView(_ field: UITextField, context: UIViewRepresentableContext<Self>) {
        context.coordinator.parent = self
        field.placeholder = BubbleLocalization.text("输入单词或短语")
        field.accessibilityLabel = field.placeholder
        if field.text != text { field.text = text }
    }

    final class Coordinator: NSObject, UITextFieldDelegate {
        var parent: BubbleLookupField
        init(_ parent: BubbleLookupField) { self.parent = parent }

        @objc func edit(_ field: UITextField) {
            parent.onEdit(field.text ?? "", field.markedTextRange != nil)
        }

        func textFieldShouldReturn(_ field: UITextField) -> Bool {
            guard field.markedTextRange == nil else { return false }
            parent.onSubmit()
            field.resignFirstResponder()
            return true
        }
    }
}
#endif
