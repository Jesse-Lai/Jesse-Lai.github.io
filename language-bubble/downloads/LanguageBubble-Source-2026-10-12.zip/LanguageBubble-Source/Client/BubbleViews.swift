import SwiftUI
import UniformTypeIdentifiers
import AVFoundation
#if os(macOS)
import AppKit
#else
import UIKit
#endif

struct BubbleRootView: View {
    @AppStorage("bubbleInterfaceLanguage") private var interfaceLanguage = "zh-Hans"
    @Environment(BubbleStore.self) private var store
    @Environment(\.scenePhase) private var phase
    @State private var lookup = BubbleLookup()

    var body: some View {
        @Bindable var store = store
        Group {
            #if os(macOS)
            BubbleMacWorkspace()
            #else
            TabView(selection: $store.selectedTab) {
                NavigationStack { BubbleRecordsView() }.tabItem { Label("记录", systemImage: "bubble.left.and.text.bubble.right") }.tag(0)
                NavigationStack { BubbleLookupView(lookup: lookup) }.tabItem { Label("查词", systemImage: "magnifyingglass") }.tag(1)
                NavigationStack { BubbleLearningView() }.tabItem { Label("学习", systemImage: "rectangle.stack") }.tag(2)
                NavigationStack { BubbleSettingsView() }.tabItem { Label("设置", systemImage: "gearshape") }.tag(3)
            }
            #endif
        }
        .environment(\.locale, Locale(identifier: interfaceLanguage))
        .onChange(of: store.session?.deviceId) { lookup.reset() }
        .task(id: phase) {
            guard phase == .active else { return }
            while !Task.isCancelled {
                await store.sync()
                do { try await Task.sleep(for: .seconds(4)) } catch { return }
            }
        }
    }
}

#if os(macOS)
private struct BubbleMacWorkspace: View {
    @AppStorage("bubbleInterfaceLanguage") private var interfaceLanguage = "zh-Hans"
    @Environment(BubbleStore.self) private var store
    @State private var selectedRecord: BubbleRecord.ID?
    @State private var selectedArticle: String?
    @State private var articlePreviews: [ArticleGenerationPreview] = []

    var body: some View {
        @Bindable var store = store
        Group {
            if store.selectedTab == 2 {
                BubbleArticleLibrary(selection: $selectedArticle, previews: $articlePreviews)
            } else {
                BubbleMacRecordsView(selection: $selectedRecord)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background {
            Group {
                if store.selectedTab != 2 { BubbleRecordBackground() }
                else if selectedArticle != nil { ArticleReaderStyle.canvas }
                else { ArticleReaderStyle.canvas }
            }.ignoresSafeArea()
        }
        .navigationTitle("")
        .toolbar {
            ToolbarItem(placement: .principal) {
                BubbleMacTabs(selection: $store.selectedTab)
                    .fixedSize()
            }
            if #available(macOS 26, *) {
                ToolbarItem(placement: .primaryAction) {
                    BubbleMacToolbarControl(content: accountMenu
                        .menuStyle(.button)
                        .buttonStyle(.plain)
                        .frame(width: 36, height: 36)
                        .contentShape(Circle())
                        .glassEffect(.regular.interactive(), in: Circle())
                        .environment(store)
                        .environment(\.locale, Locale(identifier: interfaceLanguage)))
                        .fixedSize()
                }
                .sharedBackgroundVisibility(.hidden)
            } else {
                ToolbarItem(placement: .primaryAction) {
                    accountMenu
                        .buttonBorderShape(.circle)
                }
            }
        }
        .toolbar(.visible, for: .windowToolbar)
        .sheet(isPresented: $store.showingSettings) {
            NavigationStack {
                BubbleSettingsView()
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button("完成") { store.showingSettings = false }
                                .keyboardShortcut(.cancelAction)
                        }
                    }
            }
            .frame(minWidth: 600, idealWidth: 660, minHeight: 520, idealHeight: 640)
            .bubbleAppearance()
            .environment(\.locale, Locale(identifier: interfaceLanguage))
        }
    }

    private var accountMenu: some View {
        Menu {
            if let session = store.session {
                Text(BubbleLocalization.text("测试账号：%@", String(session.userId.prefix(8))))
            } else {
                Text("尚未连接")
            }
            Divider()
            BubbleLearningLanguagePicker(showsSelection: true).pickerStyle(.menu)
            Divider()
            Button("设置…", systemImage: "gearshape") { store.showingSettings = true }
            Button("立即同步", systemImage: "arrow.triangle.2.circlepath") {
                Task { await store.sync() }
            }.disabled(store.session == nil || store.syncing)
        } label: {
            Image("AccountAvatar")
                .renderingMode(.original)
                .resizable()
                .scaledToFill()
                .frame(width: 28, height: 28)
                .clipShape(Circle())
        }
        .menuIndicator(.hidden)
        .accessibilityLabel("账号")
        .help("账号与设置")
        .accessibilityIdentifier("accountMenu")
    }
}

// Keep the menu's button shape and label layout intact instead of letting the
// toolbar convert its image into an automatically sized NSMenuToolbarItem.
private struct BubbleMacToolbarControl<Content: View>: NSViewRepresentable {
    var content: Content

    func makeNSView(context: Context) -> NSHostingView<Content> {
        let view = NSHostingView(rootView: content)
        view.sizingOptions = [.intrinsicContentSize]
        return view
    }

    func updateNSView(_ view: NSHostingView<Content>, context: Context) {
        view.rootView = content
    }
}

// AppKit draws the system's toolbar segments, including the glass treatment on
// macOS 26. Explicit segment widths keep the selection as wide as its tab.
private struct BubbleMacTabs: NSViewRepresentable {
    @Binding var selection: Int

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeNSView(context: Context) -> NSSegmentedControl {
        let control = NSSegmentedControl(labels: [BubbleLocalization.text("收集"), BubbleLocalization.text("学习")],
            trackingMode: .selectOne, target: context.coordinator, action: #selector(Coordinator.selectTab(_:)))
        control.segmentStyle = .automatic
        control.controlSize = .large
        control.font = BubbleTypography.nativeFont(size: 13, weight: .medium)
        control.segmentDistribution = .fillEqually
        for index in 0..<2 { control.setWidth(96, forSegment: index) }
        if #available(macOS 26, *) { control.borderShape = .capsule }
        control.setAccessibilityLabel(BubbleLocalization.text("导航"))
        control.setAccessibilityIdentifier("workspaceTabs")
        return control
    }

    func updateNSView(_ control: NSSegmentedControl, context: Context) {
        context.coordinator.parent = self
        control.setLabel(BubbleLocalization.text("收集"), forSegment: 0)
        control.setLabel(BubbleLocalization.text("学习"), forSegment: 1)
        control.selectedSegment = selection == 2 ? 1 : 0
    }

    final class Coordinator: NSObject {
        var parent: BubbleMacTabs
        init(_ parent: BubbleMacTabs) { self.parent = parent }
        @objc func selectTab(_ sender: NSSegmentedControl) {
            parent.selection = sender.selectedSegment == 1 ? 2 : 0
        }
    }
}

private struct BubbleMacRecordsView: View {
    @Environment(BubbleStore.self) private var store
    @Binding var selection: BubbleRecord.ID?
    private let bottomFadeHeight: CGFloat = 48
    private let listContentInset: CGFloat = 2
    private var records: [BubbleRecord] { store.learningRecords }

    var body: some View {
        GeometryReader { geometry in
            let scale = geometry.size.width / 1728
            workspace(scale: scale)
        }
        .onChange(of: records.map(\.id), initial: true) { _, ids in
            if selection.map({ !ids.contains($0) }) ?? true { selection = ids.first }
        }
    }

    private func workspace(scale: CGFloat) -> some View {
        let scrollerGutter = min(24, 32 * scale)
        return HStack(alignment: .top, spacing: 32 * scale - scrollerGutter) {
            Group {
                if #available(macOS 26, *) {
                    // Keep the last row clear of the native bottom blur region.
                    recordList(scale: scale, scrollerGutter: scrollerGutter)
                        .safeAreaBar(edge: .bottom, spacing: 0) {
                            // On macOS 26, a Color/Shape-only bar gets the native
                            // fade but not the blur. A blank text layout supplies
                            // the content geometry needed by the soft edge effect.
                            Text(verbatim: " ")
                                .frame(maxWidth: .infinity)
                                .frame(height: 6)
                                .padding(.top, bottomFadeHeight - 6)
                                .allowsHitTesting(false)
                                .accessibilityHidden(true)
                        }
                        .scrollEdgeEffectStyle(.soft, for: [.top, .bottom])
                        .mask {
                            VStack(spacing: 0) {
                                Rectangle().fill(.black)
                                // Let the native blur remain visible first, then
                                // fade out into the shared window material.
                                LinearGradient(stops: [
                                    .init(color: .black, location: 0),
                                    .init(color: .black.opacity(0.9), location: 0.3),
                                    .init(color: .black.opacity(0.5), location: 0.55),
                                    .init(color: .black.opacity(0.1), location: 0.7),
                                    .init(color: .clear, location: 0.75),
                                    .init(color: .clear, location: 1)
                                ], startPoint: .top, endPoint: .bottom)
                                .frame(height: bottomFadeHeight / 2)
                            }
                        }
                } else {
                    recordList(scale: scale, scrollerGutter: scrollerGutter)
                }
            }
            .frame(width: 803 * scale + scrollerGutter)
            .frame(maxHeight: .infinity, alignment: .top)

            Group {
                if let selection {
                    BubbleMacRecordDetail(recordID: selection, scale: scale).id(selection)
                } else {
                    ContentUnavailableView("选择一条记录", systemImage: "text.bubble",
                        description: Text("在这里查看释义和当时的场景。"))
                }
            }
            .frame(width: 797 * scale)
            .frame(maxHeight: .infinity)
            .background(BubbleRecordPalette.panel, in: RoundedRectangle(cornerRadius: 32 * scale))
            .clipShape(RoundedRectangle(cornerRadius: 32 * scale))
            .overlay { RoundedRectangle(cornerRadius: 32 * scale).strokeBorder(BubbleRecordPalette.border, lineWidth: 0.5) }
        }
        .padding(.horizontal, 48 * scale)
        .padding(.top, 24 * scale)
        .padding(.bottom, 48 * scale)
    }

    private func recordList(scale: CGFloat, scrollerGutter: CGFloat) -> some View {
        ScrollView {
            LazyVStack(spacing: 12 * scale) {
                ForEach(records) { record in
                    Button { selection = record.id } label: {
                        BubbleMacRecordRow(record: record, scale: scale)
                            .background(selection == record.id ? BubbleRecordPalette.panel : .clear,
                                        in: RoundedRectangle(cornerRadius: 32 * scale))
                            .overlay {
                                RoundedRectangle(cornerRadius: 32 * scale)
                                    .strokeBorder(selection == record.id ? BubbleRecordPalette.border : .clear, lineWidth: 0.5)
                            }
                            .contentShape(RoundedRectangle(cornerRadius: 32 * scale))
                    }
                    .buttonStyle(.plain)
                    .accessibilityIdentifier("capture-" + record.latest.id)
                    .accessibilityAddTraits(selection == record.id ? .isSelected : [])
                }
            }
            .padding(listContentInset)
            // Extend only the scroll viewport into the column gap, leaving
            // the cards at their original width.
            .padding(.trailing, scrollerGutter)
            .background(BubbleScrollIndicatorStyle())
        }
        .accessibilityIdentifier("recordScrollView")
        .overlay {
            if records.isEmpty {
                ContentUnavailableView("暂无记录", systemImage: "text.bubble",
                    description: Text("当前学习语言还没有记录，可在菜单中切换语言。"))
            }
        }
        .onMoveCommand { direction in
            guard let index = records.firstIndex(where: { $0.id == selection }) else { return }
            if direction == .down { selection = records[min(index + 1, records.count - 1)].id }
            if direction == .up { selection = records[max(index - 1, 0)].id }
        }
    }
}

private struct BubbleMacSearchField: View {
    @Binding var text: String
    var prompt: String
    var leadingInset: CGFloat = 14
    var usesRecordVibrancy = false

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField(LocalizedStringKey(prompt), text: $text).textFieldStyle(.plain)
                .lineLimit(1)
                .accessibilityIdentifier("workspaceSearch")
            if !text.isEmpty {
                Button { text = "" } label: { Image(systemName: "xmark.circle.fill") }
                    .buttonStyle(.plain).foregroundStyle(.secondary).accessibilityLabel("清除搜索")
            }
        }
        .padding(.leading, leadingInset)
        .padding(.trailing, 14)
        .frame(height: 36)
        .background {
            BubbleRecordPalette.page
                .opacity(usesRecordVibrancy ? BubbleRecordVibrancy.searchTintOpacity : 1)
                .clipShape(Capsule())
        }
        .overlay {
            Capsule().strokeBorder(Color.black.opacity(0.15), lineWidth: 0.5)
        }
    }
}
#endif

struct ConnectionStatus: View {
    @Environment(BubbleStore.self) private var store
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                if store.syncing { ProgressView().controlSize(.small) }
                Text(LocalizedStringKey(store.status)).bubbleFont(.caption)
                Spacer()
                if store.aiMode == "mock" { Text("AI Mock").bubbleFont(.caption, weight: .bold).foregroundStyle(.orange) }
                if store.aiMode == "live" { BubbleBadge(title: "真实 AI").accessibilityIdentifier("liveAIStatus") }
            }
            if let error = store.error {
                Text(LocalizedStringKey(error)).bubbleFont(.caption).foregroundStyle(.red).textSelection(.enabled)
            }
        }.foregroundStyle(.secondary)
    }
}

struct BubbleRecordsView: View {
    @Environment(BubbleStore.self) private var store
    @State private var search = ""
    private var records: [BubbleRecord] {
        store.learningRecords.filter { $0.matches(search) }
    }
    var body: some View {
        List {
            if records.isEmpty { Text(search.isEmpty ? "当前学习语言还没有记录，可在菜单中切换语言。" : "试试其他关键词。").foregroundStyle(.secondary).padding(.vertical) }
            ForEach(records) { record in
                let capture = record.latest
                NavigationLink { BubbleCaptureView(recordID: record.id) } label: {
                    BubbleRecordRow(record: record)
                }.accessibilityIdentifier("capture-" + capture.id)
                    .listRowSeparator(.hidden)
                    .swipeActions { Button("删除", role: .destructive) { Task { await store.deleteRecord(record.id) } } }
            }
        }
        #if os(macOS)
        .listStyle(.inset)
        #else
        .listStyle(.insetGrouped)
        #endif
        .navigationTitle(BubbleLocalization.text("记录"))
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Menu {
                    BubbleLearningLanguagePicker(showsSelection: true).pickerStyle(.menu)
                } label: {
                    Label("正在学习的语言", systemImage: "globe")
                }.accessibilityIdentifier("learningLanguageMenu")
            }
        }
        .searchable(text: $search, prompt: "搜索")
        .refreshable { await store.sync() }
    }
}

private struct BubbleRecordRow: View {
    @Environment(BubbleStore.self) private var store
    let record: BubbleRecord

    private var definition: String {
        let capture = record.latest
        let text: String
        if capture.kind == "translation", let entry = store.dictionary(for: record) {
            text = entry.groups.map { group in
                (group.pos.isEmpty ? "—" : group.pos) + " " + group.meanings.joined(separator: "；")
            }.joined(separator: "；")
        } else {
            text = [capture.result, capture.explanation].filter { !$0.isEmpty }.joined(separator: "；")
        }
        return text.split(whereSeparator: \.isWhitespace).joined(separator: " ")
    }

    var body: some View {
        let capture = record.latest
        VStack(alignment: .leading, spacing: 7) {
            Text(record.displayTitle)
                .bubbleFont(.headline, size: BubbleTypography.size(for: .headline) + 2, weight: .medium, role: .word)
                .lineLimit(2)
            Text(definition).foregroundStyle(.secondary).lineLimit(1).truncationMode(.tail)
            if capture.isMock { Text("AI Mock · 测试数据").bubbleFont(.caption2).foregroundStyle(.orange) }
        }
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .task(id: capture.id) {
            guard capture.kind == "translation" else { return }
            // Older records share the detail view's dictionary cache; keep the
            // saved translation visible while loading or if lookup fails.
            _ = try? await store.loadDictionary(for: record)
        }
    }
}

struct SceneImage: View {
    var data: Data
    var body: some View {
        #if os(macOS)
        if let image = NSImage(data: data) { Image(nsImage: image).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 12)) }
        #else
        if let image = UIImage(data: data) { Image(uiImage: image).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 12)) }
        #endif
    }
}

struct CaptureSceneView: View {
    var capture: BubbleCapture
    var showsMetadata = true
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if showsMetadata {
                if let app = capture.sourceApp { Label(app, systemImage: "app") }
                if let context = capture.surroundingText, !context.isEmpty { Text(context).textSelection(.enabled) }
            }
            if let url = capture.sourceLink {
                Link(destination: url) {
                    Label(url.absoluteString, systemImage: "link")
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .help(url.absoluteString)
                .accessibilityIdentifier("captureSourceLink")
            }
            ForEach(capture.assetIds, id: \.self) { id in CaptureSceneImage(assetID: id) }
            if capture.assetIds.isEmpty && capture.sourceLink == nil && (!showsMetadata || capture.surroundingText == nil) {
                Text("未保存来源链接或截图。").bubbleFont(.caption).foregroundStyle(.secondary)
            }
        }
    }
}

private struct CaptureSceneImage: View {
    @AppStorage("bubbleInterfaceLanguage") private var interfaceLanguage = "zh-Hans"
    @Environment(BubbleStore.self) private var store
    let assetID: String
    @State private var image: Data?
    @State private var failed = false
    @State private var attempt = 0
    @State private var preview = false

    var body: some View {
        Group {
            if let image {
                Button { preview = true } label: {
                    SceneImage(data: image).frame(maxHeight: 340)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("记录时的场景图片")
                .accessibilityHint("查看原图")
                .accessibilityIdentifier("capturedScene")
            } else if failed {
                HStack {
                    Text("截图暂时无法加载").foregroundStyle(.secondary)
                    Button("重试") { attempt += 1 }
                }.bubbleFont(.caption)
            } else {
                ProgressView("正在加载截图…").controlSize(.small)
            }
        }
        .task(id: "\(assetID)-\(attempt)") {
            image = nil; failed = false
            do {
                let data = try await store.asset(assetID)
                try Task.checkCancellation()
                image = data
            } catch { if !Task.isCancelled { failed = true } }
        }
        .sheet(isPresented: $preview) {
            VStack(spacing: 16) {
                HStack {
                    Text("记录时的场景图片").bubbleFont(.headline)
                    Spacer()
                    Button("完成") { preview = false }.keyboardShortcut(.cancelAction)
                }
                ScrollView {
                    if let image { SceneImage(data: image).frame(maxWidth: .infinity) }
                }
            }
            .padding(20)
            .environment(\.locale, Locale(identifier: interfaceLanguage))
            #if os(macOS)
            .frame(minWidth: 640, idealWidth: 960, minHeight: 480, idealHeight: 720)
            #endif
        }
    }
}

struct WordDictionaryView: View {
    let entry: WordDictionaryEntry
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            ForEach(Array(entry.groups.enumerated()), id: \.offset) { _, group in
                HStack(alignment: .firstTextBaseline, spacing: 16) {
                    Text(group.pos.isEmpty ? "—" : group.pos)
                        .bubbleFont(.body, weight: .medium).foregroundStyle(.secondary)
                        .frame(width: 66, alignment: .leading)
                    Text(group.meanings.joined(separator: "；"))
                        .fixedSize(horizontal: false, vertical: true).textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            if let url = CaptureSourceLink.url(entry.url) {
                Link(entry.source + " · " + entry.license, destination: url)
                    .bubbleFont(.caption).foregroundStyle(.secondary)
            }
        }.accessibilityIdentifier("wordDictionaryMeanings")
    }
}

struct CaptureContextMeaningView: View {
    @Environment(BubbleStore.self) private var store
    let capture: BubbleCapture
    @State private var analyzing = false
    @State private var failed = false
    @State private var attempt = 0
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let context = capture.surroundingText?.trimmingCharacters(in: .whitespacesAndNewlines), !context.isEmpty {
                Text(context).bubbleFont(.callout).foregroundStyle(.secondary).textSelection(.enabled)
            }
            if let sense = store.contextMeaning(for: capture) {
                Text("此处含义").bubbleFont(.caption).foregroundStyle(.secondary)
                HStack(alignment: .firstTextBaseline, spacing: 12) {
                    if !sense.pos.isEmpty { Text(sense.pos).foregroundStyle(.secondary) }
                    Text(sense.meaning).textSelection(.enabled)
                }
                if !sense.explanation.isEmpty {
                    Text(sense.explanation).bubbleFont(.callout).foregroundStyle(.secondary).textSelection(.enabled)
                }
            } else {
                Text("当时的翻译").bubbleFont(.caption).foregroundStyle(.secondary)
                Text(capture.result).textSelection(.enabled)
                if !capture.explanation.isEmpty {
                    Text(capture.explanation).bubbleFont(.callout).foregroundStyle(.secondary).textSelection(.enabled)
                }
                if analyzing {
                    ProgressView("正在分析语境…").controlSize(.small)
                } else if failed {
                    Button("重新分析语境") { attempt += 1 }.buttonStyle(.borderless)
                }
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityIdentifier("captureContextMeaning-" + capture.id)
            .task(id: capture.id + ":" + String(attempt)) {
                guard store.contextMeaning(for: capture) == nil else { return }
                analyzing = true; failed = false
                defer { analyzing = false }
                do { try await store.loadContextMeaning(for: capture) }
                catch is CancellationError { }
                catch { if !Task.isCancelled { failed = true } }
            }
    }
}

struct BubbleCaptureView: View {
    @Environment(BubbleStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let recordID: BubbleRecord.ID
    var embedded = false
    @State private var confirm = false
    @State private var dictionaryStatus = "loading"
    @State private var dictionaryAttempt = 0
    @ScaledMetric(relativeTo: .largeTitle) private var sourceFontSize = 34.0
    var body: some View {
        ScrollView {
            if let record = store.record(recordID) {
                let capture = record.latest
                VStack(alignment: .leading, spacing: 32) {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Text(record.displayTitle)
                                .bubbleFont(.title, size: sourceFontSize, weight: .medium, role: .word)
                                .fixedSize(horizontal: false, vertical: true)
                                .textSelection(.enabled)
                                .accessibilityAddTraits(.isHeader)
                            if embedded {
                                Spacer(minLength: 8)
                                Button("删除", systemImage: "trash", role: .destructive) { confirm = true }
                                    .labelStyle(.iconOnly).buttonStyle(.borderless).foregroundStyle(.secondary)
                                    .help("删除记录")
                            }
                        }
                        SpeechControls(text: capture.source, iconOnly: true,
                            phonetic: capture.kind == "translation" ? store.dictionary(for: record)?.phonetic : nil)
                    }
                    VStack(alignment: .leading, spacing: 12) {
                        Text(capture.kind == "translation" ? "释义" : "修改建议")
                            .bubbleFont(.headline).accessibilityAddTraits(.isHeader)
                        if capture.kind == "translation", let entry = store.dictionary(for: record) {
                            WordDictionaryView(entry: entry)
                        } else {
                            Text(capture.result).textSelection(.enabled)
                            if !capture.explanation.isEmpty {
                                Text(capture.explanation).foregroundStyle(.secondary).textSelection(.enabled)
                            }
                            if capture.kind == "translation" {
                                if dictionaryStatus == "loading" {
                                    ProgressView("正在查询词典…").controlSize(.small)
                                } else if ["error", "unavailable"].contains(dictionaryStatus) {
                                    HStack {
                                        Text("词典暂不可用，当前显示已保存的翻译。").bubbleFont(.caption).foregroundStyle(.secondary)
                                        Button("重试") { dictionaryAttempt += 1 }.buttonStyle(.borderless)
                                    }
                                } else if dictionaryStatus == "not_found" {
                                    Text("词典暂未收录，当前显示已保存的翻译。").bubbleFont(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    ForEach(Array(record.sources.enumerated()), id: \.element.id) { index, encounter in
                        VStack(alignment: .leading, spacing: 14) {
                            HStack(alignment: .firstTextBaseline) {
                                if index == 0 { Text("出处").bubbleFont(.headline).accessibilityAddTraits(.isHeader) }
                                Spacer(minLength: 12)
                                Text(Date(timeIntervalSince1970: encounter.createdAt), format: .dateTime.year().month().day().hour().minute())
                                    .bubbleFont(.caption).foregroundStyle(.secondary)
                                    .multilineTextAlignment(.trailing)
                            }
                            if encounter.kind == "translation" { CaptureContextMeaningView(capture: encounter) }
                            CaptureSceneView(capture: encounter, showsMetadata: false)
                        }
                    }
                    if capture.isMock { Text("AI Mock · 测试数据").bubbleFont(.caption).foregroundStyle(.orange) }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(24)
            } else { ContentUnavailableView("记录已删除", systemImage: "trash", description: Text("另一设备的删除已同步，关联场景不再展示。")) }
        }.navigationTitle(embedded ? "" : BubbleLocalization.text("记录详情"))
        .toolbar { if !embedded { Button("删除", systemImage: "trash", role: .destructive) { confirm = true } } }
        .confirmationDialog("从所有设备删除此记录及全部出处？", isPresented: $confirm) {
            Button("删除记录", role: .destructive) { Task { if await store.deleteRecord(recordID), !embedded { dismiss() } } }
        }
        .task(id: DictionaryTaskID(record: recordID, attempt: dictionaryAttempt)) {
            guard let record = store.record(recordID), record.latest.kind == "translation" else { return }
            dictionaryStatus = "loading"
            do { dictionaryStatus = try await store.loadDictionary(for: record).status }
            catch is CancellationError { }
            catch { if !Task.isCancelled { dictionaryStatus = "error" } }
        }
        .safeAreaInset(edge: .bottom) { if let error = store.error { Text(error).bubbleFont(.caption).foregroundStyle(.red).padding() } }
    }
    private struct DictionaryTaskID: Equatable {
        var record: BubbleRecord.ID
        var attempt: Int
    }
}

enum BubbleLearningDestination: Hashable {
    case plan
    case review(String)
}

struct BubbleLearningView: View {
    @Environment(BubbleStore.self) private var store
    var onSelect: ((BubbleLearningDestination) -> Void)? = nil
    var selection: BubbleLearningDestination? = nil
    @State private var filter = "全部"
    @State private var search = ""
    @State private var language = "all"
    @State private var period = "all"
    private var items: [LearningItem] {
        store.learning.filter { item in
            let evidence = item.captureIds.compactMap { store.state.captures[$0] }
            let cutoff = Date().addingTimeInterval(period == "week" ? -7 * 86400 : -30 * 86400).timeIntervalSince1970
            return (filter == "全部" || item.status() == filter) &&
                (search.isEmpty || (item.term + item.meaning).localizedCaseInsensitiveContains(search)) &&
                (language == "all" || evidence.contains { ($0.sourceLanguage ?? LanguageRouting.detect($0.source)) == language }) &&
                (period == "all" || evidence.contains { $0.createdAt >= cutoff })
        }
    }
    var body: some View {
        #if os(macOS)
        VStack(spacing: 14) {
            BubbleMacSearchField(text: $search, prompt: "查找学习过的表达")
            learningList
        }
        #else
        learningList
            .navigationTitle(BubbleLocalization.text("场景学习"))
            .searchable(text: $search, prompt: "查找学习过的表达")
        #endif
    }

    private var learningList: some View {
        List {
            Section {
                BubbleCard {
                    Label("从你查过的内容开始回忆。", systemImage: "rectangle.stack")
                        .bubbleFont(.title3, weight: .semibold)
                    Text("学习材料优先使用当时的原文。测试样例会单独标注；复习反馈和跨端同步使用真实记录。")
                        .bubbleFont(.subheadline).foregroundStyle(.secondary)
                    ConnectionStatus()
                }.listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                    .listRowBackground(Color.clear).listRowSeparator(.hidden)
                Picker("学习状态", selection: $filter) { ForEach(["全部", "待评估", "学习中", "较稳固", "建议复习", "已暂停"], id: \.self) { Text(LocalizedStringKey($0)) } }
                DisclosureGroup("按语言与时间筛选") {
                    Picker("语言", selection: $language) { Text("全部语言").tag("all"); ForEach(LanguageRouting.languages, id: \.0) { Text($0.1).tag($0.0) } }
                    Picker("遇见时间", selection: $period) { Text("全部时间").tag("all"); Text("最近 7 天").tag("week"); Text("最近 30 天").tag("month") }
                }
            }
            if let plan = store.state.plan {
                Section("自动整理的学习安排") {
                    destinationLink(.plan) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(plan.title).bubbleFont(.headline)
                            Text("每天约 \(plan.dailyMinutes) 分钟 · 从自己的场景练习听说读写").bubbleFont(.caption).foregroundStyle(.secondary)
                            if plan.isMock { Text("AI Mock · 学习模板").bubbleFont(.caption2).foregroundStyle(.orange) }
                            if ["pending", "retrying"].contains(plan.status ?? "") {
                                Text("正在根据你的记录生成练习…").bubbleFont(.caption).foregroundStyle(.secondary)
                            } else if plan.status == "failed" {
                                Text("这次没有生成成功，原记录已保存。").bubbleFont(.caption).foregroundStyle(.secondary)
                            }
                        }.bubbleRow()
                    }.accessibilityIdentifier("openStudyPlan")
                        .listRowInsets(EdgeInsets(top: 5, leading: 0, bottom: 5, trailing: 0))
                        .listRowBackground(Color.clear).listRowSeparator(.hidden)
                }
            }
            ForEach(items) { item in
                destinationLink(.review(item.id)) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(item.term).bubbleFont(.headline)
                        HStack { Text(LocalizedStringKey(item.status())); Spacer(); Text("遇见 \(item.captureIds.count) 次 · 回忆 \(item.reviews) 次") }.bubbleFont(.caption).foregroundStyle(.secondary)
                    }.bubbleRow()
                }
                .listRowInsets(EdgeInsets(top: 5, leading: 0, bottom: 5, trailing: 0))
                .listRowBackground(Color.clear).listRowSeparator(.hidden)
            }
            if store.learning.isEmpty { Text("完成一次有释义的查询后，会自动整理到这里。暂无 Mock 样例的输入不会生成虚假学习材料。").foregroundStyle(.secondary) }
        }.bubbleListStyle().refreshable { await store.sync() }
    }

    @ViewBuilder
    private func destinationLink<Label: View>(_ destination: BubbleLearningDestination, @ViewBuilder label: () -> Label) -> some View {
        if let onSelect {
            Button { onSelect(destination) } label: {
                label().frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityAddTraits(selection == destination ? .isSelected : [])
        } else {
            NavigationLink {
                switch destination {
                case .plan: BubblePlanView()
                case .review(let id): BubbleReviewView(itemId: id)
                }
            } label: { label() }
        }
    }
}

struct BubbleReviewView: View {
    @Environment(BubbleStore.self) private var store
    var itemId: String
    @State private var revealed = false
    @State private var submitted = false
    @State private var submitting = false
    var item: LearningItem? { store.state.learning[itemId] }
    var body: some View {
        List {
            if let item {
                Section("还记得它的意思吗？") { Text(item.term).bubbleFont(.title2, weight: .bold); SpeechControls(text: item.term) }
                Section("想起当时的场景") {
                    if let id = item.captureIds.first, let capture = store.state.captures[id] { CaptureSceneView(capture: capture) }
                    Text(item.example).italic().textSelection(.enabled)
                    Text(item.exampleSource == "captured" ? "来自当时记录的原文" : "AI 生成例句").bubbleFont(.caption).foregroundStyle(.secondary)
                }
                if revealed {
                    Section("释义") { Text(item.meaning).bubbleFont(.headline); Text(item.explanation); if item.isMock { Text("AI Mock · 测试数据").foregroundStyle(.orange) } }
                    Section("这次回忆怎么样？") {
                        ForEach([("again", "没想起来"), ("hard", "有点困难"), ("good", "记得"), ("easy", "很轻松")], id: \.0) { value in
                            Button(LocalizedStringKey(value.1)) {
                                submitting = true
                                Task { submitted = await store.review(item, rating: value.0); submitting = false }
                            }.buttonStyle(.bubbleSecondary).disabled(submitting || submitted || item.paused)
                        }
                    }
                    if submitted { Text("反馈已记录。联网后同步到另一台设备；多日回忆证据才会提升为较稳固。").foregroundStyle(.secondary) }
                } else { Button("揭示答案") { revealed = true }.buttonStyle(.bubblePrimary) }
                Section {
                    Text(BubbleLocalization.text("当前：%@", BubbleLocalization.text(item.status())))
                    if item.reviews > 0 { Text(BubbleLocalization.text("建议下次：%@", Date(timeIntervalSince1970: item.dueAt).formatted())) }
                    Button(LocalizedStringKey(item.paused ? "恢复学习" : "暂停学习")) { Task { await store.pause(item) } }
                }
            } else { Text("此学习项已被删除。") }
        }.bubbleListStyle().navigationTitle(BubbleLocalization.text("回忆")).onChange(of: itemId) { _, _ in revealed = false; submitted = false }
    }
}

private struct BubbleLearningLanguagePicker: View {
    @Environment(BubbleStore.self) private var store
    var showsSelection = false

    var body: some View {
        @Bindable var store = store
        Picker(selection: $store.learningLanguage) {
            ForEach(LanguageRouting.languages, id: \.0) { language in
                Text(LocalizedStringKey(language.1)).tag(language.0)
            }
        } label: {
            if showsSelection {
                Text(BubbleLocalization.text("正在学习的语言：%@",
                    BubbleLocalization.text(LanguageRouting.languages.first { $0.0 == store.learningLanguage }?.1 ?? "English")))
            } else {
                Text("正在学习的语言")
            }
        }.accessibilityIdentifier("learningLanguagePicker")
    }
}

struct BubbleSettingsView: View {
    @AppStorage("bubbleInterfaceLanguage") private var interfaceLanguage = "zh-Hans"
    @AppStorage("bubbleTheme") private var theme = "system"
    @AppStorage("bubbleAutoSpeak") private var autoSpeak = false
    @AppStorage("bubbleSlowSpeech") private var slowSpeech = false
    @AppStorage("bubbleBritishSpeech") private var britishSpeech = false
    @Environment(BubbleStore.self) private var store
    @State private var endpoint = ""
    @State private var code = ""
    @State private var token = ""
    @State private var clear = false
    var body: some View {
        Form {
            Section {
                BubbleActivityGrid()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 8)
            }
            #if os(macOS)
            MacCaptureSettings()
            #endif
            Section("双端连接") {
                ConnectionStatus()
                if let session = store.session {
                    Text(BubbleLocalization.text("测试账号：%@", String(session.userId.prefix(8)))).textSelection(.enabled)
                    Text(BubbleLocalization.text("设备：%@", String(session.deviceId.prefix(8)))).bubbleFont(.caption).foregroundStyle(.secondary)
                    Text(store.endpoint).bubbleFont(.caption)
                    Button("生成另一设备的配对码") { Task { await store.makePairCode() } }
                    if let pair = store.pairCode {
                        Text(pair.code).font(.title.monospaced()).textSelection(.enabled)
                        Text("10 分钟内有效，仅能使用一次。另一台设备填写此码即可加入同一账号。").bubbleFont(.caption)
                    }
                    Button("立即同步") { Task { await store.sync() } }.disabled(store.syncing)
                    Button("退出此设备", role: .destructive) { Task { await store.logout() } }.disabled(store.syncing || store.querying)
                } else {
                    TextField("服务地址", text: $endpoint)
                    TextField("另一设备提供的 12 位配对码", text: $code)
                    Button("与另一设备配对") { Task { await store.connect(endpoint: endpoint, code: code.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()); await store.sync() } }
                        .disabled(code.trimmingCharacters(in: .whitespacesAndNewlines).count != 12 || store.syncing)
                    DisclosureGroup("第一台设备：创建本机测试账号") {
                        SecureField("本机服务访问令牌", text: $token)
                        Button("创建测试账号") { store.bootstrapToken = token; Task { await store.connect(endpoint: endpoint); await store.sync() } }.disabled(token.isEmpty || store.syncing)
                    }
                }
            }
            Section("测试方式") {
                Text("两台设备需要访问同一个本机服务；iPhone 模拟器可以使用 127.0.0.1。账号和记录保存在此 Mac 的本机数据库中。AI 模式以连接状态为准。")
                Text("前台每 4 秒同步，可离线查看已同步的文字。已记录的操作会在重连后补传。此版本不是公网云服务。")
            }.bubbleFont(.footnote)
            Section("外观与发音") {
                Picker("界面语言 / Interface", selection: $interfaceLanguage) { Text("简体中文").tag("zh-Hans"); Text("English").tag("en") }.accessibilityIdentifier("interfaceLanguage")
                Picker("外观", selection: $theme) { Text("跟随系统").tag("system"); Text("浅色").tag("light"); Text("深色").tag("dark") }
                Toggle("打开查询结果时自动发音", isOn: $autoSpeak)
                Toggle("慢速", isOn: $slowSpeech)
                Toggle("英式", isOn: $britishSpeech)
            }
            Section("学习语言") {
                BubbleLearningLanguagePicker()
            }
            Section {
                NavigationLink("开源许可") {
                    ScrollView {
                        Text((Bundle.main.url(forResource: "ThirdPartyLicenses", withExtension: "txt")
                            .flatMap { try? String(contentsOf: $0, encoding: .utf8) }) ?? "ShadKit · MIT License")
                            .bubbleFont(.footnote).textSelection(.enabled).padding(24)
                    }.navigationTitle(BubbleLocalization.text("开源许可"))
                }
            }
            if store.session != nil { Section("学习目标") { NavigationLink("目标与每天可用时间") { BubbleGoalView() } } }
            #if os(iOS)
            Section("iOS 收集入口") { NavigationLink("系统翻译与键盘设置") { SettingsView(showDataControls: false) } }
            #endif
            if store.session != nil {
                Section("数据管理") {
                    NavigationLink("导出学习内容（CSV / Anki / TXT）") { BubbleExportView() }
                    ShareLink("导出全部记录 JSON", item: String(data: (try? BubbleCodec.encoder.encode(store.captures)) ?? Data(), encoding: .utf8) ?? "[]")
                    Button("清空此账号全部记录", role: .destructive) { clear = true }.disabled(store.syncing || store.querying)
                }
            }
        }
        #if os(macOS)
        .formStyle(.grouped)
        #endif
        .bubbleListStyle().navigationTitle(BubbleLocalization.text("设置"))
        .onAppear { endpoint = store.endpoint; token = store.bootstrapToken }
        .confirmationDialog("清空此账号在所有设备上的记录、场景和复习？", isPresented: $clear) {
            Button("清空全部", role: .destructive) { Task { await store.clear() } }
        }
    }
}

@MainActor @Observable final class BubbleSpeech {
    private let synth = AVSpeechSynthesizer()
    func speak(_ text: String, slow: Bool, british: Bool) {
        synth.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: text)
        let detected = LanguageRouting.detect(text) ?? "en"
        let language = detected == "en" ? (british ? "en-GB" : "en-US") : ["zh": "zh-CN", "es": "es-ES", "pt": "pt-PT", "fr": "fr-FR", "de": "de-DE", "ja": "ja-JP", "ko": "ko-KR"][detected] ?? detected
        utterance.voice = AVSpeechSynthesisVoice(language: language)
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * (slow ? 0.75 : 1)
        synth.speak(utterance)
    }
}

struct SpeechControls: View {
    var text: String
    var iconOnly = false
    var phonetic: String? = nil
    var designScale: CGFloat? = nil
    @State private var speech = BubbleSpeech()
    @AppStorage("bubbleSlowSpeech") private var slow = false
    @AppStorage("bubbleBritishSpeech") private var british = false
    @AppStorage("bubbleAutoSpeak") private var autoSpeak = false
    var body: some View {
        HStack(alignment: designScale == nil ? .firstTextBaseline : .center, spacing: 8) {
            if let phoneticText {
                Text(phoneticText).bubbleFont(.body).foregroundStyle(.secondary)
                    .textSelection(.enabled)
                    .accessibilityIdentifier("wordPhonetic")
            }
            if iconOnly {
                if let designScale {
                    Button { speech.speak(text, slow: slow, british: british) } label: {
                        // The Figma export includes the 12 top / 4.35 bottom optical padding.
                        Image("RecordSpeaker").resizable()
                            .frame(width: 32 * designScale, height: 71 * designScale)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain).accessibilityLabel("发音").help("发音")
                } else {
                    speakButton.labelStyle(.iconOnly)
                    .bubbleFont(.title3)
                    .buttonStyle(.borderless)
                    .controlSize(.large)
                    .help("发音")
                    #if os(iOS)
                    .frame(minWidth: 44, minHeight: 44)
                    #endif
                }
            } else {
                speakButton.bubbleFont(.caption).buttonStyle(.bubbleSecondary)
            }
        }.onAppear { if autoSpeak { speech.speak(text, slow: slow, british: british) } }
    }

    private var phoneticText: String? {
        guard let value = phonetic?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty else { return nil }
        return value.hasPrefix("/") || value.hasPrefix("[") ? value : "/\(value)/"
    }

    private var speakButton: some View {
        Button("发音", systemImage: "speaker.wave.2") { speech.speak(text, slow: slow, british: british) }
    }
}
