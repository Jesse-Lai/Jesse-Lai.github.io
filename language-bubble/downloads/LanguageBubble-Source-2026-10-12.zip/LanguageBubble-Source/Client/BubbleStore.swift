import Foundation
import Observation

struct PendingImage: Codable, Identifiable {
    var id: String
    var captureId: String
    var file: String
}

// Local presentation of an imported source image. The original screenshot is
// kept intact for the full-size preview and the existing sync protocol.
struct BubbleScenePresentation: Codable, Equatable {
    var aspectRatio: Double
    var imageWidth: Double
    var imageHeight: Double
    var imageX: Double
    var imageY: Double
    var artwork: BubbleSceneArtwork?
    // Optional curated collage image; the capture's original still opens in preview.
    var displayImageName: String? = nil
    var placement: BubbleScenePlacement? = nil
}

struct BubbleScenePlacement: Codable, Equatable {
    var x: Double
    var y: Double
    var width: Double
    var height: Double
    var rotation: Double
}

// Identifies the local design treatment; capture events and originals stay intact.
enum BubbleSceneArtwork: String, Codable {
    case bubbleBook, bubblePost, journeyTravel, journeyQuote, journeyTicket, curatedCutout, superseded
}

struct BubbleLocalState: Codable {
    var endpoint = "http://127.0.0.1:8788"
    var session: DeviceSession?
    var cursor = 0
    var epoch = 0
    var captures: [String: BubbleCapture] = [:]
    var learning: [String: LearningItem] = [:]
    var reviews: [String: ReviewEvent] = [:]
    var outbox: [SyncOperation] = []
    var images: [PendingImage] = []
    var importedIds: Set<String> = []
    var bridgeEpoch: Int?
    var profile: StudyProfile?
    var plan: StudyPlan?
    var milestones: [String: StudyMilestone]?
    var articles: [String: LearningArticle]?
    var dictionaries: [String: WordDictionaryEntry]?
    var contextMeanings: [String: WordContextMeaning]?
    var learningLanguage: String?
    var scenePresentations: [String: BubbleScenePresentation]?
    var favoriteRecords: Set<String>?
}

@MainActor @Observable
final class BubbleStore {
    private(set) var state = BubbleLocalState()
    var error: String?
    var syncing = false
    var querying = false
    var requestingPlan = false
    var status = "尚未连接"
    var aiMode = "unknown"
    var selectedTab = 0
    var showingSettings = false
    var generatingArticles = false
    var articleError: String?
    var pairCode: PairCode?
    var latest: BubbleCapture?
    var partialTranslation = ""
    private var queryGeneration = UUID()
    private var translationTask: Task<TranslationResult, Error>?
    private var polishTask: Task<PolishResult, Error>?
    var bootstrapToken = ""
    var bridgeSnapshot: (() throws -> JournalSnapshot)?
    var configureBridge: ((DeviceSession?, String) throws -> Void)?
    var syncBridge: (() async throws -> Void)?
    var removeBridgeRecord: ((String) -> Void)?
    var clearBridge: (() throws -> Void)?
    var configureBridgeProfile: ((StudyProfile) throws -> Void)?
    private let root: URL
    private var generation = UUID()
    private var articleMutation = UUID()
    private var durableState = BubbleLocalState()
    var clientFactory: (String, String) -> SyncClient = { SyncClient(endpoint: $0, token: $1) }
    var aiFactory: (CapturePreferences) -> AIClient = { AIClient(preferences: $0) }

    init(root: URL? = nil) throws {
        self.root = try root ?? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask,
            appropriateFor: nil, create: true).appendingPathComponent("LanguageBubble", isDirectory: true)
        try FileManager.default.createDirectory(at: self.root, withIntermediateDirectories: true)
        try FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: self.root.path)
        let url = self.root.appendingPathComponent("state.json")
        if FileManager.default.fileExists(atPath: url.path) {
            state = try BubbleCodec.decoder.decode(BubbleLocalState.self, from: Data(contentsOf: url))
        }
        status = state.session == nil ? "尚未连接" : "等待同步"
        durableState = state
        #if DEBUG
        if let url = Bundle.main.url(forResource: "BetaConnection", withExtension: "json"),
           let data = try? Data(contentsOf: url), let config = try? JSONDecoder().decode([String: String].self, from: data) {
            bootstrapToken = config["token"] ?? ""
        }
        #endif
    }

    var session: DeviceSession? { state.session }
    var endpoint: String { state.endpoint }
    var captures: [BubbleCapture] { state.captures.values.sorted { $0.createdAt > $1.createdAt } }
    var records: [BubbleRecord] { BubbleRecord.grouped(Array(state.captures.values)) }
    var learningLanguage: String {
        get {
            if let language = LanguageRouting.normalized(state.learningLanguage ?? state.profile?.secondaryLanguage),
               LanguageRouting.languages.contains(where: { $0.0 == language }) { return language }
            return "en"
        }
        set {
            guard LanguageRouting.languages.contains(where: { $0.0 == newValue }), newValue != state.learningLanguage else { return }
            state.learningLanguage = newValue
            do { try save() } catch { self.error = error.localizedDescription }
        }
    }
    var learningRecords: [BubbleRecord] {
        records.filter { record in
            LanguageRouting.recordLanguage(record.latest, dictionary: dictionary(for: record)) == learningLanguage
        }
    }
    func record(_ id: BubbleRecord.ID) -> BubbleRecord? { records.first { $0.id == id } }
    private func favoriteKey(_ id: BubbleRecord.ID) -> String {
        id.kind + ":" + (id.isMock ? "mock:" : "") + id.term
    }
    func isFavorite(_ id: BubbleRecord.ID) -> Bool {
        state.favoriteRecords?.contains(favoriteKey(id)) ?? false
    }
    func toggleFavorite(_ id: BubbleRecord.ID) {
        guard record(id) != nil else { return }
        let key = favoriteKey(id)
        if state.favoriteRecords == nil { state.favoriteRecords = [] }
        if state.favoriteRecords!.contains(key) { state.favoriteRecords!.remove(key) }
        else { state.favoriteRecords!.insert(key) }
        do { try save() } catch { self.error = error.localizedDescription }
    }
    func scenePresentation(_ assetID: String) -> BubbleScenePresentation? {
        state.scenePresentations?[assetID]
    }
    var learning: [LearningItem] { state.learning.values.sorted { $0.dueAt < $1.dueAt } }
    var reviews: [ReviewEvent] { Array(state.reviews.values) }
    var articles: [LearningArticle] {
        (state.articles ?? [:]).values
            .filter { $0.captureIds.allSatisfy { state.captures[$0] != nil } }
            .sorted { $0.generatedAt > $1.generatedAt }
    }
    var client: SyncClient { clientFactory(state.endpoint, state.session?.token ?? bootstrapToken) }

    func dictionary(for record: BubbleRecord) -> WordDictionaryEntry? {
        let language = record.latest.targetLanguage ?? "zh"
        return record.encounters.compactMap(\.dictionary).first { $0.language == language }
            ?? state.dictionaries?[language + ":" + record.id.term]
    }

    func loadDictionary(for record: BubbleRecord) async throws -> WordDictionaryResponse {
        if let entry = dictionary(for: record) { return WordDictionaryResponse(status: "found", entry: entry) }
        struct Body: Encodable { var text: String; var language: String }
        let language = record.latest.targetLanguage ?? "zh"
        let run = generation
        let response: WordDictionaryResponse = try await client.request("v1/dictionary", method: "POST",
            body: BubbleCodec.encoder.encode(Body(text: record.latest.source, language: language)))
        try Task.checkCancellation()
        guard generation == run, self.record(record.id) != nil else { throw CancellationError() }
        if let entry = response.entry {
            if state.dictionaries == nil { state.dictionaries = [:] }
            state.dictionaries?[language + ":" + record.id.term] = entry
            try save()
        }
        return response
    }

    func contextMeaning(for capture: BubbleCapture) -> WordContextMeaning? {
        capture.contextMeaning ?? state.contextMeanings?[capture.id]
    }

    // Backfill older records without creating another encounter or overwriting
    // their immutable original translation. Newly captured senses sync normally.
    func loadContextMeaning(for capture: BubbleCapture) async throws {
        guard contextMeaning(for: capture) == nil, !capture.isMock,
              let context = capture.surroundingText, !context.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              capture.source.split(whereSeparator: \.isWhitespace).count <= 6, let session else { return }
        let run = generation
        var prefs = CapturePreferences()
        prefs.serviceURL = endpoint; prefs.serviceToken = session.token
        let response = try await aiFactory(prefs).translate(capture.source, id: UUID(), context: context,
            targetLanguage: capture.targetLanguage ?? "zh", sourceApp: capture.sourceApp)
        try Task.checkCancellation()
        guard run == generation, state.captures[capture.id] != nil, let sense = response.contextMeaning else { return }
        if state.contextMeanings == nil { state.contextMeanings = [:] }
        state.contextMeanings?[capture.id] = sense
        try save()
    }

    private func save() throws {
        do {
        state.articles = state.articles?.filter { $0.value.captureIds.allSatisfy { state.captures[$0] != nil } }
        state.contextMeanings = state.contextMeanings?.filter { state.captures[$0.key] != nil }
        let oldAssets = Set(durableState.captures.values.flatMap(\.assetIds))
        let retainedAssets = Set(state.captures.values.flatMap(\.assetIds))
        let data = try BubbleCodec.encoder.encode(state)
        let url = root.appendingPathComponent("state.json")
        #if os(iOS)
        try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        #else
        try data.write(to: url, options: .atomic)
        #endif
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
        durableState = state
        // Delete cached scenes only after the corresponding state is durable.
        for id in oldAssets.subtracting(retainedAssets) {
            try? FileManager.default.removeItem(at: root.appendingPathComponent(id + ".png"))
        }
        } catch { state = durableState; throw error }
    }

    func connect(endpoint: String, code: String? = nil) async {
        guard !syncing else { return }
        syncing = true; error = nil
        defer { syncing = false }
        do {
            let endpoint = endpoint.trimmingCharacters(in: .whitespacesAndNewlines)
            let client = clientFactory(endpoint, bootstrapToken)
            #if os(macOS)
            let name = "Mac"
            #else
            let name = "iPhone"
            #endif
            let session = try await (code == nil ? client.account(name: name) : client.pair(code: code!, name: name))
            generation = UUID()
            state = BubbleLocalState(); state.endpoint = endpoint; state.session = session; state.epoch = session.epoch
            try save()
            try configureBridge?(session, endpoint)
            status = "已连接，准备同步"
        } catch { self.error = error.localizedDescription }
    }

    func makePairCode() async {
        do { pairCode = try await client.request("v2/pair-codes", method: "POST") }
        catch { self.error = error.localizedDescription }
    }

    func logout() async {
        guard !syncing, !querying else { return }
        do {
            let _: EmptyResponse = try await client.request("v2/logout", method: "POST")
            generation = UUID()
            try configureBridge?(nil, endpoint)
            state = BubbleLocalState(); pairCode = nil; latest = nil
            try save(); status = "已退出"
        } catch { self.error = error.localizedDescription }
    }

    private func importLegacy() throws {
        guard state.session != nil, let bridgeSnapshot else { return }
        let snapshot = try bridgeSnapshot()
        var removed = Set(snapshot.state.tombstones.map { $0.uuidString.lowercased() })
        if let epoch = state.bridgeEpoch, epoch != snapshot.state.epoch {
            removed.formUnion(state.importedIds.intersection(state.captures.keys))
        }
        for id in removed where state.captures[id] != nil { enqueueDelete(id) }
        state.bridgeEpoch = snapshot.state.epoch
        for record in snapshot.records {
            let id = record.id.uuidString.lowercased()
            guard !state.importedIds.contains(id), !removed.contains(id) else { continue }
            let capture = BubbleCapture(record: record)
            state.importedIds.insert(id)
            state.captures[id] = capture
            state.outbox.append(SyncOperation(action: "capture.put", entityId: id, capture: capture))
        }
    }

    func sync() async {
        guard state.session != nil, !syncing else { return }
        syncing = true
        let run = generation
        defer { syncing = false }
        do {
            var bridgeSession = session
            bridgeSession?.epoch = state.epoch
            try configureBridge?(bridgeSession, endpoint)
            try importLegacy(); try save()
            let health: ServiceHealth = try await client.request("health")
            guard generation == run else { return }
            aiMode = health.aiMode
            try await pull(run: run)
            guard generation == run else { return }
            bridgeSession = session
            bridgeSession?.epoch = state.epoch
            try configureBridge?(bridgeSession, endpoint)
            try await syncBridge?()
            guard generation == run else { return }
            // Upload original scene files before the immutable capture referencing them.
            var attachmentFailure: Error?
            for image in state.images {
                do {
                let body = try Data(contentsOf: root.appendingPathComponent(image.file))
                let _: AssetReceipt = try await client.request("v2/assets/\(image.id)?capture_id=\(image.captureId)",
                    method: "PUT", body: body, mime: "image/png")
                guard generation == run else { return }
                state.images.removeAll { $0.id == image.id }; try save()
                } catch { attachmentFailure = error }
            }
            while !state.outbox.isEmpty {
                let waiting = Set(state.images.map(\.captureId))
                let batch = Array(state.outbox.filter { !waiting.contains($0.entityId) }.prefix(100))
                if batch.isEmpty { break }
                let receipt = try await client.push(batch, epoch: state.epoch)
                guard generation == run else { return }
                let accepted = Set(receipt.accepted)
                guard accepted == Set(batch.map(\.opId)) else { throw ContextError.invalidResponse }
                state.outbox.removeAll { accepted.contains($0.opId) }; try save()
            }
            try await pull(run: run)
            try configureBridgeProfile?(state.profile ?? StudyProfile())
            // Separate collection keeps older clients' sync change schema compatible.
            await refreshArticles()
            if let attachmentFailure { throw attachmentFailure }
            error = nil
            status = BubbleLocalization.text("已同步 · %@", Date().formatted(date: .omitted, time: .shortened))
        } catch {
            if generation == run {
                status = BubbleLocalization.text("暂未同步 · 待发送 %lld 项", state.outbox.count)
                self.error = error.localizedDescription
            }
        }
    }

    private func pull(run: UUID) async throws {
        var more = true
        while more {
            let page = try await client.pull(cursor: state.cursor)
            guard generation == run else { return }
            if page.epoch != state.epoch {
                try clearBridge?()
                for id in state.captures.keys { removeBridgeRecord?(id) }
                state.captures = [:]; state.learning = [:]; state.reviews = [:]
                state.profile = nil; state.plan = nil; state.milestones = nil; state.articles = nil
                state.outbox = []; state.images = []
                state.epoch = page.epoch
                // Retain import IDs so cleared extension records cannot silently re-upload.
            }
            for change in page.changes {
                if change.deleted {
                    if change.kind == "capture" {
                        state.captures.removeValue(forKey: change.id)
                        state.importedIds.insert(change.id)
                        state.outbox.removeAll { $0.entityId == change.id }
                        state.images.removeAll { $0.captureId == change.id }
                        removeBridgeRecord?(change.id)
                    }
                    if change.kind == "learning" { state.learning.removeValue(forKey: change.id) }
                    if change.kind == "review" { state.reviews.removeValue(forKey: change.id) }
                    if change.kind == "profile" { state.profile = nil }
                    if change.kind == "plan" { state.plan = nil }
                    if change.kind == "milestone" { state.milestones?.removeValue(forKey: change.id) }
                } else {
                    if let value = change.capture, !state.outbox.contains(where: { $0.entityId == value.id && $0.action == "capture.delete" }) { state.captures[value.id] = value }
                    if let value = change.learning { state.learning[value.id] = value }
                    if let value = change.review { state.reviews[value.id] = value }
                    if let value = change.profile { state.profile = value }
                    if let value = change.plan { state.plan = value }
                    if let value = change.milestone {
                        if state.milestones == nil { state.milestones = [:] }
                        state.milestones?[value.id] = value
                    }
                }
            }
            state.cursor = page.cursor; more = page.hasMore
            try save()
        }
    }

    func query(_ text: String, writing: Bool = false, polishing: Bool = false, context: String? = nil, sourceApp: String? = nil,
               sourceUrl: String? = nil, image: Data? = nil, onPartial: (@MainActor (String) -> Void)? = nil) async {
        guard session != nil, !querying else { return }
        querying = true; error = nil; latest = nil; partialTranslation = ""
        let requestGeneration = UUID(); queryGeneration = requestGeneration
        let run = generation
        defer { querying = false; partialTranslation = ""; translationTask = nil; polishTask = nil }
        do {
            let source = text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !source.isEmpty, source.unicodeScalars.count <= (writing ? 500 : 6000), (context?.unicodeScalars.count ?? 0) <= 12000 else { throw ContextError.service("原文或场景文字过长，请缩小范围。") }
            let sourceUrl = sourceUrl?.trimmingCharacters(in: .whitespacesAndNewlines)
            let sourceLink = CaptureSourceLink.url(sourceUrl)
            if let sourceUrl, !sourceUrl.isEmpty, sourceLink == nil {
                throw ContextError.service("来源链接需是有效的 HTTP 或 HTTPS 地址。")
            }
            guard (image?.count ?? 0) <= 8 * 1024 * 1024 else { throw ContextError.service("场景图片需小于 8 MB。") }
            var prefs = CapturePreferences(); prefs.serviceURL = endpoint; prefs.serviceToken = session!.token; prefs.automaticChecking = true
            let id = UUID()
            var capture: BubbleCapture
            if polishing {
                let task = Task { try await aiFactory(prefs).polish(source, id: id, context: context, sourceApp: sourceApp) }
                polishTask = task
                let response = try await withTaskCancellationHandler {
                    try await task.value
                } onCancel: {
                    task.cancel()
                }
                let language = LanguageRouting.detect(source)
                capture = BubbleCapture(id: id.uuidString.lowercased(), kind: "writing", source: source,
                    result: response.polished, explanation: response.explanation, category: "polish",
                    isMock: response.isMock == true, sourceLanguage: language, targetLanguage: language)
            } else if writing {
                let response = try await aiFactory(prefs).check(source, id: id)
                guard let issue = response.actionable(in: source) else {
                    status = response.isMock == true ? (response.complete ? "AI Mock · 正确句子样例" : "AI Mock · 暂无检查样例") : "未发现明确错误"
                    return
                }
                capture = BubbleCapture(id: id.uuidString.lowercased(), kind: "writing", source: source,
                    result: source.replacingOccurrences(of: issue.original, with: issue.replacement), explanation: issue.explanation,
                    category: issue.category, originalSpan: issue.original, replacement: issue.replacement, isMock: response.isMock == true)
            } else {
                let profile = state.profile ?? StudyProfile()
                let sourceLanguage = LanguageRouting.detect(source)
                let target = LanguageRouting.target(detected: sourceLanguage, primary: profile.primaryLanguage, secondary: profile.secondaryLanguage)
                let response: TranslationResult
                let useMockStream = aiMode == "mock"
                let task = Task {
                    if useMockStream {
                        try await aiFactory(prefs).streamTranslate(source, id: id, context: context, targetLanguage: target) { [weak self] text in
                            await self?.receivePartial(text, request: requestGeneration, notify: onPartial)
                        }
                    } else {
                        try await aiFactory(prefs).translate(source, id: id, context: context, targetLanguage: target, sourceApp: sourceApp)
                    }
                }
                translationTask = task
                response = try await withTaskCancellationHandler {
                    try await task.value
                } onCancel: {
                    task.cancel()
                }
                capture = BubbleCapture(id: id.uuidString.lowercased(), source: source, result: response.translation,
                                        explanation: response.explanation, isMock: response.isMock == true,
                                        sourceLanguage: sourceLanguage, targetLanguage: target,
                                        dictionary: response.dictionary, contextMeaning: response.contextMeaning)
            }
            try Task.checkCancellation()
            guard generation == run, queryGeneration == requestGeneration else { return }
            capture.surroundingText = context; capture.sourceApp = sourceApp; capture.sourceUrl = sourceLink?.absoluteString
            // Explicit polish is a temporary editing aid, not a learning record.
            // Return it before any image, local state, outbox or sync mutation.
            if polishing { latest = capture; return }
            if let image {
                let assetId = UUID().uuidString.lowercased()
                let filename = assetId + ".png"
                try image.write(to: root.appendingPathComponent(filename), options: .atomic)
                try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: root.appendingPathComponent(filename).path)
                capture.assetIds = [assetId]
                state.images.append(PendingImage(id: assetId, captureId: capture.id, file: filename))
            }
            state.captures[capture.id] = capture
            state.outbox.append(SyncOperation(action: "capture.put", entityId: capture.id, capture: capture))
            try save(); latest = capture
            await sync()
        } catch { if queryGeneration == requestGeneration, !Task.isCancelled { self.error = error.localizedDescription } }
    }

    func cancelQuery() { queryGeneration = UUID(); translationTask?.cancel(); polishTask?.cancel(); partialTranslation = ""; status = "查询已取消，未完成内容不会保存" }
    private func receivePartial(_ text: String, request: UUID, notify: (@MainActor (String) -> Void)?) {
        if queryGeneration == request { partialTranslation = text; notify?(text) }
    }

    private func enqueueDelete(_ id: String) {
        guard let capture = state.captures[id] else { return }
        state.captures.removeValue(forKey: capture.id)
        // AI materials may draw on any selected record, so discard the whole derived plan.
        state.plan = nil
        for key in Array(state.learning.keys) {
            guard var item = state.learning[key], item.captureIds.contains(id) else { continue }
            item.captureIds.removeAll { $0 == id }
            if let remaining = item.captureIds.first, let evidence = state.captures[remaining] {
                item.example = evidence.surroundingText ?? evidence.source
                item.explanation = evidence.explanation
                state.learning[key] = item
            } else {
                state.learning.removeValue(forKey: key)
                state.plan?.tasks.removeAll { $0.learningId == key }
                state.reviews = state.reviews.filter { $0.value.learningId != key }
                state.outbox.removeAll { $0.review?.learningId == key || $0.entityId == key }
            }
        }
        state.images.removeAll { $0.captureId == capture.id }
        state.outbox.removeAll { $0.entityId == capture.id }
        state.outbox.append(SyncOperation(action: "capture.delete", entityId: capture.id))
        state.importedIds.insert(capture.id)
        if latest?.id == id { latest = nil }
    }

    @discardableResult
    func delete(_ capture: BubbleCapture) async -> Bool {
        await deleteCaptures([capture.id])
    }

    @discardableResult
    func deleteRecord(_ id: BubbleRecord.ID) async -> Bool {
        // Resolve current membership so an encounter synced after navigation is
        // included. Persist the entire deletion before touching bridge files.
        await deleteCaptures(record(id)?.encounters.map(\.id) ?? [])
    }

    private func deleteCaptures(_ ids: [String]) async -> Bool {
        let previousLatest = latest
        for id in ids { enqueueDelete(id) }
        do {
            try save()
            for id in ids { removeBridgeRecord?(id) }
            await sync()
            return true
        } catch { latest = previousLatest; self.error = error.localizedDescription; return false }
    }

    @discardableResult
    func review(_ item: LearningItem, rating: String) async -> Bool {
        guard state.learning[item.id] != nil, !item.paused,
              ["again", "hard", "good", "easy"].contains(rating) else { return false }
        let review = ReviewEvent(learningId: item.id, rating: rating)
        state.outbox.append(SyncOperation(action: "review.put", entityId: review.id, review: review))
        do { try save(); await sync(); return true } catch { self.error = error.localizedDescription; return false }
    }

    func pause(_ item: LearningItem) async {
        state.outbox.append(SyncOperation(action: "learning.pause", entityId: item.id, paused: !item.paused))
        do { try save(); await sync() } catch { self.error = error.localizedDescription }
    }

    func updateProfile(_ profile: StudyProfile) async {
        state.profile = profile
        state.outbox.append(SyncOperation(action: "profile.put", entityId: profile.id, profile: profile))
        do { try save(); await sync() } catch { self.error = error.localizedDescription }
    }

    func retryPlan() async {
        guard session != nil, !requestingPlan else { return }
        requestingPlan = true; error = nil
        defer { requestingPlan = false }
        let expected = generation
        do {
            let _: EmptyResponse = try await client.request("v2/plan/retry", method: "POST")
            guard expected == generation else { return }
            await sync()
        } catch { if expected == generation { self.error = error.localizedDescription } }
    }

    func acknowledge(_ milestone: StudyMilestone) async {
        state.milestones?[milestone.id]?.acknowledged = true
        state.outbox.append(SyncOperation(action: "milestone.ack", entityId: milestone.id))
        do { try save(); await sync() } catch { self.error = error.localizedDescription }
    }

    func refreshArticles() async {
        guard session != nil else { return }
        let expected = generation
        let expectedEpoch = state.epoch
        let expectedMutation = articleMutation
        do {
            let collection: ArticleCollection = try await client.request("v2/articles")
            guard expected == generation, expectedEpoch == state.epoch, expectedMutation == articleMutation else { return }
            var values: [String: LearningArticle] = [:]
            for article in collection.articles where article.captureIds.allSatisfy({ state.captures[$0] != nil }) {
                let current = state.articles?[article.id]
                values[article.id] = (current?.revision ?? -1) > article.revision ? current : article
            }
            state.articles = values
            try save()
            articleMutation = UUID()
        } catch { /* Keep offline articles available; explicit actions show their own errors. */ }
    }

    var articleVocabularyCounts: [ArticleVocabularyLevel: Int] {
        var items: [String: LearningItem] = [:]
        for item in learning {
            for id in item.captureIds { items[id] = item }
        }
        var seen = Set<String>()
        var counts: [ArticleVocabularyLevel: Int] = [:]
        for capture in captures where !capture.isMock && !capture.result.isEmpty {
            let item = items[capture.id]
            guard item?.paused != true, item?.isMock != true else { continue }
            let key = item?.id ?? capture.source.split(whereSeparator: \.isWhitespace).joined(separator: " ").lowercased()
                + "|" + capture.result.lowercased()
            guard seen.insert(key).inserted else { continue }
            counts[ArticleVocabularyLevel.classify(item), default: 0] += 1
        }
        return counts
    }

    func generateArticles(topic: String, captureIDs: [String] = [], wordCount: Int = 400,
                          vocabularyLevels: [ArticleVocabularyLevel] = ArticleVocabularyLevel.allCases,
                          savedWordScope: ArticleSavedWordScope = .all, instructions: String = "",
                          requestID: String) async {
        guard !generatingArticles else { return }
        guard session != nil else { articleError = "请先在账号设置中连接服务。"; return }
        generatingArticles = true; articleError = nil
        let expected = generation
        defer { generatingArticles = false }
        do {
            await sync()
            guard expected == generation else { return }
            guard state.outbox.isEmpty else { throw ContextError.service("记录尚未同步，请连接服务后重试。") }
            let expectedEpoch = state.epoch
            struct Body: Encodable {
                var requestId: String; var topic: String; var captureIds: [String]
                var wordCount: Int; var vocabularyLevels: [ArticleVocabularyLevel]
                var savedWordScope: ArticleSavedWordScope; var instructions: String
            }
            var service = client; service.timeout = 90
            let collection: ArticleCollection = try await service.request("v2/articles/generate", method: "POST",
                body: BubbleCodec.encoder.encode(Body(requestId: requestID, topic: topic, captureIds: captureIDs,
                    wordCount: wordCount, vocabularyLevels: vocabularyLevels,
                    savedWordScope: savedWordScope, instructions: instructions)))
            guard expected == generation, expectedEpoch == state.epoch else { return }
            if state.articles == nil { state.articles = [:] }
            for article in collection.articles where article.captureIds.allSatisfy({ state.captures[$0] != nil }) {
                if article.revision >= (state.articles?[article.id]?.revision ?? -1) { state.articles?[article.id] = article }
            }
            try save()
            articleMutation = UUID()
        } catch {
            if expected == generation { articleError = articleFailure(error) }
        }
    }

    func askArticle(_ id: String, question: String, requestID: String) async throws {
        guard session != nil, state.articles?[id] != nil else { throw ContextError.service("文章已不可用，请返回文章库。") }
        let expected = generation
        let expectedEpoch = state.epoch
        struct Body: Encodable { var requestId: String; var question: String; var primaryLanguage: String }
        var service = client; service.timeout = 75
        do {
            let article: LearningArticle = try await service.request("v2/articles/\(id)/chat", method: "POST",
                body: BubbleCodec.encoder.encode(Body(requestId: requestID, question: question,
                    primaryLanguage: state.profile?.primaryLanguage ?? "zh")))
            try Task.checkCancellation()
            guard expected == generation, expectedEpoch == state.epoch, state.articles?[id] != nil,
                  article.captureIds.allSatisfy({ state.captures[$0] != nil }) else { throw CancellationError() }
            if article.revision >= (state.articles?[id]?.revision ?? 0) { state.articles?[id] = article }
            try save()
            articleMutation = UUID()
        } catch is CancellationError { throw CancellationError() }
        catch { throw ContextError.service(articleFailure(error)) }
    }

    private func articleFailure(_ error: Error) -> String {
        if case ContextError.service(let message) = error { return message }
        guard let http = error as? SyncHTTPError else { return "暂时无法连接 AI 服务，请稍后重试。" }
        switch http.status {
        case 401: return "连接已失效，请在账号设置中重新配对。"
        case 404, 409: return "文章或来源记录已变化，请刷新后重试。"
        case 422: return "所选掌握程度暂无可用词汇，请调整选择；提问时请检查问题长度。"
        case 429: return "AI 正在处理请求，请稍后重试。"
        case 503: return "请先启动真实 AI 服务，再生成文章或提问。"
        default: return "这次 AI 没有完成内容，请重试。已有文章仍然保留。"
        }
    }

    func clear() async {
        guard !syncing, !querying else { return }
        do {
            let _: EmptyResponse = try await client.request("v2/clear", method: "POST")
            await sync()
        } catch { self.error = error.localizedDescription }
    }

    func asset(_ id: String) async throws -> Data {
        guard state.captures.values.contains(where: { $0.assetIds.contains(id) }) else { throw ContextError.invalidResponse }
        let local = root.appendingPathComponent(id + ".png")
        if FileManager.default.fileExists(atPath: local.path) { return try Data(contentsOf: local) }
        let run = generation
        let data = try await client.raw("v2/assets/\(id)")
        guard generation == run, state.captures.values.contains(where: { $0.assetIds.contains(id) }) else { throw ContextError.invalidResponse }
        try data.write(to: local, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: local.path)
        return data
    }
}
