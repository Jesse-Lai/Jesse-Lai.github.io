# Language Bubble

原生 iOS + macOS 场景语言学习测试版。查询与写作问题进入同一账号，保留原文、图片和上下文；自动整理学习项与听说读写练习，跨设备同步复习和进度。

本机已接通 **Azure Responses / gpt-6-sol**，真实翻译与纠错、iPhone 原生查询 / 复习和双设备接口同步已通过验收。新安装仍默认 Mock；live 模式下，听说读写安排由模型根据个人记录、原场景、目标和复习反馈自动生成；Mock 模式仍保留标注过的模板。账号会话、网络同步、附件、OCR、复习与持久化均实际运行。本轮使用方式、iPhone 真机安装及暂缓的云方案见 [最简流程指南](docs/LOCAL_TEST_GUIDE.md)。完整范围与限制见 [实现状态](docs/IMPLEMENTATION_STATUS.md)、[验收记录](docs/BETA_ACCEPTANCE.md)、[产品需求](docs/PRD.md)。

## 在这台 Mac 上测试

1. 启动本机服务并启用登录启动：`bash scripts/run-beta.sh --login`。地址 `http://127.0.0.1:8788`；后台服务由 macOS 管理，关闭终端不影响翻译，异常退出会自动恢复，重启 Mac 并登录后自动启动。仅需当前会话后台运行时使用 `--background`。
2. 打开 `build/Language Bubble.app`。也可在 Xcode 打开 `Context.xcodeproj`，选择 **LanguageBubbleMac** scheme。
3. iOS 选择 **Context** scheme、iPhone 17 Pro 模拟器，运行 App。当前本机模拟器已与 Mac 配对。
4. 新设备在 Mac 的“连接”页生成一次性配对码，在 iPhone “连接”页输入；有效期 10 分钟。
5. 一端查询 `It is a work in progress.`、`products` 或 `That makes sense.`，另一端前台约 4 秒内出现。写作样例 `I am agree with you.`。
6. “学习”页选择词句，回想原场景、揭示答案、提交反馈；另一端看到同一结果。“连接 → 学习目标”可设置目标与每日时间。

模拟器的 127.0.0.1 能连接这台 Mac；实体 iPhone 的 127.0.0.1 指向手机自身。真机请使用同一 Wi-Fi 下的 Mac 地址，按最简流程指南完成签名与配对；尚未宣称真机已安装。

## 场景与 Mac 入口

- 主界面“补充场景”可填原句、来源 URL 或导入照片 / 图片。Mac 快捷键 `⌘⇧I` 打开图片选择器。
- `⌃⌥T` 查询其他 App 的选区；无选区回退光标取词 / OCR。
- `⌃⌥R` 拖动区域截图 OCR；Esc 取消。
- 主窗口可开启 Option 悬浮取词，设置中可自定义快捷键。
- AX 选区读取需要辅助功能；OCR 只需屏幕录制权限，图片导入不需要这两项权限。当前测试构建权限自检未生效，图片导入仍可完整体验 OCR → 同步 → 学习。
- 主 App 与 Mac 浮层支持流式 Mock 结果和取消；中断结果不保存。浮层支持固定；固定气泡可跨 Spaces 保留，未固定气泡随下一次查询替换。完整多屏 / 多宿主行为尚待验收。

受控场景文件：`Tests/Fixtures/scene-products.png`。导入后将查询内容选为 `products`，保留 OCR 原文和图片，再查询，即可在另一端查看相同场景。

## iOS 系统入口

“设置 → App → 默认 App → 翻译”选择 **Language Bubble**，选词后点系统“翻译”即可进入自定义扩展，不额外询问 AI 同意。

英文键盘在“设置 → 通用 → 键盘 → 添加新键盘”添加 **Language Bubble 英文**，按需允许完全访问并开启自动检查。键盘只处理当前输入框可取得的短句；不会全局监听其他键盘输入，也不自动发送消息。翻译扩展不保证来源 URL 或全文，Look Up 不被接管。

## 从仓库首次搭建

依赖：Xcode 26.4.1（当前验收环境）、Python 3.11+。主 App 的基础界面使用 ShadKit 的 `ShadcnUI`，由 Xcode 自动获取固定提交；首次构建需要连接 GitHub。核心逻辑与扩展不依赖该包。界面接入与后续替换说明见 [轻量翻新说明](docs/SHADKIT_REFRESH.md)。

```sh
cd server
uv sync
cp -n .env.example .env
```

在忽略的 `.env` 中设置独立随机 `CONTEXT_CLIENT_TOKEN`，保持 `AI_MODE=mock`。令牌不是模型 Key；仅用于本机测试账号引导。首次设备在“连接 → 第一台设备”输入服务令牌，其他设备使用配对码。

可选的本地 `Config/BetaConnection.json` 仅包含引导令牌，为忽略且权限 0600 的文件；不提交 Git，不公开分发 Debug 构建。Release 排除此资源，代码也仅在 Debug 读取。每台设备会话当前保存在受权限保护的本地文件 / App Group，后续生产版需迁移 Keychain。

```sh
python3 scripts/generate_project.py
bash scripts/build-mac.sh
bash scripts/run-beta.sh
```

iOS 模拟器构建必须保留 ad hoc 签名，否则 App Group 无法访问：

```sh
xcodebuild -project Context.xcodeproj -scheme Context \
  -configuration Debug -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath build CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=- build
```

## 真实模型测试

本机私有 `server/.env` 已配置 Azure；密钥只由服务端读取，不进入 App 或仓库。显式配置 `AI_MODE=live`、`AI_PROVIDER=azure_responses`、`AI_RESPONSES_URL`、`AI_MODEL` 和 `AI_API_KEY`；字段模板见 `server/.env.example`。重启本机服务后，`/health` 和 App 显示真实 AI。保持 `.env` 权限 0600，模型 Key 与客户端连接令牌分开。

- 发送选中的文字和可用上下文；场景图片当前只在本机同步服务保存，不上传给模型。
- Azure 使用用户指定的 Responses 地址与部署名；`api-key` 请求头、严格 JSON 输出、`store=false`，不跟随重定向。`store=false` 不等于提供方承诺完全不保留服务日志。
- 真实模式目前整条结果返回；流式展示仍仅用于 Mock。查询取消会取消客户端请求并丢弃未完成记录，不承诺撤销已发生的模型计费。
- 翻译 / 纠错错误不自动回退 Mock；旧 Mock 记录保留原标记；live 模式会自动生成四类个性化练习，明确区分原文场景与生成材料。
- 显式运行 `cd server` 后 `.venv/bin/python smoke_live.py`：用三个合成输入调用真实模型，并在独立本机测试账号的两个设备会话之间验证场景保存、复习回传。该命令会使用模型额度。
- 新增学习流程检查：`cd server && .venv/bin/python smoke_learning.py`，用合成的查询与写作错误验证真实个性化生成、同一计划跨设备会话同步、复习反馈，结束后清理测试账号中的内容。该命令使用模型额度。
- 原生验收：`testRealAITranslationWritingAndReview`，需本机 live 服务与已配对模拟器。最近通过报告为 `build/RealAI-02.xcresult`。Mac 界面工具连接故障，真实模型版的 Mac 窗口操作及系统取词入口尚未在本轮验收。

## 测试与数据

```sh
swift test --scratch-path /private/tmp/context-core-build
cd server
.venv/bin/python -m unittest discover -s tests
.venv/bin/python smoke_mock.py
```

Xcode 的 Context scheme 包含 UI 回归测试。`testNativeCrossDeviceRoundTrip` 需用 `BETA_TEST_PAIR_CODE=新配对码` 构建后运行；`testPairedSceneAndLearningPlan` 需先通过 Mac 原生导入 products 场景。这些集成测试依赖真实本机服务，不预埋相同历史冒充同步。

- 服务数据：`server/.local-data/bubble.sqlite3`，不提交 Git。
- Mac 数据：用户 Application Support 下的 `LanguageBubble` 目录；iOS 数据在各自沙盒，扩展队列在 App Group。
- 前台轮询；后台挂起时不保证即时同步。断网可看已同步记录和已下载图片，删除 / 反馈等待重连补传；翻译需要本机服务在线。
- 本机服务停止时，运行 `bash scripts/run-beta.sh --login` 恢复并保持登录启动；重复运行会检查现有后台服务。配置在 `~/Library/LaunchAgents/com.jesselai.languagebubble.beta-server.plist`，只引用现有本地 `.env`，不嵌入密钥；项目和虚拟环境需保留在原路径。日志在 `build/beta-service/server.log`。`--stop` 停止当前服务（下次登录仍启动），`--uninstall` 同时停止服务并移除登录启动。需要局域网时停止后以 `--login --lan` 启动；只需当前登录会话使用 `--background`。不带这些选项时在当前终端运行。不要结束未知占用端口的进程。
- `--demo` 保留原有 iOS 隔离示例 UI，不参与跨端账号和同步。

正式云账号、长期自适应课程、Apple 发布签名、TestFlight 与 Mac 公证不在已验收交付中；完整计划继续保留，不把本机测试结果等同于正式发布。
