# Language Bubble · 本机 beta 验收记录

日期：2026-09-27。只记录实际执行结果。早期检查使用 Mock；用户随后提供 Azure 模型，现已通过真实翻译与纠错验收。没有公开部署。

## 可复现构建

- Mac：`bash scripts/build-mac.sh`，输出 `build/Language Bubble.app`，包含 arm64 / x86_64。
- Xcode Mac：`LanguageBubbleMac` scheme，Debug / Release 构建通过；Release 资源排除 `BetaConnection.json` 已检查。
- iOS：`Context` scheme，iPhone 17 Pro / iOS 26.4，需 `CODE_SIGNING_ALLOWED=YES CODE_SIGN_IDENTITY=-` 保留模拟器 App Group。
- 本机服务：`bash scripts/run-beta.sh`，127.0.0.1:8788；数据库与凭证都在 Git 忽略目录内。

## 通过的检查

| 类别 | 已执行结果 | 文件 / 命令 |
| --- | --- | --- |
| Swift 核心 | 47 项通过，含扩展同步及新增 4 项取词回归；另补测蓝色选区 OCR 的 SceneTests 8 项通过 | `swift test --scratch-path /private/tmp/context-core-build`；`build/hover-regression-after.log`、`build/hover-highlight-regression.log` |
| 服务与导出 | 47 项通过 | `cd server && .venv/bin/python -m unittest discover -s tests` |
| Mock 链路 | 翻译、纠错、正确句和未知样例通过；测试禁止真实 provider / 外部 HTTP | `server/smoke_mock.py`、`server/tests/test_mock.py` |
| 原生双向查询 / 复习 | 1 项通过，Mac → iPhone、iPhone → Mac 均实际出现记录 | `build/CrossDevice-03.xcresult` |
| 原生场景图片 / 计划 / 重启 | 1 项通过，原图、OCR 语境、回忆和里程碑确认均完成 | `build/SceneSync-03.xcresult` |
| 写作纠错 / 删除 / 重启 | 1 项通过，实际纠错同步到 Mac，iOS 删除持久化 | `build/WritingDelete-06.xcresult` |
| 中英文界面 / 重启 | 1 项通过，实际切换英文、重启检查学习页，再恢复中文 | `build/Localization-01.xcresult` |
| 流式取消 / 中断 | 增量回调、终止帧一致性、取消和中断后重启无部分记录 | `Tests/CoreTests/AIClientTests.swift` |
| iOS 基线 UI | 3 项通过，示例浏览设置、清空、真实 App Group 启动 | `build/Regression-02.xcresult` |
| 真实 Vision | 图片识别、products 及多行 resilient / setbacks 等词命中、蓝色选区、空白拒绝、无效图片拒绝通过 | `Tests/CoreTests/SceneTests.swift` |
| 删除与离线 | API tombstone、epoch、撤销扩展记录传播、旧学习场景清理、失败附件不阻挡独立操作 | 核心与服务测试 |
| 导出格式 | CSV 编码与公式转义、TXT 英文单词过滤、Anki ZIP/SQLite 完整性与字段映射 | `server/tests/test_export.py` |
| 凭证 | 工作区候选源码 / 配置的模型 Key 格式扫描零命中；模型凭证不在 Git | 只报告命中数量，不输出配置内容 |

## 测试中发现并修正的问题

- 无签名模拟器构建无法访问 App Group，改为 ad hoc 签名。
- UI 配对码需要显式测试 Info.plist 变量 `BETA_TEST_PAIR_CODE`，早期跳过结果不计入通过。
- 场景图片使“揭示答案”移出可见区域，测试增加滚动后通过。
- 翻译扩展撤销保存原先只删本机 journal，现通过 tombstone 导入同步删除。
- 删除场景时清理历史 learning / plan 载荷，防止新设备拉取旧场景。
- 写盘失败恢复到最近持久化状态，不能显示“反馈已记录”的假成功。
- 同一天重复成功反馈不延长记忆间隔为多日掌握。
- 图片上传失败与独立文字操作分开重试。
- 学习 worker 使用固定数据库实例和绝对路径，暂时存储错误进入重试，避免永久停止；故障恢复测试通过，重启服务 health 为 ready。
- 磁盘空间不足中断了两次构建。已获准清理本项目约 400 MB 重复编译缓存，恢复构建；SQLite integrity_check 为 ok。
- 写作 UI 测试先验证模式开关，再以记录 ID 定位；删除完成后才重启，避免点击与动画造成误判。
- 删除写盘失败时保留原场景缓存，不删除 App Group 记录，详情页展示失败信息。
- Mac 浮层新增增量结果和取消，每个固定气泡保留独立结果。双架构构建通过，真实浮层行为仍待权限与界面工具恢复。

## 尚待验收

- Mac 辅助功能 / 屏幕录制已重新关联开发证书版本，两项权限均确认开启。用户截图已展示 Option 查词、Chrome 句子译文与场景图；浮层及框选显示修复的最新证据见文末。多屏 / Spaces 和全宿主矩阵仍待验收。
- 实际 Anki / 不背单词导入、旧设置页与学习模板完整英文翻译、字幕 / 倾斜 / 混合语言 OCR、长列表性能需要进一步验证。
- Intel 和 macOS 14 仅编译目标，未在对应硬件 / 最低系统运行。
- iPhone 开发签名、真机安装与 X 系统翻译同步已完成，详见下方最新检查点；键盘真机宿主、Mac Developer ID 签名、公证、TestFlight、云账号和公开部署仍未完成。
- Mock 学习模板不是模型教学评估，简单 SRS 不是 FSRS 个性化拟合，也不代表长期记忆提升已证实。

完整范围继续保留：[执行计划](OVERNIGHT_EXECUTION_PLAN.md)、[对标清单](HOVER_TRANSLATE_PARITY.md)。

## 2026-09-27 Azure 真实模型检查点

- 用户提供的新 Azure 配置取代本机“仅 Mock”的限制；已使用 `gpt-6-sol` 和用户指定的 `2025-04-01-preview` Responses 地址实际调用。只在服务端私有配置中存储密钥。
- 直接模型调用：`We are on the same page.` → `我们达成共识了。`，约 3.6 秒；解释符合给定的发布前沟通上下文。
- `server/smoke_live.py`：真实 HTTP、两个独立设备会话、原文上下文保存、学习项和复习回传全部通过；另验证错误句修正与正确句不报错，三个模型请求合计约 6.4 秒。属于接口联动，不能称为 Mac UI 操作。
- iPhone 原生 `testRealAITranslationWritingAndReview`：1 通过、0 跳过、0 失败；`build/RealAI-02.xcresult`。真实模型查询 → 详情无 Mock 标记 → 学习 → 复习反馈；重启后真实纠错 `She don't like coffee.` → `She doesn't like coffee.`。测试截图已导出并检查。
- Swift 36 项通过，新增桌面采集任务互斥、双屏 / 边缘裁切、长文选区上下文与真实翻译取消测试。服务 38 项通过，新增 Azure 请求契约、严格输出、超时、拒绝 / 中断、重定向拒绝与错误内容脱敏测试。单元测试不访问 Azure。
- 最新 iOS 与两扩展构建通过；Mac arm64 / x86_64 构建和签名检查通过。Mac 查译新增选区边界截图、恢复来源 App、采集中切窗校验、只采集来源 App 窗口，以及无需 AX 的 OCR 路径；真实宿主验证仍待权限与界面连接。
- 本机服务已以 `live / ready` 重启，数据库 integrity_check 为 `ok`；旧 Mock 记录没有改为真实模型标记。今日练习仍是固定 Mock 模板，真实模型流式和生成学习计划待继续。
- Mac 界面自动化仍返回 `Sky Computer Use native pipe closed before response`，本轮没有通过脚本绕过连接故障，也没有完成权限开关操作。不能将 iPhone / 接口的通过记为本轮 Mac GUI 通过。

接口依据：[Azure Responses](https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/responses)、[OpenAI Responses 创建参数](https://developers.openai.com/api/reference/resources/responses/methods/create)。配置使用用户给定的旧版 Azure 地址，成功实测后保留；没有擅自改用其他部署。

### 原生 iPhone → 正在运行的 Mac App

通过只读核对 Mac App 自己持久化的 `state.json` 与服务记录，确认原生 iPhone 测试产生的翻译记录 `09fb1158-5c03-410a-853b-797d6b8adbe6`、纠错记录 `65a0f07c-c009-4026-a832-5ee0d5035ecf` 已由 Mac 客户端下载。记录 ID / 译文相同，Mac 学习项引用同一 Capture，收到 1 次真实复习反馈，`is_mock=false`。没有直接向 Mac 状态文件写入测试数据。

这证明真实模型数据和反馈已进入实际 Mac 客户端；证据是持久化状态核对，Mac 窗口可见性和系统取词操作仍未被本轮 GUI 工具验证。

原生截图：[翻译](screenshots/real-ai-translation.png)、[复习](screenshots/real-ai-review.png)、[纠错](screenshots/real-ai-writing.png)。私有 Azure Key 精确扫描覆盖 123 个候选仓库文件及 App 构建文件，命中 0；服务配置文件权限 0600。


## 2026-09-27 最简真实 AI 学习验收

- 后端 47 项、Swift 核心 37 项全部通过；新增结构化学习请求、任务重启恢复 / 有限重试、源记录删除后丢弃结果、目标变化、跨账号隔离、同一表达不同场景引用及 Debug 局域网地址规则。
- `server/smoke_learning.py` 已实际调用 Azure：合成查询 + 写作错误 → 工作目标的 4 个真实生成任务 → 两个独立设备会话得到同一计划 → 复习反馈回传。一次流程约 17.6 秒，不代表性能基准；测试完成清理独立账号内容。
- 原生 iPhone 模拟器 `testRealAIStudyPlan` 最终报告 `build/PersonalAI-04.xcresult`：1 通过，0 跳过，0 失败。覆盖查询、自动等待生成、听说读写四类材料与答案、练习内真实纠错 `He go to work every day.` → `He goes to work every day.`、重启后查看更新后的计划。结果可见性已检查，截图已导出。
- `PersonalAI-01` 发现 iPhone 前台同步没有随 scenePhase 重启，导致停在生成中；修复后 02 通过。03 补测练习内纠错，截图发现键盘遮挡结果；加入主动收起键盘并检查结果在屏幕中可见，04 通过。只以最终通过结果作为当前验收。
- 正在运行的 Mac 客户端已下载同一真实计划，任务 ID / 原文 / 答案与服务端只读核对一致（4 项）；没有向客户端状态文件写入测试记录。新 Mac 双架构构建与签名验证通过；Mac 新界面和真实宿主取词没有通过本轮 GUI 验收。
- 原生界面工具多次返回 `Sky Computer Use native pipe closed before response`，辅助功能 / 屏幕录制状态尚待用户确认。Safari、Chrome、Preview 的选词、Option 取词和区域截图仍待实际操作，不以构建或模型测试替代。
- 已读取连接的实体 iPhone 17，显示 `connected (no DDI)`；没有可用签名身份。本轮交付安装操作说明与 Debug LAN 支持，未完成实体设备安装 / Translate 和键盘真机宿主验收。
- 服务最终健康检查为 `ok / live / ready`，仍监听本机 127.0.0.1:8788；数据库检查为 ok。源码及 App 文件的 Azure Key 精确扫描 131 个文件、0 命中；私有配置未进入仓库。

截图：[个人计划](screenshots/personal-ai-plan.png)、[场景阅读](screenshots/personal-ai-reading.png)、[练习内纠错](screenshots/personal-ai-writing-check.png)。操作步骤与暂缓的云方案见 [最简流程指南](LOCAL_TEST_GUIDE.md)。

## 2026-09-27 真机系统翻译与 Mac 同步验收

- 实体 iPhone 17 / iOS 26.7 已开启开发者模式，完成开发签名安装与账号配对。本机服务通过 `run-beta.sh --lan` 监听 `0.0.0.0:8788`；iPhone 使用 Mac 的 `.local:8788` 地址，Mac 使用 `127.0.0.1:8788`，真实 AI 服务健康状态为 `ok / live / ready`。
- 系统翻译联网修复：按 Apple 文档在主 App Info.plist 补齐翻译网络访问声明，并同步更新工程生成脚本。用户真机截图确认 X 的翻译浮层返回 `workhorse` 真实译文。
- 同步修复：翻译扩展保存后直接上传，显示上传结果；持久操作队列独立于主 App 导入，失败可重试。43 项 Swift 核心测试通过，包括新增 6 项上传、重试、撤销、删除回声、epoch 和账号切换回归；真机包构建及严格签名检查通过，已覆盖安装。构建日志：`build/iphone-extension-sync-build.log`。
- 旧记录恢复由代理观察：升级后启动一次主 App，`workhorse` 补传；Mac 原生界面记录数从 16 增至 17，译文一致。
- 扩展独立上传由用户真机复测确认：按留在 X 中查新词、不返回主 App 的步骤操作，浮层显示「已同步到其他设备」；Mac 保持前台，几秒后出现新记录。此流程已通过，无需每次打开 iPhone 主 App 才能同步。
- 真机撤销同步与断网后补传仍待验收，目前只有核心测试证据。当前仍依赖 Mac 本机服务、同一局域网和 Mac 保持唤醒；没有部署云服务。

## 2026-09-27 Mac 采集权限修复进展

- 系统原生 UI 确认 Language Bubble 的辅助功能与屏幕录制开关均为 on，App 自检仍为未开启。退出旧进程后启动当前构建，自检仍未通过，排除仅旧进程未重启的解释。
- 原构建为 ad hoc 临时签名。`build-mac.sh` 已改为在仅有一个可用 Apple Development 身份时自动选择，并支持显式指定；当前 arm64 / x86_64 构建及严格签名验证通过，Team 为 `399H92R96W`。日志：`build/mac-permission-build.log`。
- 用户确认重新授权后，先手动移除了辅助功能旧条目；代理通过系统文件选择器重新加入 `build/Language Bubble.app`。屏幕录制旧条目也已移除并重新添加，执行系统「Quit & Reopen」；App 内原生 UI 最终显示「辅助功能已开启」「屏幕录制已开启」，Option 悬浮取词开启且重启后保留。
- 原生「区域 OCR」按钮已实际打开框选界面。已准备本地 Chrome 测试页；界面工具拒绝单独发送 Option（`keyPressIncludedNoNonModifierKeys`），组合键尝试不能作为单按 Option 的验收证据。已请用户框选测试句并单按 Option 复测，实际译文与新记录尚待确认。

## 2026-09-27 Mac 浮层与截图蒙层

- 用户随后提供截图：Option 查询 `resilient` 已有真实译文，Chrome 的 `A resilient team learns from setbacks and keeps moving forward.` 已显示译文及场景图。截图同时暴露浮层过窄、选框内没有挖空两处显示缺陷。
- 第二个白色词典卡片确认为 Hover Translate：进程路径及其原生最近查询 `resilie / shortened form of resilient` 与用户截图一致；它的主页明确使用 Option。用户同意后已通过菜单退出；同时退出本项目重复运行的旧 Xcode Debug App，重建后只启动 `build/Language Bubble.app`。
- 修复浮层尺寸：禁用 NSHostingView 由内容反推窗口大小，设置初始内容 480 × 520、最小 400 × 300，内容水平填充，长内容纵向滚动；定位使用实际窗口尺寸。实际原生浮层截图已确认 480 宽、译文可读、无逐字窄列。
- 「固定此气泡」改为「保留此译文窗口」，帮助提示说明下次查询不替换、跨桌面保留；底部说明记录自动保存，与是否保留窗口无关。中英文资源同步更新。
- 修复框选：每次重绘清空旧像素，even-odd 路径只绘制选框外的 30% 黑色蒙层。对实际 RegionSelectionView 做离屏位图检查，框内 alpha=0、框外约 0.3；缩小后旧选区恢复遮罩、反向拖动透明、重复绘制不加深均通过。临时验证程序与位图位于忽略的 `build/region-render-check.swift`、`build/region-mask-render.png`。
- arm64 / x86_64 编译及严格签名验证通过：`build/mac-capture-ui-build.log`。新 App 已启动，原生权限页仍显示两项权限已开启，Option 开关仍开启。
- 更新后原生浮层结果已实看；真实框选拖动补测被界面工具坐标操作 `noWindowsAvailable` 阻挡。离屏渲染通过不替代实际多屏 / Spaces 和单按 Option 的完整复测。

## 2026-09-27 Option 取词目标修复

- 用户新截图显示选中 `resilient`、`setbacks` 时分别查成 `A`、`Could`。这否定了此前对 Option 取词准确性的通过判断；浮层显示正常不代表目标文字正确。
- 旧 Option 路径不读取明确选区，直接使用 AXRangeForPosition 的字符位置且不核对词边界；OCR 回退也会在扩大后的行区域里按横向距离挑选最近单词。
- 新逻辑在按键事件时固定来源和鼠标位置；先读同一来源 App 的明确选区，检查焦点及指针处节点的少量父节点。保留真实选中文字，丢弃与其不一致的范围，插入光标和普通文本标签不能当成选区。
- 无选区时不再信任未经验证的 AX 字符位置，使用来源截图中的 OCR 单词边界，只有鼠标落在单词内（最多 2 图像像素边缘容差）才查询。AppKit → AX 和截图内归一化坐标独立检查；不命中就报错，不挑附近另一行或句首词。
- 修复前新增回归实际失败于「鼠标在句首左侧空白也选词」。修复后 Swift 47 项全部通过；另外 SceneTests 8 项通过，覆盖无选区 / 蓝色选中 resilient / 蓝色选中 setbacks 三种图像，逐个测试多行单词命中及空白拒绝。坐标来自独立字体测量，不从 OCR 结果反推。测试不调用 AI。
- arm64 / x86_64 构建及原开发证书签名验证通过，日志 `build/mac-hover-hit-build.log`；新版已重启。已请用户实际复测「选中 setbacks 后 Option」「取消选区后 hover resilient」；结果待确认，不把离屏 OCR 测试当成 Chrome 真实按键通过。

## 2026-09-27 按用户要求简化译文窗口

- 移除「保留此译文窗口」按钮、多气泡和跨桌面固定逻辑；H10 固定已移出当前计划。
- 控制器只持有一个 NSPanel，新查询替换该窗口内容并回到内容顶部，保留用户调整的位置和大小。点击关闭后保持关闭；查询结果回调只更新数据，不重新展示窗口；下次主动查询可重新打开。
- 底部提示简化为「已自动保存到记录。」，中英文资源同步更新。
- arm64 / x86_64 构建、严格签名验证、资源语法与差异检查通过；日志 `build/mac-single-window-build.log`。已通过原生应用菜单退出旧版并启动新版，主窗口正常显示已有记录。本轮未新增单元测试，也未将连续查词 / 关闭重开记为已完成的实机操作验收。
