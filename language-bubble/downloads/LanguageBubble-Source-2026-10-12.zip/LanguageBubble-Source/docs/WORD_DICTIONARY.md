# 单词详情：词典释义与语境释义

详情页按 ECDICT 原有词性展示全部已收录释义，不截断为单一译文。`a.` 规范为 `adj.`，专业领域但没有明确词性的补充释义独立显示，避免误标为上一行的动词。词典收录并不代表穷尽所有现代用法。中文和英文释义可用；其他目标语言保留原有翻译。

每次出处单独保存 `context_meaning`（词性、此处含义、判断说明）。AI 根据已采集的 `surrounding_text` 和 `source_app` 判断，例如 Figma / Frame 3 指设计画框。截图仍用于回看，并未传给文本模型；证据不足时不强行选择义项。

旧记录打开时读取词典并在本机缓存；有文本语境的旧词条会补分析语境，结果缓存于本机，不修改不可变的 capture，也不创建重复记录。新记录的词典和语境结果随 capture 同步。旧记录补分析的缓存目前各设备独立建立。词典不可用时显示已保存翻译并支持重试。

## 词库安装

本次接入版本：`skywind3000/ECDICT@bc015ed2e24a7abef49fc6dbbb7fe32c1dadaf8b`，770,611 条。

```sh
curl -L --fail https://raw.githubusercontent.com/skywind3000/ECDICT/bc015ed2e24a7abef49fc6dbbb7fe32c1dadaf8b/ecdict.csv -o /tmp/ecdict.csv
python3 scripts/import_dictionary.py /tmp/ecdict.csv
```

CSV SHA-256：`1a6947e04785db63613a92e14903cdae7954f7e84860b10e68e5c7cbb3f9c3cf`。

默认索引位于 `server/.local-data/ecdict.sqlite3`（不进入 Git），也可使用 `ECDICT_PATH` 指定路径。导入采用临时数据库后替换，运行时只读。换机器部署时须执行同样的安装步骤；接口不依赖在线第三方词典请求。

## 数据源选择与授权

- [ECDICT](https://github.com/skywind3000/ECDICT)：英汉双解、多词性、词形、音标。仓库当前 [LICENSE](https://github.com/skywind3000/ECDICT/blob/bc015ed2e24a7abef49fc6dbbb7fe32c1dadaf8b/LICENSE) 标为 MIT；授权全文保存在 `Resources/ThirdPartyLicenses.txt`，界面提供来源链接。README 同时说明内容汇集多个历史数据源；大规模商业再分发需核对这些数据来源，不能仅将仓库代码许可证理解为各上游内容版权都已核实。
- [Wiktionary / Kaikki](https://kaikki.org/dictionary/rawdata.html)：提供结构化词性、义项及多语种数据，适合后续扩展。提取器 Wiktextract 的 MIT 许可证与 Wiktionary 内容许可是两件事，接入时须按所选数据版本保留其内容许可和归属信息。
- [Free Dictionary API](https://github.com/meetDeveloper/freeDictionaryAPI)：接口直接返回 `partOfSpeech`、`definitions`；主要适合英语释义，依赖公共在线服务。本次没有接入。

## 验证

`server/tests/test_dictionary.py` 覆盖词性解析、专业补充、语言选择、索引导入与错误回退；API 和同步测试覆盖来源线索、无语境不返回确定义项、鉴权与跨设备字段保留。Swift 核心测试覆盖旧 JSON 兼容、两次出处的独立含义、旧词典/语境缓存及不改写历史。

本机服务启动后：`server/.venv/bin/python server/smoke_word_details.py` 可检查真实词库和 Figma / Frame 3 的模型结果，不写入记录。
