# Bubble Toolbar Lab

Three native SwiftUI visual studies for Language Bubble: **Dewdrop / 露珠**, **Peach Fizz / 桃汽水**, and **Aurora / 极光**. Each uses layered radial gradients, moving highlights, continuous rounded corners, and subtle breathing motion. No bitmap background assets, web view, or shader dependency.

This is an independent preview app. It does not alter the main application or register system-wide selection monitoring.

## Run

From the repository root:

```sh
bash docs/prototypes/bubble-toolbar/build.sh
open 'build/bubble-toolbar-lab/Bubble Toolbar Lab.app'
```

The build script targets Apple Silicon with macOS 14+. It uses the installed Xcode Swift compiler and ad hoc signing, with no third-party dependencies.

## Interaction

- Compare three palettes side by side; adjust overall scale, button spacing, corner radius, and animation strength together.
- Hover over buttons for feedback. The translate button opens a clearly labeled local sample result.
- Copy writes the sample phrase to the clipboard; speech uses the system synthesizer; bookmarks are held in memory for the preview session.
- Pause/resume preserves the animation phase. The system Reduce Motion preference disables idle animation.
- Reset restores the four visual controls and clears sample results/bookmarks.

The preview does not call AI or capture other apps. In a production integration, the reusable `BubbleToolbar` / `BubbleSurface` views would be hosted inside a transparent AppKit `NSPanel`; source text and actions would connect to the existing capture controller.

## Export

```sh
'build/bubble-toolbar-lab/Bubble Toolbar Lab.app/Contents/MacOS/BubbleToolbarLab' \
  --export "$PWD/docs/prototypes/bubble-toolbar/previews" --frames
```

Exports a 2× comparison PNG and individual card PNGs using SwiftUI `ImageRenderer`, plus 120 animation frames (10 seconds at 12 fps). Intermediate frames are ignored by Git.

```sh
ffmpeg -y -framerate 12 \
  -i docs/prototypes/bubble-toolbar/previews/frames/%03d.png \
  -filter_complex '[0:v]split[a][b];[a]palettegen=max_colors=192[p];[b][p]paletteuse=dither=sierra2_4a' \
  -loop 0 docs/prototypes/bubble-toolbar/previews/bubble-toolbar-motion.gif
```

The translucent appearance is a drawn surface. It does not yet include live desktop backdrop sampling or physically simulated refraction.
