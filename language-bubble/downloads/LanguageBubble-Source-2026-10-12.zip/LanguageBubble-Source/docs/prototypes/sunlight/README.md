# Learning-page sunlight and standalone preview

The macOS learning library uses one transparent sunlight/shadow layer above its entire scroll viewport. The same field crosses card backgrounds, illustrations, text, controls and surrounding canvas, like light falling across a desk. Individual card styles and the product palette remain unchanged. A separate preview app is retained for adjusting the effect without product data.

## Current visual

The preview uses the product's light-mode `ArticleReaderStyle.canvas` color, **#FBFBFB**. Lit regions reveal that exact neutral canvas; soft gray shadows move over it. The orange/pink palette has been removed. The fixed shadow base is approximately **1% in the upper-left region, 3% in the middle, and 8% toward the outside**. Viewport-relative elliptical distance follows the user's broad sketch as the window resizes. Two overlapping quintic feathers (radii 0.20–0.78 and 0.72–1.08) keep the slope and curvature continuous, without hard region boundaries. Static subpixel alpha dithering prevents visible bands on the 8-bit output. Moving light patches reduce shadow below this base. The preview slider scales the whole profile, with an outer opacity from 0% to 30%; the inner opacity is one eighth of that value. At 0%, the renderer is fully transparent. The preview deliberately uses light appearance to match the requested background comparison.

The standalone window offers full-page and 512×572-point card sizes, Pause, shadow strength, and optional Reduce Motion / diagnostics. Its text uses the same bundled Literata Italic font as the product. Its button only opens a local preview sheet and does not generate learning content or access product data.

The revised arc sketch uses separate ellipse scales for the two feathers: inner `(1.06, 0.94)`, outer `(1.09, 0.75)`. Relative to the first 1–3–8% revision, the inner region is slightly wider and flatter; the outer transition extends 9% farther horizontally and contracts 25% vertically. Its midpoint meets the left edge at roughly 67.5% of viewport height and the top edge at 98.1% of width, placing the lower edge closer to the cards. The opacity levels, broad quintic transitions, static dithering and moving light field remain the same.

## Implementation

The product and preview compile the same renderer and shader:

- `SunlightLab.swift`: standalone app and offscreen screenshot/GPU checks.
- `../../../MacApp/LearningSunlight.swift`: SwiftUI + MTKView renderer, lifecycle, and smoothed parent-owned hover input.
- `../../../MacApp/LearningSunlight.metal`: elongated procedural light field, 40-tap aperture blur, and neutral shadow composite.
- `build.sh`: builds only `build/sunlight/Sunlight Lab.app`, including its own precompiled `Sunlight.metallib` and font/license.

The renderer uses two cached half-resolution R16Float optical textures and a display-resolution BGRA8 output. It pauses when inactive, hidden, occluded, or motion-disabled, and requests 30 fps in Low Power Mode. The decorative view does not intercept controls or enter the accessibility tree. Missing Metal resources leave the underlying page unchanged.

## Product composition

`BubbleArticleLibrary` overlays its ScrollView once, before the generator's background blur. The MTKView and CAMetalLayer are nonopaque; the shader returns premultiplied black with alpha 0…0.08, preserving the underlying colors. The parent tracks normalized hover across the viewport. `pointerTravel = 0.30` maps pointer 0…1 to light-center 0.35…0.65 on each axis; y is converted to bottom-left origin first. Leaving the view returns the target to the center. The renderer then applies the existing time-based damping (6.32 per second), independently of this reduced travel range. The layer stays fixed to the viewport while cards scroll beneath it.

The creation form fades the effect out and pauses it. Article readers and Records do not instantiate it. Reduce Motion leaves a static field; Reduce Transparency and dark appearance omit the decorative layer. The native toolbar remains a separate system control.

## Build and preview

Run from the repository root:

```sh
bash scripts/build-mac.sh
bash docs/prototypes/sunlight/build.sh
open 'build/sunlight/Sunlight Lab.app'
'build/sunlight/Sunlight Lab.app/Contents/MacOS/SunlightLab' --snapshot
```

Xcode 26 requires its official optional Metal Toolchain (`xcodebuild -downloadComponent MetalToolchain`). The script resolves the installed toolchain path; `SUNLIGHT_METAL_BIN` can override the compiler directory. Restricted automation sandboxes may require normal local Xcode/GPU access.

Snapshots and GPU measurements go to `build/sunlight`: `wide.png`, `card.png`, `left.png`, `right.png`, `later.png`, and `validation.txt`. These PNGs now contain transparent shadow masks; composite them over a surface to evaluate the effect. The check asserts that every output pixel is premultiplied black with alpha at most 20/255 and that each field has visible variation. Each size uses 10 warm-up frames and 60 timed submissions; GPU timestamps exclude app CPU/compositor work and do not predict battery use.

Historical validation of the 2–8% version on 2026-10-09: universal arm64/x86_64 product build and strict signature verification passed. The Apple M4 Pro 2560×1440 wide mask and all five snapshot cases passed alpha checks. Corner samples were alpha 5/255 at top-left and 20/255 at the other three corners. These samples describe the earlier profile, not the current 1–3–8% version.

Historical product evidence: `learning-radial-2-8.png`, with build logs `radial-2-8-build.log` and `radial-2-8-lab-build.log`. Earlier `learning-overlay-4-percent.png`, `learning-overlay.png`, and `learning-overlay-form.png` record the uniform 4%, uniform 16%, and form behavior respectively. The earlier UI check opened and dismissed the creation form.

The 1–3–8% revision passed the universal product build, strict signature check and five offscreen Metal cases on 2026-10-09. Its base opacity at normalized (0.1, 0.1), (0.5, 0.5) and (0.85, 0.85) is 1.000%, 2.967% and 8.000%; actual shadows are reduced by the moving light field. All output cases remained premultiplied black with alpha 0–20/255. On Apple M4 Pro the 2560×1440 wide case measured 0.249 ms median GPU time; this excludes app/compositor work. The actual learning page showed a continuous falloff without visible region boundaries. Evidence in `build/sunlight/`: `learning-radial-1-3-8.png`, `radial-1-3-8-validation.txt`, `radial-1-3-8-build.log` and `radial-1-3-8-lab-build.log`.

The subsequent flatter-arc adjustment also passed the universal product build, signature verification and all five offscreen cases. The actual learning page was reopened and visually checked for smooth transitions. Evidence in `build/sunlight/`: `learning-radial-flatter-arc.png`, `radial-flatter-arc-validation.txt`, `radial-flatter-arc-build.log` and `radial-flatter-arc-lab-build.log`. The preceding numerical point samples belong to the original ellipse proportions.

## Reference and limits

This is a native reconstruction based on analysis of the public [microsoft.ai](https://microsoft.ai/) homepage, with a new neutral palette. Its pipeline combines a pointer-centered elliptical vignette, sine warp, animated elongated Voronoi displacement, and aperture blur. It does not reproduce individual light patches pixel for pixel. No website JavaScript, image textures, fonts, or branding assets are included; no open-source license is claimed for Microsoft's site.

Source inspected on 2026-10-08:

- https://microsoft.ai/wp-content/themes/wp-base-theme/dist/assets/BlockGL-BKpryfWb.js
- Research snapshot SHA-256: `13f90d50a8fe140b21a89ee3ae56266c4c1724c4d20c277dcc162f5d7b57c260`
- Downloaded research source remained outside the repository in `/private/tmp`.

The prototype has been rendered on Apple M4 Pro. The current product passes a universal app build; the standalone script builds the host architecture. Intel GPU, battery duration, and broad macOS hardware coverage have not been validated.

## Shape controls

The visible light patches are a soft elliptical illumination field broken up by animated, elongated Voronoi displacement and a sine warp, then aperture-blurred. They are procedural shapes rather than leaf silhouettes or white image assets. Values below are in `MacApp/LearningSunlight.metal`; only `softness` and `intensity` are currently exposed as Swift view inputs.

| Control | Current value | Effect |
| --- | --- | --- |
| Cell frequency | 26.7 | Higher values produce smaller, denser displacement regions. |
| Domain angle | 0.76794487 radians (44°) | Rotates the elongated pattern. |
| Domain y scale | 0.16 | Smaller values stretch the regions further; 1 is isotropic before warp. |
| Displacement scale | 0.4 (±0.2 UV) | Larger values break up the illumination field more strongly. |
| Sine amplitude / frequency | 0.118 / 7.0 | Adjusts bend depth / spatial waviness. |
| Ellipse scale x / y | 0.54 / 0.46 | Larger values narrow the overall lit envelope on that axis; x is aspect corrected. |
| Falloff inner / outer radius | 0.0885 / 0.2655 | Controls the bright core and its transition toward shadow. |
| Aperture blur radius | 0.022 × softness (default 1) | Larger values soften patch boundaries. |
| Cell / sine animation rate | 0.4 / 0.5235464 | Controls autonomous drift, independently of pointer travel. |

The current radial revision changes only the shadow base and its output dithering. Light-patch geometry, blur passes, animation and 30% product pointer travel remain unchanged. Lit regions still reveal the original surface. The radial base remains fixed while the light patches move. The separate canopy experiment retains its own profile.
