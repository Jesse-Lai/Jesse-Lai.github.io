import * as THREE from 'three';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { MarchingCubes } from 'three/addons/objects/MarchingCubes.js';

const signedPower = (v, power) => Math.sign(v) * Math.pow(Math.abs(v), power);
const baseGeometries=new Map();

function cloudGeometry(kind) {
  const resolution=56, extent=1.8;
  const temporaryMaterial=new THREE.MeshBasicMaterial();
  const field=new MarchingCubes(resolution,temporaryMaterial,false,false,70000);
  field.isolation=0;
  const count=kind==='clover'?4:5;
  const centers=Array.from({length:count},(_,i)=>{
    const angle=i/count*Math.PI*2+(kind==='flower'?.28:0);
    return [Math.cos(angle)*.64,Math.sin(angle)*.64];
  });
  const smoothMin=(a,b,k)=>{const h=Math.max(k-Math.abs(a-b),0)/k;return Math.min(a,b)-h*h*k*.25;};
  for(let z=0;z<resolution;z++)for(let y=0;y<resolution;y++)for(let x=0;x<resolution;x++){
    const px=(x/resolution*2-1)*extent, py=(y/resolution*2-1)*extent, pz=(z/resolution*2-1)*extent/0.69;
    let d=Math.hypot(px,py,pz)-.77;
    for(const [cx,cy] of centers)d=smoothMin(d,Math.hypot(px-cx,py-cy,pz)-.58,.32);
    field.field[x+y*resolution+z*resolution*resolution]=-d;
  }
  field.update();
  const geometry=new THREE.BufferGeometry();
  const n=field.geometry.drawRange.count*3;
  geometry.setAttribute('position',new THREE.BufferAttribute(field.geometry.attributes.position.array.slice(0,n),3));
  geometry.setAttribute('normal',new THREE.BufferAttribute(field.geometry.attributes.normal.array.slice(0,n),3));
  geometry.scale(extent,extent,extent);
  field.geometry.dispose();temporaryMaterial.dispose();
  return geometry;
}

// Closed, inflated surfaces: their depth and silhouette survive a full orbit.
export function puffGeometry(kind) {
  if(kind==='clover'||kind==='flower')return cloudGeometry(kind);
  const positions = [], indices = [];
  const rows = 72, columns = 128;
  for (let i = 0; i <= rows; i++) {
    const phi = i / rows * Math.PI;
    for (let j = 0; j <= columns; j++) {
      const theta = j / columns * Math.PI * 2;
      const cross = Math.sin(phi);
      let radius = 1;
      const roundCenter = Math.pow(Math.sin(phi), 4);
      if (kind === 'clover') radius = 0.98 * (1 + 0.21 * Math.cos(theta * 4) * roundCenter);
      if (kind === 'flower') radius = 1.03 * (1 + 0.15 * Math.cos(theta * 5 + 0.3) * roundCenter);
      if (kind === 'triangle') radius = 0.94 * (1 - 0.16 * Math.sin(theta * 3) - 0.025 * Math.cos(theta * 6));
      let x = cross * radius * Math.cos(theta);
      let y = cross * radius * Math.sin(theta);
      let z = Math.cos(phi) * 0.58;
      if (kind === 'cube') {
        x = signedPower(Math.sin(phi), 0.54) * signedPower(Math.cos(theta), 0.54) * 0.79;
        y = signedPower(Math.sin(phi), 0.54) * signedPower(Math.sin(theta), 0.54) * 0.79;
        z = signedPower(Math.cos(phi), 0.54) * 0.64;
      }
      positions.push(x, y, z);
      if (i < rows && j < columns) {
        const a = i * (columns + 1) + j, b = a + columns + 1;
        indices.push(a, b, a + 1, a + 1, b, b + 1);
      }
    }
  }
  let geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setIndex(indices);
  geometry = mergeVertices(geometry, 0.0001);
  geometry.computeVertexNormals();
  return geometry;
}

export function createGeometry(kind, palette, soften=0.3) {
  let geometry;
  if(baseGeometries.has(kind))geometry=baseGeometries.get(kind).clone();
  else if (kind === 'torus') geometry = new THREE.TorusGeometry(0.70, 0.37, 56, 128);
  else if (kind === 'capsule') {
    geometry = new THREE.CapsuleGeometry(0.56, 0.90, 24, 64);
    geometry.rotateZ(Math.PI / 2);
  } else geometry = puffGeometry(kind);
  if(!baseGeometries.has(kind))baseGeometries.set(kind,geometry.clone());
  geometry.computeBoundingBox();
  const colors = [], p = geometry.attributes.position;
  const low = new THREE.Color(palette[0]), high = new THREE.Color(palette[1]);
  const min = geometry.boundingBox.min, max = geometry.boundingBox.max;
  for (let i = 0; i < p.count; i++) {
    const t = THREE.MathUtils.clamp((p.getY(i) - min.y) / (max.y - min.y) * 0.8 + (p.getX(i) - min.x) / (max.x - min.x) * 0.2, 0, 1);
    const color = low.clone().lerp(high, t).lerp(new THREE.Color('white'), soften);
    colors.push(color.r, color.g, color.b);
  }
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  return geometry;
}
