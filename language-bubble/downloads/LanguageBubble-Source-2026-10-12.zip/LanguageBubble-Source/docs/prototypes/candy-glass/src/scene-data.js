export const BACKDROPS = [
  { id: 'cream', name: '奶油米', color: '#f1ece3', note: '温暖柔和，保留参考图的气质' },
  { id: 'white', name: '瓷白', color: '#faf9f6', note: '干净留白，让形状成为主角' },
  { id: 'gray', name: '雾灰', color: '#e5e7e7', note: '中性克制，衬托玻璃的通透感' },
  { id: 'pink', name: '樱花粉', color: '#f2e0e5', note: '一点甜，像轻盈的糖果包装' },
  { id: 'lilac', name: '浅丁香', color: '#e6e0f0', note: '安静梦幻，柔和的冷色调' },
  { id: 'blue', name: '冰川蓝', color: '#deedf4', note: '清透凉爽，让暖色更鲜明' },
  { id: 'mint', name: '鼠尾草', color: '#e2eade', note: '自然舒缓，带一点植物气息' },
  { id: 'ink', name: '深墨蓝', color: '#242b3b', dark: true, note: '沉静深色，突出轮廓与高光' },
];

export const MODES = [
  { id: 'candy', name: '糖果玻璃', en: 'Candy glass', note: '温暖、饱满，最接近参考图', background: '#ded6cb', roughness: 0.14, transmission: 0.96, thickness: 1.65, ior: 1.38, chroma: 0.025, clearcoat: 1, exposure: 1.07, caustic: 0.06, saturation: 1, light: 3.5,
    colors: [['#ff7195','#f7bdc8'],['#ffa000','#ff9044'],['#9871f0','#c5aceb'],['#d0ec67','#64c6b3'],['#23ccee','#328beb'],['#ff9268','#f991ac']] },
  { id: 'milk', name: '柔光奶冻', en: 'Opal jelly', note: '细腻磨砂，柔和的马卡龙色', background: '#e9e2d8', roughness: 0.34, transmission: 0.68, thickness: 2.1, ior: 1.30, chroma: 0.01, clearcoat: 0.75, exposure: 1.10, caustic: 0.022, saturation: 0.78, light: 3,
    colors: [['#ed9db7','#f3d1d3'],['#f1c477','#f8dfa8'],['#b5a5e1','#d7c8ef'],['#c6d7a0','#a2ccb9'],['#95c9dc','#b7d3eb'],['#eeaf99','#efd0be']] },
  { id: 'crystal', name: '澄澈水晶', en: 'Lucid crystal', note: '更清透、更锐利的折射与高光', background: '#d5dedf', roughness: 0.035, transmission: 1, thickness: 2.5, ior: 1.47, chroma: 0.055, clearcoat: 1, exposure: 1.02, caustic: 0.10, saturation: 0.55, light: 4,
    colors: [['#f9a1bb','#ffdde2'],['#ffce6c','#ffe8b7'],['#ba9aef','#e0d5ff'],['#abedbb','#c0f2ec'],['#78d6f4','#b6e8fa'],['#ffa994','#ffe0ce']] },
  { id: 'night', name: '夜色霓虹', en: 'After hours', note: '鲜明饱和，带有霓虹感的高光', background: '#151923', roughness: 0.11, transmission: 0.9, thickness: 1.9, ior: 1.40, chroma: 0.07, clearcoat: 1, exposure: 1.3, caustic: 0.16, saturation: 1, light: 5,
    colors: [['#ff438d','#ffaad5'],['#ff8b16','#ffd355'],['#8651fd','#b8a4ff'],['#a5ed49','#24cfb0'],['#00badc','#428dff'],['#ff6547','#ff77bf']] },
];

export const OBJECTS = [
  { kind: 'capsule', position: [-1.7, 1.13, -2.8], rotation: [0.12, -0.15, 0.32], scale: 1.12 },
  { kind: 'clover', position: [1.48, 1.60, -2.40], rotation: [-0.20, -0.16, -0.05], scale: 1.12 },
  { kind: 'torus', position: [-0.08, 1.04, 0.04], rotation: [-0.47, -0.33, 0.1], scale: 1.05 },
  { kind: 'cube', position: [-2.16, 0.83, 1.92], rotation: [-0.05, 0.28, -0.04], scale: 1.03 },
  { kind: 'triangle', position: [2.02, 0.86, 1.90], rotation: [-0.21, -0.12, -0.1], scale: 1.12 },
  { kind: 'flower', position: [0.29, 0.75, 4.20], rotation: [-Math.PI/2 + 0.04, 0, -0.18], scale: 1.30 },
];
