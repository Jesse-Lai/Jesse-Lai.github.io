# Soft Matter — 3D candy glass

An isolated, runnable study based on the supplied reference image. Six closed 3D shapes, four material directions, eight independent flat backgrounds, orbit/zoom, material and background comparison, subtle motion, a transparency control, and PNG export.

## Run

```sh
cd docs/prototypes/candy-glass
npm install
npm run dev
```

Open http://127.0.0.1:4320/. `npm run build` produces `dist/`.

Useful views:

- `/?style=candy`: candy glass, closest to the supplied palette.
- `/?style=milk`: soft opal jelly.
- `/?style=crystal`: clearer glass with stronger refraction.
- `/?style=night&bg=ink`: saturated colors on a dark flat background.
- `/?compare=1`: four independently rotatable material views on the selected background.
- `/?compare=background&bg=cream`: compare backgrounds 01–04 with the same material.
- `/?compare=background&page=2&bg=lilac`: compare backgrounds 05–08.
- `bg` values: `cream`, `white`, `gray`, `pink`, `lilac`, `blue`, `mint`, `ink`. Background and material can be mixed freely. Click a swatch or enlarge a comparison card to choose one.
- Background comparison uses four live canvases at a time; the two page buttons cover all eight options.
- `/?style=candy&precise=1`: progressive path tracing.
- Add `&clean=1` to omit the interface.

## Rendering

- Real-time: Three.js / React Three Fiber / Drei `MeshTransmissionMaterial` and `Caustics`. The unlit floor stays a uniform color, with faint contact shadows. Decorative colored glow defaults to off. Colored scattering fill and optional colored glow supplement screen-space transmission and projected caustics. These are deliberate real-time approximations, not a physical light simulation. Idle scenes stop rendering after settling; orbiting or enabling motion resumes rendering.
- Precise: `three-gpu-pathtracer` **0.0.23 (WebGL)**, true closed geometry, volume attenuation, rectangular area lights, and progressive reflections. A uniform background replaces the physical floor so no ground-light gradient or horizon appears; floor shadows and caustics are intentionally absent. ACES tone mapping can shift background colors slightly compared with the real-time swatches. The renderer accumulates up to 384 samples. Moving the camera restarts accumulation. The first few frames can be grainy. Motion and decorative glow controls are unavailable here because lighting is computed by the renderer.
- The pinned WebGL path tracer predates the upstream project's WebGPU version. Clearcoat is disabled in this path because its implementation produced invalid black surfaces with the selected Three.js combination; regular dielectric reflections remain enabled. A compatibility alias handles the pinned release’s `_renderQuad` / `_quad` disposal typo; background changes update the existing renderer instead of recreating its WebGL context.
- The clover and flower are smooth unions of 3D spheres reconstructed with Three.js marching cubes. The rounded cube and triangle are parametric closed meshes; the capsule and torus use Three.js geometries. No raster image is used to stand in for a 3D object. All geometry, light rigs, and palettes are editable in `src/`.
- Environment lighting is generated locally, without external models or HDR downloads. Google Fonts is optional; the stylesheet has local font fallbacks.

## Files

- `src/scene-data.js`: the four material palettes, eight flat backgrounds, and six object placements.
- `src/geometry.js`: procedural closed surfaces and gradients.
- `src/main.jsx`: material study UI and real-time rendering.
- `src/path-stage.jsx`: progressive physical rendering.
- `previews/flat-backgrounds-01.png` and `previews/flat-backgrounds-02.png`: actual browser captures of all eight flat-background options.
- `previews/comparison.png`: actual browser capture of the four live views.
- `previews/candy-precise.png`: actual browser capture of the path-traced scene.

## Open-source foundations

- [Three.js](https://github.com/mrdoob/three.js), MIT.
- [React Three Fiber](https://github.com/pmndrs/react-three-fiber), MIT.
- [Drei](https://github.com/pmndrs/drei), MIT; transmission material and caustics implementation.
- [three-gpu-pathtracer](https://github.com/gkjohnson/three-gpu-pathtracer), MIT.
- [React](https://github.com/facebook/react), MIT.

Dependency notices are provided with the installed packages. This prototype does not change the surrounding native application.

## Verification

- Production build passes.
- All six generated geometries have finite positions, normals, and vertex colors.
- Browser checks cover both pages of background comparison, choosing/enlarging backgrounds, material comparison, precision background switching, and the narrow layout. Earlier checks also cover camera orbit/reset.
