# Third-party notices

## react-particle-effect-button

Copyright (c) 2018 Travis Fischer. MIT License, preserved in `vendor/particle-LICENSE`.

Motion code adapted from https://github.com/transitive-bullshit/react-particle-effect-button. Original concept by Luis Manuel for Codrops: https://tympanus.net/codrops/2018/04/25/particle-effects-for-buttons/. The UI links visibly to the original project. No Codrops photographs or button artwork are used.

## html2canvas 1.4.1

Copyright (c) 2012 Niklas von Hertzen. MIT License, preserved in `vendor/html2canvas-LICENSE`. Source: https://github.com/niklasvh/html2canvas

## Product fonts and photography

Inter, Manrope, Literata, Source Han Sans CN and Chill Yunmo Gothic use SIL OFL 1.1. Existing licenses are preserved in `../../../Resources/Fonts/`.

The photograph is the existing product asset `design/photography-lesson/assets/lines-toward-building.jpg`, sourced from Digital Photography School: https://digital-photography-school.com/how-to-use-leading-lines-for-better-compositions/. It remains the work of its credited creator/publication; the libraries' MIT licenses do not cover this photograph. Used here only for the requested local product preview; attribution is visible below it. See `design/photography-lesson/asset-sources.json` for provenance.
