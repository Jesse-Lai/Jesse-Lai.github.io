(() => {
  const status = document.querySelector('#status');
  const playAll = document.querySelector('#play-all');
  const reset = document.querySelector('#reset');
  const speed = document.querySelector('#speed');
  const localButtons = [...document.querySelectorAll('.play-one')];
  const effects = {};
  let ready = false;

  function update() {
    if (!ready) return;
    const states = Object.values(effects).map(effect => effect.state);
    const busy = states.some(state => state === 'playing' || state === 'preparing');
    const hidden = states.filter(state => state === 'hidden').length;
    playAll.disabled = busy;
    playAll.innerHTML = `<span aria-hidden="true">${hidden ? '↻' : '▷'}</span> ${busy ? '正在消失' : hidden ? '重播全部' : '一起消失'}`;
    reset.disabled = false;
    speed.disabled = busy;
    status.textContent = busy ? '内容正在散去…' : hidden === 2 ? '已全部消失。点击「重播全部」再看一次。' : hidden ? '也可以单独播放另一侧，或还原全部内容。' : '点击「一起消失」，或分别播放文字和图片。';
    if (matchMedia('(prefers-reduced-motion: reduce)').matches && !busy) status.textContent = '已遵循系统「减少动态效果」设置，内容直接隐藏。';
    for (const [name, effect] of Object.entries(effects)) {
      const button = localButtons.find(button => button.dataset.target === name);
      const working = effect.state === 'playing' || effect.state === 'preparing';
      button.disabled = working;
      button.innerHTML = `${working ? '正在消失' : effect.state === 'hidden' ? '再看一次' : '单独播放'} <span aria-hidden="true">↗</span>`;
      document.querySelector(`[data-status="${name}"]`).textContent = working ? '消散中' : effect.state === 'hidden' ? '已消失' : '待播放';
    }
  }

  function fail(error) {
    console.error(error);
    status.textContent = '素材准备失败，请刷新页面重试。';
    status.setAttribute('role', 'alert');
  }

  function play(name) {
    if (!ready) return;
    effects[name].play(Number(speed.value)).catch(fail);
  }

  playAll.addEventListener('click', () => {
    if (!ready) return;
    for (const effect of Object.values(effects)) effect.reset();
    for (const name of Object.keys(effects)) play(name);
  });
  reset.addEventListener('click', () => Object.values(effects).forEach(effect => effect.reset()));
  localButtons.forEach(button => button.addEventListener('click', () => play(button.dataset.target)));
  window.addEventListener('keydown', event => {
    if (event.key === 'Escape' && ready) Object.values(effects).forEach(effect => effect.reset());
  });

  let resizeTimer;
  window.addEventListener('resize', () => {
    if (!ready) return;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      for (const effect of Object.values(effects)) {
        const rect = effect.content.getBoundingClientRect();
        if (Math.abs(rect.width - effect.width) > .5 || Math.abs(rect.height - effect.height) > .5) effect.reset();
      }
    }, 100);
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) Object.values(effects).forEach(effect => {
      if (effect.state === 'playing') effect.reset();
    });
  });

  async function init() {
    if (!window.html2canvas) throw new Error('html2canvas did not load');
    await Promise.all([
      document.fonts.ready,
      document.querySelector('#article-image').decode()
    ]);
    // The text and photo are the current bundled photography lesson assets.
    effects.text = new ExportDissolve(document.querySelector('#text-effect'), update);
    effects.image = new ExportDissolve(document.querySelector('#image-effect'), update);
    await Promise.all(Object.values(effects).map(effect => effect.prepare()));
    ready = true;
    Object.values(effects).forEach(effect => effect.reset());
    update();
    window.particlePreview = { effects, ready: true };
  }
  init().catch(fail);
})();
