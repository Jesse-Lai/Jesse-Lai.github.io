# Particle disappearance preview

Independent static preview of the selected **Export** effect, with the product's actual photography headline, summary, `journey` typography and original building photograph. Main product files are unchanged.

Serve the repository root and open `/docs/prototypes/particle-dissolve/`:

```sh
python3 -m http.server 4336 --bind 127.0.0.1
```

Controls: play both, play either side, replay, reset (also Escape), original speed and half speed. System Reduce Motion immediately hides the content. No network requests are needed after the local server is running.

## Motion and source

The animation engine in `effect.js` adapts the MIT-licensed `react-particle-effect-button` algorithm to a dependency-light DOM / Canvas renderer. The selected Export timing is retained: 800 ms, `easeOutSine`, particle amount coefficient 7, speed 3 and oscillation 1. The requested refinement uses circular particles of radius 0.9 px (diameter 1.8 px), a bottom-to-top wipe, and upward drift with a 117-degree spread. Particles continue fading after the 800 ms wipe, matching the source's separate lifetimes (28–68 frames at 60 Hz).

Source: https://github.com/transitive-bullshit/react-particle-effect-button/blob/master/src/index.js

Preset: https://github.com/transitive-bullshit/react-particle-effect-button/blob/master/example/src/demos.js

Changes from upstream: elapsed-time animation instead of frame-dependent motion; transparent glyph sampling and original photograph colors instead of a uniform colored rectangle; cancellable replay/reset; high-DPI rendering; independent per-element effects; Resize and Reduce Motion handling. Source sampling uses vendored html2canvas 1.4.1 for text and direct canvas drawing for the photograph. Empty text background pixels never emit particles. This is a port of the selected effect, not the old React component installed unchanged.

Assets are referenced from the existing repository rather than duplicated. Fonts and text match `Resources/Fonts/README.md` and `design/photography-lesson/lesson.json`. Photograph remains at its original aspect ratio and is credited in the page. See `THIRD_PARTY_NOTICES.md`.
