# Task progress — official component comparison

Run `npm install`, then `npm run dev`. Open <http://127.0.0.1:4327/>.
`npm run build` checks TypeScript and builds the page.

## Confirmation and input panel gallery (2026-10-10)

Open `/selection.html` for the four-library selection page. If port 4327 is occupied, run `npm run dev -- --port 4331` and open <http://127.0.0.1:4331/selection.html>.

The selection page displays existing panel styles from the four libraries. It contains assistant-ui ApprovalCard, ElicitationForm and PermissionGrant; Vercel Confirmation; prompt-kit PromptInput and SystemMessage; and a screenshot of the official ElevenLabs ConversationBar preview. The timeline and screenshot-inspired styling have been removed from this page. Components keep their own upstream styling; gallery CSS only styles the surrounding catalogue. Shared theme tokens use neutral light colors. Each card has direct documentation/source links and library filters.

The three assistant-ui panel sources and SystemMessage are copied without changes. Assistant-ui and Vercel previews retain official example content, with local callbacks for interactive receipts. No command, deletion, publication, permission change, or remote submission occurs. PromptInput retains its default style and official Basic layout; its unused tooltip provider/action wrapper is omitted because the dependency could not be downloaded. The caller guards IME composition and cleans up local simulation timers. Exact provenance and local hashes are recorded in `component-sources.json`. The ElevenLabs screenshot is in `public/panels`; connecting the actual component requires an Agent ID.

Additional references:

- https://www.assistant-ui.com/elements/approval-card
- https://www.assistant-ui.com/elements/elicitation-form
- https://www.assistant-ui.com/elements/permission-grant
- https://www.assistant-ui.com/elements/tool-fallback
- https://elements.ai-sdk.dev/components/confirmation
- https://elements.ai-sdk.dev/components/prompt-input
- https://prompt-kit.com/docs/prompt-input
- https://prompt-kit.com/docs/steps
- https://ui.elevenlabs.io/docs/components/conversation-bar
- https://github.com/elevenlabs/ui/blob/main/apps/www/content/docs/components/conversation-bar.mdx

## Learning-content flow at `/flow.html`

Open <http://127.0.0.1:4331/flow.html>. The first outline approval stage follows the user-selected Figma node [1560:17532](https://www.figma.com/design/SXTRfnywlGRth5HOe9CHwf/Vibe-Coding?node-id=1560-17532): left outline, right five-step progress, and a floating Apply / Deny / input surface. The existing Confirmation, PromptInput and Button components are styled through a scoped adapter; their upstream sources are unchanged. The mapped Stop20Filled icon is imported from @fluentui/react-icons. Original SVGs, font files and asset provenance are local; no temporary Figma URLs are referenced by the page.

The page opens at the requested approval state. “记录” → “生成” exercises the entry into this state. Only the outline step is complete; the remaining four steps start after Apply. Deny opens revision input; submitting supplementary text or “Update outline” updates the outline and returns to approval. Empty submissions are disabled, IME composition is guarded, and timers are cleaned up. Phone / 400-word / practice requests change the fixture; arbitrary text is recorded as a requirement. This remains a local prototype without an AI connection. The 3D camera mentioned in the Figma outline is planned lesson content, not a new 3D feature in this preview.

The subsequent execution and output views retain the prior prototype. Pause/resume retains the current step. Viewing an approved outline does not interrupt execution. Completion exposes the existing sample article and quiz. The gallery at `/selection.html` remains available.

## Original task progress demo at `/`

The separate original task demo uses three real React components:

| Library | Component | Official reference |
| --- | --- | --- |
| Vercel AI Elements | ChainOfThought and Confirmation | https://elements.ai-sdk.dev/components/chain-of-thought |
| prompt-kit | ChainOfThought | https://prompt-kit.com/docs/chain-of-thought |
| assistant-ui | AgentPlan | https://www.assistant-ui.com/elements/agent-plan |

The sources under `src/components` are copied from their official registries / repositories. Vercel import aliases are normalized to the local shadcn path; component logic and styles are unchanged. The source manifest records URLs and file hashes. Shadcn Button, Badge, Alert, Collapsible, Tabs and Textarea come from its new-york registry. Retrieved license files are in `THIRD_PARTY`. The prompt-kit repository snapshot did not include a root license; its component docs explicitly describe copying the component into a project and updating import paths. Source attribution is retained here and in the preview.

ElevenLabs UI was inspected but is oriented toward voice, audio and waveform components, so it is not used for this task timeline.

## Demo behavior

- Static previews for writing, outline confirmation, completion and stopped states.
- Playback uses five stages lasting 3 / 3 / 3 / 5 / 5 seconds.
- The outline requires an explicit choice before continuing; typing a supplemental instruction is also a choice.
- Stop and resume retain the stage position. Chinese/English DSLR requests and shortening are deterministic local changes.
- Completed outputs can be opened; the quiz has local answer feedback.
- Regeneration restores a stage checkpoint, fades the discarded branch out, then resumes. Outline regeneration asks for confirmation again.
- No AI connection, remote writes or synchronization.

The Vercel component models `complete`, `active`, and `pending`. Paused/waiting state is provided by the caller, with the official Confirmation component. Prompt-kit uses its `leftIcon` and collapsible APIs. AgentPlan exposes only `activeIndex`, so the comparison intentionally preserves its limitation: it continues to visually mark the next stage active during confirmation and the current stage active when stopped. It needs an API extension before use in the complete production flow.

The article fixture is a snapshot of the original seven photography headings (800 words), copied to `src/data/lesson.json` so later source edits do not change this comparison. The article, headings and media reuse `design/photography-lesson`; the title, metadata and four-option resilient quiz follow the previously supplied Figma copy. This is an isolated web comparison, not a change to the native macOS app.
