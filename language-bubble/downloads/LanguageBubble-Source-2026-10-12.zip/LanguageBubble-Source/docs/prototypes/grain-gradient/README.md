# Grain — 色彩实验室

Local HTML preview of six curated palettes using the actual Paper Grain Gradient shader. Default: 深海月银, Blob shape. Includes palette switching, the Corners shape, grain/speed controls, pause, and palette export. Respects reduced motion.

Run from the repository root:

```sh
python3 -m http.server 4321 --bind 127.0.0.1 --directory docs/prototypes/grain-gradient
```

Open <http://127.0.0.1:4321/>. Palette data, UI styles, and application code are all in `index.html`; no build or npm install is needed. The shader dependency is vendored locally, so the running preview requires no external requests.

Palette and shape are reflected in the URL hash, for example `#palette=porcelain&shape=corners`. Grain and speed adjustments are temporary; “复制当前配色” exports the complete current parameters as JSON (downloads a JSON file if clipboard access is unavailable).

Third-party dependency: `@paper-design/shaders` **0.0.81**, Apache-2.0, bundled by jsDelivr from the official npm package. Unmodified bundle: `https://cdn.jsdelivr.net/npm/@paper-design/shaders@0.0.81/+esm`. License and copyright notice are retained in `vendor/`.
