# Prismatic Glass Lab

A standalone macOS SwiftUI + Metal study of the glass material and bubble entrance in
[Janum Trivedi's Wabi video](https://x.com/jmtrivedi/status/1986572630292631861).
This is an independent visual approximation, not the author's implementation.
No downloaded video, image, framework, or network service is used by the demo.

## Run

From the repository root:

```sh
bash docs/prototypes/prismatic-glass/build.sh
```

Open `build/prismatic-glass/Prismatic Glass Lab.app`. Requires Apple Silicon, macOS 14+
and a Metal-capable GPU. Building requires Xcode/Swift; runtime shader compilation
uses the system Metal framework and does not need a separately installed compiler.

## Interaction

- **重播入场**: a large sphere rises from the bottom and shrinks as smaller spheres unfold.
- **手势入场**: resets to the large sphere; hold and drag upward to drive the transition.
- Drag a sphere in either scene; releasing it returns it with a damped spring.
- Switch between the cluster and one large sphere for inspecting the material.
- Adjust refractive index, RGB dispersion, coloured studio lights, light rotation,
  and background displacement. The grid helps reveal lens distortion.
- Scrub the entrance timeline, pause/resume ambient motion, or reset all settings.
- macOS Reduce Motion pauses automatic playback on launch; explicit replay remains available.

## Implementation

`PrismaticGlassLab.swift` contains the SwiftUI controls, AppKit pointer handling,
CPU particle motion, texture generation, and MetalKit renderer. `Glass.metal` contains
the material. A full-screen triangle shades analytically projected ellipsoids.

For each visible sphere, the fragment shader computes a curved normal, uses Snell
refraction at both interfaces, and samples three slightly different optical paths
for red, green and blue. Fresnel reflection, a procedural studio environment,
specular lighting and a narrow internal crescent provide the glass appearance.
The background text is a texture sampled by the same shader, so it is displaced
when a sphere passes over it. No CSS blur or pre-rendered animation is involved.

The render loop targets 60 frames per second; this is not a performance guarantee.
Background optical samples are clamped at canvas boundaries.

## Scope

The result reproduces the main visual language and entrance interaction. It uses
analytical sphere optics and art-directed lights rather than volumetric path tracing.
Transparent spheres do not recursively refract one another; there is no fluid
surface fusion, physically computed caustic illumination, or full collision solver.
The scene refracts its own canvas, not other macOS windows. It remains isolated from
the shipping Language Bubble app and the existing toolbar prototype.

## Render a frame

```sh
'build/prismatic-glass/Prismatic Glass Lab.app/Contents/MacOS/PrismaticGlassLab' \
  --snapshot /tmp/glass-cluster.png

'build/prismatic-glass/Prismatic Glass Lab.app/Contents/MacOS/PrismaticGlassLab' \
  --snapshot /tmp/glass-single.png --single --grid

'build/prismatic-glass/Prismatic Glass Lab.app/Contents/MacOS/PrismaticGlassLab' \
  --snapshot /tmp/glass-entrance.png --time 2.5
```

These use the same Metal pipeline as the live window. A restricted shell sandbox
may block GPU-device creation even on a supported Mac.
