# Language Bubble · 最简流程与真机安装

本轮范围：Mac 取词 / 截图 → 真实翻译 → 自动生成个人练习 → 两端查看和复习。不部署云服务、不增加正式登录、不做 TestFlight 分发。

## 1. Mac 日常入口

打开 `build/Language Bubble.app`，先确认「连接」页已有账号且显示「真实 AI」。

在「设置 → 采集权限」开启辅助功能和屏幕录制。返回 App 时会刷新状态；系统要求退出重开时，重开同一份 App。不要混用 Xcode Debug / Release 和 build 目录下的不同副本。

若系统开关已开启，但 App 仍提示未授权，可能是之前的临时签名在重新构建后失效。`build-mac.sh` 现会在只有一个可用 Apple Development 证书时自动使用它，也可通过 `BUBBLE_SIGNING_IDENTITY` 指定签名；没有唯一可用证书时仍使用临时签名并警告。首次切换到开发证书后，需要在系统权限列表中重新添加当前 `build/Language Bubble.app`，再重启该 App。后续保持相同证书与应用标识，避免每次构建都更换签名身份。

2026-09-27 实测：删除旧条目、重新添加并经系统「Quit & Reopen」后，App 内两项权限均已开启。系统列表可能显示旧工程名 `LanguageBubbleMac`，可右键「Show in Finder」核对是否指向当前 `build/Language Bubble.app`。保留旧条目直接点加号，可能无法更新失效授权；以 App 内状态和实际截图结果为准。

测试时只运行一个 Language Bubble 版本。Hover Translate 也默认使用 Option；两个应用同时运行会一起弹窗。本轮已按用户选择退出 Hover Translate。翻译只使用一个窗口：查新词刷新当前内容，保留窗口位置和大小；点击关闭就关闭，下次主动查询再打开。已移除保留 / 固定按钮，所有成功查询仍自动保存。

| 操作 | 使用方式 | 预期结果 |
|---|---|---|
| 划词翻译 | 在 Safari / Chrome 选中一句，按 Control + Option + T | 显示译文浮层，自动保存记录 |
| 悬浮取词 | 在 Bubble 主窗口启用「Option 悬浮取词」，回到原应用，将指针放在词上后按 Option | 有明确选区时优先查询选区；无选区时用 OCR 单词边界确认鼠标命中，需要屏幕录制权限。空白处不猜词。开关重启后保留 |
| 截图翻译 | 在 PDF / 图片 / 网页按 Control + Option + R，拖出文字区域 | OCR 后翻译，保存该区域图片；Esc 取消 |
| 回看场景 | 到「记录」打开刚才的条目 | 查看原文、可取得的上下文、来源应用及截图。只保存宿主实际提供的链接 |

辅助功能用于读取主动查询的选区；屏幕录制用于截图和 OCR。截图仅采集来源应用窗口。缺少权限时会显示原因，也可以使用已有的图片导入入口。

最小验收样例：在网页中查询 `Could you walk me through the launch plan?`，在 PDF / 图片中框选一行英文，再确认记录中的截图与所查区域一致。依次覆盖 Safari、Chrome 和 Preview 三个宿主；构建通过不等于这些宿主已验收。

## 2. 用户只查询，后台准备学习

1. 「连接 → 学习目标」选日常 / 工作 / 雅思 / 高考 / 语法，以及每天学习时间。
2. 正常查询词句，或在写作入口检查一句英文。查询成功即保存；只有明确错误才保存写作问题。
3. 后台从最多 6 条未暂停的学习记录中选取依据，优先最近查询和成功回忆较少的内容，结合上下文、纠错和真实复习反馈生成 4 个短练习：听、说、读、写各一个。
4. 「学习 → 自动整理的学习安排」查看选题理由并打开练习。可播放文字、查看参考答案、写一句并检查、进入回忆页提交反馈。
5. Mac 和 iPhone 使用同一份计划；前台约 4 秒同步。生成中可继续查询。修改目标、产生新记录或复习反馈后会更新安排。

「原来的场景」展示记录本身；「AI 场景练习」是模型编写的材料，二者分开展示。重复查询同一个表达时，每道练习会关联模型实际使用的那次场景。

生成失败最多自动尝试 3 次，之后可点「重试生成」；不会自动换成 Mock。删除原记录会清理派生计划，生成途中返回的过期内容不会恢复已删除的场景。旧 Mock 计划可点「用我的记录生成 AI 练习」升级。

当前口语是朗读 / 自行练习，没有录音评分；听力使用系统朗读。生成的是一组简短学习安排，没有长期课程或能力评级。场景图片保存在本机同步服务，模型接收选取的文本和上下文，不接收截图。

## 3. iPhone 真机安装

本机检查（2026-09-27）：三个 iOS target 的 Debug / Release 均已选择 Jianxun Lai 团队并启用自动签名；Apple Development 证书有效，三个组件的 Xcode Managed Profile 均已生成。iPhone 17 已开启开发者模式、安装并配对。20:57 已覆盖安装包含系统翻译联网声明修复的版本，未卸载 App。

2026-09-27 23:31 已将 SwiftUI + ShadKit 翻新版覆盖安装到连接的 iPhone 17，23:33 启动成功，沿用 `app.context.capture`，未卸载原 App。最新真机构建日志：`build/iphone-shadkit-build.log`；安装包：`build/iPhoneDevice/Build/Products/Debug-iphoneos/Context.app`，`codesign --verify --deep --strict` 通过。以下安装步骤供后续重新安装时参考。

1. 用数据线连接并解锁 iPhone，手机上选择「信任此电脑」。
2. 在 Mac 打开 `Context.xcodeproj`。Xcode → Settings → Accounts 登录你的 Apple 账号。
3. 在项目的 **Context、ContextTranslation、ContextKeyboard** 三个 target 的 Signing & Capabilities 中选择同一个 Team，启用 Automatically manage signing。实际 target 名称以左侧列表为准。让 Xcode 创建 Apple Development 证书和描述文件；不要把模型 Key 填进项目。
4. 如果 Bundle Identifier 已被占用，可用 `python3 scripts/generate_project.py --bundle-prefix 你拥有的反向域名标识` 一起更新 App、扩展和 App Group，再重新选 Team。更换标识会被系统视为新 App，原模拟器 / 真机的本地数据不会自动迁移；先不要随意改。
5. 在 Xcode → Window → Devices and Simulators 中选中手机，等待 Preparing / Developer Disk Image 完成。当前 `no DDI` 表示开发支持还没有挂载；若提示不支持手机系统，需下载匹配的 Xcode 平台支持或使用兼容的 Xcode。
6. 按提示在手机「设置 → 隐私与安全性 → 开发者模式」开启、重启并确认。若暂时没有此选项，先完成 Xcode 与设备的连接准备。
7. Xcode 顶部选择 **Context** scheme 和你的实体 iPhone，点击 ▶︎ Run。若手机要求信任开发者，在「设置 → 通用 → VPN 与设备管理」按系统提示处理。
8. 首次打开 App 时允许本地网络访问，再按下面的方法连接这台 Mac。

免费 Apple 账号可先尝试真机调试，Personal Team 描述文件通常 7 天过期，需要重新安装。是否支持本项目所需的默认翻译 capability，以当前 Xcode 签名结果为准；不能承诺只登录免费账号就一定能测全部扩展。付费 Apple Developer Program 适用于持续设备测试和后续 TestFlight / App Store 分发，现在不必先购买。

### 同一 Wi-Fi 连接，无需云部署

手机的 `127.0.0.1` 是手机自己。服务应在可信 Wi-Fi 下，以局域网模式启动：

```sh
cd "/Users/jesselai/Desktop/Language killer"
bash scripts/run-beta.sh --lan
```

若原来的 8788 服务已在运行，先在它所在的终端按 Control + C；若通过 `--background` 或 `--login` 启动，则用 `bash scripts/run-beta.sh --stop` 停止，再启动，勿结束不明进程。需要关闭终端后继续运行并在重启登录后自动启动时，使用 `bash scripts/run-beta.sh --login --lan`；`--background --lan` 仅持续到注销。`--uninstall` 停止后台服务并移除登录启动。`--lan` 监听局域网；默认不带此选项时仍只监听本机。

这台 Mac 当前的手机服务地址为 `http://JessedeMacBook-Pro.local:8788`；主机名变化时用 `scutil --get LocalHostName` 查看。手机与 Mac 必须在同一 Wi-Fi，防火墙需允许该服务入站，Mac 要保持开机且服务运行。

1. 手机 Safari 打开该地址加 `/health`，应看到 `status: ok` 和 `ai_mode: live`。如果这里打不开，先排查网络隔离、防火墙或 Mac 睡眠。
2. Mac App「连接」页生成一次性配对码。
3. iPhone App「连接」页输入上述服务地址和配对码，点「与另一设备配对」。不用在手机填 Azure Key。
4. 手机查询一句，Mac 回看；Mac 查询另一句，手机回看原场景并复习，最后确认反馈同步。

仅 Debug 构建允许 HTTP 的 localhost、`.local` 主机和私网 IPv4；Release 仍要求 HTTPS。这是可信局域网测试连接，不宜用于公共 Wi-Fi 或公开端口映射。

### 系统入口

先完成主 App 配对，再到「设置 → App → 默认 App → 翻译」选择 Language Bubble，尝试在支持系统文本选择的应用中划词后点「翻译」。最低系统要求为 iOS 18.4；具体宿主菜单和能力仍需真机验证。

如果 Safari `/health` 正常、主 App 已同步，但系统翻译报断网，需核对主 App 的 Info.plist 包含布尔值 `com.apple.developer.translation-ui-provider.network-access = true`。只在翻译扩展中声明不满足 [Apple 的主 App 配置要求](https://developer.apple.com/documentation/translationuiprovider/preparing-your-app-to-be-the-default-translation-app)。本项目已补上主 App 与工程生成脚本中的声明；更新安装后关闭旧浮层再重新触发。真实扩展返回译文仍以手机复测为准。

2026-09-27 真机复测已确认系统翻译能返回真实译文。进一步修复同步：翻译浮层保存后直接上传，显示「正在同步到其他设备」「已同步到其他设备」或失败补传提示；无需每次返回主 App。上传失败保留独立于本地导入的持久队列，下次查询或主 App 前台同步时补传，也可在浮层「重试同步」。撤销同样持久化并向其他设备同步。初次升级打开一次主 App，初始化共享连接并补传旧记录。Mac 保持前台时约每 4 秒拉取。

真机验收：2026-09-27 用户已确认，在 X 中查询新词后停留在 X，浮层显示「已同步到其他设备」，Mac 保持前台，几秒后出现新记录。旧记录 `workhorse` 也已在升级后补传，Mac 原生界面记录数由 16 增至 17。待测：在浮层撤销后确认 Mac 移除该条记录，以及断网后恢复连接的补传；这两项目前通过核心测试，尚未完成真机验收。不要通过手动调用服务器写入来代替真机验收。

键盘：设置 → 通用 → 键盘 → 键盘 → 添加新键盘 → Language Bubble 英文。网络分析需允许完全访问，并在 App 中开启自动检查。只分析当前键盘可取得的短句，不监听用户在其他键盘输入的内容。

## 4. 云服务与分发：先了解，暂不执行

这几件事可以分开决定：联网同步在哪里运行、用什么身份登录、怎么安装 App。真机 USB 安装并不要求先做云账号。

| 方案 | 需要做什么 | 影响 |
|---|---|---|
| 继续本机 + 同一 Wi-Fi（当前推荐） | 启用局域网服务、Xcode 签名安装 | 改动最小；Mac 需在线。没有云托管费，真实模型调用仍计费；离开局域网不能查询和同步 |
| 将现有 Python 服务托管到 Azure | HTTPS、持久数据库和图片存储、密钥管理、备份与服务恢复；先保留现有配对账号 | 复用现有后端最多，手机可离开 Mac 使用；开始承担持续费用和服务运维，学习记录进入所选云区域 |
| 托管账号 / 数据库，例如 Supabase + 独立 AI 服务 | 接入登录、数据库权限、图片存储，并改造现有同步接口 | 省去部分账号基础工作，但需要迁移数据模型和同步逻辑；多一个供应商和持续费用；AI Key 仍留服务端 |
| iCloud / CloudKit 同步 + 独立 AI 服务 | 改写同步层，围绕 Apple 账号管理数据，AI 请求仍走服务端 | 适合只做 Apple 生态；依赖用户 iCloud 状态，未来其他平台接入更麻烦；不能替代安全保存模型 Key 的服务端 |

正式登录后续可选 Sign in with Apple 或邮箱；目前配对已经能让两端共享同一账号，不必为了试用先做登录页。正式发布时再把设备凭证迁到 Keychain，补充账号恢复、删除、限流和配额。

分发可以继续 USB 安装；准备给多人测试时再做 TestFlight。Mac 自己测试可用当前构建，给他人稳定安装时再做 Developer ID 签名、公证和更新。TestFlight / App Store 和 Developer ID 分发需要合适的开发者团队资格；购买、建云资源和公开分发都留到你决定之后。

官方参考：[Apple 开发账号与免费调试限制](https://developer.apple.com/support/compare-memberships/)、[iOS capability 支持表](https://developer.apple.com/help/account/reference/supported-capabilities-ios/)、[Xcode 运行到设备](https://developer.apple.com/documentation/xcode/running-your-app-in-simulator-or-on-a-device)。
