# macOS 记录页 Vibrancy

记录页使用 `NSVisualEffectView` 绘制统一的窗口背景，覆盖标题栏、页面留白和未选中列表。搜索框只叠加轻微底色，透出同一块材质；选中条目和右侧详情卡片保持实色高亮。

参数集中在 `MacApp/BubbleRecordWorkspace.swift` 的 `BubbleRecordVibrancy` 中，修改后重新运行 `bash scripts/build-mac.sh`，退出并重新打开 `build/Language Bubble.app` 即可查看。

| 参数 | 当前值 | 调整效果 |
| --- | --- | --- |
| `material` | `.popover` | 材质预设，决定系统提供的模糊、底色与对比度组合。使用浮层材质配合浅色罩层；实际视觉随 macOS 版本、明暗外观和桌面内容变化。 |
| `blendingMode` | `.behindWindow` | 采样窗口后方的桌面和其他窗口。`.withinWindow` 改为采样同一窗口内的下层内容，不适合当前作为窗口最底层的用途。 |
| `state` | `.followsWindowActiveState` | 自动随窗口焦点切换。`.active` 可让失焦时仍保持活跃材质；`.inactive` 固定失焦效果。 |
| `isEmphasized` | `false` | 是否请求系统的强调样式；响应程度取决于材质。不控制记录选中状态。 |
| `tintOpacity` | `0.8` | 叠加在材质上的页面色，范围 `0...1`；浅色外观下越大越接近浅白，越小越能透出背景色。更通透可试 `0.35` 或 `0.55`。这不是模糊半径或原生材质的透明度。 |
| `searchTintOpacity` | `0.04` | 搜索框额外底色，范围 `0...1`；越大越突出搜索框。 |

底色取自 `BubbleRecordPalette.page`，自动适配明暗外观。高亮卡片色由 `BubbleRecordPalette.panel` 控制；边框由 `BubbleRecordPalette.border` 控制。

要让背景浅，同时仍能看到后方内容，可用原生材质加浅色罩层提亮。不断增加 `tintOpacity` 会逐渐遮住后方内容；`0.8` 表示叠加 80% 的页面色，保留 20% 的原生材质贡献，并不代表对桌面有 20% 的透过率。原生材质本身也有底色，因此无法独立指定最终亮度和透出强度。

`NSVisualEffectView` 的公开 API 不提供独立的模糊半径、饱和度或精确透明度参数，它们由系统材质决定。不应调整整个窗口的 `alphaValue`，否则文字、图片和高亮卡片也会一起透明。

系统开启“辅助功能 → 显示 → 减少透明度”时，页面自动回退为实色。切到学习页时恢复窗口原有背景和标题栏属性。设置弹窗及 iOS 页面保留原有背景。

验收时，将窗口置于有颜色或图案的桌面/其他窗口上并拖动，检查留白和未选中列表的背景随之变化；选中条目与详情卡片应保持实色。还应检查搜索、列表滚动、记录切换以及学习页往返。
