import XCTest

@MainActor
final class ContextUITests: XCTestCase {
    func testLookupAndRecordsHaveSeparateTabs() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["查词"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.navigationBars["记录"].exists)
        XCTAssertFalse(app.textFields["bubbleQuery"].exists)
        capture(app, name: "RecordsWithoutQueryForm")
        app.tabBars.buttons["查词"].tap()
        XCTAssertTrue(app.textFields["bubbleQuery"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["submitBubbleQuery"].exists)
        XCTAssertFalse(app.buttons["使用测试句"].exists)
        XCTAssertFalse(app.switches["writingMode"].exists)
        XCTAssertFalse(app.buttons["补充场景（可选）"].exists)
        capture(app, name: "MinimalLookup")
        app.tabBars.buttons["学习"].tap()
        XCTAssertTrue(app.navigationBars["场景学习"].waitForExistence(timeout: 5))
        app.tabBars.buttons["记录"].tap()
        XCTAssertTrue(app.navigationBars["记录"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.textFields["bubbleQuery"].exists)
        XCTAssertEqual(app.tabBars.buttons.count, 4)
        XCTAssertFalse(app.tabBars.buttons["进度"].exists)
        app.tabBars.buttons["设置"].tap()
        XCTAssertTrue(app.navigationBars["设置"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["最近 12 周的回忆足迹"].isHittable)
        XCTAssertFalse(app.staticTexts["阶段进展"].exists)
        capture(app, name: "ActivityAtTopOfSettings")
        app.terminate()
    }

    func testRealAIStudyPlan() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        app.tabBars.buttons["设置"].tap()
        XCTAssertTrue(app.staticTexts["liveAIStatus"].waitForExistence(timeout: 15))
        app.tabBars.buttons["查词"].tap()
        let editor = app.textFields["bubbleQuery"]
        editor.tap()
        editor.typeText("Could you walk me through the launch plan?")
        editor.typeText("\n")
        XCTAssertTrue(app.staticTexts["latestQueryResult"].waitForExistence(timeout: 60))
        app.tabBars.buttons["学习"].tap()
        let plan = app.buttons["openStudyPlan"]
        XCTAssertTrue(plan.waitForExistence(timeout: 15))
        plan.tap()
        XCTAssertTrue(app.staticTexts["liveStudyReady"].waitForExistence(timeout: 90))
        capture(app, name: "PersonalAIPlan")
        for (skill, label) in [("reading", "读"), ("listening", "听"), ("speaking", "说"), ("writing", "写")] {
            app.segmentedControls.buttons[label].tap()
            let exercise = app.buttons["study-task-" + skill]
            XCTAssertTrue(exercise.waitForExistence(timeout: 5))
            exercise.tap()
            XCTAssertTrue(app.navigationBars["场景练习"].waitForExistence(timeout: 5))
            let reveal = app.buttons["查看参考"]
            for _ in 0..<8 {
                if reveal.exists && reveal.isHittable { break }
                app.swipeUp()
            }
            XCTAssertTrue(reveal.isHittable)
            reveal.tap()
            let answer = app.staticTexts["studyAnswer"]
            XCTAssertTrue(answer.waitForExistence(timeout: 5))
            XCTAssertFalse(answer.label.isEmpty)
            XCTAssertFalse(app.staticTexts["AI Mock · 参考来自原场景与固定练习模板"].exists)
            capture(app, name: "PersonalAI-" + skill)
            if skill == "writing" {
                let input = app.textViews["studyWritingInput"]
                for _ in 0..<6 {
                    if input.exists && input.isHittable { break }
                    app.swipeDown()
                }
                input.tap(); input.typeText("He go to work every day.")
                let check = app.buttons["检查这句话"]
                for _ in 0..<6 {
                    if check.exists && check.isHittable { break }
                    app.swipeUp()
                }
                check.tap()
                let correction = app.staticTexts["studyWritingResult"]
                XCTAssertTrue(correction.waitForExistence(timeout: 60))
                XCTAssertEqual(correction.label, "He goes to work every day.")
                for _ in 0..<6 {
                    if correction.isHittable { break }
                    app.swipeUp()
                }
                XCTAssertTrue(correction.isHittable)
                XCTAssertTrue(app.navigationBars["场景练习"].exists)
                capture(app, name: "PersonalAIWritingChecked")
            }
            app.navigationBars.buttons.element(boundBy: 0).tap()
        }
        app.terminate(); app.launch()
        app.tabBars.buttons["学习"].tap()
        XCTAssertTrue(plan.waitForExistence(timeout: 10))
        plan.tap()
        XCTAssertTrue(app.staticTexts["liveStudyReady"].waitForExistence(timeout: 90))
    }

    func testRealAITranslationAndReview() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        app.tabBars.buttons["设置"].tap()
        XCTAssertTrue(app.staticTexts["liveAIStatus"].waitForExistence(timeout: 15), "Start the local service in live mode and pair this simulator first")
        app.tabBars.buttons["查词"].tap()
        let source = "We should get the ball rolling on the launch plan."
        let editor = app.textFields["bubbleQuery"]
        XCTAssertTrue(editor.waitForExistence(timeout: 5))
        editor.tap(); editor.typeText(source)
        editor.typeText("\n")
        let result = app.staticTexts["latestQueryResult"]
        XCTAssertTrue(result.waitForExistence(timeout: 60))
        XCTAssertFalse(result.label.contains("Mock"))
        XCTAssertFalse(result.label.contains("暂无"))
        XCTAssertNotEqual(result.label, source)
        app.tabBars.buttons["记录"].tap()
        let record = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@ AND label CONTAINS %@", "capture-", source)).firstMatch
        for _ in 0..<6 {
            if record.exists && record.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(record.waitForExistence(timeout: 10))
        record.tap()
        XCTAssertTrue(app.navigationBars["记录详情"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.staticTexts["AI Mock · 测试数据"].exists)
        capture(app, name: "RealAzureTranslation")
        app.tabBars.buttons["学习"].tap()
        let term = app.staticTexts[source].firstMatch
        for _ in 0..<10 {
            if term.exists && term.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(term.waitForExistence(timeout: 15))
        term.tap()
        let reveal = app.buttons["揭示答案"]
        XCTAssertTrue(reveal.waitForExistence(timeout: 5))
        reveal.tap(); app.swipeUp()
        app.buttons["记得"].tap()
        XCTAssertTrue(app.staticTexts["反馈已记录。联网后同步到另一台设备；多日回忆证据才会提升为较稳固。"].waitForExistence(timeout: 10))
        capture(app, name: "RealAIReviewRecorded")

    }

    func testRecordBrowsingAndSettings() throws {
        let app = XCUIApplication()
        app.launchArguments = ["--demo"]
        app.launch()
        XCTAssertTrue(app.staticTexts["示例预览 · 非真实采集记录"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.staticTexts["products"].exists)
        capture(app, name: "TranslationRecords")
        app.staticTexts["products"].tap()
        XCTAssertTrue(app.staticTexts["选中的原文"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["表达说明"].exists)
        app.navigationBars.buttons.element(boundBy: 0).tap()
        app.segmentedControls.buttons["写作问题"].tap()
        XCTAssertTrue(app.staticTexts["I am agree with you."].waitForExistence(timeout: 3))
        capture(app, name: "WritingRecords")
        app.staticTexts["I am agree with you."].tap()
        XCTAssertTrue(app.staticTexts["问题位置"].exists)
        XCTAssertTrue(app.staticTexts["为什么这样改"].exists)
        app.buttons["这是误判，移除记录"].tap()
        XCTAssertFalse(app.staticTexts["I am agree with you."].exists)
        app.buttons["openSettings"].tap()
        XCTAssertTrue(app.switches["保存翻译记录"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.switches["保存写作问题"].exists)
        XCTAssertFalse(app.switches["允许 AI 处理内容"].exists)
        XCTAssertTrue(app.switches["自动检查英文输入"].isEnabled)
        XCTAssertTrue(app.switches["保存翻译记录"].isEnabled)
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "Settings"; screenshot.lifetime = .keepAlways; add(screenshot)
    }

    func testEmptyStateHasSetupAndNoLearningFeature() throws {
        let app = XCUIApplication()
        app.launchArguments = ["--demo"]
        app.launch()
        app.buttons["openSettings"].tap()
        app.swipeUp()
        app.buttons["requestClearRecords"].tap()
        let confirmation = app.sheets.buttons["confirmClearRecords"].firstMatch
        XCTAssertTrue(confirmation.waitForExistence(timeout: 3))
        confirmation.tap()
        app.buttons["完成"].tap()
        XCTAssertTrue(app.buttons["设置收集入口"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["学习计划"].exists)
    }

    func testLiveAppCanAccessSharedContainer() throws {
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["设置"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.staticTexts["记录暂时无法打开"].exists)
    }

    func testNativeCrossDeviceRoundTrip() throws {
        guard let code = Bundle(for: Self.self).object(forInfoDictionaryKey: "BetaTestPairCode") as? String,
              code.count == 12 else { throw XCTSkip("Supply a fresh Mac pairing code with INFOPLIST_KEY_BetaTestPairCode") }
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["设置"].waitForExistence(timeout: 15))
        app.tabBars.buttons["设置"].tap()
        let field = app.textFields["另一设备提供的 12 位配对码"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap(); field.typeText(code)
        app.buttons["与另一设备配对"].tap()
        XCTAssertTrue(app.buttons["生成另一设备的配对码"].waitForExistence(timeout: 15))
        capture(app, name: "PairedIPhone")
        app.tabBars.buttons["学习"].tap()
        let term = app.staticTexts["It is a work in progress."].firstMatch
        XCTAssertTrue(term.waitForExistence(timeout: 15))
        term.tap()
        XCTAssertTrue(app.buttons["揭示答案"].waitForExistence(timeout: 5))
        app.buttons["揭示答案"].tap()
        app.swipeUp()
        app.buttons["记得"].tap()
        XCTAssertTrue(app.staticTexts["反馈已记录。联网后同步到另一台设备；多日回忆证据才会提升为较稳固。"].waitForExistence(timeout: 10))
        capture(app, name: "IPhoneReviewRecorded")
        app.tabBars.buttons["查词"].tap()
        let editor = app.textFields["bubbleQuery"]
        XCTAssertTrue(editor.waitForExistence(timeout: 5))
        editor.tap(); editor.typeText("That makes sense.\n")
        XCTAssertTrue(app.staticTexts["有道理；说得通。"].firstMatch.waitForExistence(timeout: 10))
        capture(app, name: "IPhoneQuerySynced")
    }

    func testPairedSceneAndLearningPlan() throws {
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["设置"].waitForExistence(timeout: 10))
        app.tabBars.buttons["设置"].tap()
        guard app.buttons["生成另一设备的配对码"].waitForExistence(timeout: 3) else { throw XCTSkip("Pair the simulator to a Mac account first") }
        app.tabBars.buttons["学习"].tap()
        let product = app.staticTexts["products"].firstMatch
        guard product.waitForExistence(timeout: 10) else { throw XCTSkip("Import the products OCR fixture through the Mac app first") }
        product.tap()
        XCTAssertTrue(app.descendants(matching: .any)["capturedScene"].firstMatch.waitForExistence(timeout: 12))
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "We build products for curious people.")).firstMatch.exists)
        capture(app, name: "MacSceneOnIPhone")
        app.swipeUp()
        XCTAssertTrue(app.buttons["揭示答案"].waitForExistence(timeout: 5))
        app.buttons["揭示答案"].tap()
        app.swipeUp()
        app.buttons["记得"].tap()
        XCTAssertTrue(app.staticTexts["反馈已记录。联网后同步到另一台设备；多日回忆证据才会提升为较稳固。"].waitForExistence(timeout: 10))
        app.tabBars.buttons["设置"].tap()
        XCTAssertTrue(app.navigationBars["设置"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.staticTexts["最近 12 周的回忆足迹"].exists)
        capture(app, name: "SharedActivityInSettings")
        app.terminate(); app.launch()
        app.tabBars.buttons["学习"].tap()
        let plan = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "今日场景练习")).firstMatch
        XCTAssertTrue(plan.waitForExistence(timeout: 10))
        plan.tap()
        XCTAssertTrue(app.segmentedControls.buttons["听"].waitForExistence(timeout: 5))
        capture(app, name: "SceneStudyPlanAfterRestart")
    }

    func testExistingWritingDeletePersistsAfterRestart() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["设置"].waitForExistence(timeout: 10))
        app.tabBars.buttons["设置"].tap()
        guard app.buttons["生成另一设备的配对码"].waitForExistence(timeout: 3) else { throw XCTSkip("Pair the local test account first") }
        app.tabBars.buttons["记录"].tap()
        let record = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@ AND label CONTAINS %@ AND label CONTAINS %@", "capture-", "I am agree with you.", "写作问题")).firstMatch
        for _ in 0..<5 {
            if record.exists && record.isHittable { break }
            app.swipeUp()
        }
        guard record.waitForExistence(timeout: 5) else { throw XCTSkip("Create the writing fixture through the keyboard extension before testing deletion") }
        let recordId = record.identifier
        record.tap()
        XCTAssertTrue(app.navigationBars["记录详情"].waitForExistence(timeout: 5))
        capture(app, name: "NativeWritingIssue")
        app.buttons["删除"].tap()
        let confirmDelete = app.buttons["删除记录"]
        XCTAssertTrue(confirmDelete.waitForExistence(timeout: 5))
        confirmDelete.tap()
        XCTAssertTrue(app.navigationBars["记录详情"].waitForNonExistence(timeout: 10), "Wait for durable deletion before terminating")
        app.terminate(); app.launch()
        app.tabBars.buttons["记录"].tap()
        for _ in 0..<3 { app.swipeUp() }
        XCTAssertFalse(app.buttons[recordId].exists)
        capture(app, name: "DeletedWritingAfterRestart")
    }

    private func capture(_ app: XCUIApplication, name: String) {
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = name
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    func testInterfaceLanguageSwitchPersistsAndRestoresChinese() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["设置"].waitForExistence(timeout: 10))
        app.tabBars.buttons["设置"].tap()
        let picker = app.buttons["interfaceLanguage"]
        for _ in 0..<5 {
            if picker.exists && picker.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(picker.waitForExistence(timeout: 5))
        picker.tap()
        app.buttons["English"].tap()
        XCTAssertTrue(app.tabBars.buttons["Records"].waitForExistence(timeout: 5))
        app.terminate(); app.launch()
        XCTAssertTrue(app.tabBars.buttons["Records"].waitForExistence(timeout: 10))
        app.tabBars.buttons["Learn"].tap()
        XCTAssertTrue(app.navigationBars["Learn in context"].waitForExistence(timeout: 5))
        capture(app, name: "EnglishLearningAfterRestart")
        app.tabBars.buttons["Settings"].tap()
        for _ in 0..<5 {
            if picker.exists && picker.isHittable { break }
            app.swipeUp()
        }
        picker.tap()
        app.buttons["简体中文"].tap()
        XCTAssertTrue(app.tabBars.buttons["记录"].waitForExistence(timeout: 5))
    }
}
