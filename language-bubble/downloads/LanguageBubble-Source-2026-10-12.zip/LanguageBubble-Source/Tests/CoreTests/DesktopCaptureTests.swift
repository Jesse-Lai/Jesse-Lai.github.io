#if os(macOS)
import XCTest
@testable import ContextCore

final class DesktopCaptureTests: XCTestCase {
    func testTeamsSelectionAncestorsReachWebAreaBeyondNativeWrapperDepth() {
        // Captured Teams layout: editor -> ten groups -> web area -> native host.
        let parents = Dictionary(uniqueKeysWithValues: (0..<18).map { ($0, $0 + 1) })
        let nodes = DesktopSelectionProbe.ancestors(from: 0, parent: { parents[$0] })
        XCTAssertEqual(nodes, Array(0...18))
        XCTAssertTrue(nodes.contains(11), "The web area must receive selection/focus observers")
        XCTAssertEqual(DesktopSelectionProbe.ancestors(from: 0, parent: { ($0 + 1) % 3 }), [0, 1, 2])
        XCTAssertEqual(DesktopSelectionProbe.ancestors(from: 0, parent: { $0 + 1 }).count, 24)
        XCTAssertTrue(DesktopSelectionProbe.ancestors(from: 0, parent: { _ in
            XCTFail("An expired probe must not query the host"); return nil
        }, shouldContinue: { false }).isEmpty)
    }

    @MainActor func testSelectionProbeWaitsForDelayedWebSelectionAndStopsOnSuccess() async {
        var reads = 0
        var waits: [Duration] = []
        let value = await DesktopSelectionProbe.read(shouldContinue: { true }, read: {
            reads += 1
            return reads == 2 ? "selected draft" : nil
        }, wait: { waits.append($0) })
        XCTAssertEqual(value, "selected draft")
        XCTAssertEqual(reads, 2)
        XCTAssertEqual(waits, [.milliseconds(220), .milliseconds(160)])
    }

    @MainActor func testSelectionProbeCannotReappearAfterAppOrSelectionChanges() async {
        var current = true
        var reads = 0
        var waits = 0
        let value: String? = await DesktopSelectionProbe.read(shouldContinue: { current }, read: {
            reads += 1
            return nil
        }, wait: { _ in
            waits += 1
            if waits == 2 { current = false }
        })
        XCTAssertNil(value)
        XCTAssertEqual(reads, 1, "The old source must not be read after switching apps or typing")
        let cancelled: String? = await DesktopSelectionProbe.read(shouldContinue: { true }, read: {
            XCTFail("Cancelled delay must not read or show a shortcut"); return "stale"
        }, wait: { _ in throw CancellationError() })
        XCTAssertNil(cancelled)
    }

    @MainActor func testMissingSelectionHasFiniteRetryBudget() async {
        var reads = 0
        let value: String? = await DesktopSelectionProbe.read(shouldContinue: { true }, read: {
            reads += 1; return nil
        }, wait: { _ in })
        XCTAssertNil(value)
        XCTAssertEqual(reads, 3, "An empty caret never becomes a fabricated selection")
    }

    func testPolishReplacementRequiresOriginalTextRangeAndDocument() throws {
        let document = "recieve and recieve"
        let selection = try XCTUnwrap(DesktopPolishSelection(text: "recieve", range: NSRange(location: 0, length: 7), fullValue: document))
        XCTAssertTrue(selection.matches(text: "recieve", range: NSRange(location: 0, length: 7), fullValue: document))
        XCTAssertFalse(selection.matches(text: "recieve", range: NSRange(location: 12, length: 7), fullValue: document), "Same word elsewhere is a different selection")
        XCTAssertFalse(selection.matches(text: "recieve", range: NSRange(location: 0, length: 7), fullValue: "recieve and replace"))
        XCTAssertFalse(selection.matches(text: "", range: NSRange(location: 0, length: 0), fullValue: document))
        XCTAssertFalse(selection.matches(text: "receive", range: NSRange(location: 0, length: 7), fullValue: document))
        XCTAssertNil(DesktopPolishSelection(text: "recieve", range: NSRange(location: NSNotFound, length: 7), fullValue: document))
        XCTAssertNil(DesktopPolishSelection(text: "recieve", range: NSRange(location: 0, length: Int.max), fullValue: document))
    }

    func testPolishReplacementPreservesSelectedWhitespaceAndUTF16Boundaries() throws {
        let document = "😀  我以经完成了。\nnext"
        let range = (document as NSString).range(of: "  我以经完成了。\n")
        let selection = try XCTUnwrap(DesktopPolishSelection(text: "  我以经完成了。\n", range: range, fullValue: document))
        let result = (document as NSString).replacingCharacters(in: selection.range, with: selection.replacement("我已经完成了。"))
        XCTAssertEqual(result, "😀  我已经完成了。\nnext")
        XCTAssertNil(DesktopPolishSelection(text: "😀", range: NSRange(location: 0, length: 1), fullValue: document))
    }

    func testSelectionWorkingImageIncludesFullVisibleLinesAcrossDisplay() throws {
        let screen = CGRect(x: -1440, y: -200, width: 1440, height: 900)
        let word = CGRect(x: -800, y: 400, width: 95, height: 22)
        let crop = try XCTUnwrap(DesktopSceneGeometry.selectionCrop(around: word, screens: [screen]))
        XCTAssertEqual(crop.rectangle, screen, "Capture context before trimming; never cut a sentence at the word's edge")
        let edge = CGRect(x: -1440, y: -200, width: 320, height: 90)
        let clipped = try XCTUnwrap(DesktopSceneGeometry.selectionCrop(around: edge, screens: [screen]))
        XCTAssertTrue(screen.contains(clipped.rectangle))
        XCTAssertTrue(clipped.rectangle.contains(edge))
        XCTAssertNil(DesktopSceneGeometry.selectionCrop(around: .zero, screens: [screen]))
        XCTAssertNil(DesktopSceneGeometry.selectionCrop(around: .infinite, screens: [screen]))
    }

    func testBubbleStaysVisibleWithoutCoveringSelectionAtTopEdge() {
        let screen = CGRect(x: -1440, y: 0, width: 1440, height: 875)
        for anchor in [CGRect(x: -1439, y: 840, width: 120, height: 30),
                       CGRect(x: -100, y: 20, width: 90, height: 22)] {
            let frame = DesktopSceneGeometry.bubbleFrame(near: anchor, size: CGSize(width: 96, height: 42), visible: screen)
            XCTAssertTrue(screen.contains(frame))
            XCTAssertFalse(frame.intersects(anchor))
        }
    }

    func testBrowserSourcesUseDocumentURLsAndIgnoreHyperlinks() throws {
        struct Node: Equatable {
            var id: Int
            var role: String
            var url: String? = nil
            var children: [Node] = []
        }
        let page = Node(id: 3, role: "AXWebArea", url: "https://example.com/article?chapter=2#word")
        let link = Node(id: 2, role: "AXLink", url: "https://unrelated.example/ad")
        let window = Node(id: 0, role: "AXWindow", children: [link, Node(id: 1, role: "AXGroup", children: [page])])
        func find(document: Any? = nil, tree: Node = window) -> String? {
            DesktopDocumentURL.find(in: tree, document: { _ in document }, isWebArea: { $0.role == "AXWebArea" },
                webURL: { $0.url.flatMap(URL.init(string:)) as NSURL? }, children: { $0.children })
        }
        XCTAssertEqual(find(), page.url, "Chromium supplies a URL object on its web area, not AXDocument")
        XCTAssertEqual(find(document: NSURL(string: "https://example.com/safari")), "https://example.com/safari")
        XCTAssertEqual(find(document: "https://example.com/document"), "https://example.com/document")
        XCTAssertEqual(find(document: "file:///private/document.pdf"), page.url)
        XCTAssertNil(find(tree: Node(id: 0, role: "AXWindow", children: [link])))
        XCTAssertNil(find(tree: Node(id: 0, role: "AXWebArea", url: "file:///private/local.html", children: [page])),
                     "An embedded frame must not be mistaken for the containing page")
    }

    func testDocumentSearchStopsAtCyclesAndUnavailableTrees() {
        var reads = 0
        let result = DesktopDocumentURL.find(in: 0, document: { _ in nil }, isWebArea: { _ in false },
            webURL: { _ in nil }, children: { node in reads += 1; return [node, node + 1] })
        XCTAssertNil(result)
        XCTAssertLessThanOrEqual(reads, 160)
        XCTAssertNil(DesktopDocumentURL.find(in: 0, document: { _ in nil }, isWebArea: { _ in false },
            webURL: { _ in nil }, children: { _ in XCTFail("Timed out tree should not be read"); return [] },
            shouldContinue: { false }))
    }

    func testFocusedDocumentUsesContainingPageAndRequiresSameWindow() {
        // window -> main page -> embedded frame -> selected text
        let parents = [3: 2, 2: 1, 1: 0]
        func resolve(window: Int) -> String? {
            DesktopDocumentURL.find(in: window, document: { _ in nil }, isWebArea: { [1, 2].contains($0) },
                webURL: { [1: "https://example.com/article", 2: "https://embedded.example/frame"][$0] },
                children: { _ in [] }, focused: 3, parent: { parents[$0] })
        }
        XCTAssertEqual(resolve(window: 0), "https://example.com/article")
        XCTAssertNil(resolve(window: 9), "Focus from another window cannot supply this capture's source")
    }

    func testPointerCoordinatesUseCropOriginOnEveryDisplay() throws {
        let screens = [CGRect(x: 0, y: 0, width: 1440, height: 900),
                       CGRect(x: -1920, y: -200, width: 1920, height: 1080),
                       CGRect(x: 0, y: 900, width: 1280, height: 800)]
        for point in [CGPoint(x: 20, y: 30), CGPoint(x: 1400, y: 850),
                      CGPoint(x: -1800, y: -100), CGPoint(x: 100, y: 1500)] {
            let crop = try XCTUnwrap(DesktopSceneGeometry.crop(around: CGRect(origin: point, size: CGSize(width: 1, height: 1)), screens: screens))
            let normalized = try XCTUnwrap(DesktopSceneGeometry.normalizedPoint(point, in: crop.rectangle))
            XCTAssertEqual(crop.rectangle.minX + normalized.x * crop.rectangle.width, point.x, accuracy: 0.0001)
            XCTAssertEqual(crop.rectangle.minY + normalized.y * crop.rectangle.height, point.y, accuracy: 0.0001)
            let ax = DesktopSceneGeometry.axPoint(point, primaryHeight: 900)
            XCTAssertEqual(DesktopSceneGeometry.axPoint(ax, primaryHeight: 900), point)
        }
        XCTAssertNil(DesktopSceneGeometry.normalizedPoint(.zero, in: .zero))
        XCTAssertNil(DesktopSceneGeometry.normalizedPoint(CGPoint(x: 2000, y: 0), in: screens[0]))
    }

    @MainActor
    func testRegionAndOCRReserveCaptureBeforeTranslationStarts() async throws {
        let gate = DesktopCaptureGate()
        let first = try XCTUnwrap(gate.acquire(querying: false))
        // OCR and region selection suspend before BubbleStore begins its network query.
        await Task.yield()
        XCTAssertNil(gate.acquire(querying: false), "A second shortcut must not start another capture during OCR")
        gate.release(first)
        let next = try XCTUnwrap(gate.acquire(querying: false))
        gate.release(first)
        XCTAssertEqual(gate.active, next, "A late callback from a dismissed overlay cannot release a new capture")
        gate.release(next)
        XCTAssertNil(gate.acquire(querying: true))
        XCTAssertNotNil(gate.acquire(querying: false))
    }

    func testSelectionCoordinatesAcrossDisplays() throws {
        let screens = [CGRect(x: 0, y: 0, width: 1440, height: 900),
                       CGRect(x: -1920, y: -200, width: 1920, height: 1080),
                       CGRect(x: 0, y: 900, width: 1280, height: 800)]
        let leftSelection = DesktopSceneGeometry.appKitRect(CGRect(x: -1600, y: 300, width: 180, height: 24), primaryHeight: 900)
        XCTAssertEqual(leftSelection, CGRect(x: -1600, y: 576, width: 180, height: 24))
        let left = try XCTUnwrap(DesktopSceneGeometry.crop(around: leftSelection, screens: screens))
        XCTAssertEqual(left.screen, 1)
        XCTAssertTrue(left.rectangle.contains(leftSelection))
        XCTAssertTrue(screens[1].contains(left.rectangle))
        let aboveSelection = DesktopSceneGeometry.appKitRect(CGRect(x: 100, y: -700, width: 100, height: 30), primaryHeight: 900)
        let above = try XCTUnwrap(DesktopSceneGeometry.crop(around: aboveSelection, screens: screens))
        XCTAssertEqual(above.screen, 2)
        XCTAssertTrue(above.rectangle.contains(aboveSelection))
    }

    func testCropAtDisplayEdgeRetainsContextAndNeverUsesAnotherScreen() throws {
        let screen = CGRect(x: 0, y: 0, width: 1440, height: 900)
        let anchor = CGRect(x: 1430, y: 880, width: 10, height: 20)
        let crop = try XCTUnwrap(DesktopSceneGeometry.crop(around: anchor, screens: [screen]))
        XCTAssertEqual(crop.rectangle.size, CGSize(width: 700, height: 320))
        XCTAssertTrue(crop.rectangle.contains(anchor))
        XCTAssertTrue(screen.contains(crop.rectangle))
        XCTAssertNil(DesktopSceneGeometry.crop(around: CGRect(x: 2000, y: 1000, width: 100, height: 20), screens: [screen]))
        XCTAssertNil(DesktopSceneGeometry.crop(around: .zero, screens: [screen]))
        XCTAssertNil(DesktopSceneGeometry.crop(around: .infinite, screens: [screen]))
    }

    func testSelectionSpanningScreensUsesDisplayWithMostSelectedContent() throws {
        let screens = [CGRect(x: 0, y: 0, width: 1440, height: 900), CGRect(x: 1440, y: 0, width: 1920, height: 1080)]
        let anchor = CGRect(x: 1400, y: 100, width: 440, height: 100)
        let crop = try XCTUnwrap(DesktopSceneGeometry.crop(around: anchor, screens: screens))
        XCTAssertEqual(crop.screen, 1)
        XCTAssertTrue(crop.rectangle.contains(anchor.intersection(screens[1])))
    }
}
#endif
