import XCTest
@testable import ContextCore

final class ArticleReplyTests: XCTestCase {
    func testQuizPreservesSurroundingProseAndNormalizesMarkdownChoices() {
        let text = "Let's practice!\n\n**How is resilient used?**\n\n**A.** Recovers from difficulties\n\n- **B**. Avoids difficulties\nC) Solves problems quickly\nD. Works independently\n\nTry another way if you like."
        XCTAssertEqual(ArticleReplyBlock.parse(text), [
            .paragraph("Let's practice!"),
            .quiz(question: "**How is resilient used?**", choices: ["A. Recovers from difficulties", "B. Avoids difficulties", "C. Solves problems quickly", "D. Works independently"]),
            .paragraph("Try another way if you like.")
        ])
    }

    func testOrdinaryMarkdownAndIncompleteChoicesStayIntact() {
        for text in ["## Meaning\n\n**resilient** means able to recover.\n- Example one\n- Example two",
                     "What does it mean?\nA. One unfinished option", "Headings\nA. First\nB. Second",
                     "What does it mean?\nA. First\nC. Missing B"] {
            XCTAssertEqual(ArticleReplyBlock.parse(text), [.paragraph(text)])
        }
    }

    func testMultipleQuestionsAndChinesePunctuation() {
        XCTAssertEqual(ArticleReplyBlock.parse("什么意思？\nA、恢复\nB、回避\n\nWhich fits?\nA. First\nB. Second"), [
            .quiz(question: "什么意思？", choices: ["A. 恢复", "B. 回避"]),
            .quiz(question: "Which fits?", choices: ["A. First", "B. Second"])
        ])
        XCTAssertEqual(ArticleReplyBlock.parse("\n  "), [])
    }
}
