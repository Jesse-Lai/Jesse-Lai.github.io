import XCTest
@testable import ContextCore

@MainActor
final class SyncStoreTests: XCTestCase {
    func testRecordPresentationPersistsWithoutChangingCaptureEvents() throws {
        var state = BubbleLocalState()
        let capture = BubbleCapture(source: "Bubble", result: "气泡", explanation: "", assetIds: ["scene"])
        state.captures[capture.id] = capture
        let presentation = BubbleScenePresentation(aspectRatio: 1.4, imageWidth: 1.7, imageHeight: 1.7,
            imageX: 0, imageY: -0.7, artwork: .journeyTicket, displayImageName: "JourneyTicketContent")
        state.scenePresentations = ["scene": presentation]
        let curated = BubbleScenePresentation(aspectRatio: 2.5, imageWidth: 1, imageHeight: 1,
            imageX: 0, imageY: 0, artwork: .curatedCutout, displayImageName: "CuratedClarityQuote",
            placement: .init(x: 248, y: 68, width: 430, height: 172, rotation: -2))
        state.scenePresentations?["curated"] = curated
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        let id = BubbleRecord.key(for: capture)
        XCTAssertFalse(store.isFavorite(id))
        store.toggleFavorite(id)
        let restarted = try BubbleStore(root: root)
        XCTAssertTrue(restarted.isFavorite(id))
        XCTAssertEqual(restarted.scenePresentation("scene"), presentation)
        XCTAssertEqual(restarted.scenePresentation("curated"), curated)
        XCTAssertEqual(restarted.captures, [capture])
        XCTAssertTrue(restarted.state.outbox.isEmpty)
        restarted.toggleFavorite(id)
        XCTAssertFalse(try BubbleStore(root: root).isFavorite(id))
    }

    func testLegacyScenePresentationDecodesWithoutArtwork() throws {
        let data = Data(#"{"aspect_ratio":1.4,"image_width":1,"image_height":1,"image_x":0,"image_y":0}"#.utf8)
        let presentation = try BubbleCodec.decoder.decode(BubbleScenePresentation.self, from: data)
        XCTAssertNil(presentation.artwork)
        XCTAssertNil(presentation.displayImageName)
        XCTAssertNil(presentation.placement)
        XCTAssertEqual(presentation.imageWidth, 1)
    }

    private func makeStore(_ state: BubbleLocalState) throws -> (BubbleStore, URL) {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { _ in throw URLError(.notConnectedToInternet) })
        }
        return (store, root)
    }
    private func signedIn() -> BubbleLocalState {
        var state = BubbleLocalState()
        state.session = DeviceSession(userId: "test-user", deviceId: "test-device", token: "test-only", epoch: 0)
        return state
    }
    func testExtensionUndoPersistsDeletionWhileOffline() async throws {
        var state = signedIn()
        let id = UUID()
        let key = id.uuidString.lowercased()
        state.captures[key] = BubbleCapture(id: key, source: "products", result: "产品", explanation: "fixture")
        state.importedIds = [key]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        store.bridgeSnapshot = { var journal = JournalState(); journal.tombstones = [id]; return JournalSnapshot(state: journal, records: []) }
        await store.sync()
        XCTAssertNil(store.state.captures[key])
        XCTAssertEqual(store.state.outbox.map(\.action), ["capture.delete"])
        let restarted = try BubbleStore(root: root)
        XCTAssertNil(restarted.state.captures[key])
        XCTAssertEqual(restarted.state.outbox.count, 1)
    }
    func testJournalClearDoesNotDeleteUnrelatedMacCaptures() async throws {
        var state = signedIn()
        let local = BubbleCapture(source: "local", result: "a", explanation: "fixture")
        let remote = BubbleCapture(source: "mac", result: "b", explanation: "fixture")
        state.captures = [local.id: local, remote.id: remote]
        state.importedIds = [local.id]; state.bridgeEpoch = 2
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        store.bridgeSnapshot = { var journal = JournalState(); journal.epoch = 3; return JournalSnapshot(state: journal, records: []) }
        await store.sync()
        XCTAssertNil(store.state.captures[local.id])
        XCTAssertNotNil(store.state.captures[remote.id])
    }
    func testDiskFailureDoesNotReportDurableReview() async throws {
        var state = signedIn()
        let item = LearningItem(id: "test-item", term: "products", meaning: "产品", explanation: "fixture", captureIds: [],
            example: "products", exampleSource: "captured", isMock: true, state: "unassessed", successes: 0,
            reviews: 0, dueAt: 0, intervalDays: 0, paused: false)
        state.learning[item.id] = item
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        try FileManager.default.removeItem(at: root.appendingPathComponent("state.json"))
        try FileManager.default.createDirectory(at: root.appendingPathComponent("state.json"), withIntermediateDirectories: false)
        let accepted = await store.review(item, rating: "good")
        XCTAssertFalse(accepted)
        XCTAssertTrue(store.state.outbox.isEmpty)
        XCTAssertNotNil(store.error)
    }
    func testUnknownSyncEntityDoesNotAdvanceCursor() throws {
        let payload = Data(#"{"epoch":0,"cursor":3,"has_more":false,"changes":[{"seq":3,"kind":"future","id":"x","deleted":false,"data":{}}]}"#.utf8)
        XCTAssertThrowsError(try BubbleCodec.decoder.decode(SyncPage.self, from: payload))
    }

    func testFailedDeletionKeepsSceneAndDoesNotRemoveExtensionRecord() async throws {
        var state = signedIn()
        var capture = BubbleCapture(source: "products", result: "产品", explanation: "fixture")
        capture.assetIds = ["scene"]
        state.captures[capture.id] = capture
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        let image = root.appendingPathComponent("scene.png")
        try Data("fixture".utf8).write(to: image)
        var bridgeRemoved = false
        store.removeBridgeRecord = { _ in bridgeRemoved = true }
        try FileManager.default.removeItem(at: root.appendingPathComponent("state.json"))
        try FileManager.default.createDirectory(at: root.appendingPathComponent("state.json"), withIntermediateDirectories: false)
        let deleted = await store.delete(capture)
        XCTAssertFalse(deleted)
        XCTAssertNotNil(store.state.captures[capture.id])
        XCTAssertTrue(FileManager.default.fileExists(atPath: image.path))
        XCTAssertFalse(bridgeRemoved)
        XCTAssertTrue(store.state.outbox.isEmpty)
    }

    func testSameLanguageRoutesToSecondaryTarget() {
        XCTAssertEqual(LanguageRouting.target(detected: "zh", primary: "zh", secondary: "en"), "en")
        XCTAssertEqual(LanguageRouting.target(detected: "ja", primary: "zh", secondary: "en"), "zh")
        XCTAssertEqual(LanguageRouting.target(detected: nil, primary: "zh", secondary: "en"), "zh")
    }

    func testGroupedDeletionPersistsAllEncountersAndLeavesOtherWords() async throws {
        var state = signedIn()
        let first = BubbleCapture(id: "first", source: "resilient", result: "a", explanation: "", assetIds: ["scene-one"])
        let second = BubbleCapture(id: "second", source: "Resilient", result: "b", explanation: "", assetIds: ["scene-two"])
        let other = BubbleCapture(id: "other", source: "clarity", result: "c", explanation: "")
        state.captures = [first.id: first, second.id: second, other.id: other]
        state.outbox = [SyncOperation(action: "capture.put", entityId: first.id, capture: first)]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        for asset in ["scene-one", "scene-two"] { try Data("fixture".utf8).write(to: root.appendingPathComponent(asset + ".png")) }
        var removed: Set<String> = []
        store.removeBridgeRecord = { removed.insert($0) }
        let deleted = await store.deleteRecord(BubbleRecord.key(for: first))
        XCTAssertTrue(deleted)
        XCTAssertEqual(removed, [first.id, second.id])
        XCTAssertEqual(store.state.importedIds, [first.id, second.id])
        XCTAssertEqual(Set(store.state.outbox.map(\.entityId)), [first.id, second.id])
        XCTAssertTrue(store.state.outbox.allSatisfy { $0.action == "capture.delete" })
        for asset in ["scene-one", "scene-two"] { XCTAssertFalse(FileManager.default.fileExists(atPath: root.appendingPathComponent(asset + ".png").path)) }
        let restarted = try BubbleStore(root: root)
        XCTAssertEqual(restarted.captures.map(\.id), [other.id])
        XCTAssertEqual(restarted.records.count, 1)
    }

    func testGroupedDeletionRollsBackEveryEncounterWhenSaveFails() async throws {
        var state = signedIn()
        let first = BubbleCapture(id: "first", source: "word", result: "a", explanation: "")
        let second = BubbleCapture(id: "second", source: "word", result: "b", explanation: "")
        state.captures = [first.id: first, second.id: second]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        store.latest = second
        var removed: [String] = []
        store.removeBridgeRecord = { removed.append($0) }
        try FileManager.default.removeItem(at: root.appendingPathComponent("state.json"))
        try FileManager.default.createDirectory(at: root.appendingPathComponent("state.json"), withIntermediateDirectories: false)
        let deleted = await store.deleteRecord(BubbleRecord.key(for: first))
        XCTAssertFalse(deleted)
        XCTAssertEqual(store.records.first?.encounters.count, 2)
        XCTAssertEqual(store.latest?.id, second.id)
        XCTAssertTrue(removed.isEmpty)
        XCTAssertTrue(store.state.outbox.isEmpty)
    }

    func testSyncAddsSourceToExistingRecordAndRemoteDeletionKeepsOtherSource() async throws {
        var state = signedIn()
        let first = BubbleCapture(id: "first", source: "resilient", result: "a", explanation: "", createdAt: 1)
        let second = BubbleCapture(id: "second", source: "resilient", result: "b", explanation: "", createdAt: 2,
                                   sourceUrl: "https://example.com/source")
        state.captures = [first.id: first]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        let newSource = try JSONSerialization.jsonObject(with: BubbleCodec.encoder.encode(second))
        let originalID = try XCTUnwrap(store.records.first?.id)
        var remoteDeleted = false
        store.clientFactory = { endpoint, token in
            let deleted = remoteDeleted
            return SyncClient(endpoint: endpoint, token: token, transport: { request in
                let object: [String: Any]
                if request.url!.path == "/health" { object = ["status": "ok", "ai_mode": "live"] }
                else {
                    let change: [String: Any] = deleted
                        ? ["seq": 2, "kind": "capture", "id": second.id, "deleted": true]
                        : ["seq": 1, "kind": "capture", "id": second.id, "deleted": false, "data": newSource]
                    object = ["epoch": 0, "cursor": deleted ? 2 : 1, "has_more": false, "changes": [change]]
                }
                return (try JSONSerialization.data(withJSONObject: object), HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
            })
        }
        await store.sync()
        XCTAssertEqual(store.records.count, 1)
        XCTAssertEqual(store.record(originalID)?.encounters.map(\.id), [second.id, first.id])
        remoteDeleted = true
        await store.sync()
        XCTAssertEqual(store.record(originalID)?.encounters.map(\.id), [first.id])
        XCTAssertEqual(try BubbleStore(root: root).records.first?.id, originalID)
    }

    func testMissingAttachmentDoesNotBlockUnrelatedOfflineOperation() async throws {
        var state = signedIn()
        let capture = BubbleCapture(source: "products", result: "产品", explanation: "fixture")
        state.images = [PendingImage(id: "image", captureId: capture.id, file: "missing.png")]
        state.captures[capture.id] = capture
        state.outbox = [SyncOperation(action: "capture.put", entityId: capture.id, capture: capture), SyncOperation(action: "capture.delete", entityId: UUID().uuidString.lowercased())]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                let path = request.url!.path
                let object: [String: Any]
                if path == "/health" { object = ["status": "ok", "ai_mode": "mock"] }
                else if path.hasSuffix("/pull") { object = ["epoch": 0, "cursor": 0, "has_more": false, "changes": []] }
                else if path == "/v2/articles" { object = ["articles": []] }
                else {
                    let body = try JSONSerialization.jsonObject(with: request.httpBody!) as! [String: Any]
                    let ops = body["operations"] as! [[String: Any]]
                    object = ["accepted": ops.map { $0["op_id"] as! String }]
                }
                return (try JSONSerialization.data(withJSONObject: object), HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
            })
        }
        await store.sync()
        XCTAssertEqual(store.state.outbox.count, 1)
        XCTAssertEqual(store.state.outbox.first?.entityId, capture.id)
        XCTAssertNotNil(store.error)
    }
}
