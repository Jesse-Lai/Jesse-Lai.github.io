import Foundation
import XCTest
@testable import ContextCore

final class JournalTests: XCTestCase {
    var root: URL!
    var journal: SharedJournal!
    override func setUpWithError() throws {
        root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        journal = try SharedJournal(root: root)
        try journal.updatePreferences { $0.automaticChecking = true; $0.saveTranslations = true; $0.saveWritingIssues = true }
    }
    override func tearDownWithError() throws { try FileManager.default.removeItem(at: root) }
    func record(_ ticket: CaptureTicket) -> CapturedRecord {
        CapturedRecord(id: ticket.id, epoch: ticket.epoch, kind: .translation, source: "products", result: "产品", explanation: "复数")
    }

    func testQueueSurvivesReopeningAndRetriesAreIdempotent() throws {
        let ticket = try journal.ticket()
        try journal.enqueue(record(ticket), ticket: ticket)
        try journal.enqueue(record(ticket), ticket: ticket)
        let reopened = try SharedJournal(root: root)
        try reopened.consume { XCTAssertEqual($0.records.count, 1) }
        try reopened.consume { XCTAssertTrue($0.records.isEmpty) }
    }

    func testFailedImportDoesNotLosePendingRecord() throws {
        let ticket = try journal.ticket()
        try journal.enqueue(record(ticket), ticket: ticket)
        XCTAssertThrowsError(try journal.consume { _ in throw ContextError.invalidResponse })
        try journal.consume { XCTAssertEqual($0.records.count, 1) }
    }

    func testUndoRejectsLateResponsesEvenAfterImport() throws {
        let ticket = try journal.ticket()
        try journal.enqueue(record(ticket), ticket: ticket)
        try journal.consume { _ in }
        try journal.remove(ticket.id)
        XCTAssertFalse(try journal.enqueue(record(ticket), ticket: ticket))
        try journal.consume { XCTAssertTrue($0.state.tombstones.contains(ticket.id)); XCTAssertTrue($0.records.isEmpty) }
    }

    func testClearInvalidatesInflightResponses() throws {
        let ticket = try journal.ticket()
        try journal.clear()
        XCTAssertFalse(try journal.enqueue(record(ticket), ticket: ticket))
        let next = try journal.ticket()
        XCTAssertTrue(try journal.enqueue(record(next), ticket: next))
    }

    func testOffOnDoesNotResurrectInflightRequest() throws {
        let ticket = try journal.ticket()
        try journal.updatePreferences { $0.saveTranslations = false }
        try journal.updatePreferences { $0.saveTranslations = true }
        XCTAssertFalse(try journal.enqueue(record(ticket), ticket: ticket))
    }

    func testCategoriesHaveIndependentSavingSettings() throws {
        try journal.updatePreferences { $0.saveTranslations = false }
        let ticket = try journal.ticket()
        XCTAssertFalse(try journal.enqueue(record(ticket), ticket: ticket))
        var writing = record(ticket); writing.kind = .writing
        XCTAssertTrue(try journal.enqueue(writing, ticket: ticket))
    }

    func testTranslationSavingDoesNotRequireAutomaticChecking() throws {
        try journal.updatePreferences { $0.automaticChecking = false }
        let ticket = try journal.ticket()
        XCTAssertTrue(try journal.enqueue(record(ticket), ticket: ticket))
        var writing = record(ticket); writing.id = UUID(); writing.kind = .writing
        let writingTicket = try journal.ticket(id: writing.id)
        XCTAssertFalse(try journal.enqueue(writing, ticket: writingTicket))
    }

    func testPausingAndResumingCheckingRejectsLateWritingResults() throws {
        let ticket = try journal.ticket()
        var writing = record(ticket); writing.kind = .writing
        try journal.updatePreferences { $0.automaticChecking = false }
        try journal.updatePreferences { $0.automaticChecking = true }
        XCTAssertFalse(try journal.enqueue(writing, ticket: ticket))
    }

    func testExistingInstallWithOldConsentOffCanSaveTranslation() throws {
        let legacy = """
        {"epoch":0,"consentRevision":4,"tombstones":[],"preferences":{
          "aiConsent":false,"automaticChecking":false,"saveTranslations":true,
          "saveWritingIssues":false,"serviceURL":"https://context.invalid","serviceToken":"test"}}
        """
        try Data(legacy.utf8).write(to: root.appendingPathComponent("state.json"))
        let reopened = try SharedJournal(root: root)
        let (preferences, ticket) = try reopened.capture()
        XCTAssertFalse(preferences.automaticChecking)
        XCTAssertTrue(preferences.saveTranslations)
        XCTAssertEqual(preferences.serviceURL, "https://context.invalid")
        XCTAssertTrue(try reopened.enqueue(record(ticket), ticket: ticket))
        try reopened.consume { XCTAssertEqual($0.records.count, 1) }
    }

    func testConcurrentProcessesUseOneConsistentQueue() throws {
        let roots = root!
        let failures = FailureBox()
        DispatchQueue.concurrentPerform(iterations: 30) { _ in
            do {
                let other = try SharedJournal(root: roots)
                let ticket = try other.ticket()
                let value = CapturedRecord(id: ticket.id, epoch: ticket.epoch, kind: .translation, source: "hello", result: "你好", explanation: "")
                try other.enqueue(value, ticket: ticket)
            } catch { failures.add(error) }
        }
        XCTAssertEqual(failures.count, 0)
        try journal.consume { XCTAssertEqual($0.records.count, 30) }
    }
}

private final class FailureBox: @unchecked Sendable {
    let lock = NSLock()
    private var errors: [Error] = []
    func add(_ error: Error) { lock.lock(); defer { lock.unlock() }; errors.append(error) }
    var count: Int { lock.lock(); defer { lock.unlock() }; return errors.count }
}
