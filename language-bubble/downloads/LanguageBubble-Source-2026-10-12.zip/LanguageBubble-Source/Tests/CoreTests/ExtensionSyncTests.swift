import Foundation
import XCTest
@testable import ContextCore

final class ExtensionSyncTests: XCTestCase {
    private var root: URL!
    private var journal: SharedJournal!
    private let session = DeviceSession(userId: "phone-user", deviceId: "phone", token: "fixture-token", epoch: 7)

    override func setUpWithError() throws {
        root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        journal = try SharedJournal(root: root)
        try journal.bindSyncUser(session, endpoint: "https://fixture.invalid")
    }
    override func tearDownWithError() throws { try FileManager.default.removeItem(at: root) }

    private func saveRecord(in journal: SharedJournal) throws -> CapturedRecord {
        let ticket = try journal.ticket()
        let record = CapturedRecord(id: ticket.id, epoch: ticket.epoch, kind: .translation,
            source: "workhorse", result: "主力", explanation: "test fixture")
        XCTAssertTrue(try journal.enqueue(record, ticket: ticket))
        return record
    }

    private static func receipt(_ request: URLRequest) throws -> (Data, URLResponse) {
        let body = try JSONSerialization.jsonObject(with: request.httpBody!) as! [String: Any]
        let operations = body["operations"] as! [[String: Any]]
        let data = try JSONSerialization.data(withJSONObject: ["accepted": operations.map { $0["op_id"] as! String }])
        return (data, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
    }

    func testExtensionUploadsWithoutOpeningMainAppAndKeepsLocalRecord() async throws {
        let record = try saveRecord(in: journal)
        let complete = try await journal.syncPending { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                XCTAssertEqual(request.url?.path, "/v2/sync/push")
                XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer fixture-token")
                let body = try JSONSerialization.jsonObject(with: request.httpBody!) as! [String: Any]
                XCTAssertEqual(body["epoch"] as? Int, 7, "Use server epoch, not the local journal epoch")
                let op = (body["operations"] as! [[String: Any]])[0]
                XCTAssertEqual(op["entity_id"] as? String, record.id.uuidString.lowercased())
                let capture = op["capture"] as! [String: Any]
                XCTAssertEqual(capture["source_app"] as? String, "iOS 系统翻译")
                return try Self.receipt(request)
            })
        }
        XCTAssertTrue(complete)
        XCTAssertEqual(try journal.state().pendingSync?.count, 0)
        try journal.consume { XCTAssertEqual($0.records.map(\.id), [record.id]) }
    }

    func testFailedUploadSurvivesLocalImportAndRestartWithSameOperationID() async throws {
        _ = try saveRecord(in: journal)
        let operationID = try XCTUnwrap(journal.state().pendingSync?.first?.opId)
        do {
            try await journal.syncPending { endpoint, token in
                SyncClient(endpoint: endpoint, token: token, transport: { _ in throw URLError(.notConnectedToInternet) })
            }
            XCTFail("Offline request must stay pending")
        } catch { }
        try journal.consume { XCTAssertEqual($0.records.count, 1) }
        let reopened = try SharedJournal(root: root)
        XCTAssertEqual(try reopened.state().pendingSync?.first?.opId, operationID)
        try await reopened.syncPending { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { try Self.receipt($0) })
        }
        XCTAssertTrue(try XCTUnwrap(reopened.state().pendingSync).isEmpty)
    }

    func testUndoDuringPutIsSentAfterPutAndDoesNotResurrectRecord() async throws {
        let journal = try XCTUnwrap(journal)
        let record = try saveRecord(in: journal)
        let deleted = expectation(description: "Delete acknowledged")
        try await journal.syncPending { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                let body = try JSONSerialization.jsonObject(with: request.httpBody!) as! [String: Any]
                let op = (body["operations"] as! [[String: Any]])[0]
                if op["action"] as? String == "capture.put" { try journal.remove(record.id) }
                else { XCTAssertEqual(op["action"] as? String, "capture.delete"); deleted.fulfill() }
                return try Self.receipt(request)
            })
        }
        await fulfillment(of: [deleted], timeout: 1)
        XCTAssertTrue(try XCTUnwrap(journal.state().pendingSync).isEmpty)
        try journal.consume { XCTAssertTrue($0.records.isEmpty); XCTAssertTrue($0.state.tombstones.contains(record.id)) }
    }

    func testRemoteDeletionDoesNotEchoNewOperations() throws {
        let id = UUID()
        try journal.remove(id, enqueueSync: false)
        XCTAssertTrue((try journal.state().pendingSync ?? []).isEmpty)
        XCTAssertTrue(try journal.state().tombstones.contains(id))
    }

    func testStaleServerEpochRejectsUploadUntilMainAppRefreshes() async throws {
        _ = try saveRecord(in: journal)
        do {
            try await journal.syncPending { endpoint, token in
                SyncClient(endpoint: endpoint, token: token, transport: { request in
                    (Data(), HTTPURLResponse(url: request.url!, statusCode: 409, httpVersion: nil, headerFields: nil)!)
                })
            }
            XCTFail("Stale epoch must not be reported as synced")
        } catch { XCTAssertEqual((error as? SyncHTTPError)?.status, 409) }
        XCTAssertEqual(try journal.state().pendingSync?.count, 1)
        try journal.clear()
        var next = session; next.epoch = 8
        try journal.bindSyncUser(next, endpoint: "https://fixture.invalid")
        XCTAssertTrue((try journal.state().pendingSync ?? []).isEmpty)
        try journal.consume { XCTAssertTrue($0.records.isEmpty) }
    }

    func testAccountSwitchDuringUploadDoesNotAcknowledgeNewAccountQueue() async throws {
        let journal = try XCTUnwrap(journal)
        _ = try saveRecord(in: journal)
        let next = DeviceSession(userId: "other-user", deviceId: "other", token: "other-token", epoch: 2)
        let complete = try await journal.syncPending { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                try journal.bindSyncUser(next, endpoint: "https://other.invalid")
                let ticket = try journal.ticket()
                let record = CapturedRecord(id: ticket.id, epoch: ticket.epoch, kind: .translation,
                    source: "new account", result: "新账号", explanation: "fixture")
                XCTAssertTrue(try journal.enqueue(record, ticket: ticket))
                return try Self.receipt(request)
            })
        }
        XCTAssertFalse(complete)
        XCTAssertEqual(try journal.state().pendingSync?.count, 1)
        XCTAssertEqual(try journal.state().pendingSync?.first?.capture?.source, "new account")
    }
}
