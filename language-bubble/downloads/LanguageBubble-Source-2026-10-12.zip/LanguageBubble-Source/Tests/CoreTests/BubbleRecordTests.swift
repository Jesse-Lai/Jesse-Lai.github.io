import XCTest
@testable import ContextCore

final class BubbleRecordTests: XCTestCase {
    @MainActor
    func testLearningLanguageFiltersOriginalTextAndPersistsWithoutDeletingRecords() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let english = BubbleCapture(source: "resilient", result: "有韧性的", explanation: "",
            sourceLanguage: "en-US", targetLanguage: "zh")
        let chinese = BubbleCapture(source: "但这些都还只是demo", result: "But these are all still just demos.", explanation: "",
            sourceLanguage: "zh-Hans", targetLanguage: "en")
        let frame = BubbleCapture(source: "Frame", result: "帧", explanation: "", sourceLanguage: "nl", targetLanguage: "zh")
        let french = BubbleCapture(source: "bonjour", result: "你好", explanation: "", sourceLanguage: "fr", targetLanguage: "zh")
        var state = BubbleLocalState()
        state.captures = Dictionary(uniqueKeysWithValues: [english, chinese, frame, french].map { ($0.id, $0) })
        state.dictionaries = ["zh:frame": WordDictionaryEntry(word: "frame", phonetic: "", language: "zh",
            groups: [WordDictionaryGroup(pos: "n.", meanings: ["框", "帧"])], source: "ECDICT", url: "", license: "MIT")]
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        XCTAssertEqual(store.learningLanguage, "en")
        XCTAssertEqual(Set(store.learningRecords.map(\.latest.id)), [english.id, frame.id])
        store.learningLanguage = "zh"
        XCTAssertEqual(store.learningRecords.map(\.latest.id), [chinese.id])
        XCTAssertNotNil(store.record(BubbleRecord.key(for: english)), "Filtering must not break detail access or remove history")
        store.learningLanguage = "ja"
        XCTAssertTrue(store.learningRecords.isEmpty)
        store.learningLanguage = "fr"
        let reopened = try BubbleStore(root: root)
        XCTAssertEqual(reopened.learningLanguage, "fr")
        XCTAssertEqual(reopened.learningRecords.map(\.latest.id), [french.id])
        XCTAssertEqual(reopened.captures.count, 4)
        XCTAssertTrue(reopened.state.outbox.isEmpty, "The list filter must not change translation preferences")
    }

    @MainActor
    func testLearningLanguageDefaultsToExistingProfileAndSupportsLegacyState() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        var state = BubbleLocalState()
        var profile = StudyProfile()
        profile.secondaryLanguage = "ja"
        state.profile = profile
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        XCTAssertEqual(store.learningLanguage, "ja")
        store.learningLanguage = "unsupported"
        XCTAssertEqual(store.learningLanguage, "ja")
        store.learningLanguage = "en"
        XCTAssertEqual(try BubbleStore(root: root).learningLanguage, "en")
        XCTAssertEqual(store.state.profile, profile)
    }

    func testLegacyLanguageDetectionUsesSourceInsteadOfTranslation() {
        for source in ["文章-拼贴画海报", "但这些都还只是demo"] {
            let capture = BubbleCapture(source: source, result: "English translation", explanation: "")
            XCTAssertEqual(LanguageRouting.recordLanguage(capture, dictionary: nil), "zh")
        }
        let english = BubbleCapture(source: "A resilient team learns from setbacks and keeps moving forward.", result: "中文译文", explanation: "")
        XCTAssertEqual(LanguageRouting.recordLanguage(english, dictionary: nil), "en")
        let unknown = BubbleCapture(source: "123", result: "English translation", explanation: "", sourceLanguage: "und")
        XCTAssertNil(LanguageRouting.recordLanguage(unknown, dictionary: nil))
        let mixedOCR = BubbleCapture(source: "没有响应自动点击，需要你手动完成这一步：在\n#**J#/Users/example/Desktop/Language\n/Language Bubble.app\n自认：",
            result: "中文说明", explanation: "", sourceLanguage: "en")
        XCTAssertEqual(LanguageRouting.recordLanguage(mixedOCR, dictionary: nil), "zh")
    }

    func testDictionaryAndContextDecodeFromTranslationAndSurviveCaptureRoundTrip() throws {
        let response = try JSONDecoder().decode(TranslationResult.self, from: Data(#"{"translation":"画框","explanation":"","dictionary":{"word":"frame","phonetic":"","language":"zh","groups":[{"pos":"n.","meanings":["框","帧"]},{"pos":"vt.","meanings":["设计"]}],"source":"ECDICT","url":"https://github.com/skywind3000/ECDICT","license":"MIT"},"context_meaning":{"pos":"n.","meaning":"画框","explanation":"Figma 中的容器"}}"#.utf8))
        let capture = BubbleCapture(source: "Frame", result: response.translation, explanation: response.explanation,
            dictionary: response.dictionary, contextMeaning: response.contextMeaning)
        let data = try BubbleCodec.encoder.encode(capture)
        XCTAssertEqual(try BubbleCodec.decoder.decode(BubbleCapture.self, from: data), capture)
        XCTAssertEqual(capture.dictionary?.groups.map(\.pos), ["n.", "vt."])
        XCTAssertEqual(capture.contextMeaning?.meaning, "画框")
        var legacy = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        legacy.removeValue(forKey: "dictionary"); legacy.removeValue(forKey: "context_meaning")
        let old = try BubbleCodec.decoder.decode(BubbleCapture.self, from: JSONSerialization.data(withJSONObject: legacy))
        XCTAssertNil(old.dictionary)
        XCTAssertNil(old.contextMeaning)
    }

    func testTextOnlyEncountersKeepTheirOwnContextMeaning() throws {
        let first = BubbleCapture(source: "frame", result: "画框", explanation: "", surroundingText: "Frame 3",
            contextMeaning: WordContextMeaning(pos: "n.", meaning: "设计画框", explanation: "Figma"))
        let second = BubbleCapture(source: "frame", result: "帧", explanation: "", surroundingText: "the next video frame",
            contextMeaning: WordContextMeaning(pos: "n.", meaning: "视频帧", explanation: "一幅画面"))
        let record = try XCTUnwrap(BubbleRecord.grouped([first, second]).first)
        XCTAssertEqual(record.sources.count, 2)
        XCTAssertEqual(Set(record.sources.compactMap { $0.contextMeaning?.meaning }), ["设计画框", "视频帧"])
    }

    @MainActor
    func testOldRecordDictionaryIsCachedAcrossRestartWithoutRewritingCapture() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let capture = BubbleCapture(source: "Frame", result: "帧", explanation: "旧解释")
        var state = BubbleLocalState()
        state.captures[capture.id] = capture
        state.endpoint = "https://fixture.invalid"
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                XCTAssertEqual(request.url?.path, "/v1/dictionary")
                let data = Data(#"{"status":"found","entry":{"word":"frame","phonetic":"","language":"zh","groups":[{"pos":"n.","meanings":["框","帧"]},{"pos":"vt.","meanings":["设计"]}],"source":"ECDICT","url":"https://github.com/skywind3000/ECDICT","license":"MIT"}}"#.utf8)
                return (data, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
            })
        }
        let record = try XCTUnwrap(store.records.first)
        _ = try await store.loadDictionary(for: record)
        let reopened = try BubbleStore(root: root)
        XCTAssertEqual(reopened.dictionary(for: record)?.groups.count, 2)
        XCTAssertEqual(reopened.captures, [capture])
        XCTAssertTrue(reopened.state.outbox.isEmpty)
    }

    @MainActor
    func testLegacyContextBackfillCachesSenseWithoutCreatingAnotherCapture() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let capture = BubbleCapture(source: "Frame", result: "帧", explanation: "旧解释", sourceApp: "Figma", surroundingText: "Frame 3")
        var state = BubbleLocalState()
        state.captures[capture.id] = capture
        state.endpoint = "https://fixture.invalid"
        state.session = DeviceSession(userId: "fixture", deviceId: "fixture", token: "test-only", epoch: 0)
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [ContextSenseProtocol.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        store.aiFactory = { AIClient(preferences: $0, session: session) }
        try await store.loadContextMeaning(for: capture)
        let reopened = try BubbleStore(root: root)
        XCTAssertEqual(reopened.contextMeaning(for: capture)?.meaning, "设计画框")
        XCTAssertEqual(reopened.captures, [capture])
        XCTAssertTrue(reopened.state.outbox.isEmpty)
    }

    func testSourceLinksKeepPathQueryAndFragmentAndRejectNonWebSources() {
        let address = "https://example.com/read?chapter=2&language=en#word"
        XCTAssertEqual(CaptureSourceLink.url(" \(address)\n")?.absoluteString, address)
        XCTAssertEqual(CaptureSourceLink.url(NSURL(string: address))?.absoluteString, address)
        for invalid in ["", "   ", "example.com", "https:///", "file:///private/image.png", "javascript:alert(1)"] {
            XCTAssertNil(CaptureSourceLink.url(invalid), invalid)
        }
    }

    func testRepeatedWordKeepsEverySourceUnderLatestMeaning() throws {
        let old = BubbleCapture(id: "old", source: "resilient", result: "有弹性的", explanation: "old",
                                createdAt: 1, sourceApp: "Chrome", sourceUrl: "https://example.com/one",
                                surroundingText: "A resilient team", assetIds: ["scene-one"])
        let new = BubbleCapture(id: "new", source: "  RESILIENT\n", result: "有韧性的", explanation: "new",
                                createdAt: 3, sourceApp: "Safari", sourceUrl: "https://example.com/two",
                                assetIds: ["scene-two"])
        let other = BubbleCapture(id: "other", source: "clarity", result: "清晰", explanation: "", createdAt: 2)
        let records = BubbleRecord.grouped([old, other, new])
        XCTAssertEqual(records.count, 2)
        let word = try XCTUnwrap(records.first)
        XCTAssertEqual(word.latest, new)
        XCTAssertEqual(word.encounters, [new, old])
        XCTAssertEqual(word.id, BubbleRecord.grouped([old]).first?.id)
        XCTAssertTrue(word.matches("有弹性的"), "Search must retain older contextual meanings")
        XCTAssertFalse(word.matches("unrelated"))
    }

    func testNormalizationKeepsAccentsAndPunctuationDistinct() {
        let terms = ["café", "cafe\u{301}", "cafe", "hello!", "hello", "work  in\nprogress", "work in progress"]
        let records = BubbleRecord.grouped(terms.map { BubbleCapture(source: $0, result: "", explanation: "") })
        XCTAssertEqual(records.count, 5)
    }

    func testLookupsWithoutProvenanceDoNotHideSavedSources() throws {
        let lookup = BubbleCapture(id: "lookup", source: "word", result: "词", explanation: "", createdAt: 3)
        let linked = BubbleCapture(id: "linked", source: "word", result: "词", explanation: "", createdAt: 2,
                                   sourceUrl: "https://example.com/source")
        let pictured = BubbleCapture(id: "pictured", source: "word", result: "词", explanation: "", createdAt: 1,
                                     assetIds: ["scene"])
        let record = try XCTUnwrap(BubbleRecord.grouped([pictured, lookup, linked]).first)
        XCTAssertEqual(record.encounters.count, 3)
        XCTAssertEqual(record.sources.map(\.id), [linked.id, pictured.id])
        XCTAssertEqual(BubbleRecord.grouped([lookup]).first?.sources.map(\.id), [lookup.id])
    }

    func testWritingAndMockCapturesDoNotOverwriteRealTranslation() {
        let real = BubbleCapture(source: "word", result: "词", explanation: "")
        var mock = real; mock.id = "mock"; mock.isMock = true
        var writing = real; writing.id = "writing"; writing.kind = "writing"
        var secondWriting = writing; secondWriting.id = "second-writing"
        XCTAssertEqual(BubbleRecord.grouped([real, mock, writing, secondWriting]).count, 4)
    }

    func testEqualTimestampsAndInputOrderProduceStableResults() {
        let a = BubbleCapture(id: "a", source: "word", result: "a", explanation: "", createdAt: 1)
        let b = BubbleCapture(id: "b", source: "WORD", result: "b", explanation: "", createdAt: 1)
        XCTAssertEqual(BubbleRecord.grouped([b, a]).first?.encounters.map(\.id), ["a", "b"])
        XCTAssertEqual(BubbleRecord.grouped([a, b]).first?.latest.id, "a")
        XCTAssertTrue(BubbleRecord.grouped([]).isEmpty)
    }
}

private final class ContextSenseProtocol: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(#"{"translation":"画框","explanation":"","context_meaning":{"pos":"n.","meaning":"设计画框","explanation":"Figma 中的容器"}}"#.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
