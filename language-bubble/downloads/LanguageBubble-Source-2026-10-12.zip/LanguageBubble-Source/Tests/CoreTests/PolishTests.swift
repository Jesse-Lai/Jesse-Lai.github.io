import Foundation
import XCTest
@testable import ContextCore

final class PolishTests: XCTestCase {
    private func session() -> URLSession {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [PolishProtocol.self]
        return URLSession(configuration: config)
    }

    func testExplicitPolishIgnoresAutomaticCheckingAndTranslationLanguage() async throws {
        let session = session()
        defer { session.invalidateAndCancel() }
        var preferences = CapturePreferences()
        preferences.serviceURL = "https://polish.invalid"
        preferences.serviceToken = "test-only"
        preferences.primaryLanguage = "zh"
        let value = try await AIClient(preferences: preferences, session: session)
            .polish("She go to school everyday.", id: UUID(), context: "My sister is a student.", sourceApp: "Notes")
        XCTAssertEqual(value.polished, "She goes to school every day.")
        XCTAssertFalse(preferences.automaticChecking)
    }

    func testEmptyPolishResultIsRejected() async throws {
        let session = session()
        defer { session.invalidateAndCancel() }
        var preferences = CapturePreferences()
        preferences.serviceURL = "https://empty.invalid"
        preferences.serviceToken = "test-only"
        do {
            _ = try await AIClient(preferences: preferences, session: session).polish("recieve", id: UUID())
            XCTFail("Blank output must not replace or save the selected text")
        } catch ContextError.invalidResponse {}
    }

    @MainActor
    func testPolishReturnsTemporaryResultWithoutRecordsImagesOrSync() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let session = session()
        defer { session.invalidateAndCancel() }
        let store = try makeStore(root: root, session: session)
        let before = try Data(contentsOf: root.appendingPathComponent("state.json"))
        store.clientFactory = { _, _ in
            XCTFail("Temporary polish must not initiate record sync")
            return SyncClient(endpoint: "https://unused.invalid", token: "test-only")
        }
        await store.query("She go to school everyday.", polishing: true, context: "My sister is a student.", sourceApp: "Notes",
                          image: Data("unused screenshot".utf8))
        let capture = try XCTUnwrap(store.latest)
        XCTAssertEqual(capture.kind, "writing")
        XCTAssertEqual(capture.category, "polish")
        XCTAssertEqual(capture.result, "She goes to school every day.")
        XCTAssertNil(capture.originalSpan, "A full passage must not exceed the legacy correction span limit")
        XCTAssertEqual(capture.sourceLanguage, capture.targetLanguage)
        XCTAssertEqual(capture.surroundingText, "My sister is a student.")
        XCTAssertEqual(capture.sourceApp, "Notes")
        XCTAssertNil(store.error)
        XCTAssertTrue(store.state.captures.isEmpty)
        XCTAssertTrue(store.state.outbox.isEmpty)
        XCTAssertTrue(store.state.images.isEmpty)
        XCTAssertTrue(store.records.isEmpty)
        XCTAssertEqual(try Data(contentsOf: root.appendingPathComponent("state.json")), before)
        XCTAssertEqual(try FileManager.default.contentsOfDirectory(atPath: root.path), ["state.json"])
        let reopened = try BubbleStore(root: root)
        XCTAssertTrue(reopened.state.captures.isEmpty)
        XCTAssertNil(reopened.latest)
    }

    @MainActor
    func testPolishCancellationStopsTransportAndDoesNotSave() async throws {
        let started = expectation(description: "Polish started")
        PolishProtocol.started = { started.fulfill() }
        defer { PolishProtocol.started = nil }
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let session = session()
        defer { session.invalidateAndCancel() }
        let store = try makeStore(root: root, session: session, host: "pending")
        let task = Task { await store.query("recieve", polishing: true) }
        await fulfillment(of: [started], timeout: 2)
        store.cancelQuery()
        await task.value
        XCTAssertFalse(store.querying)
        XCTAssertNil(store.latest)
        XCTAssertNil(store.error)
        XCTAssertTrue(store.state.outbox.isEmpty)
        XCTAssertTrue(try BubbleStore(root: root).state.captures.isEmpty)
    }

    @MainActor
    private func makeStore(root: URL, session: URLSession, host: String = "polish") throws -> BubbleStore {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        var state = BubbleLocalState()
        state.endpoint = "https://\(host).invalid"
        state.session = DeviceSession(userId: "fixture", deviceId: "fixture", token: "test-only", epoch: 0)
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        store.aiFactory = { AIClient(preferences: $0, session: session) }
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { _ in throw URLError(.notConnectedToInternet) })
        }
        return store
    }
}

private final class PolishProtocol: URLProtocol {
    static var started: (() -> Void)?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        XCTAssertEqual(request.url?.path, "/v1/polish")
        XCTAssertEqual(request.httpMethod, "POST")
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-only")
        var data = request.httpBody ?? Data()
        if let stream = request.httpBodyStream {
            stream.open()
            defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count <= 0 { break }
                data.append(contentsOf: buffer.prefix(count))
            }
        }
        let payload = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        XCTAssertNotNil(payload?["request_id"])
        XCTAssertNil(payload?["target_language"], "Polishing must not follow translation routing")
        if request.url?.host == "polish.invalid" {
            XCTAssertEqual(payload?["surrounding_text"] as? String, "My sister is a student.")
            XCTAssertEqual(payload?["source_app"] as? String, "Notes")
        }
        if request.url?.host == "pending.invalid" { Self.started?(); return }
        let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!
        let value = request.url?.host == "empty.invalid" ? "   " : "She goes to school every day."
        let body = try! JSONSerialization.data(withJSONObject: ["polished": value, "explanation": "修正主谓一致和拼写。"])
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: body)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
