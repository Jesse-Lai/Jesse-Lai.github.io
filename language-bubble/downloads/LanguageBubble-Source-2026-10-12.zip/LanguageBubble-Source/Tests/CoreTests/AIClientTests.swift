import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
import XCTest
@testable import ContextCore

final class AIClientTests: XCTestCase {
    @MainActor
    func testSourceLinkAndOriginalScreenshotSurviveRestartAndSyncRetry() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [TranslationProtocol.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let otherRoot = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: otherRoot, withIntermediateDirectories: true)
        defer {
            try? FileManager.default.removeItem(at: root)
            try? FileManager.default.removeItem(at: otherRoot)
        }
        var initial = BubbleLocalState()
        initial.endpoint = "https://context.invalid"
        initial.session = DeviceSession(userId: "fixture", deviceId: "fixture", token: "test-token", epoch: 0)
        for folder in [root, otherRoot] {
            try BubbleCodec.encoder.encode(initial).write(to: folder.appendingPathComponent("state.json"))
        }
        let store = try BubbleStore(root: root)
        store.aiFactory = { AIClient(preferences: $0, session: session) }
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { _ in throw URLError(.notConnectedToInternet) })
        }
        let sourceURL = "https://example.com/article?chapter=2#products"
        let fixture = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
            .appendingPathComponent("Fixtures/scene-products.png")
        let original = try Data(contentsOf: fixture)
        await store.query("products", context: "We build products for curious people.", sourceApp: "Chrome",
                          sourceUrl: sourceURL, image: original)
        let capture = try XCTUnwrap(store.latest)
        let assetID = try XCTUnwrap(capture.assetIds.first)
        XCTAssertEqual(capture.sourceUrl, sourceURL)
        XCTAssertEqual(store.state.images.count, 1, "Failed upload must stay queued")
        let reopened = try BubbleStore(root: root)
        XCTAssertEqual(reopened.records.first?.sources.first?.sourceUrl, sourceURL)
        let localImage = try await reopened.asset(assetID)
        XCTAssertEqual(localImage, original)
        let captureJSON = try JSONSerialization.jsonObject(with: BubbleCodec.encoder.encode(capture))
        let syncState = SourceSyncFixtureState()
        let connected: (String, String) -> SyncClient = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                let path = request.url!.path
                var object: [String: Any]
                if path == "/health" { object = ["status": "ok", "ai_mode": "live"] }
                else if path.hasPrefix("/v2/assets/") {
                    if request.httpMethod == "PUT" {
                        XCTAssertEqual(request.httpBody, original)
                        await syncState.markUploaded()
                        object = ["id": assetID, "sha256": "fixture-checksum"]
                    } else {
                        return (original, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
                    }
                } else if path.hasSuffix("/push") {
                    let uploaded = await syncState.uploaded
                    XCTAssertTrue(uploaded, "The capture must never sync before its original screenshot")
                    let body = try JSONSerialization.jsonObject(with: request.httpBody!) as! [String: Any]
                    let operations = body["operations"] as! [[String: Any]]
                    let sent = try XCTUnwrap(operations.first?["capture"] as? [String: Any])
                    XCTAssertEqual(sent["source_url"] as? String, sourceURL)
                    XCTAssertEqual(sent["asset_ids"] as? [String], [assetID])
                    await syncState.markPushed()
                    object = ["accepted": operations.map { $0["op_id"] as! String }]
                } else if path.hasSuffix("/pull") {
                    let pushed = await syncState.pushed
                    object = ["epoch": 0, "cursor": pushed ? 1 : 0, "has_more": false,
                              "changes": pushed ? [["seq": 1, "kind": "capture", "id": capture.id,
                                                     "deleted": false, "data": captureJSON]] : []]
                } else { object = ["articles": []] }
                return (try JSONSerialization.data(withJSONObject: object),
                        HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
            })
        }
        reopened.clientFactory = connected
        await reopened.sync()
        XCTAssertNil(reopened.error)
        XCTAssertTrue(reopened.state.images.isEmpty)
        XCTAssertTrue(reopened.state.outbox.isEmpty)
        let otherDevice = try BubbleStore(root: otherRoot)
        otherDevice.clientFactory = connected
        await otherDevice.sync()
        XCTAssertEqual(otherDevice.records.first?.sources.first?.sourceUrl, sourceURL)
        let downloaded = try await otherDevice.asset(assetID)
        XCTAssertEqual(downloaded, original)
        let offlineRestart = try BubbleStore(root: otherRoot)
        let cached = try await offlineRestart.asset(assetID)
        XCTAssertEqual(cached, original)
    }

    func testMockMarkerAndOlderResponsesDecode() throws {
        let decoder = JSONDecoder()
        let mock = try decoder.decode(TranslationResult.self,
            from: Data(#"{"translation":"测试","explanation":"AI Mock","is_mock":true}"#.utf8))
        XCTAssertEqual(mock.isMock, true)
        let older = try decoder.decode(TranslationResult.self,
            from: Data(#"{"translation":"测试","explanation":"解释"}"#.utf8))
        XCTAssertNil(older.isMock)
        let check = try decoder.decode(CheckResult.self,
            from: Data(#"{"complete":false,"issues":[],"is_mock":true}"#.utf8))
        XCTAssertEqual(check.isMock, true)
        XCTAssertNil(check.actionable(in: "An unlisted sentence."))
    }

    func testExplicitTranslationWorksWithDefaultCollectionSettings() async throws {
        var preferences = CapturePreferences()
        preferences.serviceURL = "https://context.invalid"
        preferences.serviceToken = "test-token"
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [TranslationProtocol.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }

        let result = try await AIClient(preferences: preferences, session: session)
            .translate("products", id: UUID())
        XCTAssertEqual(result.translation, "产品")
        XCTAssertFalse(preferences.automaticChecking)
        XCTAssertFalse(preferences.saveTranslations)
    }

    func testAutomaticCheckingRemainsOffByDefault() async throws {
        do {
            _ = try await AIClient(preferences: CapturePreferences()).check("I am agree.", id: UUID())
            XCTFail("Automatic checking must remain paused until enabled")
        } catch ContextError.automaticCheckingDisabled {
            // Rejected before service configuration or any network request.
        }
    }

    func testStreamDeliversPartialTextAndRequiresMatchingTerminalResult() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [TranslationStreamProtocol.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        var preferences = CapturePreferences()
        preferences.serviceToken = "test-only"
        for fixture in ["complete", "interrupted", "mismatch"] {
            preferences.serviceURL = "https://\(fixture).invalid"
            let partial = PartialTextCollector()
            do {
                let result = try await AIClient(preferences: preferences, session: session)
                    .streamTranslate("products", id: UUID(), context: nil, targetLanguage: "zh") { await partial.append($0) }
                XCTAssertEqual(fixture, "complete", "Incomplete or inconsistent results must throw")
                XCTAssertEqual(result.translation, "产品")
            } catch { XCTAssertNotEqual(fixture, "complete") }
            let delivered = await partial.values
            XCTAssertEqual(delivered, ["产", "产品"])
        }
    }

    @MainActor
    func testLiveTranslationCancellationStopsRequestWithoutSaving() async throws {
        let started = expectation(description: "Live translation request started")
        LiveCancellationProtocol.started = { started.fulfill() }
        defer { LiveCancellationProtocol.started = nil }
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [LiveCancellationProtocol.self]
        config.timeoutIntervalForResource = 3
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        var state = BubbleLocalState()
        state.endpoint = "https://live-fixture.invalid"
        state.session = DeviceSession(userId: "fixture", deviceId: "fixture", token: "test-only", epoch: 0)
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        store.aiMode = "live"
        store.aiFactory = { AIClient(preferences: $0, session: session) }
        let query = Task { await store.query("products") }
        await fulfillment(of: [started], timeout: 2)
        store.cancelQuery()
        await query.value
        XCTAssertFalse(store.querying)
        XCTAssertNil(store.error)
        XCTAssertNil(store.latest)
        XCTAssertTrue(store.state.outbox.isEmpty)
        XCTAssertTrue(try BubbleStore(root: root).state.captures.isEmpty)
    }

    @MainActor
    func testAutomaticLookupTaskCancellationStopsRequestWithoutSaving() async throws {
        let started = expectation(description: "Live translation request started")
        LiveCancellationProtocol.started = { started.fulfill() }
        defer { LiveCancellationProtocol.started = nil }
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [LiveCancellationProtocol.self]
        config.timeoutIntervalForResource = 3
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        var state = BubbleLocalState()
        state.endpoint = "https://live-fixture.invalid"
        state.session = DeviceSession(userId: "fixture", deviceId: "fixture", token: "test-only", epoch: 0)
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        store.aiMode = "live"
        store.aiFactory = { AIClient(preferences: $0, session: session) }
        let query = Task { await store.query("products") }
        await fulfillment(of: [started], timeout: 2)
        query.cancel()
        await query.value
        XCTAssertFalse(store.querying)
        XCTAssertNil(store.error)
        XCTAssertNil(store.latest)
        XCTAssertTrue(store.state.outbox.isEmpty)
        XCTAssertTrue(try BubbleStore(root: root).state.captures.isEmpty)
    }

    @MainActor
    func testCancelledOrInterruptedQueryDoesNotPersistPartialCapture() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [TranslationStreamProtocol.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        for cancel in [true, false] {
            let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
            try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
            defer { try? FileManager.default.removeItem(at: root) }
            var state = BubbleLocalState()
            state.endpoint = "https://interrupted.invalid"
            state.session = DeviceSession(userId: "fixture", deviceId: "fixture", token: "test-only", epoch: 0)
            try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
            let store = try BubbleStore(root: root)
            store.aiMode = "mock"
            store.aiFactory = { AIClient(preferences: $0, session: session) }
            var partialSeen = false
            await store.query("products") { _ in
                partialSeen = true
                if cancel { store.cancelQuery() }
            }
            XCTAssertTrue(partialSeen)
            XCTAssertFalse(store.querying)
            XCTAssertNil(store.latest)
            XCTAssertTrue(store.state.captures.isEmpty)
            XCTAssertTrue(store.state.outbox.isEmpty)
            let reopened = try BubbleStore(root: root)
            XCTAssertTrue(reopened.state.captures.isEmpty)
        }
    }
}

private actor SourceSyncFixtureState {
    private(set) var uploaded = false
    private(set) var pushed = false
    func markUploaded() { uploaded = true }
    func markPushed() { pushed = true }
}

private final class LiveCancellationProtocol: URLProtocol {
    static var started: (() -> Void)?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        XCTAssertEqual(request.url?.path, "/v1/translate")
        Self.started?()
        // Hold the transport open; cancellation must finish the app query without a response body.
    }
    override func stopLoading() {}
}

private actor PartialTextCollector {
    var values: [String] = []
    func append(_ value: String) { values.append(value) }
}

private final class TranslationStreamProtocol: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        XCTAssertEqual(request.url?.path, "/v1/translate/stream")
        let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type": "application/x-ndjson"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        var lines = [#"{"delta":"产"}"#, #"{"delta":"品"}"#]
        if request.url?.host == "complete.invalid" { lines.append(#"{"result":{"translation":"产品","explanation":"AI Mock","is_mock":true}}"#) }
        if request.url?.host == "mismatch.invalid" { lines.append(#"{"result":{"translation":"different","explanation":"AI Mock","is_mock":true}}"#) }
        client?.urlProtocol(self, didLoad: Data((lines.joined(separator: "\n") + "\n").utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

private final class TranslationProtocol: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        XCTAssertEqual(request.url?.path, "/v1/translate")
        XCTAssertEqual(request.httpMethod, "POST")
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-token")
        let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(#"{"translation":"产品","explanation":"复数"}"#.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

final class LocalEndpointTests: XCTestCase {
    func testDebugLANAndHTTPSOnly() {
        for address in ["http://127.0.0.1:8788", "http://jesse-mac.local:8788", "http://192.168.1.8:8788", "http://10.0.0.8:8788", "http://172.16.2.3:8788", "https://example.com"] {
            XCTAssertTrue(ServiceEndpoint.allowed(URL(string: address)!))
        }
        for address in ["http://example.com", "http://8.8.8.8", "http://172.32.1.2", "http://192.168.999.1", "http://user:secret@192.168.1.8", "https://example.com?secret=x", "http://mac.local.evil.invalid"] {
            XCTAssertFalse(ServiceEndpoint.allowed(URL(string: address)!))
        }
    }
}
