import XCTest
@testable import ContextCore

@MainActor
final class ArticleStoreTests: XCTestCase {
    private func article(_ captureID: String, revision: Int = 0) -> LearningArticle {
        LearningArticle(id: "article-one", title: "Teamwork", summary: "Practice from your reading", theme: "Work",
            language: "en", generatedAt: 100, generationId: "request-one", captureIds: [captureID],
            sections: [.init(heading: "A resilient team", text: "A resilient team learns from setbacks.",
                translation: "有韧性的团队会从挫折中学习。", captureIds: [captureID], question: "What does the team learn from?", answer: "Setbacks.")],
            expressions: [.init(text: "resilient", meaning: "有韧性的", captureId: captureID)],
            messages: [.init(id: "question", role: "user", text: "Explain resilient.")], revision: revision)
    }

    private func makeStore(_ state: BubbleLocalState) throws -> (BubbleStore, URL) {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try BubbleCodec.encoder.encode(state).write(to: root.appendingPathComponent("state.json"))
        let store = try BubbleStore(root: root)
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { _ in throw URLError(.notConnectedToInternet) })
        }
        return (store, root)
    }

    func testLegacyStateAndArticleConversationRoundTrip() throws {
        let legacy = try BubbleCodec.decoder.decode(BubbleLocalState.self, from: BubbleCodec.encoder.encode(BubbleLocalState()))
        XCTAssertNil(legacy.articles)
        let value = article("capture")
        XCTAssertEqual(try BubbleCodec.decoder.decode(LearningArticle.self, from: BubbleCodec.encoder.encode(value)), value)
        XCTAssertNil(value.wordCount)
    }

    func testVocabularyCountsUseReviewHistoryDeduplicateAndExcludePausedOrMock() throws {
        let new = BubbleCapture(source: "new", result: "新", explanation: "")
        let known = BubbleCapture(source: "known", result: "熟悉", explanation: "")
        let duplicate = BubbleCapture(source: "known", result: "熟悉", explanation: "")
        let forgotten = BubbleCapture(source: "forgotten", result: "忘记", explanation: "")
        let partial = BubbleCapture(source: "partial", result: "部分", explanation: "")
        let paused = BubbleCapture(source: "paused", result: "暂停", explanation: "")
        let mock = BubbleCapture(source: "mock", result: "样例", explanation: "", isMock: true)
        func item(_ capture: BubbleCapture, successes: Int, reviews: Int, paused: Bool = false) -> LearningItem {
            LearningItem(id: capture.id, term: capture.source, meaning: capture.result, explanation: "",
                captureIds: [capture.id], example: capture.source, exampleSource: "captured", isMock: false,
                state: "learning", successes: successes, reviews: reviews, dueAt: 0, intervalDays: 0, paused: paused)
        }
        var mastered = item(known, successes: 3, reviews: 5)
        mastered.captureIds.append(duplicate.id)
        var state = BubbleLocalState()
        for c in [new, known, duplicate, forgotten, partial, paused, mock] { state.captures[c.id] = c }
        for i in [mastered, item(forgotten, successes: 0, reviews: 2), item(partial, successes: 1, reviews: 2),
                  item(paused, successes: 3, reviews: 4, paused: true)] { state.learning[i.id] = i }
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        XCTAssertEqual(store.articleVocabularyCounts, [.mastered: 1, .unfamiliar: 2, .notRemembered: 1])
    }

    func testOfflineSourceDeletionRemovesDerivedArticleAndChatFromDisk() async throws {
        let capture = BubbleCapture(source: "resilient", result: "有韧性的", explanation: "fixture")
        var state = BubbleLocalState()
        state.captures = [capture.id: capture]; state.articles = ["article-one": article(capture.id)]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        XCTAssertEqual(store.articles.count, 1)
        let deleted = await store.deleteRecord(BubbleRecord.key(for: capture))
        XCTAssertTrue(deleted)
        XCTAssertTrue(store.articles.isEmpty)
        XCTAssertTrue(try BubbleStore(root: root).state.articles?.isEmpty == true)
    }

    func testRefreshPreservesNewerConversationAndDropsDeletedArticles() async throws {
        let capture = BubbleCapture(source: "resilient", result: "有韧性的", explanation: "fixture")
        var state = BubbleLocalState()
        state.session = DeviceSession(userId: "user", deviceId: "mac", token: "test-only", epoch: 0)
        state.captures = [capture.id: capture]; state.articles = ["article-one": article(capture.id, revision: 2)]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        let oldBody = try BubbleCodec.encoder.encode(ArticleCollection(articles: [article(capture.id, revision: 1)]))
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                (oldBody, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
            })
        }
        await store.refreshArticles()
        XCTAssertEqual(store.articles.first?.revision, 2)
        let emptyBody = try BubbleCodec.encoder.encode(ArticleCollection(articles: []))
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                (emptyBody, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
            })
        }
        await store.refreshArticles()
        XCTAssertTrue(store.articles.isEmpty)
        XCTAssertTrue(try BubbleStore(root: root).articles.isEmpty)
    }

    func testLateRefreshDoesNotDropNewlyGeneratedArticle() async throws {
        let capture = BubbleCapture(source: "resilient", result: "有韧性的", explanation: "fixture")
        var state = BubbleLocalState()
        state.session = DeviceSession(userId: "user", deviceId: "mac", token: "test-only", epoch: 0)
        state.captures = [capture.id: capture]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        let generatedBody = try BubbleCodec.encoder.encode(ArticleCollection(articles: [article(capture.id)]))
        let gate = ArticleRefreshGate()
        let started = expectation(description: "Old article list is in flight")
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                let body: Data
                switch request.url!.path {
                case "/health": body = Data(#"{"status":"ok","ai_mode":"live"}"#.utf8)
                case "/v2/sync/pull": body = Data(#"{"epoch":0,"cursor":0,"has_more":false,"changes":[]}"#.utf8)
                case "/v2/articles":
                    await gate.suspendFirst { started.fulfill() }
                    body = Data(#"{"articles":[]}"#.utf8)
                case "/v2/articles/generate":
                    let preferences = try JSONSerialization.jsonObject(with: request.httpBody!) as! [String: Any]
                    XCTAssertEqual(preferences["topic"] as? String, "自然科学")
                    XCTAssertEqual(preferences["word_count"] as? Int, 800)
                    XCTAssertEqual(preferences["vocabulary_levels"] as? [String], ["not_remembered"])
                    XCTAssertEqual(preferences["capture_ids"] as? [String], [])
                    XCTAssertEqual(preferences["saved_word_scope"] as? String, "half")
                    XCTAssertEqual(preferences["instructions"] as? String, "Explain with a simple ocean example.")
                    body = generatedBody
                default: throw URLError(.unsupportedURL)
                }
                return (body, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
            })
        }
        let refresh = Task { await store.refreshArticles() }
        await fulfillment(of: [started], timeout: 2)
        await store.generateArticles(topic: "自然科学", wordCount: 800, vocabularyLevels: [.notRemembered],
            savedWordScope: .half, instructions: "Explain with a simple ocean example.", requestID: "request-one")
        XCTAssertNil(store.articleError)
        XCTAssertEqual(store.articles.count, 1)
        await gate.resume()
        await refresh.value
        XCTAssertEqual(store.articles.count, 1)
        XCTAssertEqual(try BubbleStore(root: root).articles.count, 1)
    }

    func testRetryingGenerationDoesNotOverwriteNewerChat() async throws {
        let capture = BubbleCapture(source: "resilient", result: "有韧性的", explanation: "fixture")
        var state = BubbleLocalState()
        state.session = DeviceSession(userId: "user", deviceId: "mac", token: "test-only", epoch: 0)
        state.captures = [capture.id: capture]
        state.articles = ["article-one": article(capture.id, revision: 3)]
        let (store, root) = try makeStore(state)
        defer { try? FileManager.default.removeItem(at: root) }
        let body = try BubbleCodec.encoder.encode(ArticleCollection(articles: [article(capture.id, revision: 0)]))
        store.clientFactory = { endpoint, token in
            SyncClient(endpoint: endpoint, token: token, transport: { request in
                guard request.url!.path == "/v2/articles/generate" else { throw URLError(.notConnectedToInternet) }
                return (body, HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: nil)!)
            })
        }
        await store.generateArticles(topic: "", captureIDs: [capture.id], requestID: "request-one")
        XCTAssertNil(store.articleError)
        XCTAssertEqual(store.articles.first?.revision, 3)
    }
}

private actor ArticleRefreshGate {
    private var first = true
    private var continuation: CheckedContinuation<Void, Never>?

    func suspendFirst(onStart: @Sendable () -> Void) async {
        guard first else { return }
        first = false
        await withCheckedContinuation { continuation in
            self.continuation = continuation
            onStart()
        }
    }

    func resume() { continuation?.resume(); continuation = nil }
}
