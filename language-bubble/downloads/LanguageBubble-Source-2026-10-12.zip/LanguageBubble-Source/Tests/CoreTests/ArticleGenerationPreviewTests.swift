import XCTest
@testable import ContextCore

@MainActor
final class ArticleGenerationPreviewTests: XCTestCase {
    private func preview(texts: [String] = ["Notice the light with your camera. 👩🏽‍🎨", "Make a deliberate change. 比较结果。"],
                         initiallyComplete: Bool = false) -> ArticleGenerationPreview {
        let sections = texts.enumerated().map { index, text in
            LearningArticle.Section(heading: "Section \(index)", text: text, translation: "", captureIds: [], question: "", answer: "")
        }
        let article = LearningArticle(id: "demo", title: "Photography", summary: "A demo", theme: "Photography",
            language: "en", generatedAt: 0, generationId: "demo", captureIds: [], sections: sections,
            expressions: [], messages: [], revision: 0)
        return ArticleGenerationPreview(article: article, request: "Create an article", imageAsset: "", imageCaption: "",
            initiallyComplete: initiallyComplete)
    }

    func testFinishedLessonOpensWithAllContentWithoutRunningGeneration() async {
        let model = preview(initiallyComplete: true)
        XCTAssertTrue(model.opensAsFinishedArticle)
        XCTAssertTrue(model.isComplete && model.outlineVisible && model.imagesReady && model.researchReady)
        XCTAssertTrue(model.showsArticleText && model.showsImages && model.showsArtifact && model.artifactReady)
        XCTAssertFalse(model.showsArticleOutline)
        XCTAssertFalse(model.isGenerating || model.isAwaitingOutlineConfirmation || model.isRunning)
        XCTAssertFalse(model.isThinkingExpanded)
        XCTAssertEqual(model.progress, 1)
        XCTAssertEqual(model.visibleCharacters, model.totalCharacters)
        for index in model.article.sections.indices { XCTAssertEqual(model.text(at: index), model.article.sections[index].text) }
        let messages = model.messages
        await model.run { _ in XCTFail("Opening an already finished lesson must not start generation") }
        XCTAssertEqual(model.thinkingSeconds, 0)
        XCTAssertEqual(model.messages, messages)
        XCTAssertTrue(model.canEditLocally)
    }

    func testFinishedLessonSupportsQuotedEditsAndLaterRegeneration() async {
        let model = preview(initiallyComplete: true)
        let original = model.article.sections[0].text
        let selection = ArticleGenerationPreview.LocalSelection(target: .paragraph(section: 0, paragraph: 0),
            original: original, range: (original as NSString).range(of: "camera"))
        XCTAssertTrue(model.quoteSelection(selection))
        XCTAssertTrue(model.regenerateQuotedSelection(comment: "Replace camera with phone"))
        await model.run { _ in }
        XCTAssertTrue(model.article.sections[0].text.contains("phone"))
        let edited = model.article
        XCTAssertTrue(model.regenerate(from: .images, instruction: "换成树林配图"))
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.article.sections, edited.sections)
        XCTAssertEqual(model.imageAsset, "ArticleLeadingLinesOaks")
    }

    func testFinishedLessonUsesItsOwnPractice() {
        var article = preview().article
        article.theme = "Space"
        let practice = ArticleGenerationPreview.Practice(question: "What is an orbit?",
            choices: ["A curved path", "An atmosphere"], answer: 0, explanation: "The Moon orbits Earth.")
        let model = ArticleGenerationPreview(article: article, request: "Space", imageAsset: "", imageCaption: "",
            initiallyComplete: true, practice: practice)
        XCTAssertFalse(model.messages.last?.text.contains(practice.question) == true)
        XCTAssertFalse(model.messages.last?.text.contains("摄影") == true)
        XCTAssertFalse(model.messages.last?.text.contains("82") == true)
        model.reply(to: ArticleGenerationPreview.quizSuggestion)
        XCTAssertTrue(model.messages.last?.text.contains(practice.question) == true)
        XCTAssertFalse(model.messages.last?.text.contains("resilient") == true)
        model.reply(to: "What is an orbit?\nA. A curved path")
        XCTAssertEqual(model.messages.last?.text, "答对了！The Moon orbits Earth.")
    }

    /// Existing flow tests make an explicit user choice after running the outline.
    private func runConfirmingOutline(_ model: ArticleGenerationPreview,
        delay: @MainActor (Duration) async throws -> Void) async {
        await model.run(delay: delay)
        if model.isAwaitingOutlineConfirmation {
            XCTAssertTrue(model.confirmOutline())
            await model.run(delay: delay)
        }
    }

    func testContentAppearsInOutlineTextImageArtifactOrder() async {
        let model = preview()
        XCTAssertFalse(model.showsArticleOutline || model.showsArticleText || model.showsImages || model.showsArtifact)
        await model.run { _ in }
        XCTAssertTrue(model.isAwaitingOutlineConfirmation && model.showsArticleOutline)
        XCTAssertFalse(model.showsArticleText || model.showsImages || model.showsArtifact)

        XCTAssertTrue(model.confirmOutline())
        XCTAssertEqual(model.step, .research)
        XCTAssertTrue(model.showsArticleOutline, "Keep the outline on screen while gathering sources")
        XCTAssertFalse(model.showsArticleText || model.showsImages || model.showsArtifact)
        await model.run { _ in if model.step == .writing { throw CancellationError() } }
        XCTAssertFalse(model.showsArticleOutline)
        XCTAssertTrue(model.showsArticleText && model.showsSection(at: 0))
        XCTAssertFalse(model.showsSection(at: 1), "Do not insert unwritten sections in the reading pane")
        XCTAssertFalse(model.showsImages || model.showsArtifact || model.imagesReady || model.artifactReady)

        await model.run { _ in if !model.text(at: 1).isEmpty { throw CancellationError() } }
        XCTAssertEqual(model.step, .writing)
        XCTAssertTrue(model.showsSection(at: 0) && model.showsSection(at: 1))
        XCTAssertFalse(model.showsImages || model.showsArtifact)
        await model.run { _ in if model.step == .images { throw CancellationError() } }
        XCTAssertEqual(model.visibleCharacters, model.totalCharacters)
        XCTAssertTrue(model.showsArticleText && model.showsImages)
        XCTAssertFalse(model.imagesReady || model.showsArtifact || model.artifactReady)

        await model.run { _ in if model.step == .artifact { throw CancellationError() } }
        XCTAssertTrue(model.showsImages && model.imagesReady && model.showsArtifact)
        XCTAssertFalse(model.artifactReady, "The interactive view waits for Artifact generation to finish")
        await model.run { _ in }
        XCTAssertTrue(model.isComplete && model.artifactReady)
        XCTAssertFalse(model.showsSection(at: -1) || model.showsSection(at: model.article.sections.count))
    }

    func testRegenerationAndPauseHideOutputsFromLaterStages() async {
        for stage in [ArticleGenerationPreview.Step.writing, .images, .artifact] {
            let model = preview(initiallyComplete: true)
            XCTAssertTrue(model.regenerate(from: stage, instruction: "再生成一次"))
            XCTAssertTrue(model.artifactReady, "Keep the outgoing content for its discard animation")
            await model.run { _ in if !model.isRewinding { throw CancellationError() } }
            XCTAssertEqual(model.step, stage)
            model.stop()
            XCTAssertTrue(model.isStopped && model.showsArticleText)
            XCTAssertEqual(model.showsImages, stage.rawValue >= ArticleGenerationPreview.Step.images.rawValue)
            XCTAssertEqual(model.imagesReady, stage == .artifact)
            XCTAssertEqual(model.showsArtifact, stage == .artifact)
            XCTAssertFalse(model.artifactReady)
            await model.run { _ in XCTFail("Pausing must not expose a later output") }
            model.resume()
            await model.run { _ in }
            XCTAssertTrue(model.isComplete && model.imagesReady && model.artifactReady)
        }
    }

    func testThinkingTimePausesAcrossNavigationStopAndApproval() async {
        let model = preview()
        XCTAssertEqual(model.thinkingSeconds, 0)
        model.isThinkingExpanded = false
        await model.run { _ in
            if model.thinkingSeconds == 1 { throw CancellationError() }
        }
        XCTAssertEqual(model.thinkingSeconds, 1)
        model.stop()
        await model.run { _ in XCTFail("Stopped work must not run the clock") }
        XCTAssertEqual(model.thinkingSeconds, 1)
        model.resume()
        await model.run { _ in }
        XCTAssertEqual(model.thinkingSeconds, 3)
        XCTAssertTrue(model.isAwaitingOutlineConfirmation)
        await model.run { _ in XCTFail("Approval wait must not run the clock") }
        XCTAssertTrue(model.reviseOutline("Replace camera with DSLR camera"))
        XCTAssertEqual(model.thinkingSeconds, 3)
        XCTAssertTrue(model.confirmOutline())
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.thinkingSeconds, 19)
        await model.run { _ in XCTFail("Completed work must not run the clock") }
        XCTAssertEqual(model.thinkingSeconds, 19)
        XCTAssertFalse(model.isThinkingExpanded, "Disclosure preference survives every stage and navigation")
    }

    func testThinkingTimeRestartsOnlyAfterRegenerationDiscardCommits() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        XCTAssertEqual(model.thinkingSeconds, 19)
        XCTAssertTrue(model.regenerate(from: .images, instruction: "换成人像配图"))
        var sawNewAttempt = false
        await model.run { _ in
            if model.isRewinding {
                XCTAssertEqual(model.thinkingSeconds, 19, "The outgoing plan retains its time during the discard animation")
            } else if !sawNewAttempt {
                sawNewAttempt = true
                XCTAssertEqual(model.thinkingSeconds, 0)
            }
        }
        XCTAssertTrue(sawNewAttempt)
        XCTAssertEqual(model.thinkingSeconds, 10, "Only the image and practice stages run again")
    }

    func testThinkingCollapsesOnCompletionAndCanBeReopened() async {
        let model = preview()
        XCTAssertTrue(model.isThinkingExpanded)
        await model.run { _ in }
        XCTAssertTrue(model.isAwaitingOutlineConfirmation)
        XCTAssertTrue(model.isThinkingExpanded, "Waiting for approval is not completion")
        XCTAssertTrue(model.confirmOutline())
        await model.run { _ in
            if model.step == .images { throw CancellationError() }
        }
        model.stop()
        XCTAssertTrue(model.isThinkingExpanded, "Pause retains the current disclosure state")
        model.resume()
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertFalse(model.isThinkingExpanded)
        model.isThinkingExpanded = true
        await model.run { _ in XCTFail("Reopening the steps must not restart generation") }
        XCTAssertTrue(model.isThinkingExpanded, "Completed steps can still be inspected manually")
        model.isThinkingExpanded = false
        XCTAssertTrue(model.regenerate(from: .images, instruction: "换成树林配图"))
        var sawExpandedRun = false
        await model.run { _ in
            if !model.isRewinding {
                sawExpandedRun = true
                XCTAssertTrue(model.isThinkingExpanded, "A new attempt opens its active steps")
            }
        }
        XCTAssertTrue(sawExpandedRun)
        XCTAssertFalse(model.isThinkingExpanded, "The regenerated attempt also folds when complete")
    }

    func testRevisedPlanAutomaticallyCollapsesWhenComplete() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in
            if model.step == .images { throw CancellationError() }
        }
        XCTAssertTrue(model.isThinkingExpanded)
        model.steer("教我一些照相机的部件知识")
        await model.run { _ in }
        XCTAssertNotNil(model.latestPlanMessageID)
        XCTAssertTrue(model.isComplete)
        XCTAssertFalse(model.isThinkingExpanded)
    }

    func testAssistantDefaultsToChineseWhileKeepingEnglishLearningContent() async {
        let model = preview(texts: ["Notice the light with your camera."])
        let article = model.article
        await runConfirmingOutline(model) { _ in }
        XCTAssertEqual(model.article.sections, article.sections)
        let blocks = ArticleReplyBlock.parse(model.messages.last!.text)
        XCTAssertEqual(blocks, [.paragraph("现在已经使用之前收集的82个语料，帮你生成了一篇摄影教程，读读看有什么收获？如果想换另一种方式学习，尽管和我说！")])
        XCTAssertEqual(model.suggestions, ["出几道题考考我", "让文章的生词更少一些"])
        XCTAssertEqual(model.completionMessageID, model.messages.last?.id)
        model.reply(to: "Hello")
        XCTAssertEqual(model.messages.last?.text, ArticleGenerationPreview.completionFollowUp)
        model.reply(to: model.article.sections[0].heading)
        XCTAssertTrue(model.messages.last!.text.hasPrefix("这节对应的英文原文是："))
        XCTAssertTrue(model.messages.last!.text.contains(article.sections[0].text))
        model.reply(to: "Question\nA. Recovers from difficulties")
        XCTAssertEqual(model.messages.last?.text, "答对了！resilient 表示有韧性，能够从困难或挫折中恢复。")
    }

    func testRevisedPlanKeepsAccumulatingThinkingTimeAndDisclosurePreference() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in
            if model.step == .images { throw CancellationError() }
        }
        XCTAssertEqual(model.thinkingSeconds, 9)
        model.isThinkingExpanded = false
        model.steer("教我一些照相机的部件知识")
        var previousSeconds = model.thinkingSeconds
        await model.run { _ in
            XCTAssertGreaterThanOrEqual(model.thinkingSeconds, previousSeconds)
            previousSeconds = model.thinkingSeconds
        }
        XCTAssertNotNil(model.latestPlanMessageID)
        XCTAssertEqual(model.thinkingSeconds, 26, "Includes 650 ms submission, 4 s plan review, and 13 s remaining work")
        XCTAssertFalse(model.isThinkingExpanded, "Moving the progress list to a revised plan must not reopen it")
    }

    func testQuotedComposerTargetsTheQuotedOccurrenceAfterSelectionChanges() async {
        let model = preview(texts: ["A camera. Another camera.\n\nKeep this camera."])
        await runConfirmingOutline(model) { _ in }
        let target = ArticleGenerationPreview.LocalTarget.paragraph(section: 0, paragraph: 0)
        let text = model.localContent(target)!
        let quoted = ArticleGenerationPreview.LocalSelection(target: target, original: text,
            range: (text as NSString).range(of: "camera", options: .backwards))
        let other = ArticleGenerationPreview.LocalSelection(target: target, original: text,
            range: (text as NSString).range(of: "camera"))
        model.localSelection = quoted
        let before = model.messages.count
        XCTAssertTrue(model.quoteSelection(quoted))
        XCTAssertEqual(model.quotedSelection, quoted)
        XCTAssertNil(model.localSelection)
        XCTAssertNil(model.localEdit)
        XCTAssertEqual(model.messages.count, before, "Quoting only attaches context; it does not send")
        model.localSelection = other
        XCTAssertTrue(model.regenerateQuotedSelection(comment: "Replace camera with phone"))
        XCTAssertEqual(model.localEdit?.selection, quoted)
        XCTAssertNil(model.quotedSelection)
        await model.run { _ in }
        XCTAssertEqual(model.article.sections[0].text, "A camera. Another phone.\n\nKeep this camera.")
    }

    func testQuoteRemovalReplacementAndValidation() async {
        let model = preview(texts: ["👩🏽‍🎨 café 相机。 Keep this."])
        await runConfirmingOutline(model) { _ in }
        let target = ArticleGenerationPreview.LocalTarget.paragraph(section: 0, paragraph: 0)
        let text = model.localContent(target)!
        let first = ArticleGenerationPreview.LocalSelection(target: target, original: text,
            range: (text as NSString).range(of: "café 相机"))
        let second = ArticleGenerationPreview.LocalSelection(target: target, original: text,
            range: (text as NSString).range(of: "Keep this."))
        XCTAssertTrue(model.quoteSelection(first))
        XCTAssertFalse(model.quoteSelection(.init(target: target, original: text, range: NSRange(location: 1, length: 1))))
        XCTAssertEqual(model.quotedSelection, first)
        XCTAssertFalse(model.regenerateQuotedSelection(comment: "  \n "))
        XCTAssertFalse(model.regenerateQuotedSelection(comment: String(repeating: "x", count: 2001)))
        XCTAssertEqual(model.quotedSelection, first)
        XCTAssertTrue(model.quoteSelection(second))
        XCTAssertEqual(model.quotedSelection, second)
        model.removeQuote()
        XCTAssertNil(model.quotedSelection)
        XCTAssertFalse(model.regenerateQuotedSelection(comment: "改为：Nothing"))
        XCTAssertTrue(model.quoteSelection(first))
        XCTAssertTrue(model.regenerateSelection(first, comment: "改为：相机 📷"))
        await model.run { _ in }
        XCTAssertFalse(model.regenerateQuotedSelection(comment: "改为：Stale"))
        XCTAssertEqual(model.quotedSelection, first, "A rejected send must retain its reference")
        XCTAssertEqual(model.article.sections[0].text, "👩🏽‍🎨 相机 📷。 Keep this.")
    }

    func testImageQuoteUsesExistingLocalGenerationAndCancellation() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        let original = model.imageAsset
        let quote = ArticleGenerationPreview.LocalSelection(target: .image, original: original,
            range: NSRange(location: 0, length: 0))
        XCTAssertTrue(model.quoteSelection(quote))
        XCTAssertTrue(model.regenerateQuotedSelection(comment: "换成树林配图"))
        XCTAssertEqual(model.localEdit?.imageAsset, original)
        XCTAssertNil(model.quotedSelection)
        await model.run { _ in model.cancelLocalEdit() }
        XCTAssertEqual(model.imageAsset, original)
        XCTAssertNil(model.localEdit)
        XCTAssertTrue(model.quoteSelection(quote))
    }

    func testLocalEditReplacesOnlyTheSelectedOccurrenceAndKeepsConversation() async {
        let model = preview(texts: ["A camera. Another camera.\n\nKeep this camera.", "A camera elsewhere."])
        await runConfirmingOutline(model) { _ in }
        let original = model.article
        let history = model.messages
        let target = ArticleGenerationPreview.LocalTarget.paragraph(section: 0, paragraph: 0)
        let text = model.localContent(target)!
        let selection = ArticleGenerationPreview.LocalSelection(target: target, original: text,
            range: (text as NSString).range(of: "camera", options: .backwards))
        XCTAssertTrue(model.regenerateSelection(selection, comment: "Replace camera with phone"))
        let edit = model.localEdit!
        XCTAssertEqual(model.article, original, "Keep the original until the shimmer finishes")
        XCTAssertEqual(Array(model.messages.prefix(history.count)), history)
        XCTAssertEqual(model.localEditComments[edit.id]?.selection.quote, "camera")
        XCTAssertFalse(model.regenerateSelection(selection, comment: "Replace camera with DSLR camera"))
        XCTAssertFalse(model.regenerate(from: .images, instruction: "换成人像配图"))
        await model.run { duration in
            XCTAssertEqual(duration, .seconds(3))
            XCTAssertEqual(model.article, original)
            XCTAssertNotNil(model.localEdit)
        }
        XCTAssertEqual(model.article.sections[0].text, "A camera. Another phone.\n\nKeep this camera.")
        XCTAssertEqual(model.article.sections[1], original.sections[1])
        XCTAssertEqual(model.article.title, original.title)
        XCTAssertEqual(model.outline.map(\.heading), original.sections.map(\.heading))
        XCTAssertNil(model.localEdit)
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.text(at: 0), model.article.sections[0].text)
        XCTAssertEqual(model.article.revision, original.revision + 1)
    }

    func testLocalEditsHandleUTF16RangesAndRejectStaleSelections() async {
        let model = preview(texts: ["👩🏽‍🎨 café 相机。 Keep this."])
        await runConfirmingOutline(model) { _ in }
        let target = ArticleGenerationPreview.LocalTarget.paragraph(section: 0, paragraph: 0)
        let text = model.localContent(target)!
        let selection = ArticleGenerationPreview.LocalSelection(target: target, original: text,
            range: (text as NSString).range(of: "café 相机"))
        XCTAssertTrue(model.regenerateSelection(selection, comment: "改为：新的相机 📷"))
        await model.run { _ in }
        XCTAssertEqual(model.article.sections[0].text, "👩🏽‍🎨 新的相机 📷。 Keep this.")
        XCTAssertFalse(model.regenerateSelection(selection, comment: "改为：stale"))
        XCTAssertFalse(model.regenerateSelection(.init(target: target, original: model.localContent(target)!,
            range: NSRange(location: 1, length: 1)), comment: "改为：bad emoji"))
    }

    func testLocalEditCancellationAndNavigationCannotPublishStaleContent() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        let original = model.article
        let selection = ArticleGenerationPreview.LocalSelection(target: .title, original: original.title,
            range: NSRange(location: 0, length: (original.title as NSString).length))
        XCTAssertTrue(model.regenerateSelection(selection, comment: "改为：New title"))
        await model.run { _ in throw CancellationError() }
        XCTAssertNotNil(model.localEdit, "Navigation pauses the pending edit")
        XCTAssertEqual(model.article, original)
        await model.run { _ in model.cancelLocalEdit() }
        XCTAssertNil(model.localEdit)
        XCTAssertEqual(model.article, original)
        XCTAssertTrue(model.regenerateSelection(selection, comment: "改为：Better title"))
        await model.run { _ in }
        XCTAssertEqual(model.article.title, "Better title")
        XCTAssertEqual(model.article.sections, original.sections)
    }

    func testLocalImageEditKeepsBodyAndQuizAndStoresOriginalThumbnail() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        model.quizSelection = 1
        let original = model.article
        let practice = model.practice
        let image = model.imageAsset
        XCTAssertTrue(model.regenerateSelection(.init(target: .image, original: image,
            range: NSRange(location: 0, length: 0)), comment: "换成树林配图"))
        let commentID = model.localEdit!.id
        XCTAssertEqual(model.localImageProgress, 0)
        var elapsed: Duration = .zero
        await model.run { tick in
            if elapsed >= .milliseconds(1500) { throw CancellationError() }
            elapsed += tick
            XCTAssertEqual(model.imageAsset, image)
        }
        XCTAssertEqual(model.localImageProgress!, 0.3, accuracy: 0.001)
        XCTAssertNotNil(model.localEdit, "Leaving the reader preserves image progress")
        await model.run { tick in
            elapsed += tick
            XCTAssertEqual(model.imageAsset, image)
        }
        XCTAssertEqual(elapsed, ArticleGenerationPreview.Step.images.duration)
        XCTAssertNil(model.localImageProgress)
        XCTAssertEqual(model.imageAsset, "ArticleLeadingLinesOaks")
        XCTAssertEqual(model.localEditComments[commentID]?.imageAsset, image)
        XCTAssertEqual(model.article.sections, original.sections)
        XCTAssertEqual(model.practice, practice)
        XCTAssertEqual(model.quizSelection, 1)
        XCTAssertEqual(model.messages.last?.text, "配图已更新。")
        XCTAssertTrue(model.regenerateSelection(.init(target: .image, original: model.imageAsset,
            range: NSRange(location: 0, length: 0)), comment: "换成人像配图"))
        await model.run { _ in model.cancelLocalEdit() }
        XCTAssertEqual(model.imageAsset, "ArticleLeadingLinesOaks")
        XCTAssertNil(model.localImageProgress)
    }

    func testLocalEditValidationAndUnsupportedInstructionsKeepTheOriginal() async {
        let model = preview()
        let text = model.article.title
        let selection = ArticleGenerationPreview.LocalSelection(target: .title, original: text,
            range: NSRange(location: 0, length: (text as NSString).length))
        XCTAssertFalse(model.regenerateSelection(selection, comment: "改为：New title"))
        await runConfirmingOutline(model) { _ in }
        let original = model.article
        for comment in [" \n ", String(repeating: "x", count: 2001)] {
            XCTAssertFalse(model.regenerateSelection(selection, comment: comment))
        }
        XCTAssertFalse(model.regenerateSelection(.init(target: .title, original: text,
            range: NSRange(location: 0, length: 0)), comment: "改为：New title"))
        XCTAssertFalse(model.regenerateSelection(.init(target: .title, original: text,
            range: NSRange(location: 500, length: 10)), comment: "改为：New title"))
        XCTAssertTrue(model.regenerateSelection(selection, comment: "Explain quantum mechanics"))
        await model.run { _ in }
        XCTAssertEqual(model.article, original)
        XCTAssertNil(model.localEdit)
        XCTAssertTrue(model.messages.last!.text.contains("原文已保留"))
        XCTAssertTrue(model.regenerateSelection(.init(target: .image, original: model.imageAsset,
            range: NSRange(location: 0, length: 0)), comment: "Draw a spaceship"))
        await model.run { _ in }
        XCTAssertEqual(model.imageAsset, "")
        XCTAssertTrue(model.messages.last!.text.contains("原图已保留"))
    }

    func testLocalChangesSurviveLaterStageReruns() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        let target = ArticleGenerationPreview.LocalTarget.paragraph(section: 0, paragraph: 0)
        let text = model.localContent(target)!
        XCTAssertTrue(model.regenerateSelection(.init(target: target, original: text,
            range: NSRange(location: 0, length: (text as NSString).length)), comment: "改为：A new paragraph."))
        await model.run { _ in }
        XCTAssertTrue(model.regenerate(from: .images, instruction: "换成人像配图"))
        await model.run { _ in }
        XCTAssertEqual(model.article.sections[0].text, "A new paragraph.")
        XCTAssertEqual(model.imageAsset, "ArticleLeadingLinesPortraitWall")
    }

    func testOutlineWaitsForAnExplicitChoiceAcrossReopeningAndResume() async {
        let model = preview()
        XCTAssertFalse(model.confirmOutline(), "A choice before the outline is ready must not skip it")
        var elapsed: Duration = .zero
        await model.run { elapsed += $0 }
        XCTAssertEqual(elapsed, .seconds(3))
        XCTAssertTrue(model.outlineVisible)
        XCTAssertTrue(model.isAwaitingOutlineConfirmation)
        XCTAssertFalse(model.isGenerating)
        XCTAssertFalse(model.isRunning)
        XCTAssertFalse(model.isStopped)
        XCTAssertEqual(model.step, .outline)
        XCTAssertEqual(model.progress, 0.2)
        XCTAssertEqual(model.visibleCharacters, 0)
        XCTAssertFalse(model.imagesReady)
        let promptID = model.outlineConfirmationMessageID
        model.stop()
        model.resume()
        await model.run { _ in XCTFail("Reopening or resuming must not bypass confirmation") }
        XCTAssertEqual(model.outlineConfirmationMessageID, promptID)
        XCTAssertEqual(model.messages.map(\.text), [ArticleGenerationPreview.outlineConfirmationPrompt])
        XCTAssertTrue(model.confirmOutline())
        XCTAssertFalse(model.confirmOutline(), "A double click must not duplicate the choice")
        XCTAssertFalse(model.isAwaitingOutlineConfirmation)
        XCTAssertTrue(model.isGenerating)
        XCTAssertEqual(model.step, .research)
        var durations: [ArticleGenerationPreview.Step: Duration] = [:]
        await model.run { durations[model.step, default: .zero] += $0 }
        XCTAssertEqual(durations, [.research: .seconds(3), .writing: .seconds(3), .images: .seconds(5), .artifact: .seconds(5)])
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.messages.filter { $0.text == ArticleGenerationPreview.directGenerationChoice }.count, 1)
    }

    func testSupplementalChoiceUpdatesOutlineBeforeAnyBodyIsGenerated() async {
        let model = preview()
        await model.run { _ in }
        let waitingRunID = model.runID
        XCTAssertFalse(model.confirmOutline(instruction: " \n "))
        XCTAssertFalse(model.confirmOutline(instruction: String(repeating: "x", count: 2001)))
        XCTAssertEqual(model.messages.count, 1)
        XCTAssertTrue(model.isAwaitingOutlineConfirmation)
        model.steer("把摄影机换成单反相机")
        XCTAssertTrue(model.isAwaitingOutlineConfirmation)
        XCTAssertEqual(model.runID, waitingRunID)
        XCTAssertEqual(model.step, .outline)
        XCTAssertFalse(model.isGenerating)
        XCTAssertTrue(model.outline[0].detail.contains("DSLR camera"))
        XCTAssertEqual(model.visibleCharacters, 0)
        XCTAssertTrue(model.article.sections[0].heading.contains("DSLR camera"))
        XCTAssertTrue(model.article.sections[0].text.contains("DSLR camera"))
        XCTAssertEqual(model.messages[1].text, "把摄影机换成单反相机")
        XCTAssertEqual(model.messages[1].role, "user")
        XCTAssertEqual(model.generationNotes[.outline], "把摄影机换成单反相机")
        await model.run { _ in XCTFail("A revision must still wait for Apply") }
        XCTAssertTrue(model.confirmOutline())
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        let confirmedOutline = model.article.sections.map(\.heading)
        let confirmedMessages = Array(model.messages.prefix(3))
        XCTAssertTrue(model.regenerate(from: .writing, instruction: "写短一点"))
        await model.run { _ in }
        XCTAssertTrue(model.isComplete, "A later step must retain the approved outline")
        XCTAssertFalse(model.isAwaitingOutlineConfirmation)
        XCTAssertEqual(model.article.sections.map(\.heading), confirmedOutline)
        XCTAssertEqual(Array(model.messages.prefix(3)), confirmedMessages)
    }

    func testUnsupportedSupplementIsAcknowledgedWithoutClaimingItWasApplied() async {
        let model = preview()
        let original = model.article
        await model.run { _ in }
        XCTAssertTrue(model.reviseOutline("Explain quantum mechanics"))
        XCTAssertEqual(model.article.sections, original.sections)
        XCTAssertEqual(model.article.title, original.title)
        XCTAssertEqual(model.messages[1].text, "Explain quantum mechanics")
        XCTAssertTrue(model.messages.last!.text.contains("暂不能自动应用"))
        XCTAssertEqual(model.step, .outline)
        XCTAssertTrue(model.isAwaitingOutlineConfirmation)
        XCTAssertTrue(model.confirmOutline())
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
    }

    func testRegeneratedOutlineRequiresANewChoiceAndDiscardsTheOldChoice() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        let oldMessageIDs = model.messages.map(\.id)
        XCTAssertTrue(model.regenerate(from: .outline, instruction: "把摄影机换成单反相机"))
        XCTAssertTrue(oldMessageIDs.allSatisfy(model.isDiscardingMessage))
        await model.run { _ in }
        XCTAssertTrue(model.isAwaitingOutlineConfirmation)
        XCTAssertFalse(model.isComplete)
        XCTAssertEqual(model.visibleCharacters, 0)
        XCTAssertTrue(Set(oldMessageIDs).isDisjoint(with: model.messages.map(\.id)))
        XCTAssertEqual(model.messages.filter { $0.text == ArticleGenerationPreview.outlineConfirmationPrompt }.count, 1)
        await model.run { _ in XCTFail("Regeneration must wait for the new choice") }
        XCTAssertTrue(model.confirmOutline())
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
    }

    func testStagesOnlyRevealTheirOwnResultsAndCompleteInOrder() async {
        let model = preview()
        XCTAssertFalse(model.outlineVisible)
        XCTAssertFalse(model.imagesReady)
        XCTAssertEqual(model.text(at: 0), "")
        var seen: [ArticleGenerationPreview.Step] = []
        var sawOutlineBeforeWriting = false
        await runConfirmingOutline(model) { _ in
            await MainActor.run {
                if seen.last != model.step { seen.append(model.step) }
                if model.outlineVisible && model.step == .outline {
                    sawOutlineBeforeWriting = true
                    XCTAssertEqual(model.visibleCharacters, 0)
                }
                if model.step == .images {
                    XCTAssertFalse(model.imagesReady)
                    XCTAssertEqual(model.visibleCharacters, model.totalCharacters)
                }
                if model.step == .artifact {
                    XCTAssertTrue(model.imagesReady)
                    XCTAssertFalse(model.isComplete)
                }
            }
        }
        XCTAssertEqual(seen, [.outline, .research, .writing, .images, .artifact])
        XCTAssertTrue(sawOutlineBeforeWriting)
        XCTAssertTrue(model.isComplete)
        XCTAssertFalse(model.isRunning)
        XCTAssertEqual(model.progress, 1)
        for index in model.article.sections.indices {
            XCTAssertEqual(model.text(at: index), model.article.sections[index].text)
        }
        await runConfirmingOutline(model) { _ in XCTFail("Completed generations must not restart") }
    }

    func testCancellationPausesAndReopeningResumesWithoutLosingText() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in
            let shouldCancel = await MainActor.run { model.visibleCharacters >= 5 }
            if shouldCancel { throw CancellationError() }
        }
        XCTAssertEqual(model.step, .writing)
        XCTAssertEqual(model.visibleCharacters, 5)
        XCTAssertFalse(model.isRunning)
        XCTAssertFalse(model.isComplete)
        XCTAssertFalse(model.imagesReady)
        let prefix = model.text(at: 0)
        await runConfirmingOutline(model) { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertTrue(model.text(at: 0).hasPrefix(prefix))
    }

    func testSuggestionsStayLocalAndQuizHasMeaningfulFeedback() async {
        let model = preview()
        model.reply(to: "Quiz me")
        XCTAssertTrue(model.messages.isEmpty)
        XCTAssertTrue(model.suggestions.isEmpty)
        await runConfirmingOutline(model) { _ in }
        XCTAssertEqual(ArticleReplyBlock.parse(model.messages.last!.text), [.paragraph(ArticleGenerationPreview.completionIntroduction)])
        let completionID = model.completionMessageID
        model.reply(to: model.suggestions[0])
        XCTAssertEqual(model.messages.count, 5)
        XCTAssertEqual(model.messages[3].text, "出几道题考考我")
        XCTAssertTrue(model.messages[4].text.contains("A. Recovers from difficulties"))
        XCTAssertTrue(model.messages[4].text.contains("D. Works independently"))
        XCTAssertTrue(model.suggestions.isEmpty, "Hide the starter prompts after the conversation continues")
        XCTAssertEqual(model.completionMessageID, completionID)
        model.reply(to: "Question\nA. Recovers from difficulties")
        XCTAssertTrue(model.messages.last!.text.hasPrefix("答对了！"))
        model.reply(to: "Question\nD. Works independently")
        XCTAssertTrue(model.messages.last!.text.contains("正确答案是 A"))
    }

    func testSimplifySuggestionRewritesBodyAndReturnsToCompletionWithoutQuiz() async {
        let model = preview(texts: ["Photographs show a familiar entrance on your journey. 👩🏽‍🎨",
                                    "Make a deliberate change. The shutter controls light. 比较结果。"])
        await runConfirmingOutline(model) { _ in }
        let original = model.article
        let outline = model.outline
        let oldCompletionID = model.completionMessageID
        model.reply(to: model.suggestions[1])
        XCTAssertTrue(model.isRewinding)
        XCTAssertTrue(model.suggestions.isEmpty)
        XCTAssertEqual(model.article, original, "Keep the prior content during the discard animation")
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertFalse(model.isThinkingExpanded)
        XCTAssertEqual(model.article.sections.map(\.text), [
            "Pictures show a well-known door on your journey. 👩🏽‍🎨",
            "Make a planned change. The shutter controls light. 比较结果。"
        ])
        XCTAssertEqual(model.article.title, original.title)
        XCTAssertEqual(model.article.summary, original.summary)
        XCTAssertEqual(model.article.sections.map(\.heading), original.sections.map(\.heading))
        XCTAssertEqual(model.outline, outline)
        XCTAssertEqual(model.messages.filter { $0.role == "user" && $0.text == "让文章的生词更少一些" }.count, 1)
        XCTAssertNotEqual(model.completionMessageID, oldCompletionID)
        XCTAssertEqual(model.messages.last?.id, model.completionMessageID)
        XCTAssertEqual(ArticleReplyBlock.parse(model.messages.last!.text), [.paragraph(ArticleGenerationPreview.completionIntroduction)])
        XCTAssertEqual(model.suggestions.count, 2)
    }

    func testEachStageUsesItsRequestedDurationRegardlessOfTextLength() async {
        let model = preview()
        var durations: [ArticleGenerationPreview.Step: Duration] = [:]
        await runConfirmingOutline(model) { duration in durations[model.step, default: .zero] += duration }
        XCTAssertEqual(durations, [.outline: .seconds(3), .research: .seconds(3), .writing: .seconds(3), .images: .seconds(5), .artifact: .seconds(5)])
        XCTAssertEqual(model.visibleCharacters, model.totalCharacters)
    }

    func testReadingAnchorFollowsStreamedSectionsAndImageProgressFreezesOnStop() async {
        let model = preview(texts: ["The first section.", "A second section with a camera."])
        var sections: [Int] = []
        await runConfirmingOutline(model) { _ in
            if let index = model.writingSectionIndex, sections.last != index { sections.append(index) }
            if model.step == .images, let fraction = model.imageProgress, fraction >= 0.3 { model.stop() }
        }
        XCTAssertEqual(sections, [0, 1])
        XCTAssertNil(model.writingSectionIndex)
        XCTAssertTrue(model.isStopped)
        let frozenProgress = model.imageProgress!
        XCTAssertGreaterThanOrEqual(frozenProgress, 0.3)
        XCTAssertLessThan(frozenProgress, 1)
        await model.run { _ in XCTFail("A stopped image must not advance") }
        XCTAssertEqual(model.imageProgress, frozenProgress)
        model.resume()
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertNil(model.imageProgress)
    }

    func testExplicitStopFreezesEveryStageAndDoesNotRestartOnReopen() async {
        for stage in ArticleGenerationPreview.Step.allCases {
            let model = preview()
            var frozenCharacters = 0
            await runConfirmingOutline(model) { _ in
                if model.step == stage {
                    frozenCharacters = model.visibleCharacters
                    model.stop()
                }
            }
            XCTAssertTrue(model.isStopped)
            XCTAssertFalse(model.isRunning)
            XCTAssertFalse(model.isComplete)
            XCTAssertEqual(model.step, stage)
            XCTAssertEqual(model.visibleCharacters, frozenCharacters)
            await runConfirmingOutline(model) { _ in XCTFail("Reopening must not override an explicit stop") }
            XCTAssertEqual(model.messages.filter { $0.text.hasPrefix("已暂停生成") }.count, 1)
            model.resume()
            await runConfirmingOutline(model) { _ in }
            XCTAssertTrue(model.isComplete)
            XCTAssertFalse(model.isStopped)
        }
    }

    func testChineseSteeringUpdatesOutlineAndRemainingTextWhileWriting() async {
        let model = preview()
        var revisedCount = 0
        await runConfirmingOutline(model) { _ in
            if model.step == .writing && model.visibleCharacters >= 5 {
                model.steer("把 摄影机换成单反相机")
                revisedCount = model.visibleCharacters
            }
        }
        XCTAssertFalse(model.isStopped)
        XCTAssertFalse(model.isComplete)
        XCTAssertEqual(model.visibleCharacters, revisedCount, "The invalidated run must not publish another tick")
        XCTAssertEqual(model.planAdjustmentPhase, .submitted)
        await model.run { _ in if model.isShowingRevisedOutline { throw CancellationError() } }
        XCTAssertEqual(model.visibleCharacters, 0)
        XCTAssertEqual(model.article.sections[0].heading, "Start with your DSLR camera")
        XCTAssertTrue(model.article.summary.contains("DSLR camera"))
        XCTAssertTrue(model.article.sections[0].text.contains("your DSLR camera"))
        XCTAssertTrue(model.imageCaption.contains("DSLR camera"))
        XCTAssertEqual(model.messages.last(where: { $0.role == "user" })?.text, "把 摄影机换成单反相机")
        XCTAssertTrue(model.messages.last!.text.hasPrefix("好的，已将"))
        await runConfirmingOutline(model) { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.text(at: 0), model.article.sections[0].text)
    }

    func testLateSteerRebuildsPendingAssetsAndResumesStoppedGeneration() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in if model.step == .artifact { model.stop() } }
        XCTAssertTrue(model.imagesReady)
        model.steer("Replace camera with DSLR camera")
        XCTAssertFalse(model.isStopped)
        await model.run { _ in if model.isShowingRevisedOutline { throw CancellationError() } }
        XCTAssertEqual(model.step, .writing)
        XCTAssertFalse(model.imagesReady)
        XCTAssertEqual(model.visibleCharacters, 0)
        await runConfirmingOutline(model) { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertTrue(model.imagesReady)
        XCTAssertTrue(model.article.sections[0].text.contains("DSLR camera"))
    }

    func testOldRunCannotPublishAfterStopAndResumeOrDuplicateCompletion() async {
        let model = preview()
        var interleaved = false
        await runConfirmingOutline(model) { _ in
            if !interleaved && model.step == .writing {
                interleaved = true
                model.stop()
                model.resume()
                await runConfirmingOutline(model) { _ in }
            }
        }
        XCTAssertTrue(model.isComplete)
        XCTAssertFalse(model.isRunning)
        XCTAssertEqual(model.messages.filter { $0.text.hasPrefix(ArticleGenerationPreview.completionIntroduction) }.count, 1)
    }

    func testReplacementIsIdempotentAndUnsupportedSteeringKeepsContents() {
        let model = preview()
        model.steer("Replace camera with DSLR camera")
        let updated = model.article
        model.steer("Replace camera with DSLR camera")
        XCTAssertEqual(model.article, updated)
        XCTAssertFalse(model.article.sections[0].text.contains("DSLR DSLR"))
        model.steer("Explain quantum mechanics")
        XCTAssertEqual(model.article, updated)
        XCTAssertTrue(model.messages.last!.text.hasPrefix("当前本地演示"))
    }

    func testShorterSteeringActuallyReducesTheArticle() {
        let model = preview(texts: ["Notice the light. Move your camera. Compare the result. Take another picture.",
                                    "Make one deliberate change. Keep the subject. Look at the background. Repeat the experiment."])
        let originalLength = model.totalCharacters
        model.steer("写短一点")
        XCTAssertLessThan(model.totalCharacters, originalLength)
        XCTAssertFalse(model.article.sections[0].text.contains("Take another picture"))
        XCTAssertTrue(model.messages.last!.text.hasPrefix("好的，我精简"))
        XCTAssertEqual(model.article.sections.count, 2)
        XCTAssertTrue(model.article.sections.allSatisfy { $0.text.hasSuffix(".") })
    }


    func testRegenerationKeepsStrictlyEarlierOutputsForEveryCheckpoint() async {
        for selected in ArticleGenerationPreview.Step.allCases {
            let model = preview(texts: ["Notice your camera. Move closer. Compare the image. Try again.",
                                        "Make a deliberate change. Keep the subject. Study the light."])
            await runConfirmingOutline(model) { _ in }
            let original = model.article
            let originalImage = model.imageAsset
            let originalCaption = model.imageCaption
            let instruction: String
            switch selected {
            case .outline: instruction = "把摄影机换成单反相机"
            case .research: instruction = "Use the photography tutorial"
            case .writing: instruction = "写短一点"
            case .images: instruction = "换成建筑配图"
            case .artifact: instruction = "考查 notice 这个单词"
            }
            XCTAssertTrue(model.regenerate(from: selected, instruction: instruction))
            XCTAssertTrue(model.isRewinding)
            XCTAssertTrue(model.isComplete, "Old outputs stay mounted for their exit animation")
            XCTAssertEqual(model.article, original)
            for stage in ArticleGenerationPreview.Step.allCases {
                XCTAssertEqual(model.isDiscarding(stage), stage.rawValue >= selected.rawValue)
            }
            var durations: [ArticleGenerationPreview.Step: Duration] = [:]
            await runConfirmingOutline(model) { duration in
                if !model.isRewinding { durations[model.step, default: .zero] += duration }
            }
            XCTAssertTrue(model.isComplete)
            XCTAssertFalse(model.isRewinding)
            XCTAssertEqual(Set(durations.keys), Set(ArticleGenerationPreview.Step.allCases.filter { $0.rawValue >= selected.rawValue }))
            if selected != .outline {
                XCTAssertEqual(model.article.title, original.title)
                XCTAssertEqual(model.article.summary, original.summary)
                XCTAssertEqual(model.article.sections.map(\.heading), original.sections.map(\.heading))
            }
            if selected == .images || selected == .artifact { XCTAssertEqual(model.article, original) }
            if selected == .artifact {
                XCTAssertEqual(model.imageAsset, originalImage)
                XCTAssertEqual(model.imageCaption, originalCaption)
                XCTAssertEqual(model.practice.answer, 0)
                XCTAssertTrue(model.practice.question.lowercased().contains("notice"))
            }
            if selected == .images { XCTAssertEqual(model.imageAsset, "ArticleLeadingLinesBuilding") }
            if selected == .writing { XCTAssertLessThan(model.totalCharacters, original.sections.map(\.text).joined().count) }
            if selected == .outline { XCTAssertTrue(model.article.sections[0].heading.contains("DSLR")) }
        }
    }

    func testRegenerationRemovesOnlyConversationAfterTheCheckpoint() async {
        let model = preview()
        var recorded = Set<ArticleGenerationPreview.Step>()
        await runConfirmingOutline(model) { _ in
            if recorded.insert(model.step).inserted {
                model.messages.append(.init(id: "stage-\(model.step.rawValue)", role: "assistant", text: model.step.title))
            }
        }
        model.reply(to: "Quiz me")
        let oldIDs = Set(model.messages.map(\.id))
        let expectedKeptIDs = Set(model.messages.prefix(while: { $0.id != "stage-3" }).map(\.id))
        XCTAssertTrue(model.regenerate(from: .images, instruction: "换成建筑配图"))
        XCTAssertFalse(model.isDiscardingMessage("stage-0"))
        XCTAssertFalse(model.isDiscardingMessage("stage-1"))
        XCTAssertFalse(model.isDiscardingMessage("stage-2"))
        XCTAssertTrue(model.isDiscardingMessage("stage-3"))
        XCTAssertTrue(model.isDiscardingMessage("stage-4"))
        await runConfirmingOutline(model) { _ in }
        let keptIDs = Set(model.messages.map(\.id)).intersection(oldIDs)
        XCTAssertEqual(keptIDs, expectedKeptIDs)
        XCTAssertEqual(model.messages.filter { $0.text.hasPrefix(ArticleGenerationPreview.completionIntroduction) }.count, 1)
        XCTAssertTrue(model.messages.contains { $0.role == "user" && $0.text == "换成建筑配图" })
    }

    func testDiscardedSteeringCannotLeakIntoRegeneratedContent() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in
            if model.step == .images { model.steer("Replace camera with DSLR camera") }
        }
        await runConfirmingOutline(model) { _ in }
        XCTAssertTrue(model.article.sections[0].text.contains("DSLR camera"))
        XCTAssertTrue(model.regenerate(from: .writing, instruction: "Replace camera with mirrorless camera"))
        await runConfirmingOutline(model) { _ in }
        XCTAssertFalse(model.article.sections[0].text.contains("DSLR"))
        XCTAssertTrue(model.article.sections[0].text.contains("mirrorless camera"))
        XCTAssertFalse(model.messages.contains { $0.text.contains("DSLR") })
        XCTAssertEqual(model.article.sections[0].heading, "Section 0")
    }

    func testRegenerationWaitsForExitAndSurvivesNavigationDuringExit() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        let original = model.article
        let messages = model.messages
        XCTAssertTrue(model.regenerate(from: .outline, instruction: "Replace camera with DSLR camera"))
        XCTAssertFalse(model.regenerate(from: .artifact, instruction: "考查 compare"), "A double click must not replace the pending branch")
        await runConfirmingOutline(model) { duration in
            XCTAssertEqual(duration, ArticleGenerationPreview.discardDuration)
            XCTAssertEqual(model.article, original)
            XCTAssertEqual(model.messages, messages)
            throw CancellationError()
        }
        XCTAssertTrue(model.isRewinding)
        XCTAssertFalse(model.isRunning)
        await runConfirmingOutline(model) { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertFalse(model.isRewinding)
        XCTAssertTrue(model.article.sections[0].text.contains("DSLR camera"))
        XCTAssertEqual(model.messages.filter { $0.text.hasPrefix(ArticleGenerationPreview.completionIntroduction) }.count, 1)
    }

    func testRepeatedRegenerationUsesNewCheckpointsAndResetsPractice() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        XCTAssertTrue(model.regenerate(from: .images, instruction: "换成建筑配图"))
        await runConfirmingOutline(model) { _ in }
        model.quizSelection = 1
        XCTAssertTrue(model.regenerate(from: .artifact, instruction: "考查 compare 这个单词"))
        await runConfirmingOutline(model) { _ in }
        XCTAssertEqual(model.imageAsset, "ArticleLeadingLinesBuilding")
        XCTAssertNil(model.quizSelection)
        XCTAssertTrue(model.practice.question.lowercased().contains("compare"))
        model.reply(to: "Quiz me")
        XCTAssertTrue(model.messages.last!.text.contains("Look for similarities and differences"))
        XCTAssertTrue(model.regenerate(from: .images, instruction: "换成人像配图"))
        await runConfirmingOutline(model) { _ in }
        XCTAssertEqual(model.imageAsset, "ArticleLeadingLinesPortraitWall")
        XCTAssertEqual(model.practice, .vocabulary)
        XCTAssertNil(model.generationNotes[.artifact])
        XCTAssertFalse(model.messages.contains { $0.text.contains("建筑配图") || $0.text.contains("考查 compare") })
    }

    func testRegenerationRequiresCompletionAndNonemptyBoundedInput() async {
        let model = preview()
        XCTAssertFalse(model.regenerate(from: .outline, instruction: "Change camera to phone"))
        await runConfirmingOutline(model) { _ in }
        XCTAssertFalse(model.regenerate(from: .outline, instruction: " \n "))
        XCTAssertFalse(model.regenerate(from: .outline, instruction: String(repeating: "x", count: 2001)))
        XCTAssertFalse(model.isRewinding)
        XCTAssertTrue(model.isComplete)
    }

    func testReducedMotionRewindCommitsWithoutParticleWait() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in }
        let article = model.article
        XCTAssertTrue(model.regenerate(from: .images, instruction: "换成人像配图"))
        var exitDelay: Duration?
        await model.run(reduceMotion: true) { duration in
            if model.isRewinding {
                exitDelay = duration
                XCTAssertEqual(model.article, article)
                XCTAssertTrue(model.researchReady)
            }
        }
        XCTAssertEqual(exitDelay, .milliseconds(120))
        XCTAssertEqual(model.article, article)
        XCTAssertEqual(model.imageAsset, "ArticleLeadingLinesPortraitWall")
        XCTAssertTrue(model.isComplete)
    }

    func testResearchOutputSurvivesDownstreamRewind() async {
        let model = preview()
        XCTAssertFalse(model.researchReady)
        await runConfirmingOutline(model) { _ in }
        XCTAssertTrue(model.regenerate(from: .writing, instruction: "写短一点"))
        await model.run { _ in
            XCTAssertTrue(model.researchReady, "A later node must never hide completed research")
        }
        XCTAssertTrue(model.isComplete)
    }

    func testCameraPartsAdjustmentShowsNewOutlineThenAutomaticallyContinues() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in if model.step == .images { throw CancellationError() } }
        let originalArticle = model.article
        let originalCharacters = model.visibleCharacters
        model.steer("教我一些照相机的部件知识")
        XCTAssertEqual(model.planAdjustmentPhase, .submitted)
        XCTAssertEqual(model.article, originalArticle, "Submitted state retains the old reading content")
        XCTAssertEqual(model.visibleCharacters, originalCharacters)
        XCTAssertEqual(model.messages.last?.text, "教我一些照相机的部件知识")
        var submitted: Duration = .zero
        var reviewing: Duration = .zero
        var sawReview = false
        await model.run { delay in
            if model.planAdjustmentPhase == .submitted { submitted += delay }
            if model.isShowingRevisedOutline {
                sawReview = true
                reviewing += delay
                XCTAssertEqual(model.step, .writing)
                XCTAssertEqual(model.visibleCharacters, 0)
                XCTAssertEqual(model.outline.count, 4)
                XCTAssertTrue(model.outline[1].detail.contains("3D"))
                XCTAssertFalse(model.imagesReady)
                XCTAssertTrue(model.showsArticleOutline)
                XCTAssertFalse(model.showsArticleText || model.showsImages || model.showsArtifact || model.artifactReady)
                XCTAssertFalse(model.showsSection(at: 0))
                XCTAssertFalse(model.isAwaitingOutlineConfirmation)
                XCTAssertEqual(model.latestPlanMessageID, model.messages.last?.id)
            }
        }
        XCTAssertTrue(sawReview)
        XCTAssertEqual(submitted, .milliseconds(650))
        XCTAssertEqual(reviewing, .seconds(4))
        XCTAssertTrue(model.isComplete)
        XCTAssertTrue(model.teachesCameraParts)
        XCTAssertNil(model.planAdjustmentPhase)
        XCTAssertEqual(model.practice, .cameraParts)
        XCTAssertTrue(model.article.sections[1].text.contains("film SLR camera"))
        XCTAssertEqual(model.visibleCharacters, model.totalCharacters)
        XCTAssertEqual(model.messages.filter { $0.text == ArticleGenerationPreview.outlineConfirmationPrompt }.count, 1)
        XCTAssertEqual(model.messages.filter { $0.text.hasPrefix(ArticleGenerationPreview.completionIntroduction) }.count, 1)
        let revisedOutline = model.outline
        XCTAssertTrue(model.regenerate(from: .writing, instruction: "写短一点"))
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.outline, revisedOutline)
        XCTAssertTrue(model.teachesCameraParts)
        XCTAssertEqual(model.practice, .cameraParts)
    }

    func testPlanAdjustmentPausesOnStopAndSurvivesNavigation() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in if model.step == .writing { throw CancellationError() } }
        model.steer("教我一些照相机的部件知识")
        await model.run { _ in if model.isShowingRevisedOutline { model.stop() } }
        XCTAssertTrue(model.isStopped)
        XCTAssertTrue(model.isShowingRevisedOutline)
        let stoppedMessages = model.messages
        await model.run { _ in XCTFail("Stopping freezes plan review") }
        model.resume()
        await model.run { _ in throw CancellationError() }
        XCTAssertTrue(model.isShowingRevisedOutline, "Leaving the reader preserves the pending review")
        XCTAssertEqual(model.messages, stoppedMessages)
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.messages.filter { $0.text.hasPrefix("好的，我调整了计划") }.count, 1)
    }

    func testAnotherAdjustmentDuringReviewSupersedesTheOldRunAndKeepsConversation() async {
        let model = preview(texts: ["One camera. A second sentence. A third sentence."])
        await runConfirmingOutline(model) { _ in if model.step == .writing { throw CancellationError() } }
        model.steer("教我一些照相机的部件知识")
        var firstResponseID: String?
        var firstLength = 0
        await model.run { _ in
            if model.isShowingRevisedOutline {
                firstResponseID = model.latestPlanMessageID
                firstLength = model.totalCharacters
                model.steer("写短一点")
            }
        }
        XCTAssertEqual(model.planAdjustmentPhase, .submitted)
        XCTAssertEqual(model.visibleCharacters, 0)
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertNotEqual(firstResponseID, model.latestPlanMessageID)
        XCTAssertTrue(model.messages.contains { $0.id == firstResponseID })
        XCTAssertLessThan(model.totalCharacters, firstLength)
        XCTAssertEqual(model.practice, .cameraParts)
        XCTAssertEqual(model.messages.filter { $0.text == "写短一点" }.count, 1)
    }

    func testUnsupportedAndDuplicatePlanInputsDoNotCorruptGeneration() async {
        let model = preview()
        await runConfirmingOutline(model) { _ in if model.step == .images { throw CancellationError() } }
        let original = model.article
        let messageCount = model.messages.count
        model.steer(" \n ")
        model.steer(String(repeating: "x", count: 2001))
        XCTAssertEqual(model.messages.count, messageCount)
        model.steer("Explain quantum mechanics")
        model.steer("Explain quantum mechanics")
        XCTAssertEqual(model.messages.count, messageCount + 1)
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.article, original)
        XCTAssertNil(model.latestPlanMessageID)
        XCTAssertTrue(model.messages.contains { $0.text.contains("暂时无法在演示中应用") })
    }

    func testCameraPartsRewriteKeepsTheApprovedSectionCountAtWritingCheckpoint() async {
        let model = preview(texts: ["One camera.", "A second paragraph."])
        await runConfirmingOutline(model) { _ in }
        let headings = model.article.sections.map(\.heading)
        let outline = model.outline
        XCTAssertTrue(model.regenerate(from: .writing, instruction: "教我一些照相机的部件知识"))
        await model.run { _ in }
        XCTAssertTrue(model.isComplete)
        XCTAssertEqual(model.article.sections.map(\.heading), headings)
        XCTAssertEqual(model.outline, outline)
        XCTAssertTrue(model.article.sections[1].text.contains("Canon AT-1"))
        XCTAssertEqual(model.practice, .cameraParts)
    }

}
