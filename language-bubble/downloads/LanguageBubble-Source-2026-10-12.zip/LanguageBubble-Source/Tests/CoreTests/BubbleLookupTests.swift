import XCTest
@testable import ContextCore

@MainActor
final class BubbleLookupTests: XCTestCase {
    func testTypingDebouncesAndReturnDoesNotRepeatCompletedLookup() async throws {
        let model = BubbleLookup(delay: .milliseconds(80))
        let completed = expectation(description: "Only the completed word is queried")
        var calls: [String] = []
        let lookup: (String) async throws -> BubbleCapture = { word in
            calls.append(word)
            completed.fulfill()
            return BubbleCapture(source: word, result: "释义", explanation: "")
        }
        model.update("re", lookup: lookup)
        try await Task.sleep(for: .milliseconds(20))
        model.update("res", lookup: lookup)
        model.update("resilient", lookup: lookup)
        await fulfillment(of: [completed], timeout: 2)
        model.update("resilient  ", immediately: true, lookup: lookup)
        XCTAssertEqual(calls, ["resilient"])
        XCTAssertEqual(model.visibleResult?.source, "resilient")
    }

    func testReturnBypassesDebounceAndDeduplicatesInFlightRequest() async throws {
        let model = BubbleLookup(delay: .seconds(60))
        let started = expectation(description: "Return starts immediately")
        var resume: CheckedContinuation<BubbleCapture, Error>?
        var calls = 0
        let lookup: (String) async throws -> BubbleCapture = { _ in
            calls += 1
            return try await withCheckedThrowingContinuation {
                resume = $0
                started.fulfill()
            }
        }
        model.update("word", immediately: true, lookup: lookup)
        await fulfillment(of: [started], timeout: 2)
        model.update("word", immediately: true, lookup: lookup)
        XCTAssertEqual(calls, 1)
        resume?.resume(returning: BubbleCapture(source: "word", result: "词", explanation: ""))
        await Task.yield()
        XCTAssertEqual(model.visibleResult?.result, "词")
    }

    func testSupersededResponseCannotReplaceNewQuery() async throws {
        let model = BubbleLookup()
        let oldStarted = expectation(description: "Old request started")
        let newCompleted = expectation(description: "New request completed")
        var resume: CheckedContinuation<BubbleCapture, Error>?
        model.update("old", immediately: true) { _ in
            try await withCheckedThrowingContinuation {
                resume = $0
                oldStarted.fulfill()
            }
        }
        await fulfillment(of: [oldStarted], timeout: 2)
        model.update("new", immediately: true) { word in
            newCompleted.fulfill()
            return BubbleCapture(source: word, result: "新", explanation: "")
        }
        resume?.resume(returning: BubbleCapture(source: "old", result: "旧", explanation: ""))
        await fulfillment(of: [newCompleted], timeout: 2)
        XCTAssertEqual(model.visibleResult?.source, "new")
        XCTAssertNil(model.error)
    }

    func testCompositionAndClearingDoNotSendQueries() async throws {
        let model = BubbleLookup(delay: .milliseconds(30))
        let called = expectation(description: "No query while composing or empty")
        called.isInverted = true
        let lookup: (String) async throws -> BubbleCapture = { word in
            called.fulfill()
            return BubbleCapture(source: word, result: "", explanation: "")
        }
        model.update("pin", composing: true, lookup: lookup)
        try await Task.sleep(for: .milliseconds(60))
        model.update("拼", lookup: lookup)
        model.update("  ", lookup: lookup)
        await fulfillment(of: [called], timeout: 0.15)
        XCTAssertNil(model.visibleResult)
        XCTAssertFalse(model.isSearching)
    }

    func testSuggestionsPreferHistoryAndExcludeDuplicatesAndNonPrefixes() {
        XCTAssertEqual(BubbleLookupSuggestions.matches("res", history: ["resilient", "a result", "RESULT", "res"],
                                                      dictionary: ["result", "reset", "resist"]),
                       ["resilient", "RESULT", "reset", "resist"])
        XCTAssertEqual(BubbleLookupSuggestions.matches("", history: ["word"], dictionary: ["test"]), [])
    }
}
