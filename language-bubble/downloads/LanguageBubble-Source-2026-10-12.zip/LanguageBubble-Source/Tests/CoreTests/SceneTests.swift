import XCTest
#if os(macOS)
import AppKit
#endif
@testable import ContextCore

final class SceneTests: XCTestCase {
    func testScreenshotFallbackMatchesWholeSelectionAndClosestOccurrence() throws {
        let first = CGRect(x: 0.1, y: 0.8, width: 0.1, height: 0.04)
        let last = CGRect(x: 0.6, y: 0.2, width: 0.1, height: 0.04)
        let tokens = [("resilient", first), ("teams", CGRect(x: 0.22, y: 0.8, width: 0.1, height: 0.04)),
                      ("learn", CGRect(x: 0.1, y: 0.72, width: 0.08, height: 0.04)), ("resilient", last)]
        XCTAssertEqual(SceneText.selectedBounds("Resilient", in: tokens, near: CGPoint(x: 0.65, y: 0.2)), last)
        let passage = try XCTUnwrap(SceneText.selectedBounds("Resilient teams\nlearn.", in: tokens, near: .zero))
        XCTAssertTrue(passage.contains(first))
        XCTAssertTrue(passage.contains(tokens[2].1))
        XCTAssertNil(SceneText.selectedBounds("resilient leaders", in: tokens, near: .zero))
        XCTAssertNil(SceneText.selectedBounds("", in: tokens, near: .zero))
    }

    func testExplicitSelectionIsNotReplacedWithTheStartOfTheLine() throws {
        let full = "A resilient team learns from setbacks and keeps moving forward."
        for word in ["resilient", "setbacks"] {
            // Some hosts report a node-relative or stale position of zero.
            let selected = try XCTUnwrap(SceneText.selection(in: full, explicit: word, range: NSRange(location: 0, length: 1)))
            XCTAssertEqual(selected.text, word)
            XCTAssertNil(selected.range, "Do not reuse mismatched bounds or context offsets")
        }
        XCTAssertNil(SceneText.selection(in: full, explicit: nil, range: NSRange(location: 0, length: 0)))
        XCTAssertNil(SceneText.selection(in: full, explicit: "", range: NSRange(location: 0, length: 1)))
        XCTAssertNil(SceneText.selection(in: full, explicit: nil, range: nil), "A text node's value is not a selection")
    }

    func testSelectionRangeUsesUTF16AndRejectsInvalidRanges() throws {
        let full = "🙂 resilient and resilient"
        let range = NSRange(try XCTUnwrap(full.range(of: "resilient", options: .backwards)), in: full)
        let selected = try XCTUnwrap(SceneText.selection(in: full, explicit: nil, range: range))
        XCTAssertEqual(selected.text, "resilient")
        XCTAssertEqual(selected.range, range)
        XCTAssertNil(SceneText.selection(in: full, explicit: nil, range: NSRange(location: 100, length: 1)))
        XCTAssertNil(SceneText.selection(in: full, explicit: nil, range: NSRange(location: 2, length: Int.max)))
        XCTAssertNil(SceneText.selection(in: full, explicit: "   ", range: nil))
        XCTAssertEqual(SceneText.selection(in: "", explicit: "setbacks", range: nil)?.text, "setbacks")
    }

    func testLongDocumentRetainsContextAroundTheSelectedOccurrence() throws {
        let full = "Earlier products. " + String(repeating: "old text. ", count: 2000) + "Today we build products for curious people."
        let range = try XCTUnwrap(full.range(of: "products", options: .backwards))
        let context = try XCTUnwrap(SceneText.context(in: full, selected: "products", range: NSRange(range, in: full)))
        XCTAssertTrue(context.contains("Today we build products for curious people."))
        XCTAssertFalse(context.contains("Earlier products"))
        XCTAssertLessThanOrEqual(context.unicodeScalars.count, 12000)
        XCTAssertNil(SceneText.context(in: full, selected: "products"), "An ambiguous word without a selection range must not use the wrong occurrence")
    }

    func testContextBudgetCountsUnicodeScalarsAndKeepsSelection() throws {
        let word = "cafe\u{301}"
        let full = String(repeating: "🙂", count: 8000) + word + String(repeating: "👩‍💻", count: 4000)
        let context = try XCTUnwrap(SceneText.context(in: full, selected: word, limit: 41))
        XCTAssertTrue(context.contains(word))
        XCTAssertEqual(context.unicodeScalars.count, 41)
        XCTAssertNil(SceneText.context(in: full, selected: word, limit: 3))
        XCTAssertNil(SceneText.context(in: full, selected: "missing"))
    }

    func testWordsRetainContractionsHyphensAndIdentifiers() {
        let text = "don't re-enter user_name déjà-vu 안녕하세요"
        XCTAssertEqual(SceneText.ranges(in: text).map { String(text[$0]) }, ["don't", "re-enter", "user_name", "déjà-vu", "안녕하세요"])
    }
    func testRealVisionOCRAndPointerHit() async throws {
        let url = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent().appendingPathComponent("Fixtures/scene-products.png")
        let data = try Data(contentsOf: url)
        let imported = try await SceneImporter.decode(data)
        XCTAssertEqual(imported.png, data, "The saved screenshot must remain byte-for-byte identical after OCR")
        XCTAssertTrue(imported.text.contains("products"))
        XCTAssertTrue(imported.text.contains("We build products for curious people."))
        let hit = try await SceneImporter.word(data, at: CGPoint(x: 0.18, y: 0.59))
        XCTAssertEqual(hit.word, "products")
    }
    func testInvalidImageFailsWithoutCreatingText() async {
        do { _ = try await SceneImporter.decode(Data("not an image".utf8)); XCTFail("Invalid input must not succeed") }
        catch { XCTAssertFalse(error.localizedDescription.isEmpty) }
    }

    #if os(macOS)
    func testSelectionScreenshotKeepsCompleteSentenceOrPassage() async throws {
        let width = 1200, height = 500
        let bitmap = try XCTUnwrap(NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width,
            pixelsHigh: height, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
            isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0))
        let context = try XCTUnwrap(NSGraphicsContext(bitmapImageRep: bitmap))
        let attributes: [NSAttributedString.Key: Any] = [
            .font: NSFont.systemFont(ofSize: 30), .foregroundColor: NSColor.black
        ]
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = context
        NSColor.white.setFill(); NSRect(x: 0, y: 0, width: width, height: height).fill()
        ("Unrelated heading" as NSString).draw(at: NSPoint(x: 40, y: 400), withAttributes: attributes)
        ("A resilient team learns from setbacks." as NSString).draw(at: NSPoint(x: 40, y: 260), withAttributes: attributes)
        ("They keep moving forward." as NSString).draw(at: NSPoint(x: 40, y: 200), withAttributes: attributes)
        ("Unrelated footer" as NSString).draw(at: NSPoint(x: 40, y: 60), withAttributes: attributes)
        NSGraphicsContext.restoreGraphicsState()
        let data = try XCTUnwrap(bitmap.representation(using: .png, properties: [:]))
        for selection in ["resilient", "A resilient team learns from setbacks. They keep moving forward."] {
            let cropped = try await SceneImporter.selectedImage(data, text: selection, near: CGPoint(x: 0.2, y: 0.5))
            let image = try XCTUnwrap(NSBitmapImageRep(data: cropped))
            XCTAssertLessThan(image.pixelsWide, width)
            XCTAssertLessThan(image.pixelsHigh, height / 2)
            let recognized = try await SceneImporter.decode(cropped).text
            XCTAssertTrue(recognized.contains("resilient"))
            XCTAssertFalse(recognized.contains("Unrelated"))
            if selection == "resilient" {
                XCTAssertTrue(recognized.contains("A resilient team learns from setbacks."))
                XCTAssertGreaterThan(image.pixelsWide, 400)
            } else {
                XCTAssertTrue(recognized.contains("They keep moving forward."))
            }
        }
        do {
            _ = try await SceneImporter.selectedImage(data, text: "not present", near: .zero)
            XCTFail("An unverified selection must never save an unrelated screenshot")
        } catch { }
    }

    func testParagraphLayoutKeepsWrapsAndRejectsNextBulletAndOtherColumn() {
        func line(_ text: String, x: CGFloat = 40, y: CGFloat, width: CGFloat = 600) -> SceneText.ArtworkLine {
            let bounds = CGRect(x: x, y: y, width: width, height: 30)
            return .init(text: text, bounds: bounds, tokens: [(text, bounds)])
        }
        let fragments = [line("• Determine root causes of incidents faster by", y: 200),
                         line("correlating changes directly to Datadog telemetry.", y: 158, width: 570),
                         line("• Limit the blast radius of a faulty release.", y: 116),
                         line("Other column", x: 800, y: 200, width: 300)]
        // Geometry also locates words hidden from OCR by their selection highlight.
        let paragraph = SceneText.artworkLines("telemetry", in: fragments, near: CGPoint(x: 550, y: 170),
            selection: CGRect(x: 500, y: 160, width: 60, height: 20))
        XCTAssertEqual(paragraph.map(\.text), Array(fragments.prefix(2)).map(\.text))
    }

    func testHostBoundsKeepHighlightedOccurrenceWhenOCRMissesItsWord() {
        let other = CGRect(x: 40, y: 500, width: 100, height: 30)
        let selected = CGRect(x: 40, y: 200, width: 600, height: 30)
        let lines: [SceneText.ArtworkLine] = [
            .init(text: "bubble", bounds: other, tokens: [("bubble", other)]),
            .init(text: "Created a generator.", bounds: selected, tokens: [])
        ]
        let paragraph = SceneText.artworkLines("bubble", in: lines, near: CGPoint(x: 180, y: 215),
            selection: CGRect(x: 150, y: 200, width: 60, height: 30))
        XCTAssertEqual(paragraph.map(\.bounds), [selected])
    }

    func testRealVisionMakesTransparentContourAroundWrappedParagraph() async throws {
        let bitmap = try XCTUnwrap(NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: 1400,
            pixelsHigh: 650, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
            isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0))
        let context = try XCTUnwrap(NSGraphicsContext(bitmapImageRep: bitmap))
        let attributes: [NSAttributedString.Key: Any] = [.font: NSFont.systemFont(ofSize: 30), .foregroundColor: NSColor.black]
        let lines = ["Created a bubble generator that can create animated soda fizz",
                     "or stationary bubbles that you would see in hand blown glass.",
                     "Might have to graduate this into a legit plugin."]
        NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = context
        NSColor.white.setFill(); NSRect(x: 0, y: 0, width: 1400, height: 650).fill()
        ("Unrelated heading" as NSString).draw(at: NSPoint(x: 70, y: 530), withAttributes: attributes)
        for (index, line) in lines.enumerated() {
            if index == 0 {
                let x = 70 + ("Created a " as NSString).size(withAttributes: attributes).width
                let size = ("bubble" as NSString).size(withAttributes: attributes)
                NSColor(srgbRed: 1, green: 0.91, blue: 0.42, alpha: 1).setFill()
                NSBezierPath(roundedRect: CGRect(x: x - 3, y: 390, width: size.width + 6, height: size.height),
                             xRadius: 5, yRadius: 5).fill()
            }
            (line as NSString).draw(at: NSPoint(x: 70, y: 390 - index * 44), withAttributes: attributes)
        }
        ("Unrelated footer" as NSString).draw(at: NSPoint(x: 70, y: 90), withAttributes: attributes)
        NSGraphicsContext.restoreGraphicsState()
        let original = try XCTUnwrap(bitmap.representation(using: .png, properties: [:]))
        let cutout = try await SceneImporter.selectedImage(original, text: "bubble", near: CGPoint(x: 0.2, y: 0.63))
        let output = try XCTUnwrap(NSBitmapImageRep(data: cutout))
        let recognized = try await SceneImporter.decode(cutout).text
        XCTAssertTrue(recognized.contains("Created a bubble generator"))
        XCTAssertTrue(recognized.contains("hand blown glass."))
        XCTAssertTrue(recognized.contains("legit plugin."))
        XCTAssertFalse(recognized.contains("Unrelated"))
        XCTAssertGreaterThan(output.pixelsWide, 700)
        XCTAssertLessThan(output.pixelsHigh, 200)
        XCTAssertLessThan(try XCTUnwrap(output.colorAt(x: output.pixelsWide - 8, y: output.pixelsHigh - 12)).alphaComponent, 0.01,
                          "The shorter final line leaves transparent space, not a rectangular background")
        if let folder = ProcessInfo.processInfo.environment["SCENE_ARTWORK_PREVIEW_DIR"] {
            try original.write(to: URL(fileURLWithPath: folder).appendingPathComponent("sentence-source.png"))
            try cutout.write(to: URL(fileURLWithPath: folder).appendingPathComponent("sentence-cutout.png"))
        }
    }

    func testPointerHitsActualWordsInMultipleLinesAndRejectsWhitespace() async throws {
        // Match the reported browser layout, including two occurrences of resilient.
        // Coordinates come from the rendered font metrics, independently of Vision.
        let width = 1200, height = 500
        let bitmap = try XCTUnwrap(NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width,
            pixelsHigh: height, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
            isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0))
        let context = try XCTUnwrap(NSGraphicsContext(bitmapImageRep: bitmap))
        let font = NSFont.systemFont(ofSize: 30)
        let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: NSColor.black]
        let lines: [(String, CGFloat)] = [
            ("resilient", 350),
            ("A resilient team learns from setbacks and keeps moving forward.", 230),
            ("Could you walk me through the launch plan?", 110)
        ]
        for highlighted: String? in [nil, "resilient", "setbacks"] {
            NSGraphicsContext.saveGraphicsState()
            NSGraphicsContext.current = context
            NSColor.white.setFill(); NSRect(x: 0, y: 0, width: width, height: height).fill()
            for (line, y) in lines {
                if let highlighted, y == 230, let range = line.range(of: highlighted) {
                    let prefix = (String(line[..<range.lowerBound]) as NSString).size(withAttributes: attributes).width
                    let size = (highlighted as NSString).size(withAttributes: attributes)
                    NSColor(red: 0.68, green: 0.82, blue: 1, alpha: 1).setFill()
                    NSRect(x: 40 + prefix, y: y, width: size.width, height: size.height).fill()
                }
                (line as NSString).draw(at: NSPoint(x: 40, y: y), withAttributes: attributes)
            }
            NSGraphicsContext.restoreGraphicsState()
            let data = try XCTUnwrap(bitmap.representation(using: .png, properties: [:]))
            for (line, y) in lines {
                for word in ["resilient", "setbacks", "Could", "through", "forward"] {
                    guard let range = line.range(of: word) else { continue }
                    let prefix = (String(line[..<range.lowerBound]) as NSString).size(withAttributes: attributes).width
                    let size = (word as NSString).size(withAttributes: attributes)
                    let point = CGPoint(x: (40 + prefix + size.width / 2) / CGFloat(width),
                                        y: (y + size.height / 2) / CGFloat(height))
                    let hit = try await SceneImporter.word(data, at: point)
                    XCTAssertEqual(hit.word, word, "Pointer at \(point) on \(line)")
                    XCTAssertEqual(hit.line, line)
                }
            }
            for point in [CGPoint(x: 0.015, y: 0.49), CGPoint(x: 0.5, y: 0.38)] {
                do {
                    _ = try await SceneImporter.word(data, at: point)
                    XCTFail("Whitespace must not select a nearby word: \(point)")
                } catch { }
            }
        }
    }
    #endif
}
