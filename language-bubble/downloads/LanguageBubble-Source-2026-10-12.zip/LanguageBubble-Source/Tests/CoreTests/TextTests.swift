import XCTest
@testable import ContextCore

final class TextTests: XCTestCase {
    let document = UUID()
    func snapshot(_ before: String, _ selected: String = "", _ after: String = "") -> TextSnapshot {
        TextSnapshot(document: document, before: before, selected: selected, after: after)
    }
    func issue(_ original: String = "am agree", _ replacement: String = "agree") -> WritingIssue {
        WritingIssue(original: original, replacement: replacement, category: "grammar", explanation: "agree 是动词", confidence: 0.98)
    }
    func testOnlyCurrentSentenceIsSubmitted() {
        XCTAssertEqual(snapshot("Earlier private context. I am agree with you.").analysisText, "I am agree with you.")
        XCTAssertEqual(snapshot("I like ", "", "apples.").analysisText, "I like apples")
    }
    func testSensitiveAndOversizedInputExcluded() {
        XCTAssertNil(snapshot("Contact me at person@example.com.").analysisText)
        XCTAssertNil(snapshot(String(repeating: "word ", count: 150)).analysisText)
        XCTAssertNil(snapshot("Hi").analysisText)
    }
    func testReplacementOnlyOnExactSuffixOrSelection() {
        XCTAssertNotNil(snapshot("I am agree").safeReplacement(for: issue()))
        XCTAssertNotNil(snapshot("I ", "am agree", " with you").safeReplacement(for: issue()))
        XCTAssertNil(snapshot("I am agree with you.").safeReplacement(for: issue()))
        XCTAssertNil(snapshot("I agree").safeReplacement(for: issue()))
    }
    func testIncompleteAndAmbiguousIssuesAreNotRecorded() {
        XCTAssertNil(CheckResult(complete: false, issues: [issue()]).actionable(in: "I am agree"))
        XCTAssertFalse(issue().isValid(in: "I am agree and am agree"))
        var style = issue(); style.category = "style"
        XCTAssertFalse(style.isValid(in: "I am agree"))
    }
}
