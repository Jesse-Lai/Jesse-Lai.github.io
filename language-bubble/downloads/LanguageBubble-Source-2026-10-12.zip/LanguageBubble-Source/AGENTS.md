# Language Bubble source handoff

Read README.md and docs/CODEX_HANDOFF.md first. This is a native SwiftUI/AppKit macOS app.
Use the LanguageBubbleMac scheme and scripts/build-mac.sh for macOS.
Start with independent Mock configuration via scripts/setup-local-demo.py; keep local credentials private.
Historical validation notes refer to the original author's machine, not this installation.
The learning article preview is deterministic and in memory; distinguish it from the server AI pipeline.
Preserve current native interactions and assets when making scoped changes.
