import Foundation

enum SceneText {
    struct ArtworkLine {
        var text: String
        var bounds: CGRect
        var tokens: [(text: String, bounds: CGRect)]
    }

    /// Work in image pixels (bottom-left origin), so layout decisions also work
    /// for Retina captures and tall or wide windows. Join OCR fragments on the
    /// same baseline before expanding the selection to its surrounding paragraph.
    static func artworkLines(_ selected: String, in fragments: [ArtworkLine], near point: CGPoint,
                             selection: CGRect? = nil) -> [ArtworkLine] {
        var lines: [ArtworkLine] = []
        for fragment in fragments.sorted(by: { $0.bounds.minX < $1.bounds.minX }) {
            if let index = lines.indices.first(where: {
                let a = lines[$0].bounds, b = fragment.bounds
                let overlap = min(a.maxY, b.maxY) - max(a.minY, b.minY)
                return overlap > min(a.height, b.height) * 0.6
                    && max(a.height, b.height) < min(a.height, b.height) * 1.5
                    && b.minX - a.maxX < max(a.height, b.height) * 1.6
            }) {
                lines[index].text += " " + fragment.text
                lines[index].bounds = lines[index].bounds.union(fragment.bounds)
                lines[index].tokens += fragment.tokens
            } else { lines.append(fragment) }
        }
        lines.sort {
            if abs($0.bounds.midY - $1.bounds.midY) < min($0.bounds.height, $1.bounds.height) * 0.5 {
                return $0.bounds.minX < $1.bounds.minX
            }
            return $0.bounds.midY > $1.bounds.midY
        }
        let recognized = selectedBounds(selected, in: lines.flatMap(\.tokens), near: point)
        // Selection highlights can obscure a word from OCR. In that case, the
        // host's known range is stronger evidence than another occurrence nearby.
        let matched: CGRect?
        if let selection {
            matched = recognized.map { $0.intersects(selection) ? $0 : selection } ?? selection
        } else { matched = recognized }
        guard let matched, !matched.isEmpty, !matched.isInfinite else { return [] }
        let seeds = lines.indices.filter { lines[$0].bounds.intersects(matched) }
        guard var first = seeds.first, var last = seeds.last else { return [] }
        var included = Set(seeds)
        func connected(_ upper: ArtworkLine, _ lower: ArtworkLine) -> Bool {
            let a = upper.bounds, b = lower.bounds
            let h = max(a.height, b.height)
            let overlap = min(a.maxX, b.maxX) - max(a.minX, b.minX)
            // A new bullet, column, heading or blank paragraph is a new scene.
            let bullet = lower.text.range(of: #"^\s*(?:[•●▪◦‣–—-]|\d+[.)])\s"#, options: .regularExpression) != nil
            return !bullet && b.midY < a.midY && a.minY - b.maxY <= h * 0.85
                && min(a.height, b.height) >= h * 0.68
                && overlap > min(a.width, b.width) * 0.2
                && abs(a.minX - b.minX) < h * 3
        }
        while let previous = lines.indices.prefix(first).last(where: { connected(lines[$0], lines[first]) }) {
            included.insert(previous); first = previous
        }
        while let next = lines.indices.dropFirst(last + 1).first(where: { connected(lines[last], lines[$0]) }) {
            included.insert(next); last = next
        }
        return included.sorted().map { lines[$0] }
    }

    /// Match every selected token, including multiline passages. Never attach an
    /// unrelated nearby sentence when OCR cannot verify the selected text.
    static func selectedBounds(_ selected: String, in tokens: [(text: String, bounds: CGRect)], near point: CGPoint) -> CGRect? {
        func key(_ text: String) -> String {
            text.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX"))
                .replacingOccurrences(of: "’", with: "'")
        }
        let needle = ranges(in: selected).map { key(String(selected[$0])) }
        guard !needle.isEmpty, needle.count <= tokens.count else { return nil }
        let haystack = tokens.map { key($0.text) }
        var matches: [CGRect] = []
        for index in 0...(tokens.count - needle.count) {
            guard Array(haystack[index..<(index + needle.count)]) == needle else { continue }
            let rect = tokens[index..<(index + needle.count)].reduce(CGRect.null) { $0.union($1.bounds) }
            if !rect.isNull, !rect.isInfinite, rect.width > 0, rect.height > 0 { matches.append(rect) }
        }
        return matches.min {
            hypot($0.midX - point.x, $0.midY - point.y) < hypot($1.midX - point.x, $1.midY - point.y)
        }
    }

    /// An insertion caret is not a selection. Keep explicit host text even when its
    /// range uses document offsets that do not match the element's local value.
    static func selection(in full: String, explicit: String?, range: NSRange?) -> (text: String, range: NSRange?)? {
        var validRange: NSRange?
        var rangedText: String?
        let length = full.utf16.count
        if let range, range.location >= 0, range.location <= length, range.length > 0,
           range.length <= length - range.location, let converted = Range(range, in: full) {
            validRange = range
            rangedText = String(full[converted])
        }
        guard let text = explicit ?? rangedText, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              text.unicodeScalars.count <= 6000 else { return nil }
        return (text, text == rangedText ? validRange : nil)
    }

    static func context(in full: String, selected: String, range: NSRange? = nil, limit: Int = 12000) -> String? {
        guard !selected.isEmpty, selected.unicodeScalars.count <= limit else { return nil }
        let match: Range<String.Index>
        if let range, let converted = Range(range, in: full), String(full[converted]) == selected {
            match = converted
        } else {
            // Without a host range, repeated words do not identify which scene the user selected.
            guard let first = full.range(of: selected), full.range(of: selected, range: first.upperBound..<full.endIndex) == nil else { return nil }
            match = first
        }
        if full.unicodeScalars.count <= limit { return full }
        let room = limit - selected.unicodeScalars.count
        let before = full[..<match.lowerBound].unicodeScalars.suffix(min(1000, room / 2))
        let after = full[match.upperBound...].unicodeScalars.prefix(min(1000, room - before.count))
        return String(before) + selected + String(after)
    }

    static func ranges(in text: String) -> [Range<String.Index>] {
        // Preserve contractions, hyphenated words and code identifiers without changing the original text.
        let expression = try! NSRegularExpression(pattern: #"[\p{L}\p{M}\p{N}_]+(?:[-'’][\p{L}\p{M}\p{N}_]+)*"#)
        return expression.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap { Range($0.range, in: text) }
    }
}
