import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct AIClient: Sendable {
    let preferences: CapturePreferences
    private let session: URLSession?

    init(preferences: CapturePreferences, session: URLSession? = nil) {
        self.preferences = preferences
        self.session = session
    }

    private struct Payload: Encodable { var text: String; var request_id: UUID; var surrounding_text: String?; var target_language: String?; var source_app: String? = nil }

    func translate(_ text: String, id: UUID, context: String? = nil, targetLanguage: String? = nil, sourceApp: String? = nil) async throws -> TranslationResult {
        let target = targetLanguage ?? preferences.primaryLanguage.map {
            LanguageRouting.target(detected: LanguageRouting.detect(text), primary: $0, secondary: preferences.secondaryLanguage ?? "en")
        }
        let value: TranslationResult = try await request("translate", text: text, id: id, context: context, targetLanguage: target, sourceApp: sourceApp)
        guard !value.translation.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ContextError.invalidResponse }
        return value
    }
    func check(_ text: String, id: UUID) async throws -> CheckResult {
        guard preferences.automaticChecking else { throw ContextError.automaticCheckingDisabled }
        return try await request("check", text: text, id: id)
    }

    /// An explicit user action, independent of automatic checking and translation routing.
    func polish(_ text: String, id: UUID, context: String? = nil, sourceApp: String? = nil) async throws -> PolishResult {
        let value: PolishResult = try await request("polish", text: text, id: id, context: context, sourceApp: sourceApp)
        guard !value.polished.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              value.polished.unicodeScalars.count <= 12000,
              value.explanation.unicodeScalars.count <= 4000 else { throw ContextError.invalidResponse }
        return value
    }

    func streamTranslate(_ text: String, id: UUID, context: String?, targetLanguage: String,
                         onPartial: @escaping @Sendable (String) async -> Void) async throws -> TranslationResult {
        guard let base = URL(string: preferences.serviceURL), base.host != nil, !preferences.serviceToken.isEmpty else { throw ContextError.invalidConfiguration }
        let allowed = ServiceEndpoint.allowed(base)
        guard allowed, base.user == nil, base.password == nil else { throw ContextError.invalidConfiguration }
        var request = URLRequest(url: base.appendingPathComponent("v1/translate/stream"))
        request.httpMethod = "POST"; request.timeoutInterval = 25
        request.setValue("Bearer " + preferences.serviceToken, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(Payload(text: text, request_id: id, surrounding_text: context, target_language: targetLanguage))
        let configuration = URLSessionConfiguration.ephemeral
        configuration.urlCache = nil; configuration.httpCookieStorage = nil
        let session = self.session ?? URLSession(configuration: configuration)
        defer { if self.session == nil { session.invalidateAndCancel() } }
        let (bytes, response) = try await session.bytes(for: request)
        guard let response = response as? HTTPURLResponse else { throw ContextError.invalidResponse }
        guard response.statusCode == 200 else { throw SyncHTTPError(status: response.statusCode) }
        struct Event: Decodable { var delta: String?; var result: TranslationResult? }
        var partial = ""
        for try await line in bytes.lines {
            try Task.checkCancellation()
            guard line.utf8.count < 100_000, partial.count < 12000 else { throw ContextError.invalidResponse }
            let event = try JSONDecoder().decode(Event.self, from: Data(line.utf8))
            if let result = event.result {
                guard !result.translation.isEmpty, result.translation == partial else { throw ContextError.invalidResponse }
                return result
            }
            if let delta = event.delta { partial += delta; await onPartial(partial) }
        }
        throw ContextError.service("结果接收中断，请重试。未完成的内容没有保存。")
    }

    private func request<T: Decodable>(_ path: String, text: String, id: UUID, context: String? = nil, targetLanguage: String? = nil, sourceApp: String? = nil) async throws -> T {
        guard let base = URL(string: preferences.serviceURL), base.host != nil,
              !preferences.serviceToken.isEmpty else { throw ContextError.invalidConfiguration }
        let allowed = ServiceEndpoint.allowed(base)
        guard allowed, base.user == nil, base.password == nil else { throw ContextError.invalidConfiguration }
        var request = URLRequest(url: base.appendingPathComponent("v1/" + path))
        request.httpMethod = "POST"
        request.timeoutInterval = 60
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer " + preferences.serviceToken, forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(Payload(text: text, request_id: id, surrounding_text: context, target_language: targetLanguage, source_app: sourceApp))
        let config = URLSessionConfiguration.ephemeral
        config.urlCache = nil
        config.httpCookieStorage = nil
        let session = self.session ?? URLSession(configuration: config)
        defer { if self.session == nil { session.finishTasksAndInvalidate() } }
        let (data, response) = try await session.data(for: request)
        guard let response = response as? HTTPURLResponse else { throw ContextError.invalidResponse }
        guard response.statusCode == 200 else {
            let message: String
            switch response.statusCode {
            case 401, 403: message = "服务授权无效，请在主 App 中检查连接。"
            case 429: message = "请求较频繁，请稍后重试。"
            case 503: message = "AI 服务尚未就绪，请稍后重试。"
            default: message = "暂时无法完成分析，请重试。"
            }
            throw ContextError.service(message)
        }
        guard data.count < 100_000 else { throw ContextError.invalidResponse }
        do { return try JSONDecoder().decode(T.self, from: data) }
        catch { throw ContextError.invalidResponse }
    }
}
