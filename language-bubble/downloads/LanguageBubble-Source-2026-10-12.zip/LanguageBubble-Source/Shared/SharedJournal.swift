import Foundation
#if canImport(Darwin)
import Darwin
#else
import Glibc
#endif

struct JournalState: Codable {
    var epoch = 0
    // Keep the persisted key compatible with earlier installs; tracks any settings change.
    var consentRevision = 0
    var preferences = CapturePreferences()
    var tombstones: Set<UUID> = []
    var syncUserId: String? = nil
    var syncEpoch: Int? = nil
    // Separate from the local inbox: importing into SwiftData must not acknowledge a network upload.
    var pendingSync: [SyncOperation]? = nil
}

struct JournalSnapshot {
    var state: JournalState
    var records: [CapturedRecord]
}

/// All processes coordinate via flock. The queue remains durable until SwiftData has committed it.
final class SharedJournal: @unchecked Sendable {
    let root: URL
    private let processLock = NSLock()

    static func live() throws -> SharedJournal {
        #if os(iOS)
        let group = Bundle.main.object(forInfoDictionaryKey: "ContextAppGroup") as? String ?? "group.app.context.capture"
        guard let root = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
            throw ContextError.unavailableStorage
        }
        return try SharedJournal(root: root.appendingPathComponent("Capture", isDirectory: true))
        #else
        throw ContextError.unavailableStorage
        #endif
    }

    init(root: URL) throws {
        self.root = root
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: queue, withIntermediateDirectories: true)
        #if os(iOS)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: root.path)
        #endif
    }

    private var queue: URL { root.appendingPathComponent("Inbox", isDirectory: true) }
    private var stateURL: URL { root.appendingPathComponent("state.json") }

    private func locked<T>(_ operation: () throws -> T) throws -> T {
        processLock.lock()
        defer { processLock.unlock() }
        let descriptor = open(root.appendingPathComponent("journal.lock").path, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR)
        guard descriptor >= 0 else { throw ContextError.unavailableStorage }
        defer { close(descriptor) }
        guard flock(descriptor, LOCK_EX) == 0 else { throw ContextError.unavailableStorage }
        defer { flock(descriptor, LOCK_UN) }
        return try operation()
    }

    private func readState() throws -> JournalState {
        guard FileManager.default.fileExists(atPath: stateURL.path) else { return JournalState() }
        return try JSONDecoder().decode(JournalState.self, from: Data(contentsOf: stateURL))
    }

    private func write<T: Encodable>(_ value: T, to url: URL) throws {
        let data = try JSONEncoder().encode(value)
        #if os(iOS)
        try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        #else
        try data.write(to: url, options: .atomic)
        #endif
    }

    func state() throws -> JournalState { try locked { try readState() } }

    func bindSyncUser(_ session: DeviceSession?, endpoint: String) throws {
        try locked {
            var state = try readState()
            let next = session?.userId
            if state.syncUserId != next {
                if state.syncUserId != nil {
                    state.epoch += 1; state.tombstones = []
                    for url in try FileManager.default.contentsOfDirectory(at: queue, includingPropertiesForKeys: nil) {
                        try FileManager.default.removeItem(at: url)
                    }
                }
                state.syncUserId = next
                state.pendingSync = []
                state.consentRevision += 1
                if next != nil { state.preferences.saveTranslations = true; state.preferences.saveWritingIssues = true }
            }
            if let previous = state.syncEpoch, previous != session?.epoch { state.pendingSync = [] }
            state.syncEpoch = session?.epoch
            if state.preferences.serviceURL != endpoint || state.preferences.serviceToken != (session?.token ?? "") {
                state.preferences.serviceURL = endpoint; state.preferences.serviceToken = session?.token ?? ""
                state.consentRevision += 1
            }
            try write(state, to: stateURL)
        }
    }

    func updatePreferences(_ update: (inout CapturePreferences) -> Void) throws {
        try locked {
            var state = try readState()
            let old = state.preferences
            update(&state.preferences)
            if old != state.preferences { state.consentRevision += 1 }
            try write(state, to: stateURL)
        }
    }

    func ticket(id: UUID = UUID()) throws -> CaptureTicket {
        try locked {
            let state = try readState()
            return CaptureTicket(id: id, epoch: state.epoch, consentRevision: state.consentRevision)
        }
    }

    func capture(id: UUID = UUID()) throws -> (preferences: CapturePreferences, ticket: CaptureTicket) {
        try locked {
            let state = try readState()
            return (state.preferences, CaptureTicket(id: id, epoch: state.epoch, consentRevision: state.consentRevision))
        }
    }

    /// Returns false if settings changed, the user deleted the item, or cleared all records in flight.
    @discardableResult
    func enqueue(_ record: CapturedRecord, ticket: CaptureTicket) throws -> Bool {
        try locked {
            var state = try readState()
            let saving = record.kind == .translation ? state.preferences.saveTranslations :
                state.preferences.automaticChecking && state.preferences.saveWritingIssues
            guard record.id == ticket.id, record.epoch == ticket.epoch,
                  state.epoch == ticket.epoch, state.consentRevision == ticket.consentRevision,
                  saving, !state.tombstones.contains(record.id) else { return false }
            try write(record, to: queue.appendingPathComponent(record.id.uuidString + ".json"))
            if state.syncUserId != nil, state.syncEpoch != nil {
                let capture = BubbleCapture(record: record)
                var operations = state.pendingSync ?? []
                if !operations.contains(where: { $0.entityId == capture.id }) {
                    operations.append(SyncOperation(action: "capture.put", entityId: capture.id, capture: capture))
                    state.pendingSync = operations
                    try write(state, to: stateURL)
                }
            }
            return true
        }
    }

    func remove(_ id: UUID, enqueueSync: Bool = true) throws {
        try locked {
            var state = try readState()
            state.tombstones.insert(id)
            if enqueueSync, state.syncUserId != nil, state.syncEpoch != nil {
                let key = id.uuidString.lowercased()
                var operations = (state.pendingSync ?? []).filter { $0.entityId != key || $0.action == "capture.delete" }
                if !operations.contains(where: { $0.entityId == key && $0.action == "capture.delete" }) {
                    operations.append(SyncOperation(action: "capture.delete", entityId: key))
                }
                state.pendingSync = operations
            }
            // Persist the tombstone first; it also rejects late retries from other processes.
            try write(state, to: stateURL)
            let item = queue.appendingPathComponent(id.uuidString + ".json")
            if FileManager.default.fileExists(atPath: item.path) { try FileManager.default.removeItem(at: item) }
        }
    }

    func clear() throws {
        try locked {
            var state = try readState()
            state.epoch += 1
            state.tombstones = []
            state.pendingSync = []
            try write(state, to: stateURL)
            for url in try FileManager.default.contentsOfDirectory(at: queue, includingPropertiesForKeys: nil) {
                try FileManager.default.removeItem(at: url)
            }
        }
    }

    /// May run in the extension or containing app. File locks cover snapshots/acks, never network waits.
    /// Concurrent retries retain operation IDs; server tombstones win even if an undo overtakes a put.
    @discardableResult
    func syncPending(clientFactory: @Sendable (String, String) -> SyncClient = {
        SyncClient(endpoint: $0, token: $1)
    }) async throws -> Bool {
        while true {
            try Task.checkCancellation()
            let snapshot = try state()
            guard snapshot.syncUserId != nil, let epoch = snapshot.syncEpoch,
                  !snapshot.preferences.serviceToken.isEmpty else { return false }
            let operations = Array((snapshot.pendingSync ?? []).prefix(100))
            guard !operations.isEmpty else { return true }
            let receipt = try await clientFactory(snapshot.preferences.serviceURL, snapshot.preferences.serviceToken)
                .push(operations, epoch: epoch)
            let accepted = Set(receipt.accepted)
            guard accepted == Set(operations.map(\.opId)) else { throw ContextError.invalidResponse }
            let sameSession = try locked {
                var current = try readState()
                guard current.syncUserId == snapshot.syncUserId, current.syncEpoch == snapshot.syncEpoch,
                      current.epoch == snapshot.epoch,
                      current.preferences.serviceToken == snapshot.preferences.serviceToken else { return false }
                current.pendingSync = (current.pendingSync ?? []).filter { !accepted.contains($0.opId) }
                try write(current, to: stateURL)
                return true
            }
            guard sameSession else { return false }
        }
    }

    /// The callback must commit the database transaction before returning. Failed imports retain their files.
    func consume(_ commit: (JournalSnapshot) throws -> Void) throws {
        try locked {
            let state = try readState()
            let files = try FileManager.default.contentsOfDirectory(at: queue, includingPropertiesForKeys: nil)
                .filter { $0.pathExtension == "json" }
            let records = try files.map { try JSONDecoder().decode(CapturedRecord.self, from: Data(contentsOf: $0)) }
                .filter { $0.epoch == state.epoch && !state.tombstones.contains($0.id) }
            try commit(JournalSnapshot(state: state, records: records))
            for file in files { try FileManager.default.removeItem(at: file) }
        }
    }
}
