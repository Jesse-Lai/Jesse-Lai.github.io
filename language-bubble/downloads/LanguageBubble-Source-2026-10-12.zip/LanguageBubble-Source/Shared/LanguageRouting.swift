import Foundation
import NaturalLanguage

enum LanguageRouting {
    static let languages = [("zh", "中文"), ("en", "English"), ("es", "Español"), ("pt", "Português"), ("fr", "Français"), ("de", "Deutsch"), ("ja", "日本語"), ("ko", "한국어")]
    static func detect(_ text: String) -> String? {
        guard let code = NLLanguageRecognizer.dominantLanguage(for: text)?.rawValue else { return nil }
        return code.hasPrefix("zh") ? "zh" : code
    }
    static func normalized(_ code: String?) -> String? {
        guard let code = code?.trimmingCharacters(in: .whitespacesAndNewlines), !code.isEmpty else { return nil }
        let base = code.lowercased().split(whereSeparator: { $0 == "-" || $0 == "_" }).first.map(String.init)
        return base == "und" ? nil : base
    }
    static func recordLanguage(_ capture: BubbleCapture, dictionary: WordDictionaryEntry?) -> String? {
        // OCR can mix Chinese/Japanese/Korean prose with long Latin file paths.
        // Classify the prose before trusting the language saved for that capture.
        let prose = capture.source.split(whereSeparator: \.isWhitespace)
            .filter { !$0.contains("/") && !$0.contains("\\") }.joined(separator: " ")
        let detected = detect(prose)
        if let detected, ["zh", "ja", "ko"].contains(detected) { return detected }
        // Short English words are often misidentified by the system recognizer
        // (e.g. Frame as Dutch). ECDICT identifies the source word as English;
        // its language field describes the definitions, not the source.
        if let dictionary, dictionary.source == "ECDICT",
           dictionary.word.trimmingCharacters(in: .whitespacesAndNewlines)
            .caseInsensitiveCompare(capture.source.trimmingCharacters(in: .whitespacesAndNewlines)) == .orderedSame {
            return "en"
        }
        return normalized(capture.sourceLanguage) ?? detected
    }
    static func target(detected: String?, primary: String, secondary: String) -> String {
        detected == primary ? secondary : primary
    }
}

enum BubbleLocalization {
    static func text(_ key: String, _ arguments: CVarArg...) -> String {
        let language = UserDefaults.standard.string(forKey: "bubbleInterfaceLanguage") ?? "zh-Hans"
        let bundle = Bundle.main.url(forResource: language, withExtension: "lproj").flatMap(Bundle.init(url:)) ?? .main
        let format = bundle.localizedString(forKey: key, value: key, table: nil)
        return arguments.isEmpty ? format : String(format: format, locale: Locale(identifier: language), arguments: arguments)
    }
}
