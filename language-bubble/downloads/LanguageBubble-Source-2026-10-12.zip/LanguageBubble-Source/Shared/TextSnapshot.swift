import Foundation

struct TextSnapshot: Equatable, Sendable {
    let document: UUID
    let before: String
    let selected: String
    let after: String
    var text: String { before + selected + after }

    /// Only send the current sentence, not the whole document or a long message history.
    var analysisText: String? {
        if !selected.isEmpty { return eligible(selected) }
        let trimmed = before.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let effective = trimmed.hasSuffix(".") || trimmed.hasSuffix("!") || trimmed.hasSuffix("?")
            ? String(trimmed.dropLast()) : trimmed
        let boundary = effective.rangeOfCharacter(from: CharacterSet(charactersIn: ".!?\n"), options: .backwards)
        let start = boundary.map { effective.distance(from: effective.startIndex, to: $0.upperBound) } ?? 0
        let leadingWhitespaceCount = before.prefix(while: { $0.isWhitespace }).count
        let preceding = String(before.dropFirst(leadingWhitespaceCount + start))
        let following = after.prefix { !".!?\n".contains($0) }
        let complete = trimmed.last.map { ".!?".contains($0) } ?? false
        return eligible(preceding + (complete ? "" : String(following)))
    }

    private func eligible(_ value: String) -> String? {
        let text = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard text.count >= 5, text.count <= 500,
              text.range(of: "[A-Za-z]", options: .regularExpression) != nil,
              text.split(whereSeparator: { $0.isWhitespace }).count >= 2 else { return nil }
        // Conservative local exclusions; this is not a guarantee that all sensitive text is detectable.
        let sensitive = ["https?://", "[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", "[0-9]{8,}", "(?i)(api[_ -]?key|password|验证码)\\s*[:=]"]
        guard !sensitive.contains(where: { text.range(of: $0, options: [.regularExpression, .caseInsensitive]) != nil }) else { return nil }
        return text
    }

    /// Avoid cursor manipulation: replace only a selected exact span or the exact suffix at the cursor.
    func safeReplacement(for issue: WritingIssue) -> Replacement? {
        if selected == issue.original { return Replacement(deleteCount: 0, insert: issue.replacement) }
        guard selected.isEmpty, before.hasSuffix(issue.original),
              after.isEmpty || after.first?.isWhitespace == true || after.first.map({ ".!?;,".contains($0) }) == true
        else { return nil }
        return Replacement(deleteCount: issue.original.count, insert: issue.replacement)
    }
}

struct Replacement: Equatable {
    var deleteCount: Int
    var insert: String
}
