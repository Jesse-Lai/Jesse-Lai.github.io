import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct SyncHTTPError: LocalizedError {
    var status: Int
    var errorDescription: String? {
        switch status {
        case 401: return "连接授权已失效，请重新配对。"
        case 409: return "同步状态已变化，请刷新后重试。"
        case 413: return "图片过大或已达到本机测试存储上限。"
        case 429: return "操作较频繁，请稍后再试。"
        default: return "服务未完成请求（\(status)），请检查本机服务。"
        }
    }
}

struct SyncClient: Sendable {
    var endpoint: String
    var token: String
    var transport: (@Sendable (URLRequest) async throws -> (Data, URLResponse))? = nil
    var timeout: TimeInterval = 25

    func request<T: Decodable>(_ path: String, method: String = "GET", body: Data? = nil,
                               mime: String = "application/json") async throws -> T {
        let data = try await raw(path, method: method, body: body, mime: mime)
        return try BubbleCodec.decoder.decode(T.self, from: data)
    }

    func raw(_ path: String, method: String = "GET", body: Data? = nil,
             mime: String = "application/json") async throws -> Data {
        guard let base = URL(string: endpoint), base.host != nil else { throw ContextError.invalidConfiguration }
        let allowed = ServiceEndpoint.allowed(base)
        guard allowed, base.user == nil, base.password == nil,
              let url = URL(string: endpoint.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + path) else {
            throw ContextError.invalidConfiguration
        }
        var request = URLRequest(url: url)
        request.httpMethod = method; request.httpBody = body; request.timeoutInterval = timeout
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        request.setValue(mime, forHTTPHeaderField: "Content-Type")
        let configuration = URLSessionConfiguration.ephemeral
        configuration.urlCache = nil; configuration.httpCookieStorage = nil
        let session = URLSession(configuration: configuration)
        defer { session.finishTasksAndInvalidate() }
        let data: Data
        let response: URLResponse
        if let transport { (data, response) = try await transport(request) }
        else { (data, response) = try await session.data(for: request) }
        guard let response = response as? HTTPURLResponse else { throw ContextError.invalidResponse }
        guard response.statusCode == 200 else { throw SyncHTTPError(status: response.statusCode) }
        guard data.count < 16 * 1024 * 1024 else { throw ContextError.invalidResponse }
        return data
    }

    func account(name: String) async throws -> DeviceSession {
        try await request("v2/accounts", method: "POST", body: BubbleCodec.encoder.encode(["device_name": name]))
    }
    func pair(code: String, name: String) async throws -> DeviceSession {
        try await request("v2/pair", method: "POST", body: BubbleCodec.encoder.encode(["code": code, "device_name": name]))
    }
    func pull(cursor: Int) async throws -> SyncPage { try await request("v2/sync/pull?cursor=\(cursor)") }
    func push(_ operations: [SyncOperation], epoch: Int) async throws -> AcceptedOperations {
        struct Body: Encodable { var epoch: Int; var operations: [SyncOperation] }
        return try await request("v2/sync/push", method: "POST", body: BubbleCodec.encoder.encode(Body(epoch: epoch, operations: operations)))
    }
}
