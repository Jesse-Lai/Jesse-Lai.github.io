import Foundation

enum ServiceEndpoint {
    static func allowed(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased(), !host.isEmpty,
              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil else { return false }
        if url.scheme == "https" { return true }
        #if DEBUG
        guard url.scheme == "http" else { return false }
        if ["localhost", "127.0.0.1", "::1", "[::1]"].contains(host) { return true }
        if host.hasSuffix(".local"), host.count > 6 { return true }
        let pieces = host.split(separator: ".", omittingEmptySubsequences: false)
        let octets = pieces.compactMap { Int($0) }
        guard octets.count == 4, pieces.count == 4,
              zip(pieces, octets).allSatisfy({ String($0.1) == $0.0 && (0...255).contains($0.1) }) else { return false }
        return octets[0] == 10 || (octets[0] == 172 && (16...31).contains(octets[1])) || (octets[0] == 192 && octets[1] == 168)
        #else
        return false
        #endif
    }
}

enum RecordKind: String, Codable, CaseIterable, Sendable {
    case translation, writing
    var title: String { self == .translation ? "翻译记录" : "写作问题" }
    var symbol: String { self == .translation ? "character.bubble" : "pencil.line" }
}

struct CapturePreferences: Codable, Equatable, Sendable {
    var automaticChecking = false
    var saveTranslations = false
    var saveWritingIssues = false
    // This is the app's proxy endpoint/token, never the upstream model API key.
    var serviceURL = ""
    var serviceToken = ""
    var primaryLanguage: String? = nil
    var secondaryLanguage: String? = nil
}

struct CaptureTicket: Codable, Equatable, Sendable {
    var id = UUID()
    var epoch: Int
    var consentRevision: Int
}

struct CapturedRecord: Codable, Identifiable, Equatable, Sendable {
    var id: UUID
    var epoch: Int
    var kind: RecordKind
    var source: String
    var result: String
    var explanation: String
    var category: String?
    var originalSpan: String?
    var replacement: String?
    var createdAt = Date()
    var dictionary: WordDictionaryEntry? = nil
    var contextMeaning: WordContextMeaning? = nil
}

struct WordDictionaryGroup: Codable, Equatable, Sendable {
    var pos: String
    var meanings: [String]
}

struct WordDictionaryEntry: Codable, Equatable, Sendable {
    var word: String
    var phonetic: String
    var language: String
    var groups: [WordDictionaryGroup]
    var source: String
    var url: String
    var license: String
}

struct WordContextMeaning: Codable, Equatable, Sendable {
    var pos: String
    var meaning: String
    var explanation: String
}

struct WordDictionaryResponse: Decodable, Sendable {
    var status: String
    var entry: WordDictionaryEntry?
}

struct TranslationResult: Codable, Sendable {
    var translation: String
    var explanation: String
    var isMock: Bool? = nil
    var dictionary: WordDictionaryEntry? = nil
    var contextMeaning: WordContextMeaning? = nil
    enum CodingKeys: String, CodingKey {
        case translation, explanation, dictionary
        case isMock = "is_mock"
        case contextMeaning = "context_meaning"
    }
}

struct PolishResult: Codable, Sendable {
    var polished: String
    var explanation: String
    var isMock: Bool? = nil
    enum CodingKeys: String, CodingKey {
        case polished, explanation
        case isMock = "is_mock"
    }
}

struct WritingIssue: Codable, Equatable, Sendable {
    var original: String
    var replacement: String
    var category: String
    var explanation: String
    var confidence: Double

    func isValid(in text: String) -> Bool {
        let categories = ["grammar", "spelling", "collocation", "word_choice"]
        return categories.contains(category) && confidence >= 0.92 && confidence <= 1 &&
            !original.isEmpty && original != replacement && text.components(separatedBy: original).count == 2 &&
            !explanation.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    var categoryTitle: String {
        ["grammar": "语法", "spelling": "拼写", "collocation": "搭配", "word_choice": "用词"][category] ?? "表达"
    }
}

struct CheckResult: Codable, Sendable {
    var complete: Bool
    var issues: [WritingIssue]
    var isMock: Bool? = nil
    enum CodingKeys: String, CodingKey {
        case complete, issues
        case isMock = "is_mock"
    }
    func actionable(in text: String) -> WritingIssue? {
        guard complete else { return nil }
        return issues.first(where: { $0.isValid(in: text) })
    }
}

enum ContextError: LocalizedError {
    case unavailableStorage, invalidConfiguration, automaticCheckingDisabled, service(String), invalidResponse
    var errorDescription: String? {
        switch self {
        case .unavailableStorage: return "无法访问共享记录，请检查 App Group 配置。"
        case .invalidConfiguration: return "服务尚未连接，请先在主 App 中完成设置。"
        case .automaticCheckingDisabled: return "自动检查已暂停，可在键盘或主 App 设置中开启。"
        case .service(let message): return message
        case .invalidResponse: return "未取得有效结果，请重试。"
        }
    }
}
