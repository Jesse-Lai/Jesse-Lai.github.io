import Foundation

struct DeviceSession: Codable, Equatable, Sendable {
    var userId: String
    var deviceId: String
    var token: String
    var epoch: Int
}

struct BubbleCapture: Codable, Identifiable, Equatable, Sendable {
    var id = UUID().uuidString.lowercased()
    var kind = "translation"
    var source: String
    var result: String
    var explanation: String
    var createdAt = Date().timeIntervalSince1970
    var category: String? = nil
    var originalSpan: String? = nil
    var replacement: String? = nil
    var sourceApp: String? = nil
    var sourceUrl: String? = nil
    var surroundingText: String? = nil
    var assetIds: [String] = []
    var isMock = false
    var sourceLanguage: String? = nil
    var targetLanguage: String? = nil
    var dictionary: WordDictionaryEntry? = nil
    var contextMeaning: WordContextMeaning? = nil
}

extension BubbleCapture {
    var sourceLink: URL? { CaptureSourceLink.url(sourceUrl) }

    init(record: CapturedRecord) {
        self.init(id: record.id.uuidString.lowercased(), kind: record.kind.rawValue, source: record.source,
            result: record.result, explanation: record.explanation, createdAt: record.createdAt.timeIntervalSince1970,
            category: record.category, originalSpan: record.originalSpan, replacement: record.replacement,
            sourceApp: record.kind == .translation ? "iOS 系统翻译" : "iOS Composer",
            isMock: record.explanation.contains("AI Mock"), dictionary: record.dictionary, contextMeaning: record.contextMeaning)
    }
}

enum CaptureSourceLink {
    static func url(_ value: Any?) -> URL? {
        let text: String
        if let value = value as? URL { text = value.absoluteString }
        else if let value = value as? String { text = value.trimmingCharacters(in: .whitespacesAndNewlines) }
        else { return nil }
        guard text.count <= 4000, let url = URL(string: text),
              ["https", "http"].contains(url.scheme?.lowercased() ?? ""),
              let host = url.host, !host.isEmpty else { return nil }
        return url
    }
}

// Captures remain immutable sync events. The record list groups encounters so
// existing history and captures arriving from other devices share one entry.
struct BubbleRecord: Identifiable, Sendable {
    struct ID: Hashable, Sendable {
        let kind: String
        let term: String
        let isMock: Bool
    }

    let id: ID
    let encounters: [BubbleCapture]
    var latest: BubbleCapture { encounters[0] }
    var displayTitle: String {
        guard latest.kind == "translation" else { return latest.source }
        let source = latest.source.trimmingCharacters(in: .whitespacesAndNewlines)
        return source.prefix(1).uppercased() + source.dropFirst()
    }
    var sources: [BubbleCapture] {
        let saved = encounters.filter {
            !$0.assetIds.isEmpty || $0.sourceLink != nil || !($0.surroundingText ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        // Lookups without provenance must not bury saved sources under empty
        // blocks. Keep one empty state only when the word has no saved source.
        return saved.isEmpty ? [latest] : saved
    }

    static func key(for capture: BubbleCapture) -> ID {
        // Writing corrections are independent events; case can be the error.
        let term = capture.kind == "translation"
            ? capture.source.split(whereSeparator: \.isWhitespace).joined(separator: " ")
                .precomposedStringWithCanonicalMapping.lowercased(with: Locale(identifier: "en_US_POSIX"))
            : capture.id
        return ID(kind: capture.kind, term: term, isMock: capture.isMock)
    }

    static func grouped(_ captures: [BubbleCapture]) -> [BubbleRecord] {
        Dictionary(grouping: captures, by: key).map { key, values in
            BubbleRecord(id: key, encounters: values.sorted(by: newestFirst))
        }.sorted { newestFirst($0.latest, $1.latest) }
    }

    func matches(_ search: String) -> Bool {
        search.isEmpty || encounters.contains { ($0.source + " " + $0.result).localizedCaseInsensitiveContains(search) }
    }

    private static func newestFirst(_ lhs: BubbleCapture, _ rhs: BubbleCapture) -> Bool {
        lhs.createdAt == rhs.createdAt ? lhs.id < rhs.id : lhs.createdAt > rhs.createdAt
    }
}

struct LearningItem: Codable, Identifiable, Equatable, Sendable {
    var id: String
    var term: String
    var meaning: String
    var explanation: String
    var captureIds: [String]
    var example: String
    var exampleSource: String
    var isMock: Bool
    var state: String
    var successes: Int
    var reviews: Int
    var dueAt: Double
    var intervalDays: Double
    var lastReviewAt: Double?
    var lastSuccessAt: Double?
    var paused: Bool

    func status(at date: Date = Date()) -> String {
        if paused { return "已暂停" }
        if state == "unassessed" { return "待评估" }
        if dueAt <= date.timeIntervalSince1970 { return "建议复习" }
        return state == "stable" ? "较稳固" : "学习中"
    }
}

struct ReviewEvent: Codable, Identifiable, Equatable, Sendable {
    var id = UUID().uuidString.lowercased()
    var learningId: String
    var rating: String
    var reviewedAt: Double? = nil
}

struct SyncOperation: Codable, Identifiable, Sendable {
    var opId = UUID().uuidString.lowercased()
    var action: String
    var entityId: String
    var capture: BubbleCapture? = nil
    var review: ReviewEvent? = nil
    var paused: Bool? = nil
    var profile: StudyProfile? = nil
    var id: String { opId }
}

struct SyncChange: Decodable, Sendable {
    var seq: Int
    var kind: String
    var id: String
    var deleted: Bool
    var capture: BubbleCapture?
    var learning: LearningItem?
    var review: ReviewEvent?
    var profile: StudyProfile?
    var plan: StudyPlan?
    var milestone: StudyMilestone?

    private enum CodingKeys: String, CodingKey { case seq, kind, id, deleted, data }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        seq = try c.decode(Int.self, forKey: .seq)
        kind = try c.decode(String.self, forKey: .kind)
        id = try c.decode(String.self, forKey: .id)
        deleted = try c.decode(Bool.self, forKey: .deleted)
        if !deleted {
            switch kind {
            case "capture": capture = try c.decode(BubbleCapture.self, forKey: .data)
            case "learning": learning = try c.decode(LearningItem.self, forKey: .data)
            case "review": review = try c.decode(ReviewEvent.self, forKey: .data)
            case "profile": profile = try c.decode(StudyProfile.self, forKey: .data)
            case "plan": plan = try c.decode(StudyPlan.self, forKey: .data)
            case "milestone": milestone = try c.decode(StudyMilestone.self, forKey: .data)
            default: throw ContextError.invalidResponse
            }
        }
    }
}

struct SyncPage: Decodable, Sendable {
    var epoch: Int
    var cursor: Int
    var hasMore: Bool
    var changes: [SyncChange]
}

struct PairCode: Codable, Sendable { var code: String; var expiresAt: Double }
struct ServiceHealth: Decodable, Sendable { var status: String; var aiMode: String }
struct AcceptedOperations: Decodable, Sendable { var accepted: [String] }
struct AssetReceipt: Decodable, Sendable { var id: String; var sha256: String }
struct EmptyResponse: Decodable, Sendable {}

enum ArticleSavedWordScope: String, Codable, CaseIterable, Sendable {
    case all, half, recent

    var title: String {
        switch self {
        case .all: return "All"
        case .half: return "Half"
        case .recent: return "Recently saved"
        }
    }
}

enum ArticleVocabularyLevel: String, Codable, CaseIterable, Sendable {
    case mastered
    case unfamiliar
    case notRemembered = "not_remembered"

    static func classify(_ item: LearningItem?) -> Self {
        guard let item else { return .unfamiliar }
        if item.successes >= 3 { return .mastered }
        return item.reviews > 0 && item.successes == 0 ? .notRemembered : .unfamiliar
    }

    var title: String {
        switch self {
        case .mastered: return "已经记住"
        case .unfamiliar: return "不熟悉"
        case .notRemembered: return "未记住"
        }
    }
    var explanation: String {
        switch self {
        case .mastered: return "多次复习后，已能稳定想起"
        case .unfamiliar: return "新收集，或还在逐步熟悉"
        case .notRemembered: return "复习过，但还没能记住"
        }
    }
}

struct LearningArticle: Codable, Identifiable, Equatable, Sendable {
    struct Section: Codable, Equatable, Sendable {
        var heading: String
        var text: String
        var translation: String
        var captureIds: [String]
        var question: String
        var answer: String
    }
    struct Expression: Codable, Equatable, Identifiable, Sendable {
        var text: String
        var meaning: String
        var captureId: String
        var id: String { captureId + ":" + text }
    }
    struct Message: Codable, Equatable, Identifiable, Sendable {
        var id: String
        var role: String
        var text: String
    }
    var id: String
    var title: String
    var summary: String
    var theme: String
    var language: String
    var generatedAt: Double
    var generationId: String
    var captureIds: [String]
    var sections: [Section]
    var expressions: [Expression]
    var messages: [Message]
    var revision: Int
    var wordCount: Int? = nil
    var requestedWordCount: Int? = nil
    var vocabularyLevels: [ArticleVocabularyLevel]? = nil
    var readingMinutes: Int { max(1, (sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count + 149) / 150) }
}

struct ArticleCollection: Codable, Sendable { var articles: [LearningArticle] }

/// Presentation only: existing conversations remain plain Markdown on disk.
/// Recognize question + ordered letter choices without changing ordinary prose.
enum ArticleReplyBlock: Equatable {
    case paragraph(String)
    case quiz(question: String, choices: [String])

    static func parse(_ text: String) -> [ArticleReplyBlock] {
        let lines = text.components(separatedBy: .newlines)
        var blocks: [ArticleReplyBlock] = []
        var prose: [String] = []
        var index = 0
        func paragraph(_ lines: [String]) -> String { lines.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines) }

        while index < lines.count {
            guard let first = choice(lines[index]), first.letter == "A",
                  let questionIndex = prose.lastIndex(where: { !$0.trimmingCharacters(in: .whitespaces).isEmpty }),
                  prose[questionIndex].contains("?") || prose[questionIndex].contains("？") else {
                prose.append(lines[index]); index += 1; continue
            }
            var choices: [String] = []
            var cursor = index
            let letters = Array("ABCDEF")
            while cursor < lines.count, choices.count < letters.count {
                if lines[cursor].trimmingCharacters(in: .whitespaces).isEmpty { cursor += 1; continue }
                guard let option = choice(lines[cursor]), option.letter == letters[choices.count] else { break }
                choices.append("\(option.letter). \(option.text)")
                cursor += 1
            }
            guard choices.count >= 2 else { prose.append(lines[index]); index += 1; continue }
            let preceding = paragraph(Array(prose[..<questionIndex]))
            if !preceding.isEmpty { blocks.append(.paragraph(preceding)) }
            blocks.append(.quiz(question: prose[questionIndex].trimmingCharacters(in: .whitespaces), choices: choices))
            prose = []
            index = cursor
        }
        let remaining = paragraph(prose)
        if !remaining.isEmpty { blocks.append(.paragraph(remaining)) }
        return blocks
    }

    private static func choice(_ line: String) -> (letter: Character, text: String)? {
        var value = line.trimmingCharacters(in: .whitespaces)
        if value.hasPrefix("- ") || value.hasPrefix("* ") { value = String(value.dropFirst(2)) }
        // Both **A.** Answer and **A**. Answer are common Markdown output.
        value = value.replacingOccurrences(of: "**", with: "")
        guard let letter = value.first, "ABCDEF".contains(letter), value.count >= 3 else { return nil }
        let afterLetter = value.dropFirst()
        guard let separator = afterLetter.first, ".)、．:：".contains(separator) else { return nil }
        let answer = afterLetter.dropFirst().trimmingCharacters(in: .whitespaces)
        guard !answer.isEmpty else { return nil }
        return (letter, answer)
    }
}

enum BubbleCodec {
    static var encoder: JSONEncoder { let value = JSONEncoder(); value.keyEncodingStrategy = .convertToSnakeCase; return value }
    static var decoder: JSONDecoder { let value = JSONDecoder(); value.keyDecodingStrategy = .convertFromSnakeCase; return value }
}

struct StudyProfile: Codable, Equatable, Sendable {
    var id = "00000000-0000-0000-0000-000000000001"
    var goal = "daily"
    var dailyMinutes = 10
    var primaryLanguage = "zh"
    var secondaryLanguage = "en"
    static let goals = [("daily", "日常交流"), ("work", "工作沟通"), ("ielts", "雅思"), ("gaokao", "高考"), ("grammar", "语法")]
}
struct StudyTask: Codable, Identifiable, Sendable {
    var id: String
    var learningId: String
    var skill: String
    var instruction: String
    var prompt: String
    var answer: String
    var materialSource: String? = nil
    var captureId: String? = nil
    var evidenceIds: [String]? = nil
}
struct StudyPlan: Codable, Identifiable, Sendable {
    var id: String
    var goal: String
    var dailyMinutes: Int
    var generatedAt: Double
    var title: String
    var isMock: Bool
    var tasks: [StudyTask]
    var explanation: String
    var status: String? = nil
}
struct StudyMilestone: Codable, Identifiable, Sendable {
    var id: String
    var title: String
    var achievedAt: Double
    var acknowledged: Bool
}
