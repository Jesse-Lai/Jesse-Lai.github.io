#if os(macOS)
import Foundation
import Observation

enum DesktopSelectionProbe {
    /// Teams' compose field is eleven ancestors below its AXWebArea. Follow
    /// only the focused/hit ancestor chain, with cycle and time bounds.
    static func ancestors<Node: Equatable>(from start: Node?, parent: (Node) -> Node?,
        shouldContinue: () -> Bool = { true }) -> [Node] {
        var nodes: [Node] = []
        var current = start
        while let node = current, nodes.count < 24, shouldContinue(), !nodes.contains(node) {
            nodes.append(node)
            current = parent(node)
        }
        return nodes
    }

    /// A Chromium selection can arrive after mouse-up while its accessibility
    /// tree starts. Never let a retry outlive the selection or foreground app.
    @MainActor static func read<Value>(shouldContinue: () -> Bool, read: () -> Value?,
        wait: (Duration) async throws -> Void = { try await Task.sleep(for: $0) }) async -> Value? {
        for delay in [220, 160, 260] {
            guard !Task.isCancelled, shouldContinue() else { return nil }
            do { try await wait(.milliseconds(delay)) } catch { return nil }
            guard !Task.isCancelled, shouldContinue() else { return nil }
            if let value = read() { return value }
        }
        return nil
    }
}

/// Snapshot of an editable selection. Identical words at a different location
/// must never be treated as the original replacement target.
struct DesktopPolishSelection {
    let text: String
    let range: NSRange
    let fullValue: String?

    init?(text: String, range: NSRange, fullValue: String?) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              range.location != NSNotFound, range.location >= 0, range.length > 0 else { return nil }
        if let fullValue {
            let length = fullValue.utf16.count
            guard range.location <= length, range.length <= length - range.location,
                  let selected = Range(range, in: fullValue), String(fullValue[selected]) == text else { return nil }
        }
        self.text = text; self.range = range; self.fullValue = fullValue
    }

    func matches(text: String?, range: NSRange?, fullValue: String?) -> Bool {
        text == self.text && range == self.range && (self.fullValue == nil || fullValue == self.fullValue)
    }

    func replacement(_ polished: String) -> String {
        // The service trims its input; keep selected boundary spaces and newlines.
        String(text.prefix(while: \.isWhitespace)) + polished.trimmingCharacters(in: .whitespacesAndNewlines)
            + String(text.reversed().prefix(while: \.isWhitespace).reversed())
    }
}

enum DesktopDocumentURL {
    /// Safari can expose AXDocument on the window; Chromium exposes AXURL on
    /// its web area, often as a CFURL. Never use a page's individual hyperlinks.
    static func find<Node: Equatable>(in window: Node, document: (Node) -> Any?,
        isWebArea: (Node) -> Bool, webURL: (Node) -> Any?, children: (Node) -> [Node],
        focused: Node? = nil, parent: (Node) -> Node? = { _ in nil },
        shouldContinue: () -> Bool = { true }) -> String? {
        if let url = CaptureSourceLink.url(document(window)) { return url.absoluteString }
        if let url = CaptureSourceLink.url(webURL(window)) { return url.absoluteString }
        // The focused ancestor chain avoids scanning a large browser tab strip.
        // Require it to reach this window, and prefer the outermost web area.
        var ancestor = focused
        var source: URL?
        for _ in 0..<24 {
            guard let node = ancestor, shouldContinue() else { break }
            if node == window {
                if let source { return source.absoluteString }
                break
            }
            if isWebArea(node) { source = CaptureSourceLink.url(webURL(node)) }
            ancestor = parent(node)
        }
        var queue = [(window, 0)]
        var visited: [Node] = []
        var index = 0
        while index < queue.count, index < 160, shouldContinue() {
            let (node, depth) = queue[index]; index += 1
            guard !visited.contains(node) else { continue }
            visited.append(node)
            if isWebArea(node) {
                if let url = CaptureSourceLink.url(webURL(node)) { return url.absoluteString }
                // An embedded document is not the containing page's address.
                continue
            }
            if depth < 12 {
                queue.append(contentsOf: children(node).prefix(160 - queue.count).map { ($0, depth + 1) })
            }
        }
        return nil
    }
}

/// Reserve the whole capture operation, including the time spent choosing a region or running OCR.
@MainActor @Observable
final class DesktopCaptureGate {
    private(set) var active: UUID?
    func acquire(querying: Bool) -> UUID? {
        guard active == nil, !querying else { return nil }
        let id = UUID(); active = id
        return id
    }
    func release(_ id: UUID) {
        if active == id { active = nil }
    }
}

enum DesktopSceneGeometry {
    /// Transient working area for paragraph recognition. Capture the full visible
    /// source display so neither long lines nor wrapped sentences are cut off;
    /// only the subsequent text-shaped cutout is retained.
    static func selectionCrop(around anchor: CGRect, screens: [CGRect]) -> (screen: Int, rectangle: CGRect)? {
        guard !anchor.isNull, !anchor.isInfinite, anchor.width > 0, anchor.height > 0,
              let best = screens.indices.max(by: {
                  area(screens[$0].intersection(anchor)) < area(screens[$1].intersection(anchor))
              }), area(screens[best].intersection(anchor)) > 0 else { return nil }
        return (best, screens[best])
    }

    static func bubbleFrame(near anchor: CGRect, size: CGSize, visible: CGRect) -> CGRect {
        let x = min(max(anchor.midX - size.width / 2, visible.minX + 4), visible.maxX - size.width - 4)
        let above = anchor.maxY + 8
        let y = above + size.height <= visible.maxY - 4 ? above : anchor.minY - size.height - 8
        return CGRect(x: x, y: min(max(y, visible.minY + 4), visible.maxY - size.height - 4),
                      width: size.width, height: size.height)
    }

    static func axPoint(_ point: CGPoint, primaryHeight: CGFloat) -> CGPoint {
        CGPoint(x: point.x, y: primaryHeight - point.y)
    }

    /// AppKit and Vision both use a bottom-left origin. Normalize against the actual
    /// crop (which shifts near display edges), independent of Retina pixel scaling.
    static func normalizedPoint(_ point: CGPoint, in crop: CGRect) -> CGPoint? {
        guard point.x.isFinite, point.y.isFinite, !crop.isNull, !crop.isInfinite,
              crop.width > 0, crop.height > 0, crop.contains(point) else { return nil }
        return CGPoint(x: (point.x - crop.minX) / crop.width, y: (point.y - crop.minY) / crop.height)
    }

    /// AX uses a top-left origin on the primary display; AppKit uses its bottom-left origin.
    static func appKitRect(_ axRect: CGRect, primaryHeight: CGFloat) -> CGRect {
        CGRect(x: axRect.minX, y: primaryHeight - axRect.maxY, width: axRect.width, height: axRect.height)
    }

    static func crop(around anchor: CGRect, screens: [CGRect]) -> (screen: Int, rectangle: CGRect)? {
        guard !anchor.isNull, !anchor.isInfinite, anchor.width > 0, anchor.height > 0,
              let best = screens.indices.max(by: {
                  area(screens[$0].intersection(anchor)) < area(screens[$1].intersection(anchor))
              }), area(screens[best].intersection(anchor)) > 0 else { return nil }
        let visibleAnchor = anchor.intersection(screens[best])
        let width = min(max(700, visibleAnchor.width + 80), screens[best].width)
        let height = min(max(320, visibleAnchor.height + 80), screens[best].height)
        let x = min(max(visibleAnchor.midX - width / 2, screens[best].minX), screens[best].maxX - width)
        let y = min(max(visibleAnchor.midY - height / 2, screens[best].minY), screens[best].maxY - height)
        return (best, CGRect(x: x, y: y, width: width, height: height))
    }

    private static func area(_ rect: CGRect) -> CGFloat { rect.isNull ? 0 : rect.width * rect.height }
}
#endif
