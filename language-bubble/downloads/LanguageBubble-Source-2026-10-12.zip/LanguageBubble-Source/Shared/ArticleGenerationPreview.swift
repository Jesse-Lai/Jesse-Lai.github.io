import Foundation
import Observation

/// An in-memory demo. It never calls the AI service or writes to the synced library.
@MainActor @Observable
final class ArticleGenerationPreview: Identifiable {
    enum Step: Int, CaseIterable {
        case outline, research, writing, images, artifact
        var title: String {
            ["梳理学习大纲", "查找摄影教程", "撰写学习文章", "添加示例图片", "制作互动练习"][rawValue]
        }
        var duration: Duration { .seconds(rawValue <= Step.writing.rawValue ? 3 : 5) }
        var detail: String {
            ["将学习思路整理成清晰的大纲。",
             "准备本地预览中包含的摄影教程。",
             "逐步撰写各个章节的内容。",
             "添加直观的示例图片，帮助理解。",
             "准备可以动手尝试的词汇练习。"][rawValue]
        }
    }

    struct OutlineItem: Equatable {
        var heading: String
        var detail: String
    }

    private(set) var article: LearningArticle
    private(set) var outline: [OutlineItem]
    private(set) var outlineFeedback: String?
    let request: String
    // Bundled lessons open as finished reading material without replaying generation.
    let opensAsFinishedArticle: Bool
    private(set) var imageAsset: String
    private(set) var imageCaption: String
    nonisolated let id: String
    private(set) var step: Step = .outline
    private(set) var outlineVisible = false
    private(set) var visibleCharacters = 0
    private(set) var isComplete = false
    private(set) var completionMessageID: String?
    private(set) var isRunning = false
    private(set) var isStopped = false
    private(set) var outlineConfirmationMessageID: String?
    private(set) var outlineApprovalMessageIDs = Set<String>()
    var isAwaitingOutlineConfirmation: Bool { outlineConfirmationMessageID != nil }
    private(set) var runID = UUID()
    private var activeRun: UUID?
    private var stepElapsed: Duration = .zero
    // Active processing time for this attempt. Waiting for approval, Stop,
    // navigation, discard animations and later local edits do not add time.
    @ObservationIgnored private var thinkingElapsed: Duration = .zero
    private(set) var thinkingSeconds = 0
    var isThinkingExpanded = true
    var isGenerating: Bool { !isComplete && !isStopped && !isAwaitingOutlineConfirmation && rewind == nil }
    enum PlanAdjustmentPhase { case submitted, reviewing }
    private(set) var planAdjustmentPhase: PlanAdjustmentPhase?
    private var planAdjustmentInstruction = ""
    private var planAdjustmentElapsed: Duration = .zero
    private(set) var latestPlanMessageID: String?
    var isShowingRevisedOutline: Bool { planAdjustmentPhase == .reviewing }
    private(set) var teachesCameraParts = false
    var isRewinding: Bool { rewind != nil }
    var discardingStep: Step? { rewind?.step }
    private(set) var generationNotes: [Step: String] = [:]
    private(set) var practice = Practice.vocabulary
    private var checkpoints: [Step: Checkpoint] = [:]
    private var rewind: Rewind?
    private struct Checkpoint {
        var article: LearningArticle
        let outline: [OutlineItem]
        var imageAsset: String
        var imageCaption: String
        let practice: Practice
        let notes: [Step: String]
        let messageCount: Int
        let teachesCameraParts: Bool
        let latestPlanMessageID: String?
    }
    private struct Rewind {
        let step: Step
        let instruction: String
        let checkpoint: Checkpoint
        let discardedMessages: Set<String>
    }
    struct Practice: Equatable {
        var question: String
        var choices: [String]
        var answer: Int
        var explanation: String
        // Chinese guidance with English choices for vocabulary practice.
        static let vocabulary = Practice(question: "resilient 在文中表达什么含义？",
            choices: ["Recovers from difficulties", "Avoids difficulties", "Solves problems quickly", "Works independently"],
            answer: 0, explanation: "resilient 表示有韧性，能够从困难或挫折中恢复。")
        static let cameraParts = Practice(question: "拍照时，需要按下相机的哪个部件？",
            choices: ["The shutter release", "The film rewind knob", "The camera body", "The battery-check switch"],
            answer: 0, explanation: "shutter release 是快门按钮，按下它会触发快门并拍摄照片。")

        func label(at index: Int) -> String { String(UnicodeScalar(65 + index)!) }
        var prompt: String {
            question + "\n" + choices.enumerated().map { label(at: $0.offset) + ". " + $0.element }.joined(separator: "\n")
        }
    }
    var messages: [LearningArticle.Message] = []
    var quizSelection: Int?
    private var characterCounts: [Int]
    private var sectionCharacters: [[Character]]
    var localSelection: LocalSelection?
    private(set) var quotedSelection: LocalSelection?
    private(set) var localEdit: LocalEdit?
    private var localImageElapsed: Duration = .zero
    private(set) var localEditComments: [String: LocalEdit] = [:]
    var canEditLocally: Bool { isComplete && !isRewinding && localEdit == nil }
    var localImageProgress: Double? {
        guard localEdit?.selection.target == .image else { return nil }
        return min(1, Double(localImageElapsed / .milliseconds(1)) / Double(Step.images.duration / .milliseconds(1)))
    }

    init(article: LearningArticle, request: String, imageAsset: String, imageCaption: String,
         outline: [OutlineItem]? = nil, initiallyComplete: Bool = false, practice: Practice = .vocabulary) {
        self.id = article.id
        self.article = article
        self.outline = outline ?? article.sections.map { OutlineItem(heading: $0.heading, detail: $0.text) }
        self.request = request
        self.opensAsFinishedArticle = initiallyComplete
        self.practice = practice
        self.imageAsset = imageAsset
        self.imageCaption = imageCaption
        sectionCharacters = article.sections.map { Array($0.text) }
        characterCounts = article.sections.map { $0.text.count }
        if initiallyComplete {
            step = .artifact
            outlineVisible = true
            visibleCharacters = totalCharacters
            isComplete = true
            isThinkingExpanded = false
            // Retain regeneration and quoting for finished lessons. There is no
            // fabricated processing time or approval exchange on initial load.
            for stage in Step.allCases { checkpoints[stage] = currentCheckpoint() }
            appendCompletion()
        }
    }

    // Gate the content and its placeholders together. Pausing keeps the current
    // stage visible; reviewing a revised outline hides every downstream output.
    var showsArticleText: Bool {
        outlineVisible && !isShowingRevisedOutline && (step.rawValue >= Step.writing.rawValue || isComplete)
    }
    var showsArticleOutline: Bool { outlineVisible && !showsArticleText }
    var showsImages: Bool { showsArticleText && (step.rawValue >= Step.images.rawValue || isComplete) }
    var showsArtifact: Bool { showsArticleText && (step == .artifact || isComplete) }
    var imagesReady: Bool { showsImages && (step == .artifact || isComplete) }
    var artifactReady: Bool { showsArtifact && isComplete }
    var researchReady: Bool { step.rawValue > Step.research.rawValue || isComplete }
    // 800 ms wipe + up to 68 frames of particle life at 60 Hz, with capture headroom.
    static let discardDuration: Duration = .milliseconds(2100)
    var imageProgress: Double? {
        guard step == .images else { return nil }
        return min(1, Double(stepElapsed / .milliseconds(1)) / Double(step.duration / .milliseconds(1)))
    }
    var totalCharacters: Int { characterCounts.reduce(0, +) }
    var writingSectionIndex: Int? {
        guard step == .writing, !characterCounts.isEmpty else { return nil }
        var end = 0
        for index in characterCounts.indices {
            end += characterCounts[index]
            if visibleCharacters < end { return index }
        }
        return characterCounts.indices.last
    }
    var progress: Double {
        if isComplete { return 1 }
        if isAwaitingOutlineConfirmation { return 1 / Double(Step.allCases.count) }
        let fraction = step == .writing ? Double(visibleCharacters) / Double(max(1, totalCharacters)) : 0
        return (Double(step.rawValue) + fraction) / Double(Step.allCases.count)
    }
    func text(at index: Int) -> String {
        guard sectionCharacters.indices.contains(index) else { return "" }
        let preceding = characterCounts.prefix(index).reduce(0, +)
        return String(sectionCharacters[index].prefix(max(0, visibleCharacters - preceding)))
    }
    func showsSection(at index: Int) -> Bool {
        guard showsArticleText, characterCounts.indices.contains(index) else { return false }
        return step != .writing || isComplete || index <= (writingSectionIndex ?? 0)
    }
    func isWritingSection(_ index: Int) -> Bool {
        guard isGenerating, step == .writing, characterCounts.indices.contains(index) else { return false }
        let preceding = characterCounts.prefix(index).reduce(0, +)
        return visibleCharacters >= preceding && visibleCharacters < preceding + characterCounts[index]
    }

    /// View cancellation pauses; explicit Stop remains stopped when the reader reopens.
    /// A run token prevents cancelled work from publishing after a steer or resume.
    func run(reduceMotion: Bool = false, delay: @MainActor (Duration) async throws -> Void = { try await Task.sleep(for: $0) }) async {
        guard isGenerating || isRewinding || localEdit != nil else { return }
        let token = UUID()
        activeRun = token
        isRunning = true
        defer {
            if activeRun == token { activeRun = nil; isRunning = false }
        }
        do {
            if let edit = localEdit {
                if edit.selection.target == .image {
                    while localImageElapsed < Step.images.duration {
                        let tick = min(.milliseconds(30), Step.images.duration - localImageElapsed)
                        try await delay(tick)
                        try Task.checkCancellation()
                        guard activeRun == token, localEdit?.id == edit.id else { return }
                        localImageElapsed += tick
                    }
                } else {
                    try await delay(.seconds(3))
                }
                try Task.checkCancellation()
                guard activeRun == token, localEdit?.id == edit.id else { return }
                commitLocalEdit(edit)
                return
            }
            if rewind != nil {
                // Both panes retain their old content for the exit animation before the cut commits.
                try await delay(reduceMotion ? .milliseconds(120) : Self.discardDuration)
                try Task.checkCancellation()
                guard activeRun == token else { return }
                commitRegeneration()
            }
            saveCheckpointIfNeeded()
            while !isComplete {
                if let phase = planAdjustmentPhase {
                    // Keep the submitted message visible before presenting the revised plan.
                    // A cancellable clock also preserves this phase across stop and navigation.
                    let duration: Duration = phase == .submitted ? .milliseconds(650) : .seconds(4)
                    let tick = min(.milliseconds(30), duration - planAdjustmentElapsed)
                    try await delay(tick)
                    try Task.checkCancellation()
                    guard activeRun == token, isGenerating else { return }
                    planAdjustmentElapsed += tick
                    recordThinkingTime(tick)
                    if planAdjustmentElapsed >= duration {
                        if phase == .submitted { applyPlanAdjustment() }
                        else { planAdjustmentPhase = nil; planAdjustmentElapsed = .zero }
                    }
                    continue
                }
                let tick = min(.milliseconds(30), step.duration - stepElapsed)
                try await delay(tick)
                try Task.checkCancellation()
                guard activeRun == token, isGenerating else { return }
                stepElapsed += tick
                recordThinkingTime(tick)
                if step == .outline && stepElapsed >= .seconds(1) { outlineVisible = true }
                if step == .writing {
                    let fraction = Double(stepElapsed / .milliseconds(1)) / 3000
                    visibleCharacters = min(totalCharacters, Int(Double(totalCharacters) * fraction))
                }
                if stepElapsed >= step.duration {
                    if step == .outline {
                        outlineVisible = true
                        append(Self.outlineConfirmationPrompt, role: "assistant")
                        outlineConfirmationMessageID = messages.last?.id
                        return
                    } else if step == .artifact {
                        isComplete = true
                        isThinkingExpanded = false
                        appendCompletion()
                    } else {
                        step = Step(rawValue: step.rawValue + 1)!
                        stepElapsed = .zero
                        saveCheckpointIfNeeded()
                    }
                }
            }
        } catch { /* A disappeared reader pauses at its last published tick. */ }
    }

    private func recordThinkingTime(_ duration: Duration) {
        thinkingElapsed += duration
        let seconds = Int(thinkingElapsed / .seconds(1))
        if thinkingSeconds != seconds { thinkingSeconds = seconds }
    }

    func stop() {
        guard isGenerating else { return }
        isStopped = true
        invalidateRun()
        append("已暂停生成，大纲和已生成的内容都已保留。准备好后可以继续，也可以告诉我需要调整的地方。", role: "assistant")
    }

    func resume() {
        guard isStopped, !isComplete else { return }
        isStopped = false
        invalidateRun()
    }

    private func invalidateRun() {
        activeRun = nil
        isRunning = false
        runID = UUID()
    }

    private func append(_ text: String, role: String) {
        messages.append(.init(id: UUID().uuidString, role: role, text: text))
    }

    static let outlineConfirmationPrompt = "要按照大纲计划，继续生成学习内容吗？"
    static let directGenerationChoice = "确认并生成"

    /// Updating requirements never approves the outline or starts downstream work.
    @discardableResult
    func reviseOutline(_ instruction: String) -> Bool {
        let note = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
        guard isAwaitingOutlineConfirmation, !isRewinding, !note.isEmpty, note.count <= 2000 else { return false }
        append(note, role: "user")
        generationNotes[.outline] = note
        if applyTextInstruction(note) != nil {
            outlineFeedback = "大纲已更新，请确认后继续。"
        } else {
            outlineFeedback = "当前本地演示支持替换词语和缩短正文；这条要求暂不能自动应用，大纲保持不变。"
        }
        sectionCharacters = article.sections.map { Array($0.text) }
        characterCounts = sectionCharacters.map(\.count)
        article.wordCount = article.sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count
        append(outlineFeedback!, role: "assistant")
        return true
    }

    /// Only an explicit choice at the outline gate can start the remaining stages.
    @discardableResult
    func confirmOutline(instruction: String? = nil) -> Bool {
        guard isAwaitingOutlineConfirmation, !isRewinding else { return false }
        let note = instruction?.trimmingCharacters(in: .whitespacesAndNewlines)
        if let note, note.isEmpty || note.count > 2000 { return false }
        append(note ?? Self.directGenerationChoice, role: "user")
        if note == nil, let id = messages.last?.id { outlineApprovalMessageIDs.insert(id) }
        if let note {
            generationNotes[.outline] = note
            let acknowledgement = applyTextInstruction(note)
            sectionCharacters = article.sections.map { Array($0.text) }
            characterCounts = sectionCharacters.map(\.count)
            article.wordCount = article.sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count
            append(acknowledgement ?? "已收到补充要求。当前本地演示支持替换词语和缩短正文；这条要求暂不能自动应用，将按当前大纲继续生成。", role: "assistant")
        }
        outlineConfirmationMessageID = nil
        outlineFeedback = nil
        step = .research
        stepElapsed = .zero
        isStopped = false
        // Later reruns retain the confirmed outline and the user's choice.
        saveCheckpointIfNeeded()
        invalidateRun()
        return true
    }

    /// Deterministic local steering, with explicit feedback when a request is unsupported.
    func steer(_ instruction: String) {
        let instruction = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !instruction.isEmpty, instruction.count <= 2000, !isComplete, !isRewinding,
              planAdjustmentPhase != .submitted else { return }
        if isAwaitingOutlineConfirmation {
            reviseOutline(instruction)
            return
        }
        append(instruction, role: "user")
        if step != .outline {
            planAdjustmentInstruction = instruction
            planAdjustmentPhase = .submitted
            planAdjustmentElapsed = .zero
            isStopped = false
            invalidateRun()
            return
        }
        guard let acknowledgement = applyTextInstruction(instruction) else {
            append("当前本地演示支持替换文章中的词语或缩短正文。可以试试“把摄影机换成单反相机”或“写短一点”。如果内容已经更新，就无需重复修改。", role: "assistant")
            return
        }
        let fraction = totalCharacters == 0 ? 0 : Double(visibleCharacters) / Double(totalCharacters)
        sectionCharacters = article.sections.map { Array($0.text) }
        characterCounts = sectionCharacters.map(\.count)
        visibleCharacters = min(totalCharacters, Int(Double(totalCharacters) * fraction))
        article.wordCount = article.sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count
        if step.rawValue > Step.writing.rawValue {
            // Downstream assets have to wait for the revised article.
            step = .writing
            stepElapsed = .zero
            visibleCharacters = 0
        }
        checkpoints = checkpoints.filter { $0.key.rawValue <= step.rawValue }
        isStopped = false
        quizSelection = nil
        invalidateRun()
        append(acknowledgement, role: "assistant")
    }

    private func applyPlanAdjustment() {
        let instruction = planAdjustmentInstruction
        let wasCameraParts = teachesCameraParts
        guard let acknowledgement = applyTextInstruction(instruction) else {
            append("这条要求暂时无法在演示中应用。可以试试“教我一些照相机的部件知识”、“把相机换成单反相机”或“写短一点”。我会继续当前计划。", role: "assistant")
            planAdjustmentPhase = nil
            planAdjustmentElapsed = .zero
            return
        }
        generationNotes[.outline] = instruction
        sectionCharacters = article.sections.map { Array($0.text) }
        characterCounts = sectionCharacters.map(\.count)
        article.wordCount = article.sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count
        step = step.rawValue >= Step.writing.rawValue ? .writing : .research
        stepElapsed = .zero
        visibleCharacters = 0
        outlineVisible = true
        outlineFeedback = nil
        quizSelection = nil
        checkpoints = checkpoints.filter { $0.key.rawValue <= step.rawValue }
        append(acknowledgement, role: "assistant")
        latestPlanMessageID = messages.last?.id
        if teachesCameraParts && !wasCameraParts {
            // A new lesson focus becomes the baseline of downstream reruns.
            checkpoints = checkpoints.filter { $0.key == .outline }
            checkpoints[.research] = currentCheckpoint()
            if step == .writing { checkpoints[.writing] = currentCheckpoint() }
        }
        planAdjustmentPhase = .reviewing
        planAdjustmentElapsed = .zero
    }

    private func applyTextInstruction(_ instruction: String) -> String? {
        let normalized = instruction.lowercased()
        if article.theme.lowercased().contains("photo"),
           ["相机", "摄影机", "camera"].contains(where: normalized.contains),
           ["部件", "结构", "构造", "parts", "components", "anatomy"].contains(where: normalized.contains) {
            return applyCameraPartsPlan()
        }
        let oldArticle = article
        let oldOutline = outline
        let oldCaption = imageCaption
        var acknowledgement: String?
        if let (source, target) = Self.replacement(instruction) {
            func replace(_ value: String) -> String {
                // Protect the target so camera → DSLR camera is idempotent.
                let marker = "\u{E000}replacement\u{E001}"
                let protected = value.replacingOccurrences(of: target, with: marker, options: .caseInsensitive)
                let pattern = "(?<![\\p{L}\\p{N}])" + NSRegularExpression.escapedPattern(for: source) + "(?![\\p{L}\\p{N}])"
                guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else { return value }
                let replaced = regex.stringByReplacingMatches(in: protected, range: NSRange(protected.startIndex..., in: protected),
                    withTemplate: NSRegularExpression.escapedTemplate(for: target))
                return replaced.replacingOccurrences(of: marker, with: target)
            }
            article.title = replace(article.title)
            article.summary = replace(article.summary)
            for index in article.sections.indices {
                article.sections[index].heading = replace(article.sections[index].heading)
                article.sections[index].text = replace(article.sections[index].text)
            }
            imageCaption = replace(imageCaption)
            for index in outline.indices {
                outline[index].heading = replace(outline[index].heading)
                outline[index].detail = replace(outline[index].detail)
            }
            if article != oldArticle || outline != oldOutline || imageCaption != oldCaption {
                // Make the revised photography focus visible in the already-created outline.
                if source.lowercased() == "camera", article.theme.lowercased().contains("photo"), !article.sections.isEmpty {
                    article.sections[0].heading = "Start with your " + target
                    article.summary = "Explore photography with your \(target) through a small everyday experiment — and pick up a few useful English words along the way."
                    imageCaption += " A composition to practise with your \(target)."
                }
                acknowledgement = "好的，已将 \(source) 改为 \(target)，并同步调整大纲和正文，接下来会按新计划继续生成。"
            }
        } else if Self.requestsSimplerVocabulary(instruction) {
            // The local preview has a bounded vocabulary rewrite. Keep lesson
            // terms (journey, shutter, lens, orbit) and the section structure.
            let replacements = [
                "entrance": "door", "photograph": "picture", "photographs": "pictures",
                "purpose": "goal", "judge": "check", "familiar": "well-known",
                "recommends": "suggests", "adjusting": "changing", "viewer": "person",
                "relationship": "connection", "deliberate": "planned", "mechanism": "inner parts",
                "destination": "place to reach", "intention": "plan", "approximately": "about",
                "demonstrates": "shows", "observe": "watch", "enormous": "very big"
            ]
            for index in article.sections.indices {
                var text = article.sections[index].text
                for (word, simpler) in replacements {
                    let pattern = "(?<![\\p{L}\\p{N}])" + word + "(?![\\p{L}\\p{N}])"
                    guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else { continue }
                    for match in regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).reversed() {
                        guard let range = Range(match.range, in: text) else { continue }
                        let replacement = text[range].first?.isUppercase == true
                            ? simpler.prefix(1).uppercased() + simpler.dropFirst() : simpler
                        text.replaceSubrange(range, with: replacement)
                    }
                }
                article.sections[index].text = text
            }
            acknowledgement = "好的，我会用更常见的词语改写正文，保留学习内容和关键术语。"
        } else if ["shorter", "more concise", "写短", "简短", "精简"].contains(where: { instruction.lowercased().contains($0) }) {
            for index in article.sections.indices {
                let sentences = article.sections[index].text.components(separatedBy: ". ")
                article.sections[index].text = sentences.prefix(2).joined(separator: ". ")
                if !article.sections[index].text.hasSuffix(".") { article.sections[index].text += "." }
            }
            for index in outline.indices {
                outline[index].detail = outline[index].detail.components(separatedBy: ". ").prefix(1).joined()
                if !outline[index].detail.hasSuffix(".") { outline[index].detail += "." }
            }
            acknowledgement = "好的，我精简了大纲和正文，每个章节只保留核心内容，接下来会按新计划继续生成。"
        }
        return acknowledgement
    }

    private func applyCameraPartsPlan() -> String {
        teachesCameraParts = true
        article.title = "Get to Know Your Camera: Parts and Functions"
        article.summary = "Learn camera parts through a hands-on 3D exploration and a quick vocabulary challenge."
        outline = [
            .init(heading: "Start with the camera body:", detail: "Identify the body, lens and shutter release, and learn what each part does."),
            .init(heading: "Explore a camera in 3D:", detail: "Rotate a 3D Canon AT-1 and take it apart to discover its controls and practise their English names."),
            .init(heading: "Match each part to its job:", detail: "Use an interactive challenge to connect the shutter release, speed dial and film controls with their functions."),
            .init(heading: "Put the words into practice:", detail: "Describe how you would take a photograph using the camera-part vocabulary you have learned.")
        ]
        let content = [
            "Look at a camera before you take a picture. The camera body holds the mechanism and protects it from unwanted light. The lens focuses light, and the shutter controls how long that light reaches the film or sensor.\n\nFind the shutter release: it is the button you press to take a photograph. Say the name aloud, then point to the body and the lens. Each word names a part with a different job.",
            "Explore the Canon AT-1 below. This is a film SLR camera. Drag to rotate it, then move the slider to separate the controls. Select Body, Shutter or Speed dial to learn a part's name and function.\n\nThe shutter-speed dial sets the exposure time. The film advance lever moves the film to the next frame. The rewind knob returns exposed film to its cartridge. Compare these controls as you rotate the model.",
            "Imagine you are ready to take a photograph. Which part do you press? Choose the shutter release. Which control changes the exposure time? Find the shutter-speed dial.\n\nTry the same challenge on the model: select a part, read its explanation, then hide the explanation and describe its job. The battery-check switch checks the battery; it does not release the shutter.",
            "Use the words in a short sequence: I hold the camera body, choose a shutter speed and press the shutter release. With this film camera, I use the film advance lever before the next photograph.\n\nNow rotate the model once more and name three parts without looking at their labels. Finish with the quick quiz to check which word and function you remember."
        ]
        article.sections = zip(outline, content).map { item, text in
            .init(heading: String(item.heading.dropLast()), text: text, translation: "", captureIds: [], question: "", answer: "")
        }
        practice = .cameraParts
        return "好的，我调整了计划，用互动游戏的方式介绍一些单反相机的结构知识。"
    }

    func isDiscarding(_ candidate: Step) -> Bool {
        guard let discardingStep else { return false }
        return candidate.rawValue >= discardingStep.rawValue
    }

    func isDiscardingMessage(_ id: String) -> Bool { rewind?.discardedMessages.contains(id) == true }

    /// The selected step is rebuilt; all strictly earlier outputs and messages are retained.
    @discardableResult
    func regenerate(from selected: Step, instruction: String) -> Bool {
        let instruction = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
        guard canEditLocally, !instruction.isEmpty, instruction.count <= 2000,
              let checkpoint = checkpoints[selected] else { return false }
        localSelection = nil
        rewind = Rewind(step: selected, instruction: instruction, checkpoint: checkpoint,
            discardedMessages: Set(messages.dropFirst(checkpoint.messageCount).map(\.id)))
        invalidateRun()
        return true
    }

    private func saveCheckpointIfNeeded() {
        guard checkpoints[step] == nil else { return }
        checkpoints[step] = currentCheckpoint()
    }

    private func currentCheckpoint() -> Checkpoint {
        Checkpoint(article: article, outline: outline, imageAsset: imageAsset, imageCaption: imageCaption,
            practice: practice, notes: generationNotes, messageCount: messages.count,
            teachesCameraParts: teachesCameraParts, latestPlanMessageID: latestPlanMessageID)
    }

    private func commitRegeneration() {
        guard let transaction = rewind else { return }
        let saved = transaction.checkpoint
        article = saved.article
        outline = saved.outline
        outlineFeedback = nil
        imageAsset = saved.imageAsset
        imageCaption = saved.imageCaption
        practice = saved.practice
        teachesCameraParts = saved.teachesCameraParts
        latestPlanMessageID = saved.latestPlanMessageID
        planAdjustmentPhase = nil
        planAdjustmentElapsed = .zero
        generationNotes = saved.notes
        messages = Array(messages.prefix(saved.messageCount))
        localEditComments = localEditComments.filter { entry in messages.contains { $0.id == entry.key } }
        outlineApprovalMessageIDs.formIntersection(Set(messages.map(\.id)))
        checkpoints = checkpoints.filter { $0.key.rawValue < transaction.step.rawValue }
        step = transaction.step
        stepElapsed = .zero
        thinkingElapsed = .zero
        thinkingSeconds = 0
        isComplete = false
        completionMessageID = nil
        isThinkingExpanded = true
        isStopped = false
        outlineConfirmationMessageID = nil
        outlineVisible = step != .outline
        quizSelection = nil
        // Save before the new correction so another rerun of this node also discards this branch.
        saveCheckpointIfNeeded()
        generationNotes[step] = transaction.instruction
        switch step {
        case .outline, .writing:
            _ = applyTextInstruction(transaction.instruction)
            if step == .writing {
                // The outline belongs to the previous completed node, so preserve it exactly.
                article.title = saved.article.title
                article.summary = saved.article.summary
                outline = saved.outline
                let revisedSections = article.sections
                article.sections = saved.article.sections.enumerated().map { index, original in
                    var section = original
                    if revisedSections.indices.contains(index) { section.text = revisedSections[index].text }
                    return section
                }
            }
        case .research:
            // This preview reuses its bundled tutorial; no network research is performed.
            break
        case .images:
            let note = transaction.instruction.lowercased()
            if note.contains("建筑") || note.contains("building") {
                imageAsset = "ArticleLeadingLinesBuilding"
                imageCaption = "Follow the edges of the building: architectural lines give the eye a route through the frame."
            } else if note.contains("人像") || note.contains("portrait") {
                imageAsset = "ArticleLeadingLinesPortraitWall"
                imageCaption = "Notice how the wall leads your attention toward the person."
            } else if note.contains("树") || note.contains("forest") || note.contains("树林") {
                imageAsset = "ArticleLeadingLinesOaks"
                imageCaption = "Follow the avenue of trees toward the light."
            } else {
                imageCaption = "\(saved.imageCaption) Visual focus: \(transaction.instruction)"
            }
        case .artifact:
            let note = transaction.instruction.lowercased()
            if note.contains("compare") || note.contains("比较") {
                practice = Practice(question: "比较第一次和第二次尝试时，compare 要求你做什么？",
                    choices: ["Repeat without looking", "Look for similarities and differences", "Choose the newest result"],
                    answer: 1, explanation: "compare 表示比较，也就是找出事物之间的相同点和不同点。")
            } else if note.contains("notice") || note.contains("注意") {
                practice = Practice(question: "留意一个吸引你的细节，这里的 notice 是什么意思？",
                    choices: ["Become aware of something", "Change something on purpose", "Ignore the details"],
                    answer: 0, explanation: "notice 表示注意到或察觉某件事。")
            } else {
                practice = saved.practice
            }
        }
        sectionCharacters = article.sections.map { Array($0.text) }
        characterCounts = sectionCharacters.map(\.count)
        visibleCharacters = step.rawValue > Step.writing.rawValue ? totalCharacters : 0
        if step.rawValue <= Step.writing.rawValue {
            article.wordCount = article.sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count
        }
        append(transaction.instruction, role: "user")
        append("将从“\(step.title)”开始重新生成。此前的内容已保留，我会根据你的要求更新这一步及后续内容。", role: "assistant")
        rewind = nil
    }

    private static func replacement(_ instruction: String) -> (String, String)? {
        let patterns = [#"(?:把|将)\s*(.+?)\s*(?:替换为|替换成|换成|改成|改为)\s*(.+?)[。！!]*$"#,
                        #"(?:replace|change)\s+(.+?)\s+(?:with|to)\s+(.+?)[.!]*$"#]
        let aliases = ["摄影机": "camera", "相机": "camera", "单反相机": "DSLR camera", "单反": "DSLR camera",
                       "手机": "phone", "绿色的门": "green door", "绿门": "green door", "红门": "red door"]
        let quotes = CharacterSet.whitespacesAndNewlines.union(CharacterSet(charactersIn: "\"'“”‘’"))
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive),
                  let match = regex.firstMatch(in: instruction, range: NSRange(instruction.startIndex..., in: instruction)),
                  let first = Range(match.range(at: 1), in: instruction), let second = Range(match.range(at: 2), in: instruction) else { continue }
            let source = String(instruction[first]).trimmingCharacters(in: quotes)
            let target = String(instruction[second]).trimmingCharacters(in: quotes)
            guard !source.isEmpty, !target.isEmpty else { return nil }
            return (aliases[source] ?? source, aliases[target] ?? target)
        }
        return nil
    }

    static let completionIntroduction = "现在已经使用之前收集的82个语料，帮你生成了一篇摄影教程，读读看有什么收获？如果想换另一种方式学习，尽管和我说！"
    static let completionFollowUp = "想换一种学习方式，或调整学习内容，随时告诉我。"
    static let quizSuggestion = "出几道题考考我"
    static let simplifySuggestion = "让文章的生词更少一些"

    private func appendCompletion() {
        let text = article.theme.lowercased().contains("photo") ? Self.completionIntroduction
            : "学习内容已经准备好了，读读看有什么收获？如果想换另一种方式学习，尽管和我说！"
        append(text, role: "assistant")
        completionMessageID = messages.last?.id
    }

    var suggestions: [String] {
        guard canEditLocally, messages.last?.id == completionMessageID else { return [] }
        return [Self.quizSuggestion, Self.simplifySuggestion]
    }

    private static func requestsSimplerVocabulary(_ instruction: String) -> Bool {
        [simplifySuggestion, "减少生词", "更简单的词", "simpler vocabulary", "fewer unfamiliar words"]
            .contains(where: instruction.lowercased().contains)
    }

    func reply(to question: String) {
        guard isComplete, !isRewinding else { return }
        if Self.requestsSimplerVocabulary(question) {
            _ = regenerate(from: .writing, instruction: question)
            return
        }
        messages.append(.init(id: UUID().uuidString, role: "user", text: question))
        let lower = question.lowercased()
        let response: String
        if practice.choices.indices.contains(where: { lower.contains("\n" + practice.label(at: $0).lowercased() + ".") }) {
            let answer = practice.label(at: practice.answer)
            response = lower.contains("\n" + answer.lowercased() + ".")
                ? "答对了！" + practice.explanation
                : "正确答案是 \(answer)。" + practice.explanation
        } else if question == practice.question || lower.contains("quiz") || lower.contains("考") || lower.contains("做题") {
            response = practice.prompt
        } else if let section = article.sections.first(where: { $0.heading.caseInsensitiveCompare(question) == .orderedSame }) {
            response = section.translation.isEmpty
                ? "这节对应的英文原文是：\n\n\(section.text)\n\n可以选中想深入了解的部分，引用到对话中继续学习。"
                : section.translation
        } else {
            response = Self.completionFollowUp
        }
        messages.append(.init(id: UUID().uuidString, role: "assistant", text: response))
    }
}

extension ArticleGenerationPreview {
    enum LocalTarget: Equatable {
        case title, summary, heading(Int), paragraph(section: Int, paragraph: Int), image
        var label: String {
            switch self {
            case .title: return "文章标题"
            case .summary: return "文章简介"
            case .heading(let index): return "第 \(index + 1) 节标题"
            case .paragraph(let section, _): return "第 \(section + 1) 节文本"
            case .image: return "文章配图"
            }
        }
    }

    struct LocalSelection: Equatable {
        let target: LocalTarget
        let original: String
        // NSTextView offsets are UTF-16, never Character offsets.
        let range: NSRange
        var quote: String {
            guard target != .image, let range = Range(range, in: original) else { return original }
            return String(original[range])
        }
    }

    struct LocalEdit: Identifiable {
        let id: String
        let selection: LocalSelection
        let comment: String
        let imageAsset: String?
    }

    func localContent(_ target: LocalTarget) -> String? {
        switch target {
        case .title: return article.title
        case .summary: return article.summary
        case .image: return imageAsset
        case .heading(let index):
            return article.sections.indices.contains(index) ? article.sections[index].heading : nil
        case .paragraph(let section, let paragraph):
            guard article.sections.indices.contains(section) else { return nil }
            let paragraphs = article.sections[section].text.components(separatedBy: "\n\n")
            return paragraphs.indices.contains(paragraph) ? paragraphs[paragraph] : nil
        }
    }

    @discardableResult
    func quoteSelection(_ selection: LocalSelection) -> Bool {
        guard canEditLocally, isCurrentSelection(selection) else { return false }
        quotedSelection = selection
        localSelection = nil
        return true
    }

    func removeQuote() { quotedSelection = nil }

    /// The composer keeps the original target and UTF-16 range separate from the instruction.
    @discardableResult
    func regenerateQuotedSelection(comment: String) -> Bool {
        guard let selection = quotedSelection,
              regenerateSelection(selection, comment: comment) else { return false }
        quotedSelection = nil
        return true
    }

    private func isCurrentSelection(_ selection: LocalSelection) -> Bool {
        guard localContent(selection.target) == selection.original else { return false }
        if selection.target == .image { return true }
        guard selection.range.length > 0, let range = Range(selection.range, in: selection.original),
              selection.original.indices.contains(range.lowerBound),
              range.upperBound == selection.original.endIndex || selection.original.indices.contains(range.upperBound)
        else { return false }
        return !selection.quote.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    @discardableResult
    func regenerateSelection(_ selection: LocalSelection, comment: String) -> Bool {
        let comment = comment.trimmingCharacters(in: .whitespacesAndNewlines)
        guard canEditLocally, !comment.isEmpty, comment.count <= 2000,
              isCurrentSelection(selection) else { return false }
        let edit = LocalEdit(id: UUID().uuidString, selection: selection, comment: comment,
                            imageAsset: selection.target == .image ? imageAsset : nil)
        localEdit = edit
        localImageElapsed = .zero
        localSelection = nil
        localEditComments[edit.id] = edit
        messages.append(.init(id: edit.id, role: "user", text: selection.target.label + "\n“" +
            (selection.target == .image ? imageCaption : selection.quote) + "”\n\n" + comment))
        invalidateRun()
        return true
    }

    func cancelLocalEdit() {
        guard localEdit != nil else { return }
        localEdit = nil
        localImageElapsed = .zero
        invalidateRun()
        append("已取消局部修改，原内容已保留。", role: "assistant")
    }

    private func commitLocalEdit(_ edit: LocalEdit) {
        defer { localEdit = nil; localImageElapsed = .zero }
        let selection = edit.selection
        guard localContent(selection.target) == selection.original else {
            append("这部分内容已发生变化，请重新选取后再修改。", role: "assistant")
            return
        }
        if selection.target == .image {
            let note = edit.comment.lowercased()
            let replacement: (String, String)?
            if ["人像", "portrait"].contains(where: note.contains) {
                replacement = ("ArticleLeadingLinesPortraitWall", "Notice how the wall leads your attention toward the person.")
            } else if ["树", "forest", "tree"].contains(where: note.contains) {
                replacement = ("ArticleLeadingLinesOaks", "Follow the avenue of trees toward the light.")
            } else if ["建筑", "building", "architecture"].contains(where: note.contains) {
                replacement = ("ArticleLeadingLinesBuilding", "Architectural lines give the eye a route through the frame.")
            } else { replacement = nil }
            guard let replacement else {
                append("当前本地演示支持建筑、人像和树林配图。原图已保留，可以重新选取并补充要求。", role: "assistant")
                return
            }
            guard replacement.0 != imageAsset else {
                append("当前已是这张配图。可以试试换成人像、建筑或树林。", role: "assistant")
                return
            }
            imageAsset = replacement.0
            imageCaption = replacement.1
        } else {
            guard let replacement = Self.localReplacement(selection.quote, comment: edit.comment),
                  replacement != selection.quote, let range = Range(selection.range, in: selection.original) else {
                append("这条要求暂未改变选中的文本。本地演示支持“把 X 换成 Y”、“写短一点”，或“改为：新的文本”。原文已保留。", role: "assistant")
                return
            }
            var updated = selection.original
            updated.replaceSubrange(range, with: replacement)
            switch selection.target {
            case .title: article.title = updated
            case .summary: article.summary = updated
            case .heading(let index): article.sections[index].heading = updated
            case .paragraph(let section, let paragraph):
                var paragraphs = article.sections[section].text.components(separatedBy: "\n\n")
                paragraphs[paragraph] = updated
                article.sections[section].text = paragraphs.joined(separator: "\n\n")
            case .image: break
            }
            sectionCharacters = article.sections.map { Array($0.text) }
            characterCounts = sectionCharacters.map(\.count)
            visibleCharacters = totalCharacters
            article.wordCount = article.sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count
        }
        article.revision += 1
        // Keep local corrections when a later generation stage is rerun.
        for stage in Step.allCases where checkpoints[stage] != nil {
            let affectedStage: Step
            switch selection.target {
            case .title, .summary, .heading: affectedStage = .outline
            case .paragraph: affectedStage = .writing
            case .image: affectedStage = .images
            }
            if stage.rawValue > affectedStage.rawValue {
                guard var saved = checkpoints[stage] else { continue }
                switch selection.target {
                case .title: saved.article.title = article.title
                case .summary: saved.article.summary = article.summary
                case .heading(let index):
                    if saved.article.sections.indices.contains(index) {
                        saved.article.sections[index].heading = article.sections[index].heading
                    }
                case .paragraph(let section, _):
                    if saved.article.sections.indices.contains(section) {
                        saved.article.sections[section].text = article.sections[section].text
                        saved.article.wordCount = saved.article.sections.map(\.text).joined(separator: " ").split(whereSeparator: \.isWhitespace).count
                    }
                case .image: saved.imageAsset = imageAsset; saved.imageCaption = imageCaption
                }
                saved.article.revision = article.revision
                checkpoints[stage] = saved
            }
        }
        append(selection.target == .image ? "配图已更新。" : "已更新选中的文本。", role: "assistant")
    }

    private static func localReplacement(_ text: String, comment: String) -> String? {
        for prefix in ["改为：", "改为:", "替换为：", "替换为:", "rewrite as:", "replace with:"] {
            if comment.lowercased().hasPrefix(prefix) {
                let value = String(comment.dropFirst(prefix.count)).trimmingCharacters(in: .whitespacesAndNewlines)
                return value.isEmpty ? nil : value
            }
        }
        if let (source, target) = replacement(comment) {
            return text.replacingOccurrences(of: source, with: target, options: .caseInsensitive)
        }
        if ["shorter", "concise", "写短", "简短", "精简"].contains(where: comment.lowercased().contains) {
            if let end = text.firstIndex(where: { ".!?。！？".contains($0) }), text.index(after: end) < text.endIndex {
                return String(text[...end])
            }
            let words = text.split(whereSeparator: \.isWhitespace)
            guard words.count > 5 else { return nil }
            return words.prefix(max(4, words.count * 2 / 3)).joined(separator: " ") + "."
        }
        return nil
    }
}
